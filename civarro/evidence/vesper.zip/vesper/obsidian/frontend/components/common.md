---
tags: [frontend, stable]
updated: 2026-05-21
---

# Catalog — Common Components

Files in `src/components/common/` — shared infrastructure that may depend on
providers. Conventions: [[component-conventions]].

## SiteHeader — `site-header.tsx`

The fixed, site-wide header from the Figma hero — a centred glass pill bar
(wordmark left, primary nav centred, Contact Us right). Rendered **once in the
root layout** (`position: fixed`, `z-50`) so it floats above every section on
scroll. Nav uses `next/link`; **above 1024px** sizes are Figma pixels in `vw`
(÷14.4) so the bar scales linearly with viewport width. See ADR-0025 and
[[webgl-scene]].

Below 1024px the links move into [[#MobileNav — `mobile-nav.tsx`]] — a `vw`-sized
pill is 14px tall on a phone, and four links plus a button do not fit that row at
any legible size (ADR-0029). This stays a **Server Component**; only the toggle is
a client leaf.

## MobileNav — `mobile-nav.tsx`

`"use client"`. The header's nav below 1024px: a burger toggle whose two bars
animate into an ✕, and a panel that drops out from under the bar carrying the same
links plus Contact Us.

- **Spring, not a CSS transition** — the project has no CSS motion (ADR-0002). The
  panel and both toggle bars run off `SPRING_SOFT` (`lib/springs/config.ts`).
- **Unmounts on `onRest`**, rather than lingering at `opacity: 0` — a fixed,
  blurred panel left in the tree keeps compositing over the WebGL canvas for
  nothing. This is the sanctioned `AnimatePresence` replacement: a spring plus an
  unmount on rest.
- `aria-expanded` / `aria-controls`, and **Escape closes it** — a menu the keyboard
  cannot dismiss is a trap.

## Cookie — `Cookie/`

Self-contained cookie consent system — a bottom-right **banner** plus a full
category **preferences modal**. No third-party library (the old
`react-cookie-consent` dependency was removed). Lives in `src/components/common/Cookie/`.

| File | Role |
|------|------|
| `Cookie.tsx` | Mount component — hydrates the store, renders banner + modal |
| `LazyCookie.tsx` | `next/dynamic` `ssr:false` wrapper — keeps cookie JS out of first-load |
| `CookieBanner.tsx` | Bottom-right consent banner |
| `CookiePreferencesModal.tsx` | Category preferences dialog with per-category toggles |
| `CookieButton.tsx` | Local button primitive — `primary` / `secondary` variants, sprung via [[components/ui\|PressableButton]] (ADR-0031) |
| `cookieStore.ts` | Zustand store + `localStorage` persistence |
| `index.ts` | Barrel exports — `Cookie`, `LazyCookie`, `useCookieStore`, `CookieConsent` |

**Mounting** — the root layout renders `<LazyCookie />` inside `ScrollLayout`:
```tsx
import { LazyCookie } from "@/components/common/Cookie";
```

**State** — `useCookieStore` (Zustand). `consent` is `null` until the user decides;
the banner shows only after hydration confirms `consent === null`. Persisted to
`localStorage` under key `cookie-consent-v1`. Three categories: `necessary`
(always on), `analytics`, `marketing`.

**Styling & motion** — ported to the project stack: Tailwind v4 with the
`background` / `foreground` design tokens (dark-mode adaptive, no hardcoded hex),
and `@react-spring/web` for all motion — `useTransition` drives the banner and
modal mount/unmount, `useSpring` drives the toggle knob. No CSS transitions.
The modal locks scroll through the Lenis [[smooth-scroll|scroll store]]
(`useScroll.stop()`), not `body` overflow.

> [!note] `#todo`
> The privacy-policy link points to `/privacy-policy` — that route does not exist
> yet. Placeholder consent copy should be reviewed before launch.

## Grid — adaptive scaling (`grid/`)

The **adaptive scaling grid** keeps a rem-based layout proportional across every
viewport by scaling the root (`<html>`) font-size. Design in `rem` once, and the
whole UI scales as one unit. Lives in `src/components/common/grid/`.

| File | Role |
|------|------|
| `grid.config.ts` | Breakpoints + `FONT_BASE` — the single source of truth for the grid |
| `adaptive-grid.tsx` | `<AdaptiveGrid>` client component — drives the scale-up, renders `null` |
| `index.ts` | Barrel exports — `AdaptiveGrid`, `GRID_BREAKPOINTS`, … |

**How it works** — the grid governs the range **1024px and up** (ADR-0029):

- **Scale down** (1024px ≤ viewport ≤ 1920px) — `vw`-based `html { font-size }`
  media queries in `globals.css`. At each breakpoint's design base width the root
  font-size resolves to 16px; between breakpoints it tracks the viewport.
- **Scale up** (viewport > 1920px) — the `<AdaptiveGrid>` component sets an
  inline `html` font-size at runtime via [[hooks|`useAdaptiveGrid`]], so the
  design keeps growing (damped by `coef`) on large displays.

The `globals.css` media queries and `grid.config.ts` describe the same
breakpoints — **keep them in sync** (formula: `font-size = 16 * 100 / baseWidth vw`).

> [!warning] The ladder stops below 1024px — the grid does not run there
> Proportional scaling is right when the page is one artboard being resized. It is
> wrong when the page is a *different* layout: a shrinking root would just carry
> the desktop's type down with it, and the desktop's body copy is 4px on a phone.
>
> So `globals.css` pins `html { font-size: 16px }` under 1024px and the tablet /
> phone layouts are authored in `rem` against that. `grid.config.ts` still lists
> its 1024 and 640 rungs, but **they no longer have matching `globals.css` media
> queries** — they describe the design bases those ranges were laid out at, not a
> scaling rule. See [[design-system]] and ADR-0029.

**Mounting** — the root layout renders `<AdaptiveGrid />` inside `ScrollLayout`:
```tsx
import { AdaptiveGrid } from "@/components/common/grid";
```
Mount it once. Props: `baseWidth` (defaults to the largest breakpoint) and
`coef` (0–1 scale-up damping, default `0.6666`).

> [!note]
> This replaced a `styled-components`-based scaling system that was dropped into
> `common/` — see [[decisions-log]] ADR-0008. `styled-components` is **not** a
> project dependency; the scale-down CSS lives in `globals.css` per [[design-system]].

## ReducedMotion — `reduced-motion.tsx`

`<ReducedMotion>` — a client leaf that calls react-spring's `useReducedMotion()`.
It watches the `prefers-reduced-motion` media query and toggles react-spring's
global `skipAnimation`, so every spring — and `spring-text-engine` — jumps to its
end state instead of animating. Renders `null`; mounted once in the root layout.
See [[animation-system]] and [[seo-metadata]].

## Skeleton loaders

Three skeleton components for `loading` states of async-data components — every
async component must mirror its final layout with one of these
(see [[component-conventions]]).

| Component | File | For |
|-----------|------|-----|
| `<SkeletonImage>` | `skeleton-image.tsx` | image placeholders |
| `<SkeletonLoader>` | `skeleton-loader.tsx` | generic block placeholders |
| `<SkeletonVideo>` | `skeleton-video.tsx` | video placeholders |

> [!note]
> `components/ui/` (design-system primitives) does not exist yet — create it when
> the first primitive is added. See [[folder-structure]].

## Related

[[component-conventions]] · [[components/animation-springs]]
