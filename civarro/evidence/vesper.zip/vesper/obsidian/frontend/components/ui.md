---
tags: [frontend, ui, stable]
updated: 2026-07-12
---

# Catalog — UI Primitives

Files in `src/components/ui/` — design-system primitives. Stateless, no provider
dependencies. Conventions: [[component-conventions]].

## `<PressableLink>` / `<PressableButton>` / `usePressable` — `pressable.tsx`

**Every interactive control on the site goes through one of these.** They give a
control its hover *and* press response, sprung, from a preset in
`lib/springs/interaction.ts`. The interaction language itself — and why none of it
scales — is documented in [[design-system]].

```tsx
<PressableLink href="/#contact" interaction={GHOST} className="border px-4">
  Contact Us
</PressableLink>
```

`interaction` is a plain object, so it crosses the server/client boundary — a
Server Component (like `SiteHeader`) can render these directly.

**`usePressable(interaction)` → `{ style, bind }`** is the escape hatch for when the
element the pointer meets is *not* the element that should react. Spread `bind` on
the trigger, put `style` on the surface:

```tsx
const { style, bind } = usePressable(SOLID_CTA);
<Link {...bind}>                       {/* the whole link is the hit area */}
  <animated.span style={style}>…</animated.span>   {/* only the block is filled */}
  <img src="/assets/hero/send-icon.svg" />         {/* …but this is inside it */}
</Link>
```
That is exactly `views/home/send-request.tsx`. Springing the span alone would leave
the arrow inert, so the button would fail to light up from a third of its own hit
area.

> [!note] Why not `<Hover>`?
> The engine's [[components/animation-springs|`<Hover>`]] covers mouse enter/leave
> only, and it styles its own wrapper. It is still the right tool for a decorative
> hover on a non-control. For a **control**, `usePressable` adds the press state, the
> `pointerType` guard (a touch tap fires `pointerenter` with no `pointerleave` to
> follow, so a `<Hover>`-based control lights up and stays lit on a phone), the
> focus-visible hover, and the shared focus ring.

Every pressable carries `focus-visible:outline-signal`. The hover is a colour shift,
which is invisible to a keyboard user mid-tab — and several of these sit on a live
WebGL canvas, where the UA default outline disappears entirely.

## `<Button>` — `button.tsx`

The generic call to action. Renders an `<a>` via `next/link` when `href` is set,
a `<button>` otherwise — never a `div` with a click handler.

| Prop | Meaning |
|------|---------|
| `href` | renders a link instead of a button |
| `onClick` / `type` | button behaviour |
| `className` | appended to the base classes |

Hover and press are springs via `PressableButton`/`PressableLink` (`GHOST`), and
they move **colour, not size**. This used to wrap the button in a `<Hover>` that
scaled it to `1.03` — removed: a control that grows under the cursor is motion added
for its own sake, and it shoulders whatever sits next to it.

Border and background colours come from the spring, so the base class list carries
width and style only — an inline spring value beats a `border-*` utility anyway, and
declaring both would be a lie in the markup. The rest is glass: `shadow-glass`,
`backdrop-blur-glass`, `rounded-card`. Those are tokens; see [[design-system]].

## Adding a primitive

Stateless, typed `interface ...Props`, named export, under ~150 lines. Anything
that needs a provider belongs in `components/common/` instead.

## Related

[[component-conventions]] · [[design-system]] · [[animation-system]] ·
[[components/common]] · [[components/animation-springs]]
