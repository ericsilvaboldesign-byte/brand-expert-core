---
tags: [frontend, design-system, stable]
updated: 2026-05-22
---

# Design System — Tailwind v4

Styling uses **Tailwind CSS v4**, configured entirely in CSS. There is **no
`tailwind.config.js`**. ADR: [[decisions-log]] ADR-0004.

## Where config lives

`src/app/globals.css` is the single config file:

```css
@import "tailwindcss";

:root {
  --background: #ffffff;
  --foreground: #171717;
}

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --font-sans: var(--font-onest);
}
```

Extra CSS layers can be split into `src/style/index.css` and imported.

## Design tokens

All colours, spacing, font sizes, radii, and shadows are **tokens** declared under
`:root` (raw values) and `@theme inline` (Tailwind bindings).

Once a token is in `@theme`, it becomes a utility automatically:

| Token | Generated utilities |
|-------|--------------------|
| `--color-brand` | `bg-brand`, `text-brand`, `border-brand` |
| `--radius-card` | `rounded-card` |
| `--spacing-section` | `pt-section`, `mt-section`, … |

> [!important] The token rule
> **Never** hardcode hex values, pixel spacing, or named colours in `className` or
> inline styles. If a value doesn't exist as a token, **add it to `globals.css`
> first** — with a comment noting where it came from (e.g. a Figma frame).

## CSS layers

Every custom style goes inside a layer — never outside one:

```css
@layer base {        /* element resets & defaults: h1, p, a … */ }
@layer components {  /* pseudo-elements & 3rd-party overrides only — see below */ }
@layer utilities {   /* single-purpose helpers: .scrollbar-none … */ }
```

## Where a style goes (ADR-0012)

`globals.css` is **not** a place to park component styles — it holds tokens and
base resets and stays a few hundred lines forever. Follow this order; the first
match wins:

| Situation | Goes where |
|-----------|-----------|
| One-off styling | Tailwind utilities in `className` — nothing in CSS |
| Repeated pattern with markup / structure / props | a **React component** in `components/ui/` |
| Repeated *pure-utility* combo, no structure | a Tailwind v4 `@utility` |
| Pseudo-elements, 3rd-party DOM overrides, complex selectors | `@layer components` — the genuine exceptions |
| A new colour / spacing / radius value | a **token** in `:root` + `@theme` |

> [!important] The default answer to "this looks repeated" is a **React
> component**, not a CSS class. An eyebrow label with a `::before` dot is an
> `<Eyebrow>` component — not a `.label-eyebrow` global class. `@layer
> components` is for what utilities and components genuinely *cannot* express.

There are **no CSS Modules** in this project — utilities + components cover
every case (motion is spring-based, so there are no keyframes to co-locate).

## Surfaces

| Token | Use |
|-------|-----|
| `--void` | the scene backdrop, and the loader curtain |
| `--surface` | opaque content plane — now unused; the closing sections went transparent over the shader (ADR-0026 update) |
| `--surface-raised` | now unused — was the dev colour panel's surface (removed 2026-07-12) |

`--surface` is a **different** purple from `--void` on purpose: content below the
scene should read as a separate plane, not as more sky. It is opaque — the fixed
canvas must not show through, and that is also what lets the frame gate stop
rendering the scene down there. See [[webgl-scene]].

## Current theme state

The starter ships a **minimal** theme: just `background` / `foreground` and the
Onest font, with a dark-mode override via `@media (prefers-color-scheme: dark)`.
The `@layer base/components/utilities` blocks are empty — fill them per project.

## Typography

Faces loaded in `src/app/layout.tsx`:

| Token | Face | Used for |
|-------|------|----------|
| `--font-general` | **General Sans** (self-hosted, 300/400/500) | the Figma face — every title, body, header, CTA |
| `--font-tag` | **Mulish** (`next/font/google`) | eyebrows / tag rows / stat labels |
| `--font-sans` | **Onest** (`next/font/google`) | app default; only the Cookie components use it |
| `--font-display` | aliases `--font-general` | headings |
| `--font-hud-mono` | system mono stack | `ui/button.tsx` only (the dev colour panel that also used it is gone) |

> [!note] Open Sans is gone
> `--font-display` used to be **Open Sans**, loaded at three weights and referenced
> by **nothing** — the Figma redesign moved every heading to General Sans and the
> font stayed behind in the layout. Removed 2026-07-12; the token now aliases
> `--font-general`. (It had itself replaced Orbitron, whose techno look read as
> costume at hero sizes — hence `--tracking-title: -0.022em`, negative, where the
> old face wanted positive.)

## Responsive — two regimes, split at 1024px (ADR-0029)

This is the single most important thing to know before sizing anything.

**≥1024px — the artboard.** The page is the 1440-wide Figma frame, scaled
proportionally. Sections are measured in **`vw`** (Figma pixels ÷ 14.4) with
elements absolutely placed at their design offsets, and the [[components/common|adaptive
grid]] scales the root font-size to match. Pixel-faithful at any desktop width.

**<1024px — an authored layout.** The `vw` ladder stops: `html` is pinned to
`16px`, `rem` means real pixels again, and each section is a purpose-built stack.
Carrying the artboard down does not work — body copy at `1.111vw` is **4px on a
360px phone**, and the header pill is 14px tall.

Both live in **one DOM tree**; the difference is CSS:

| Variant | Media query | Use for |
|---------|-------------|---------|
| *(none)* | — | the ≥1024 `vw` artboard |
| `max-lg:` | `width < 64rem` (1024) | tablet **and** phone |
| `max-sm:` | `width < 40rem` (640) | phone only (wins — Tailwind orders `max-*` descending) |

These land on true 1024/640 pixel boundaries: `rem` inside a media query is always
the *initial* 16px root, never the scaled one. They also match the scene's own
tiers in `adaptive.ts`, so DOM and WebGL step down together.

> [!warning] `TextEngine` sets `position` inline — only `!` can beat it
> The engine hardcodes `position` as an **inline style**, so a plain `max-lg:static`
> class loses to it and the copy stays absolutely placed on a phone. Use Tailwind's
> important modifier — `max-lg:static!` → `position: static !important` — to pull it
> back into flow. See `hero.tsx`.

> [!warning] Tailwind scans raw file text, including comments
> Writing a class name in a JSDoc comment keeps its rule in the stylesheet even if
> no element uses it. Describe removed classes in prose, not as `code`.

## Interaction language — hover & press

`src/lib/springs/interaction.ts` is the whole vocabulary. Every control on the site
picks a preset from it and renders through
[[components/ui|`<PressableLink>` / `<PressableButton>` / `usePressable`]]. Three
states, layered: `hover` merges over `rest`, `press` merges over both, so a preset
only declares what actually changes.

| Preset | Where | Response |
|--------|-------|----------|
| `SOLID_CTA` | Send Request | white block → **signal mint** |
| `GHOST` | header / mobile "Contact Us", `<Button>`, modal close | border firms to white, surface takes light |
| `GHOST_SIGNAL` | the footer's submit | same, in the accent |
| `NAV_LINK` | header + mobile nav | white ink → signal mint |
| `MUTED_LINK` | footer link columns | white/70 → white |
| `QUIET` | wordmark, burger | opacity |
| `CARD_ROW` | FAQ accordion rows | tints with **ink** — it sits on the white card |
| `SOLID_INVERSE` / `GHOST_INVERSE` | cookie banner | as above, on a light surface |
| `TEXT_LINK` | 404, error, inline legal | opacity |

> [!important] Nothing scales
> A control that grows under the cursor is a tell that the motion was added for its
> own sake — and it shoulders whatever sits beside it. These respond in **colour and
> weight**: the surface takes light, the border firms up, the ink shifts to the
> accent. The box never moves, so nothing reflows and nothing wobbles against the
> WebGL scene behind it.

> [!warning] The interaction colours are literals, not `var(--token)`
> react-spring animates a colour by interpolating its **channels**, which it can only
> do between two *parsed* colours. `var(--chalk)` is an opaque string to it, so a
> spring between two custom properties does not animate — it snaps on the first
> frame, which is exactly the CSS-transition-shaped result the project bans.
>
> So `interaction.ts` holds hex/rgba literals, on the same exemption
> `lib/scene/constants.ts` takes for the WebGL palette and for the same reason: these
> are values an *interpolator* consumes, not styles a stylesheet resolves. **Keep them
> in step with the tokens above.**

> [!note] A control's colours belong to the spring, not to a utility
> Where a preset drives `backgroundColor` / `borderColor` / `color`, the element's
> class list carries width and style only (`border`, not `border-white/50`). An inline
> spring value beats a utility regardless, so declaring both would just be a lie in
> the markup. Use `bg-current` for a dot or bar that should follow the sprung ink.

Focus rings are deliberately **not** sprung — a focus indicator that eases in is a
focus indicator that is briefly wrong.

## Styling rules

- Use utilities in JSX `className`; keep class strings short and readable.
- Every interactive control renders through a **pressable** (above). Never a bare
  `hover:` utility — it snaps, and it would be the only control on the page that does.
- Extract a repeated pattern to a **React component** — not a `@layer
  components` class. See *Where a style goes* above (ADR-0012).
- Responsive: the desktop artboard is the base, with `max-lg:` / `max-sm:`
  overrides below it (see above) — **not** mobile-first `sm:` / `md:` / `lg:`.
- Dark mode: `dark:` prefix or token overrides in a `prefers-color-scheme` block.
- No inline `style` except for dynamic values (e.g. spring-animated values).

## Related

[[component-conventions]] · [[animation-system]] · [[new-page]]
