---
tags: [frontend, animation, stable, do-not-modify]
updated: 2026-05-21
---

# Animation System

The core of this starter. **Every motion is spring-based** via `@react-spring/web`.
CSS transitions, CSS keyframes, and `framer-motion` are **banned**. ADR:
[[decisions-log]] ADR-0002.

> [!warning] #do-not-modify
> `src/components/animation/springs/` and `src/hooks/animation/` are the animation
> engine. Treat them as a vendored library — **consume them, don't edit them
> without explicit sign-off**. One authorized performance refactor has been made;
> see [[decisions-log]] ADR-0009.

## Shared render loop (ticker)

Every per-frame animation hook subscribes to **one** app-wide
`requestAnimationFrame` loop — `src/lib/animation/ticker.ts` (`subscribeToTicker`).
A page with N scroll-driven components runs **one** rAF, not N. The loop is
reference-counted: it starts on the first subscriber and stops when the last one
unmounts, so an idle page costs nothing.

- `useLoop` (and everything built on it — `useLoopInView`, `useResizeLoop`,
  `useSpringTrigger`, `useProgressTrigger`, `<AdaptiveGrid>`) goes through the
  ticker. Each subscriber keeps its own `framerate` throttle.
- **Lenis** goes through it too — smooth scroll is not a separate rAF loop.
- The scene's `FrameGate` drives `invalidate()` from it. See [[webgl-scene]].
- Window dimensions (`useWindowWidth` / `useWindowHeight` / `useWindowSize`)
  share **one** debounced `resize` listener via a `useSyncExternalStore` store.

`src/lib/animation/ticker.ts` is **not** `#do-not-modify` — it is the supported
extension point for loop-based animation.

### Run order (`TICKER_PRIORITY`)

Subscribers run in priority order, lowest first. There is one rule that matters:
**Lenis writes the scroll position, and everything else reads it back** with
`getBoundingClientRect`. It subscribes at `TICKER_PRIORITY.scroll` (`-100`) so the
write always lands before the reads; everything else defaults to `0`. Left to
registration order, the triggers could spend the whole frame measuring the
*previous* frame's scroll.

### The frame gate needs a jitter tolerance

> [!warning] `elapsed <= interval` drops every other frame
> A subscriber asking for 60 fps has an interval of `1000/60 = 16.6667` ms, and a
> 60 Hz display delivers rAF timestamps `16.6667` ms apart. A strict `<=` test
> rejects a frame that arrived **exactly on time** — and a rejected frame does not
> advance `last`, so the next one is measured across a doubled gap and always
> passes. The subscriber alternates render / skip: **39 fps at a 33 / 16.7 ms
> cadence**, with zero jitter, on a perfect display.
>
> The gate therefore compares against `getFramerate() - JITTER_MS` (1 ms). That is
> far below the 16.7 ms spacing of the next real frame, so it cannot let a 30 fps
> subscriber steal a frame — it only stops the gate rejecting frames it meant to
> accept. Do not "simplify" it back. [[decisions-log]] ADR-0030.

## The components

All live in `src/components/animation/springs/` and accept a `tag` prop so they
render the semantically correct HTML element. Full catalog:
[[components/animation-springs]].

| Component | Trigger | Use for |
|-----------|---------|---------|
| `<Inview>` | element enters viewport | fade/slide-in reveals |
| `<Spring>` | mount / enabled flag | unconditional spring animation |
| `<SpringTrigger>` | scroll progress | parallax, scrub, scroll-toggled motion |
| `<ProgressTrigger>` | scroll progress | raw 0–1 progress callback (no animation) |
| `<Hover>` | mouse enter/leave | hover effects (off on mobile) |
| `<Handle>` | content change | smooth enter/exit on children swap |
| `<AnimatedVarTextTag>` | — | low-level `animated[tag]` primitive |

For **text**, do not use these — use [[text-engine]].

## Choosing the right primitive

| Need | Component |
|------|-----------|
| Element fades/slides in when scrolled into view | `<Inview from={} to={} mode="once">` |
| Element moves continuously with scroll (parallax) | `<SpringTrigger mode="scrub">` |
| Element snaps to a state at a scroll point | `<SpringTrigger mode="toggle">` |
| Mouse hover animation | `<Hover from={} to={}>` |
| Just a 0–1 scroll progress value | `<ProgressTrigger onChange={}>` |
| Heading / copy reveal | `<TextEngine>` → [[text-engine]] |

## Common props

| Prop | Meaning |
|------|---------|
| `tag` | HTML element to render (`section`, `h1`, `div`…) — use the semantic one |
| `from` / `to` | spring start / end states — animatable CSS values only |
| `config` | `@react-spring/web` `SpringConfig` (`tension`, `friction`, …) |
| `mode` | trigger behaviour — varies per component (see below) |
| `delayIn` / `delayOut` | ms delay before enter / exit |
| `disableOnMobile` | respect the global mobile-disable config |
| `className` / `innerClassName` | Tailwind classes (kept separate from spring `style`) |

> Never pass Tailwind class names into `from`/`to`. Spring values are numbers or
> unit strings; classes go on `className`.

## Modes

- **`<Inview>` / `<Spring>`:** `"once"` (play once, stay), `"always"` (reverse on
  leave), `"forward"` (only on downward scroll).
- **`<SpringTrigger>`:** `"scrub"` (interpolate with scroll), `"toggle"` (snap at
  trigger point).

## Trigger positions (`start` / `end`)

Scroll components use a GSAP-style `TriggerPos` string:
`"<element-edge> <viewport-edge>"`, e.g. `"top bottom"`, `"center center"`,
`"bottom top-=100"`. Full grammar in [[text-engine]] (shared format).

## When the catalog components don't fit

The components above cover viewport-, scroll-, and hover-triggered motion. Two
cases fall outside them. Both still use `@react-spring/web` directly — that is
the rule (spring-based motion), not an exception to it.

**Infinite ambient loops** — a rotating mark, a pulsing light, a nudging arrow.
There is no `<Spring loop>`; use `useSpring` with `loop`:

```tsx
const { opacity } = useSpring({
  from: { opacity: 1 },
  to: { opacity: 0.35 },
  loop: { reverse: true },              // `loop: true` restarts instead
  config: { duration: 700, easing: easings.easeInOutSine },
});
<animated.span style={{ opacity }} />
```

Reach for this **only** when replacing a CSS `@keyframes` — see
`views/home/hud/hud-motion.tsx`. Need a CSS `cubic-bezier()` curve?
`easings` has no bezier factory; use `utils/animation/cubic-bezier.ts`.

**Continuous particle fields** — the loader's star-fall, the WebGL scene — are a
render loop, not a transition between two states, so they are not springs. They
subscribe to `lib/animation/ticker.ts` (the supported extension point) rather
than starting their own `requestAnimationFrame`. This is the *only* sanctioned
non-spring motion; do not use it for UI transitions.

**Binding to a clock that lives outside React** — e.g. a scroll timeline or an
intro spring read per-frame by a render loop. Hold a bare `SpringValue` and
interpolate it; do not mirror it into React state, which would re-render on every
frame:

```tsx
const progress = useMemo(() => new SpringValue(0), []);
useEffect(() => sceneTimeline.subscribe((v) => progress.set(v)), [progress]);
const opacity = useMemo(
  () => progress.to({ range: [0, 1, 2], output: [0, 1, 0], extrapolate: "clamp" }),
  [progress],
);
```

`.set()` is instant (correct for scroll-scrubbed values); `.start()` springs to
the target. See [[webgl-scene]].

## Global config

`src/lib/springs/config.ts`:

```ts
export const springsConfig = {
  mobileWidth: 768,
  disableOnMobile: {
    hover: true,        // always — no hover on mobile
    inview: false,
    spring: false,
    springtrigger: false,
  },
};
```

`isMobileDisabled(value, viewportWidth?)` checks the viewport against `mobileWidth`.
Pass a React-tracked width (e.g. from `useWindowWidth()`) as the second argument so
the check re-evaluates on resize; it falls back to `window.innerWidth` when omitted.
Components opt in per-instance via `disableOnMobile`. **Never disable animation
globally** — toggle per component when an animation hurts mobile UX.

The same file exports **`SPRING_SOFT`** — the house spring for UI chrome (menus,
toggles, accordions). Quick enough to read as a response, damped hard enough not to
ring. Reach for it wherever a component would otherwise want a CSS transition, which
this project does not have.

## Interaction springs (hover / press)

`src/lib/springs/interaction.ts` is a separate vocabulary, for **controls**: how every
button, link and row answers a pointer. Presets (`SOLID_CTA`, `GHOST`, `NAV_LINK`,
`CARD_ROW`, …) are consumed by
[[components/ui|`<PressableLink>` / `<PressableButton>` / `usePressable`]]. Nothing in
it scales. Full table and rationale: [[design-system]], [[decisions-log]] ADR-0031.

## Underlying hooks

The components are built on `src/hooks/animation/` — also `#do-not-modify`. See
[[hooks]] for the catalog.

## Related

[[text-engine]] · [[components/animation-springs]] · [[data-flow]] · [[new-page]]
