---
tags: [frontend, webgl, scene, stable]
updated: 2026-07-10
---

# WebGL Scene — VESPER / V—0RB

The home view is a fixed, full-viewport `@react-three/fiber` canvas behind a
fixed HUD. Nothing on the page scrolls except four invisible tracks, whose
progress advances a **global clock** that both layers read.

> [!note] Scroll distance per scene is one constant
> Each track is `SCROLL_TRACK_LVH` lvh tall (`hud/windows.ts`, currently **200** =
> two viewports), and its `getProgress` spans that height — so it sets how much
> **scroll** advances one clock unit, i.e. how far you drag between scenes. Raising
> it lengthens the whole timeline without touching the clock's shape or range; the
> reveal bands read the same constant (`toLvh`) so copy stays synced. `scroll-stage`
> sizes the track `<div>`s from `toLvh(1)`.

Three forms hand off across that clock: an **orb** (hero), a **spiral galaxy**,
and a point-cloud **brain** (the final act). The orb and galaxy were ported from
`getlayers-scenes/orb.html` and `spiral-galaxy.html`; the brain is area-sampled
from a **baked mesh** (ADR-0024 introduced it from a GLB; ADR-0028 replaced the
GLB with a 43 KB binary). Deps: [[tech-stack]].

> [!important] The orb no longer returns — the third act is the brain
> The tail used to re-form the orb and open its core over a spinning logo. That is
> replaced by the {@link brainAppear} brain: `orbOut` now holds at 1 through
> keyframes 3–4, so the orb stays scattered, and `orbCoreOpen`/`orbApproach` are
> dormant. The brain assembles across clock 2.6→3.4 as the galaxy blows apart.
> See `scene/brain/` and ADR-0024. (Amends the return-shape ADR-0016/0022 note
> below — keep that history for context, but the orb return is intentionally gone.)

## The global clock

`src/lib/scene/timeline.ts` owns a 0→4 clock and a five-entry keyframe track.

```
sceneTimeline.setTrack(i, p)   ← written by 4 useProgressTrigger calls
sceneTimeline.getState()       ← read every frame by the scene
sceneTimeline.subscribe(fn)    ← read by the HUD
```

> [!warning] The clock is `p1 + 2·p2 + p3`
> The fourth track measures the **third** track against the viewport bottom, so it
> resolves to the same value as the second. The clock runs at **double rate**
> through its middle segment. Every keyframe was authored against that shape —
> do not "simplify" it. [[decisions-log]] ADR-0016.

`getState()` returns a **stable object mutated in place**. Read it each frame;
never cache its fields. It is deliberately not React state — a per-frame
`setState` would re-render the tree at 60 Hz.

The keyframes are a **coarse skeleton**. Everything that needs a curve, or has to
happen *in sequence* inside one keyframe span, is a derived selector over the
clock — pure functions, so a beat is retimed by editing one `smoothstep` range.
[[decisions-log]] ADR-0019.

| Helper | Meaning |
|--------|---------|
| `orbDissolve` / `orbAlpha` | eased dissolve, and the opacity that follows it |
| `orbCoreOpen` | the core cut-out, opening across 2.9 → 3.6 |
| `orbApproach` | the orb's exit — rushes toward the camera and distorts, held until the core has finished opening |
| `galaxyPresence` | how much of the frame the galaxy owns — drives camera, backdrop, atmosphere |
| `galaxyAppear` | the galaxy's opacity ramp |
| `galaxyAssemble` | how far its stars still are from their resting places, 1 → 0 |
| `galaxyBlow` | its dispersal amount |

> [!important] `galaxyPresence` must track `galaxyAppear`, never raw `galaxyIn`
> Keyed to the raw value, the camera starts retreating on the first pixel of
> scroll and yanks the orb into the distance while it is still half-visible. It
> reads as the orb *vanishing* rather than dissolving.

A separate `lib/scene/outro.ts` clock, driven by a `useProgressTrigger` on the
outro section, fades the HUD chrome and the orb out as the closing sections
arrive — a fixed overlay must not sit on top of real content.

> [!important] `SECTION_WINDOWS` must lead the scene, not trail it
> The copy should already read "Beyond the core" *before* the galaxy arrives, so
> section 2 lands at clock 0.52 and `galaxyAppear` ramps from 0.55. The windows
> must not overlap either, or two sections render on top of each other. The HUD's
> `INDICATOR_STEPS` have to be retimed alongside them.

The keyframes preserve the original section transitions exactly, including the
detail that **the orb returns** across `2 → 3`. Across the final section it then
opens its core and **rushes toward the camera, distorting** as it fills the frame
(`orbApproach`; see [[decisions-log]] ADR-0022) — it does not sink away. Keep that
shape when retiming.

## The intro clock

`src/lib/scene/intro.ts` is a bare `SpringValue` (0→1), started once the loader
finishes. The render loop reads it via `getIntro()`; the HUD binds to it
declaratively through `introValue.to({ range, output })`. It drives the camera
dolly-in, the HUD fade-up, and the first section's copy.

## Layout

```
app/layout.tsx                  SiteHeader (fixed, site-wide — ADR-0025)
src/views/home.tsx              Server Component — owns the copy
└─ home/scroll-stage.tsx        "use client" — tracks, bands, clocks, assembly
   ├─ scene/scene-canvas.tsx    <Canvas>, client-only
   │  └─ scene/main-scene.tsx   CameraRig + Backdrop, HeroLine, Orb, Galaxy, Brain, Atmosphere, Bloom
   │     ├─ scene/hero-line.tsx     the Figma rule, behind the orb (renderOrder −0.5)
   │     └─ scene/brain/brain.tsx   point cloud sampled from the baked mesh — the final act (ADR-0024/0028)
   ├─ overlay.ts                shared overlay plumbing — useSceneClock, hiddenWhenClear
   ├─ send-request.tsx          the CTA shared by the hero + brain overlays (ADR-0031)
   ├─ hero/hero.tsx             fixed Figma overlay — section one (ADR-0025)
   ├─ section-galaxy.tsx        fixed Figma overlay — section two (ADR-0025)
   ├─ section-brain.tsx         fixed Figma overlay — section three, convergence (ADR-0025)
   ├─ loader/loader.tsx         star-fall curtain, drives `startIntro()`
   │  └─ loader/star-fall.tsx   ticker-driven 2D canvas, angled streaks in the orb's colours
   └─ sections/                 financial-section.tsx (white card, ADR-0026), faq-section.tsx, site-footer.tsx
```

> [!note] The dev colour panel used to hang off `scroll-stage` here
> `hud/color-panel.tsx` was mounted behind `process.env.NODE_ENV === "development"`.
> It is gone (see *The colour store* below); only `hud/windows.ts` remains in that
> folder.

> [!note] Section one is the Figma hero now; the HUD carries only 2–3
> The hero is `hero/hero.tsx` (ADR-0025), not the HUD. `hud.tsx` skips section
> index 0 and renders only the scroll-scrubbed galaxy/brain copy. The old chrome
> (frame brackets, brand, status, scroll hint) is gone. The hero's horizontal rule
> is `scene/hero-line.tsx` — WebGL, because the opaque canvas can't have a DOM line
> behind it.

The canvas has `pointer-events: none`; `eventSource={document.body}` keeps the
pointer flowing to the scene through the HUD above it.

## One camera, two scales

Each source scene shipped its own camera — the orb sits close (`z ≈ 3.8`), the
galaxy far out (`z = 48`, diving to 18). Rather than rescale one form to meet the
other, `CameraRig` **travels between them**, interpolated by `galaxyPresence`.

That is what makes the galaxy's arrival immersive: the camera falls toward the
core while the disc tips toward edge-on, so the second scene envelops the viewer
instead of merely fading up. And because presence returns to 0 as the galaxy
disperses, the camera pulls back to the orb exactly as the orb returns.
[[decisions-log]] ADR-0017.

## The backdrop

Both source scenes composited a background wash plus a drifting "flame"
domain-warp in a **post pass, after bloom**. Here it is a clip-space quad drawn
first, beneath the additive particles — visually equivalent, and it avoids
threading a second composer through `@react-three/postprocessing`. It is also
where the palette crossfade lives: the whole background shifts from the orb's
magenta to the galaxy's violet as the forms hand off.

## Section copy — fixed Figma overlays

Each section's copy is a **fixed overlay** faded against the global clock (ADR-0025):
`hero/hero.tsx`, `section-galaxy.tsx`, `section-brain.tsx`. Their opacity is a
`smoothstep` window on `sceneTimeline.getProgress()` (the hero also gates on the
intro). Above 1024px, measurements are Figma pixels in `vw` (÷14.4) — see the note
in `hero.tsx`. Below it they become authored stacks; [[design-system]], ADR-0029.

Their shared plumbing is `views/home/overlay.ts`:

| Export | Purpose |
|--------|---------|
| `useSceneClock()` | mirrors the clock into a `SpringValue` — **not** React state, or the split text would re-render at 60 Hz |
| `hiddenWhenClear(opacity)` | derives `visibility` from that opacity |
| `smoothstep(a, b, x)` | the eased ramp every window is built from |

> [!important] An invisible overlay is not a free overlay
> All three are `fixed inset-0` and **always mounted** — a fixed overlay cannot use
> in-view, so it has to be present to be faded. But `opacity: 0` does not retire a
> layer: the browser still rasterises it every frame. That is unusually expensive
> here, because `spring-text-engine` splits the copy into per-letter spans and each
> one carries an animated `filter: blur()`, composited over a live WebGL canvas —
> and **two of the three overlays are invisible at any given moment**.
>
> `hiddenWhenClear` flips them to `visibility: hidden` below `opacity` 0.001, which
> takes the subtree out of paint while leaving it mounted and laid out, so the
> springs and the engine keep their state and the fade back in is unchanged.

> [!note] The old per-line `TextEngine` reveal system is gone
> Sections used to be `TextEngine mode="progress"`, one engine per authored line,
> each triggered by a zero-content **reveal band** placed in the scroll document
> (`hud/windows.ts` inverted the clock to position them). That whole layer — the
> HUD, `Section`, the bands — was removed when the sections became Figma overlays.
> Only the scroll **tracks** (which advance the clock) and `toLvh` remain in
> `hud/windows.ts`.

## Rules that shaped the port

- **No `framer-motion`.** `motionValue` → `SpringValue` / plain store;
  `motion.*` → `animated.*`; `AnimatePresence` → a spring + unmount on `onRest`.
- **No CSS `@keyframes`.** Looping motion is spring-based — see `loader/loader.tsx`
  (the old HUD `spin`/`pulse`/`arrow` motions went with `hud-motion.tsx`, ADR-0025).
- **No hardcoded values.** Palette, type scale, and frame spacing are tokens in
  `globals.css`. Scene colours are the exception: they are WebGL values that
  cannot reference a CSS custom property, so they live in `lib/scene/constants.ts`.
  `ORB.bg` doubles as the canvas clear colour and must stay in step with
  `--color-void`.

## The colour store

`lib/scene/color-store.ts` is a zustand store seeded from `constants.ts`
(`SCENE_COLOR_DEFAULTS`) that **shadows** every scene/backdrop colour. The scene
reads it imperatively — `getSceneColors()` in `useFrame`, `subscribeSceneColors()`
to refresh uniforms on change. `backdrop`, `atmosphere`, `orb`, `galaxy`, and
`brain` refresh their colour uniforms **in place** via `scene/color.ts` →
`setLinearVec3(target, hex)` (the allocation-free sibling of `hexToLinearVec3`), so
per-frame lerps read store-backed endpoints. The store has one slice per form
(`orb`/`galaxy`/`brain`).

> [!warning] The "Colors" dev panel is gone (2026-07-12)
> `views/home/hud/color-panel.tsx` — the bottom-right **"Colors"** toggle, mounted
> dev-only from `scroll-stage`, with the per-form sliders and the "Copy JSON"
> export — was **removed on request**. It never shipped to production (it was behind
> `process.env.NODE_ENV`), so nothing about the built site changes.
>
> **The store stays**, because it is not just the panel's backing state: all five
> scene components read it every frame, and `constants.ts` seeds it. Retuning a
> scene colour now means editing `constants.ts` directly — which it always was:
> the store's docs called it the source of truth, and the panel only existed to make
> the edit loop fast. Amends [[decisions-log]] ADR-0023.
[[decisions-log]] ADR-0023.

## Gotchas

> [!warning] Never pass `uniforms` to `<shaderMaterial>` for animated scenes
> r3f does **not** keep the uniforms object you pass as a prop — the material ends
> up owning a different one, so every `useFrame` write lands in a detached object
> the GPU never reads. The scene renders nothing and never moves.
>
> Build the material instead, and hand r3f the instance:
>
> ```tsx
> const material = useMemo(() => new THREE.ShaderMaterial({ uniforms, … }), [uniforms]);
> <points geometry={geometry} material={material} />
> ```
>
> Three's constructor assigns `parameters.uniforms` by reference, so it stays
> live. [[decisions-log]] ADR-0018.

> [!warning] Shader colours must be **linear**
> The renderer runs `outputColorSpace = SRGBColorSpace`, so the output pass
> encodes linear → sRGB. Uploading raw hex bytes encodes twice: `#170a2b`
> (near-black violet, linear `0.009`) renders as washed lavender (raw `0.090`).
> Always go through `scene/color.ts` → `hexToLinearVec3`.
>
> The same applies to `Bloom`'s `luminanceThreshold` — it is a **linear**
> luminance, not an sRGB one.

> [!warning] The frame loop is a shared resource
> react-spring is rAF-driven. If the scene is heavy enough to starve
> `requestAnimationFrame`, **every** spring on the page freezes — including the
> loader's exit. The symptom is an opaque curtain stuck mid-fade over a scene you
> can never see. Watch the cost: it scales with `points × pointSize² × dpr²`.

## Performance

> [!warning] `targetFps` is a ceiling reached by skipping whole rAF frames
> The gate can only *drop* frames, so on a 60 Hz panel the honest values are 60
> (every frame) and 30 (every other). The tablet's 45 is representable only on a
> 90/120 Hz display and degrades to 30 elsewhere — which is the intent.
>
> Until 2026-07-12 **none** of these were delivered. The ticker throttled with
> `elapsed <= interval`, and at `targetFps: 60` the interval is `16.6667` ms while
> a 60 Hz display delivers frames `16.6667` ms apart — so the gate rejected frames
> that arrived *exactly on time*, then passed the doubled gap. The result was
> **39 fps with an alternating 33 / 16.7 ms cadence**, on a perfect display with
> zero jitter. An uneven cadence reads as stutter far more readily than an even,
> lower frame rate does — this was the single biggest source of the scene feeling
> laggy, and no amount of tuning point counts would have found it. Fixed with a
> 1 ms tolerance in `lib/animation/ticker.ts`. See [[decisions-log]] ADR-0030.

The scene runs `frameloop="demand"`. `scene/frame-gate.tsx` drives `invalidate()`
from the shared ticker at the tier's frame rate, and **stops entirely** when the
tab is hidden or `getSceneCover() >= 0.995` — i.e. once *opaque* closing content
actually covers the scene. It deliberately does **not** stop on `outro`: the
closing cards are inset white cards (ADR-0026) that float over the still-drawing
scene, so the shader stays visible around them.

> [!note] As of 2026-07-12 the footer is also transparent over the shader (ADR-0026
> update), so **no** closing content is opaque and nothing drives `sceneCover` — it
> stays `0` and the gate runs to the bottom of the page. The `getSceneCover()` check
> is kept for when opaque closing content is reintroduced.

`scene/adaptive.ts` is the single dial. Four tiers by viewport width:

| | orb pts | galaxy pts | dpr | fps | bloom | clock lerp |
|---|---|---|---|---|---|---|
| desktop | 23 000 | 67 781 | 1–2 | 60 | on | 0.07 |
| laptop (≤1440) | 17 000 | 43 361 | 1–1.75 | 60 | on | 0.08 |
| tablet (≤1024) | 11 000 | 25 351 | 0.9–1.25 | 45 | on | 0.13 |
| phone (≤640) | 6 500 | 12 141 | 0.75–1.1 | 30 | **off** | 0.15 |

> [!note] Desktop dpr and clock lerp were retuned (ADR-0023)
> The desktop/laptop dpr caps were `1.5`/`1.35` — enough to look soft on HiDPI
> displays, since the sprites upscaled — and are now `2`/`1.75`. The `clock lerp`
> was progressively lowered as the handoff kept reading too sharp: `1`/`0.55` →
> `0.16`/`0.18` → **`0.07`/`0.08`** (desktop/laptop; tablet/phone `0.13`/`0.15`).
> At `0.07` the scene trails the scroll by ~0.25 s, which is the point — the
> orb→galaxy transition glides instead of scrubbing. It also means the scene lags
> the HUD copy slightly (the copy tracks raw scroll bands); that trade is
> deliberate. Cost is `∝ dpr²`, so watch the frame budget if you push dpr higher.

> [!note] The orb was de-soaped by sharpening the sprite, not by resolution
> Raising dpr alone did **not** fix the "soapy" orb: each point sprite had a wide
> soft falloff (`smoothstep(0.5,0.0,d)`) that, additively overlapped at
> `orbPointSize` ~34, blurred into a wash at any resolution. The fix
> (`orb-shaders.ts`) squares the falloff — tight bright core, thin halo, ×1.2 to
> hold peak brightness — trims `orbPointSize` per tier, and tightens `Bloom`
> (intensity 0.6, threshold 0.6, radius 0.3) so only hot cores glow. Because cost
> scales with `pointSize²`, the smaller sprites also claw back the budget the dpr
> bump spent. If the orb reads dim after retuning colours, raise
> `ORB_CONFIG.brightness` in `constants.ts` rather than widening the sprite.

- `antialias: false` — MSAA does nothing for additive point sprites.
- No `AdaptiveDpr`: it fights `demand`, and dpr is pinned per tier.
- Bloom is omitted (not merely disabled) on phones — a full mipmap chain
  dominates the frame at any dpr.
- The galaxy's `SphereGeometry` **must** have its index dropped (below).

> [!important] A low frame rate needs a lerped clock
> Un-smoothed, the clock jumps to wherever the finger dragged and the scene steps.
> `configureTimeline(progressLerp)` + `advanceTimeline(dt)` ease it, frame-rate
> independently. The lerp runs on the **ticker**, not the render loop, so the HUD
> keeps moving while the scene is idle. [[decisions-log]] ADR-0021.

> [!important] Additive blending cannot draw black
> A point can only *add* light. When one looks black, what you are seeing is the
> near-black backdrop through a point whose alpha collapsed. Keep floors under the
> depth and lighting terms in `vAlpha` (and under `col`), or noise troughs and the
> far hemisphere read as black blotches rather than as dimmer particles.

> [!important] Nothing in the scene suspends any more — the brain is a baked mesh
> The brain used to load a 4.67 MB GLB through `useGLTF` (ADR-0024). It now reads a
> **43 KB baked mesh** (`brain-mesh.bin`) via `fetch`, and **never suspends**
> (ADR-0028).
>
> That matters more than the byte count. `useGLTF` suspends, and `<Brain>` lives
> inside `MainScene`'s one `<Suspense>` — so the orb, the galaxy, the backdrop and
> the hero copy all waited behind a 4.67 MB download for a form that does not
> appear until the third act. **4.5 MB of that GLB was PBR texture images the brain
> shader never read**; it samples geometry only, and the mesh is just 2,605 verts.
>
> Consequences: no three.js loader runs at all now, so drei's `useProgress` reports
> `total: 0` and the loader falls back to its minimum duration (its
> `total > 0 ? loaded/total : 1` guard already covered this). A failed mesh fetch
> logs and renders nothing rather than taking the whole scene down.
>
> The source GLB is **deleted**, not relocated — 4.67 MB in the tree bloats every
> clone, and git history has it. To change the model, recover or supply a `.glb`,
> re-bake, and do **not** put it back under `public/` (anything there is served):
> ```sh
> node scripts/bake-brain.mjs /tmp/brain.glb public/assets/brain/brain-mesh.bin
> ```

> [!warning] Never assign `vNormal` in a point-cloud `onBeforeCompile`
> Kept for reference: three sets `FLAT_SHADED` when a geometry has no `normal`
> attribute, which compiles the `varying vec3 vNormal;` declaration out. The
> current scene uses standalone `ShaderMaterial`s and no longer patches stock
> materials, so this cannot bite — but it silently killed every particle when it
> did. Details in [[changelog]] (2026-07-10).

- Geometry is built once on mount from `getParams(window.innerWidth)`. The scene
  does **not** rebuild on resize; only the camera and pointer parallax react.
- The galaxy's `SphereGeometry(4.2, 200, 600)` is a **seed lattice**, never drawn
  as a sphere — the vertex shader hashes each position into an arm or bulge
  coordinate. Its segment counts *are* the point count; they drop on mobile.
  The geometry is **indexed**, and `THREE.Points` honours the index: left alone it
  draws **718,800** sprites for only **120,801** distinct stars, stacked exactly on
  top of one another. `setIndex(null)` draws each once. Additive blending is
  linear, so N coincident sprites of alpha `a` sum to exactly `N·a` — scaling
  `uOpacity` by the duplicate factor (~5.95) reproduces the image at a sixth of
  the cost.
- Both forms set `group.visible = false` once fully scattered / dispersed. Keep
  that — the galaxy alone is ~120k points.
- Pointer effects (the orb's viscous "oil", the galaxy's cursor void, camera
  sway) are disabled below 576 px via `pointerReaction`.

> [!important] The core is a bore in object space, not a circle in screen space
> `uCore` opens a cylinder along the camera axis, measured in the orb's own frame
> against the **displaced** surface, with its radius modulated by the same noise.
> The rim therefore rides the blob's shape, and the cut removes front *and* back —
> a real tunnel, not a stencil. `uCamLocal` must be recomputed after the per-frame
> spin (and after `updateMatrixWorld()`), or the bore swims. [[decisions-log]]
> ADR-0020.
>
> Radii are fractions of the unit sphere: rest 0.36, open 0.56. The logo plane's
> half-size (0.35) has to stay under the open value.

> [!warning] Shader spawn radii are not free parameters
> The galaxy's assembly spawn radius is in galaxy-local units, multiplied by
> `uScale` (0.18); too large and the inbound shell encloses the camera and swamps
> the hero. Caught only by looking at rendered frames.

> [!warning] A backtick inside a `/* glsl */` template literal ends the string
> Writing `` `uCore` `` in a GLSL comment terminates the JS template literal and
> produces a baffling `TS1005: ',' expected`. Never use backticks in shader
> comments — this has bitten three times.
- Two lint rules are off for `scene/**`. [[decisions-log]] ADR-0015.

## Removed

`Grid`, `Model` (the `logo.glb` mark), `Blob`, `Universe`, `Lights`, and `Stars`
are all gone. `Stars` recycled its starfield against a static `camera.position.z`;
the camera now travels ~4 → ~48 world units, which that logic could not survive.
The `Atmosphere` motes — camera-attached, and shipped by both source scenes —
replace it and work at any depth.

`orb/logo-plane.tsx` and `orb/logo-texture.ts` (the VESPER mark that span inside
the orb's opened core) are also gone: the third act is the brain now, so the orb
never re-forms to open its core (ADR-0024).

## Related

[[animation-system]] · [[text-engine]] · [[tech-stack]] · [[decisions-log]]
