---
tags: [meta, decision]
updated: 2026-07-12
---

# Decisions Log (ADRs)

Architecture Decision Records. Each entry captures a choice, its context, and its
consequences. Use [[templates/adr-note]] for new entries. Newest first.

---

## ADR-0031 — One interaction language: sprung hover + press, and nothing scales

- **Status:** Accepted
- **Date:** 2026-07-12

**Context.** The Figma sections shipped with **no hover states at all** — the
header nav, the Send Request CTA, the FAQ rows and the footer's submit were all
inert under the cursor. What interaction did exist was inconsistent: the footer's
links and the cookie banner used bare `hover:` utilities (an instant swap — legal
under the no-CSS-transitions rule, but the only controls on the page that snapped),
and `ui/button.tsx` wrapped itself in a `<Hover>` that **scaled it to 1.03**.

The engine's `<Hover>` is also the wrong shape for a real control:
- it covers mouse enter/leave only — no press state;
- it styles **its own wrapper**, but the Send Request CTA is a `<Link>` whose fill
  lives on an inner `<span>`, with the arrow tile outside it. Wrapping the span
  leaves the arrow inert, so the button fails to light up from a third of its own
  hit area;
- on touch, `pointerenter` fires with no `pointerleave` behind it, so a tapped
  control lights up and **stays lit**.

**Decision.** One vocabulary, `src/lib/springs/interaction.ts`, and one primitive,
`components/ui/pressable.tsx` (`<PressableLink>`, `<PressableButton>`,
`usePressable`). Every control on the site now goes through it. Presets layer three
states — `hover` over `rest`, `press` over both — so each declares only what changes.

**No scale, anywhere.** Controls respond in **colour and weight**: the surface takes
light, the border firms up, the ink shifts to the signal mint. The box never moves,
so nothing reflows and nothing wobbles against the WebGL scene behind it. A control
that grows under the cursor is a tell that the motion was added for its own sake.

`usePressable` returns `{ style, bind }` **separately** — spread `bind` on whatever
the pointer meets, put `style` on whatever should react — which is what makes the
CTA (and anything else with a decorative sibling) work.

**Consequences.**
- `<Hover>` stays in the engine, unmodified (it is `#do-not-modify`), and is still
  right for a decorative hover on a **non-control**. Controls use `usePressable`.
- The interaction colours are **literals, not `var(--token)`** — react-spring
  interpolates a colour's channels and cannot parse a custom property, so a spring
  between two `var()`s snaps. Same exemption `lib/scene/constants.ts` takes, same
  reason. They must be kept in step with `globals.css` by hand.
- Where a preset drives a colour, the element's classes carry width/style only
  (`border`, not `border-white/50`): an inline spring value beats a utility anyway.
- The duplicated Send Request markup in `hero.tsx` and `section-brain.tsx` collapsed
  into `views/home/send-request.tsx`.
- Focus rings are **not** sprung — an indicator that eases in is briefly wrong — and
  every pressable now carries one. Several controls sit on a live WebGL canvas where
  the UA default outline is invisible, and the footer's inputs had `outline-none`
  with nothing put back.

---

## ADR-0030 — The shared ticker's frame gate needs a jitter tolerance

- **Status:** Accepted
- **Date:** 2026-07-12

**Context.** Every per-frame consumer in the app — the scene's `FrameGate`, the
scroll-clock lerp, all five `useProgressTrigger`s — is throttled by one rule in
`lib/animation/ticker.ts`:

```ts
if (time - sub.last <= sub.getFramerate()) continue;   // getFramerate() = 1000/targetFps
```

For a tier asking for 60 fps, `getFramerate()` is `1000/60 = 16.6667`. A 60 Hz
display delivers rAF timestamps `16.6667` ms apart. `16.6667 <= 16.6667` is
**true**, so the frame is rejected — and because a rejected frame does not advance
`last`, the next one is measured across a doubled gap and always passes.

The gate therefore alternates render / skip **by construction, on a perfect
display with zero jitter**. Replayed against exact 60 Hz timestamps it yields
**39 fps with a 33 / 16.7 ms cadence**. Real vsync jitter (16.4, 16.9, 16.6) makes
it worse and irregular. The eye reads an uneven cadence as stutter far more
readily than it reads a lower, *even* frame rate — so the scene felt laggy while
every individual frame was cheap.

The same rule was silently halving the phone tier (30 fps asked, ~24 fps with
33 / 50 ms gaps) and the scroll clock.

**Decision.** Give the gate one millisecond of slack:

```ts
if (time - sub.last < sub.getFramerate() - JITTER_MS) continue;   // JITTER_MS = 1
```

1 ms is far below the 16.7 ms spacing of the next real frame, so it cannot let a
30 fps subscriber steal an extra frame — it only stops the gate rejecting frames
it meant to accept.

**Consequences.** `targetFps` in [[webgl-scene]]'s `adaptive.ts` now means what it
says. The desktop tier genuinely runs at 60 fps (it was running at ~40), which
*raises* its GPU load — that is intended, and the budget freed elsewhere in this
pass (ADR-0028, the overlay paint fix) more than covers it.

Note that `targetFps` is a ceiling reachable only by skipping whole rAF frames, so
on a 60 Hz panel the honest values are 60 and 30. The tablet's 45 is only
representable on a 90/120 Hz display and degrades to 30 elsewhere — which is the
intent.

---

## ADR-0028 — The brain ships as a baked mesh, not a GLB

- **Status:** Accepted
- **Date:** 2026-07-12
- **Amends:** ADR-0024 (which introduced the GLB-sampled brain)

**Context.** The third act (ADR-0024) sampled its point cloud from
`rotten-brain.glb` via drei's `useGLTF`. Two things were wrong with that, and both
were invisible from the code:

1. **The GLB was 4.67 MB, and 4.5 MB of it was three PBR texture images** — the
   mesh itself is 2,605 vertices / 4,850 triangles, about 100 KB. The brain
   material is a standalone `ShaderMaterial`; it reads *geometry only* and has
   never touched a texture. The site was shipping 4.5 MB of albedo/normal/specular
   maps to every visitor so it could throw them away.
2. **`useGLTF` suspends.** `<Brain>` sits inside `MainScene`, inside the canvas's
   one `<Suspense>`. So the orb, the galaxy, the backdrop and the hero copy all
   waited behind that 4.67 MB download — for a form that does not appear until the
   viewer has scrolled through two full acts. The loader gated on `useProgress`,
   which reported the GLB, so the curtain sat there too.

On top of that, every page load re-did work that never changes: flatten the scene
graph to a world-space triangle soup, sample it, then recentre and rescale the
*result*.

**Decision.** Bake it offline. `scripts/bake-brain.mjs` parses the GLB container by
hand (no three.js, no DOM), flattens it to world space, normalises it once — the
same area-weighted-sample centroid and unit bounding radius the runtime used to
compute — and writes an indexed, quantised mesh:

```
magic 'VBRN' u32 | version u32 | vertexCount u32 | indexCount u32
positions i16 × v × 3   (unit sphere → ÷ 32767)
indices   u16 × i
```

**43 KB** (27 KB brotli), down from 4.67 MB — **172×**. The GLB is deleted.

`Brain` now `fetch`es that file and **never suspends on it**. Nothing blocks; the
brain simply renders once its mesh lands, several viewports of scroll before it is
needed. If the fetch fails it logs and renders nothing — the orb and galaxy are
unaffected, where before a failed GLB took the whole scene down.

Positions are normalised to radius 1, not to `BRAIN_CONFIG.radius`, so the radius
stays a live tunable rather than being frozen into the asset. Per-tier point counts
still sample at runtime (~10 ms, once, behind the loader): every sample is
independent, so a lower `brainCount` is a genuine subsample of the same surface.

**Consequences.**
- `useGLTF` is gone; nothing in the scene goes through a three.js loader, so
  `useProgress` reports `total: 0` again and the loader runs on its minimum
  duration (its `total > 0 ? loaded/total : 1` fallback already handled this).
- **The source GLB is deleted, not relocated** — keeping 4.67 MB in the tree bloats
  every clone, and it is recoverable from git history when the model needs to
  change:
  ```sh
  git show <commit-before-this>:public/assets/brain/rotten-brain.glb > /tmp/brain.glb
  node scripts/bake-brain.mjs /tmp/brain.glb public/assets/brain/brain-mesh.bin
  ```
  If the brain is ever re-modelled, bake from the new source and **do not** put the
  `.glb` back under `public/` — anything there is served.
- Quantisation error is 3.5e-5 world units at the brain's radius. Invisible.
- The bake is deterministic in shape but not in bytes: the normalising transform is
  derived from a 200k random surface sample, so re-running it shifts the centroid
  by ~1e-3. That is well inside the noise of the runtime sampling, which reseeds on
  every page load anyway.

---

## ADR-0029 — Below 1024px the `vw` ladder stops; the layout is authored, not scaled

- **Status:** Accepted
- **Date:** 2026-07-12

**Context.** Every Figma section (ADR-0025 onward) is measured in `vw` — Figma
pixels ÷ 14.4, against the 1440-wide artboard — with elements absolutely placed at
their design offsets. That is exactly right *above* 1024px: the page is one
artboard, scaled proportionally, and it stays pixel-faithful at any desktop width.

Carried below 1024px it collapses. Body copy is authored at `1.111vw`, which is
**4px on a 360px phone**. The header pill is `3.542vw` — 14px tall, holding four
nav links and a button. The galaxy's stat band is four `11vw` columns pinned at
fixed `left` offsets. The site was not responsive; it was *uniformly shrunk*, and
nothing below a laptop was usable.

The root font-size ladder in `globals.css` had `1024 → 1.5625vw` and
`640 → 4.444vw` rungs, but the sections bypass `rem` entirely, so those rungs did
nothing for the actual layout.

**Decision.** Split the two regimes at Tailwind's `lg` (1024px), which already
matches the scene's own tablet tier in `adaptive.ts`.

- **≥1024px** — unchanged. The `vw` artboard, the proportional root font-size, the
  `AdaptiveGrid` scale-up above 1920. Pixel-identical to before.
- **<1024px** — the ladder stops (`html { font-size: 16px }`), so `rem` means real
  pixels again, and each section gets a purpose-built stack authored in `rem` via
  `max-lg:` / `max-sm:` overrides. Absolute Figma offsets become flex columns and
  grids; the header's links move into a burger panel (`MobileNav`).

One DOM tree, not two — the overrides are CSS. The one subtlety: `TextEngine`
hardcodes `position` as an **inline style**, so a class cannot beat it. The
overlays use Tailwind's important modifier (`max-lg:static!` →
`position: static !important`) to pull the copy back into flow.

**Consequences.**
- Desktop is untouched — verified by driving the page; the hero, cards and footer
  render identically.
- `max-lg:` / `max-sm:` map onto `@media (width < 64rem)` / `(width < 40rem)`.
  Media-query `rem` is always the *initial* 16px root, not the scaled one, so these
  are true 1024/640 breakpoints regardless of the ladder.
- The 1024 and 640 rungs are gone from `globals.css`; `grid.config.ts` still lists
  them and now only describes the ≥1024 range. Anything below is authored, not
  derived.
- New: [[components/common|MobileNav]]. `SiteHeader` stays a Server Component; only
  the toggle is a client leaf.

---

## ADR-0027 — Section reveal animations (per-letter / per-word) without moving the layout

- **Status:** Accepted
- **Date:** 2026-07-11

**Context.** The Figma sections needed: headings revealing **per-letter**
(left→right, blur + opacity), body copy **per-word** (bottom→up, blur + opacity),
the photo unmasking top→bottom, exit as the reverse of entry, and — on reload — the
hero playing *after* the loader. Per project hard rule, character/word text
animation must use `spring-text-engine`. The catch: naive `TextEngine` usage moved
the exact `vw` layouts.

**Why it moved (root cause).** `TextEngine` lays its container out as
`display:flex; flex-wrap:wrap` with a `column-gap` (default `0.3em`) between word
flex-items, and hardcodes `position: relative` on it. Three consequences broke the
design:
1. **Inline `position: relative` beats the Tailwind `absolute` class** — so an
   absolutely-positioned engine falls back into normal flow. Left-anchored copy
   (title, tagline) survives by coincidence (relative offset from a top-left origin
   ≈ its absolute spot), but `right-0` copy (the hero support line) and centered
   copy break — the support line stacked under the tagline on the left.
2. **Flex ignores `text-align`** — so `text-center` / `text-right` containers
   (galaxy titles, brain right column) collapsed to left.
3. The `0.3em` gap ≠ the font's natural space, so word spacing / wrap points shifted.
(An interim fix reverted to whole-element `Inview` reveals, which preserved the
layout but lost the per-letter/word motion — not what the design wanted.)

**Decision.** Keep `spring-text-engine` for headings (`LETTER_REVEAL`) and body
(`WORD_REVEAL`), and neutralise the flex/position side-effects at every call site:

- **Positioning** — pass `style={{ position: "absolute" }}`; the engine spreads
  `...style` last, so it overrides the hardcoded `relative`. (In-flow copy like the
  FAQ title passes nothing.)
- **Alignment** — add `justify-center` / `justify-end` to the container className
  wherever the copy was `text-center` / `text-right` (left is the flex default).
  Keep the `text-*` class for the engine's hidden SEO copy.
- **Spacing** — `columnGap: 0.25` (≈ the space glyph) instead of the `0.3` default.
- **No layout-affecting transforms** — letters animate opacity + blur only (the
  left→right feel comes from `letterStagger`); words add a `y` translate, but the
  transform rides the inner word span, **not** the container, so it never fights a
  `-translate-x-1/2` centering. Opacity-0 letters still reserve their space, so the
  container box is stable from the first frame.

Non-text units (CTA, stat labels, FAQ list) and the photo stay on the `Inview`
wrapper (`UNIT_REVEAL`, `MASK_REVEAL`) — no per-character motion needed there.

**Triggering (unchanged from the interim design).**
- **Scroll cards** (`FinancialSection`, `FaqSection`) are in flow → `mode="always"`,
  `immediateOut={false}`: in-view drives reveal in *and* out (natural reverse).
- **Fixed overlays** (hero, galaxy, brain) are always in-view, so they gate the
  engine's `enabled` on a **boolean**. The engine's play-in effect depends on
  `enabled` (verified in its source: `inView && enabled && innerEnabled && !played
  → playIn`), so flipping the flag reliably starts it. Hero → `introStarted`,
  `mode="once"` (reveal after the preloader, group opacity fade on exit).
  Galaxy/brain → `active` clock window, `mode="always"` (reverses when the window
  ends).
- The **header** is intentionally not animated.

**Consequences.** Per-letter/word reveals are back and the layout holds (container
box + alignment preserved; only inter-word spacing is engine-controlled, tuned to
match). If word spacing ever looks off, adjust `columnGap` in `reveal.ts`. The
per-element `Inview` reveal remains available for any copy that shouldn't be split.

## ADR-0026 — The scene keeps drawing behind the first closing card (`sceneCover`)

- **Status:** Accepted
- **Date:** 2026-07-11

**Context.** The first closing section became a Figma **white card inset from the
viewport edges** (`sections/financial-section.tsx`), floating up over the scene as
the brain bursts — the shader must stay visible around it. But the frame gate
stopped the scene at `getOutro() >= 0.995`, and `outro` ramps exactly as the card
slides in (it drives the brain's exit + overlay fades). So the scene froze the
moment the card arrived, killing the shader the design wants visible.

**Decision.** Split the two concerns. `outro` still ramps on the Financial card
(brain exit, overlay fades) via the trigger on its wrapper. A new **`sceneCover`**
clock (`outro.ts`) ramps on a separate trigger on the **opaque** FAQ/footer wrapper
below, and the frame gate now stops on `sceneCover` — i.e. only once real opaque
content has actually covered the scene. The closing content is therefore two
layers: a transparent Financial wrapper (scene shows around the card) then the
`bg-surface` FAQ/footer.

**Consequences.** The backdrop shader keeps drawing behind/around the card, at a
small extra frame cost (the brain/orb/galaxy are already faded out by `outro`, so
it is mostly the backdrop + atmosphere). `getOutro` no longer implies "scene
stopped" — use `getSceneCover` for that. The old opaque full-bleed
`outro-section.tsx` is deleted; `homeOutro` is no longer wired.

**Update.** The **FAQ** (`sections/faq-section.tsx`) became a Figma white card too,
so it also floats over the live scene — it was moved out of the opaque `bg-surface`
wrapper. The **footer** is now the first opaque content, so `sceneCover` triggers
there, and the scene draws through both the Financial and FAQ cards.

**Update (2026-07-12).** The **footer** (`sections/site-footer.tsx`) was rebuilt to
the Figma design and made **transparent over the live shader** too — so there is no
longer *any* opaque closing content. The `sceneCover` trigger + `coverRef` were
removed from `scroll-stage.tsx`; nothing drives `sceneCoverValue`, so it stays `0`
and the frame gate never stops — the scene now draws behind the closing content all
the way to the bottom of the page. Trade: the "stop drawing once covered" saving is
gone (by design — the shader is meant to show under the footer), but at the end the
scene is just the backdrop + atmosphere (brain/orb/galaxy long faded), so the cost
is small. The `sceneCover` machinery in `outro.ts` is left in place but dormant, in
case opaque closing content is reintroduced.

## ADR-0025 — Figma hero overlay + fixed site-wide header; HUD demoted

- **Status:** Accepted
- **Date:** 2026-07-11

**Context.** The hero was HUD chrome (frame brackets, brand line, status, scroll
hint) around the section-one text engine. A Figma redesign replaces it with a
marketing hero ("Turn data into decisions") and a fixed pill header.

**Decision.**
- **Header** (`components/common/site-header.tsx`) renders **once in the root
  layout**, `position: fixed`, so it is above every section and every route —
  not part of the scene overlay. Logo/nav/CTA are `next/link`.
- **Hero** (`views/home/hero/hero.tsx`) is a fixed overlay (its own `<h1>`,
  tagline, tag row, support copy, Send Request). It fades with the intro / clock,
  exactly as the old hero copy did. Figma pixels are expressed in **`vw`** (÷14.4,
  i.e. `px / 1440 × 100`), **not** `rem`: the adaptive root font-size resets its
  base per breakpoint ([[design-system]]), so `rem` *shrinks* 1440-authored
  content between 1440–1920px (root < 16px there). `vw` scales the hero linearly
  with viewport width, holding the design's proportions at every width. The header
  uses the same `vw` mapping.
- **All three sections are Figma overlays now**, so the **entire HUD / Section /
  text-reveal system is deleted.** `section-galaxy.tsx` ("Money that moves with
  you" + a four-stat band) and `section-brain.tsx` (the convergence screen) joined
  the hero; each fades on its clock window (`SECTION_WINDOWS` values, inlined).
  Removed: `hud/hud.tsx`, `hud/section.tsx`, `hud/section-cards.tsx`,
  `hud/section-meta.tsx`, `hud/frame-brackets.tsx`, `hud/hud-motion.tsx`; the
  per-line reveal bands (bands / lineRefs) are stripped from `scroll-stage`, and
  `hud/windows.ts` is trimmed to just the scroll-track scaling. `homeBrand` /
  `homeStatus` / `homeSections` are no longer wired. The scroll **tracks** (which
  advance the clock) stay — only the copy-reveal layer is gone.
- **The hero rule is WebGL** (`scene/hero-line.tsx`, renderOrder −0.5): the canvas
  clear + backdrop are opaque, so a DOM line can neither sit behind the sphere
  (hidden) nor in front (occludes it) — it has to be in the scene, between the
  backdrop and the particles. Additive particles cannot *occlude* it, so to read
  as behind the sphere the line fades out across the orb's centre footprint (a
  screen-space mask), showing only to the sides. Its Y tracks the bottom text
  cluster (24px above the tagline), scaled by width to match the vw layout.
- **Fonts:** General Sans (self-hosted woff2 via `next/font/local`) + Mulish
  (`next/font/google`), tokens `--font-general` / `--font-tag`.

**Consequences.** There is exactly one `<h1>` (the hero); scroll sections are
`<h2>`. The header is global chrome now, so future routes inherit it. The old
VESPER narrative copy still plays on the galaxy/brain scroll — it was out of scope
to restyle, and now reads against a different hero brand; revisit if the rebrand
extends past the hero. Self-hosted font files live in `src/app/fonts/`.

## ADR-0024 — The third act is a point-cloud brain, not the returning orb + logo

- **Status:** Accepted
- **Date:** 2026-07-11

**Context.** The final act used to be the orb re-forming, opening its core over a
spinning VESPER logo plane, and rushing the camera (`orbCoreOpen`/`orbApproach`,
ADR-0020/0022). The brief changed: replace that "blob with the logo" with a
GLB-sampled point-cloud **brain**, recoloured to the project palette.

**Decision.** Add a third form, `scene/brain/` — parallel to orb and galaxy:
- `brain-geometry.ts` flattens a GLB to a world-space triangle soup and
  **area-weighted-samples** ~130k points (per-tier) with geometric normals, then
  recenters and scales to a bounding radius. Only the model's geometry is used.
- `brain-shaders.ts` is the source scene's additive point material verbatim —
  vertical cool→warm tint, bright silhouette edge, white-hot synapse flashes,
  tangential flow shimmer. Colours are uniforms, recoloured in `BRAIN_CONFIG` to
  the orb's form gradient (indigo `#582eff` → mint `#52ffa5`, indigo edge, black
  interior — so it matches the first scene) and uploaded **linear** via
  `hexToLinearVec3` (the source's raw hex would wash out under our sRGB output —
  ADR from the linear-colour rule).
- `brain.tsx` loads the GLB with drei `useGLTF` (vendored same-origin at
  `public/assets/brain/rotten-brain.glb`, not the CDN), builds the material per
  ADR-0018, and drives it from the clock: `brainAppear` (2.6→3.4) fades it in and
  doubles as the explode→converge assembly, so it gathers as the galaxy blows.
  Cursor halo + swivel and a scroll-driven spin reuse the shared camera/pointer.

To free the act, the **keyframes changed**: `orbOut` now holds at 1 through
keyframes 3–4 instead of returning to 0, so the orb stays scattered and never
re-forms. The `LogoPlane`/`logo-texture` files are deleted. This **amends ADR-0016
and ADR-0022**, which had preserved the orb's return — that beat is intentionally
gone.

**Consequences.** A real GLB now loads, so `useProgress` gates the loader on it
(the loader always anticipated this — see [[webgl-scene]]); the vendored asset adds
~4.7 MB to first load, and `useGLTF` suspends `MainScene` until it arrives. Peak
point count stays ~one form's worth — the galaxy is hidden (`visible=false`) by the
time the brain assembles. `orbCoreOpen`/`orbApproach` are now dormant. Brain colour
lives in `BRAIN_CONFIG` and is **wired into the live colour panel** (a Brain
section — tint, edge, synapse, cursor, glow — via a `brain` slice of the colour
store). The brain rests side-on (`baseRotationY`, −90° + a 15° CCW nudge) through
assembly and spins horizontally (`scrollSpin`) only once scrolled past clock ~3.5.
Its **exit** is driven by the outro clock (the closing section's arrival): the
brain rushes toward the camera (`position.z → approach`) and bursts apart
(`uExplode → 1`, reusing the assemble term) as the section slides up, then fades.

## ADR-0023 — A runtime colour-authoring store shadows the scene palette

- **Status:** Accepted — **the panel was removed 2026-07-12; the store remains**
- **Date:** 2026-07-11

> [!warning] Amendment (2026-07-12) — the "Colors" panel is gone
> `views/home/hud/color-panel.tsx` — the bottom-right toggle, the per-form sliders,
> the "Copy JSON" export — was removed on request. It was dev-only
> (`process.env.NODE_ENV`) and never reached production, so nothing about the built
> site changes.
>
> **`lib/scene/color-store.ts` stays.** It is not merely the panel's backing state:
> all five scene components read it every frame via `getSceneColors()` /
> `subscribeSceneColors()`, and `constants.ts` seeds it. Ripping it out would mean
> rewiring every uniform refresh for no gain.
>
> The consequence is only that the *fast* edit loop is gone: retuning a scene colour
> means editing `constants.ts` and reloading. That was always the source of truth —
> the panel existed to make the loop quick, not to own the values. Everything below
> still describes the store accurately; treat the panel half as history.

**Context.** Scene colours are literals in `lib/scene/constants.ts` (WebGL values
that cannot reference a CSS custom property, so they sit outside the token system —
see ADR-0012). Tuning them meant edit → HMR → look → repeat. The ask was a live
panel to retune every scene/backdrop colour and export the result.

**Decision.** Add `lib/scene/color-store.ts` — a plain zustand store seeded from
`constants.ts` (`SCENE_COLOR_DEFAULTS`), read imperatively by the scene
(`getSceneColors()` / `subscribeSceneColors()`) and declaratively by the panel
(`useSceneColorStore(selector)`), mirroring the timeline's split. `backdrop`,
`atmosphere`, `orb`, and `galaxy` subscribe on mount and refresh their shader
uniforms in place via a new allocation-free `setLinearVec3(target, hex)` in
`scene/color.ts`; the per-frame lerps now read the store-backed endpoints instead
of memoised constants. The panel (`views/home/hud/color-panel.tsx`) is mounted
**dev-only** (`process.env.NODE_ENV === "development"`) from `scroll-stage`, so it
tree-shakes out of production; it serialises the live palette to JSON to paste back
into `constants.ts`.

**Consequences.** `constants.ts` stays the source of truth — the store only shadows
it, and prod behaviour is unchanged (the store defaults to the same literals). The
panel is an authoring tool, so it uses fixed-px utilities rather than the
viewport-scaled `rem` tokens the product UI uses. When a tuned palette is chosen,
paste the exported values back into `constants.ts` and the shadow disappears.

**Also in this pass (scene fidelity, not architectural).** Desktop/laptop DPR caps
raised 1.5 → **2** and 1.35 → **1.75** — capped at 1.5 the point sprites upscaled
and read soft on HiDPI displays; cost is `∝ dpr²` so 2 is the desktop ceiling.
Desktop/laptop `progressLerp` lowered 1 → **0.16** and 0.55 → **0.18** so the
orb→galaxy clock eases toward the scroll position instead of tracking it 1:1,
making the handoff glide. Both live in `scene/adaptive.ts`.

## ADR-0022 — On "Enter the unknown", the orb approaches the camera and distorts

- **Status:** Accepted
- **Date:** 2026-07-11

**Context.** Across the final section the returning orb used to sink straight down
(`orbSink`, a negative `group.position.y`). The direction called for it to instead
**rush toward the camera and warp** as it fills the frame.

**Decision.** Replace `orbSink` with `orbApproach` (0→1 over clock 3.4→4.0, held
until the core has opened). In `orb.tsx` it drives `group.position.z` toward the
camera (`orbMoveY × ORB_CONFIG.approach`) and swells the displacement noise
(`uDeform × (1 + approach × distortGain)`), so the surface churns as it nears. The
core still opens first, giving the logo its beat before the orb charges the
viewer. `orbMoveY` (formerly the sink distance) is repurposed as the per-tier
approach distance.

**Note.** A hollow particle-sphere ("blob") was also prototyped to replace the
spiral galaxy in the second scene, then **reverted** — the galaxy's look and
transition read stronger, so it stays. Only the orb exit above landed.

## ADR-0021 — The scene renders on demand, at a per-tier frame rate

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** The scene is fill-rate bound: cost scales with
`points × pointSize² × dpr²`. A free-running `frameloop="always"` spends the same
budget on a phone as on a workstation, and keeps spending it while the scene is
hidden behind the closing sections — which is most of the page's scroll length.
A starved frame loop is not a cosmetic problem here: react-spring is rAF-driven,
so it freezes the loader curtain and the HUD with it (see ADR-0018's context).

**Decision.** Four device tiers in `scene/adaptive.ts` (desktop / laptop / tablet /
phone), each pinning:

| | orb pts | galaxy pts | dpr | fps | bloom | clock lerp |
|---|---|---|---|---|---|---|
| desktop | 23 000 | 67 781 | 1–1.5 | 60 | on | 1.0 |
| laptop | 17 000 | 43 361 | 1–1.35 | 60 | on | 0.55 |
| tablet | 11 000 | 25 351 | 0.9–1.25 | 45 | on | 0.35 |
| phone | 6 500 | 12 141 | 0.75–1.1 | 30 | **off** | 0.22 |

Total live points fall from 167 091 to 91 041 on desktop (−45%) and 18 731 on a
phone (−89%). The orb halved with no visible change — at this point size the
sphere was over-sampled.

The `<Canvas>` runs `frameloop="demand"`. `FrameGate` drives `invalidate()` from
the shared ticker at the tier's frame rate, and **skips entirely** when the tab is
hidden or when `getOutro() >= 0.995` — i.e. once the closing sections own the
frame. Measured: 320 GL draw calls per 3 s on the hero, **0** on the outro.

`AdaptiveDpr` was removed; it fights `demand` and the dpr is now pinned per tier.

**Consequences.** A low frame rate makes an un-smoothed scroll clock *step*. So
the clock is now eased: `configureTimeline(progressLerp)` and `advanceTimeline()`
lerp `progress` toward the scroll target, frame-rate independently
(`1 - (1 - k)^(dt·60)`). The lerp runs on the **ticker**, not the render loop, so
the HUD keeps moving while the scene is not drawing.

Bloom is off on phones: a full mipmap chain dominates the frame at any dpr.

---

## ADR-0020 — The orb's core is bored in object space, not stamped in screen space

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** The orb's hollow centre was a *view-space* mask: the shader took each
point's angular radius from the view axis (`length(mv.xy) / -mv.z`) and faded out
anything inside a threshold. That is a perfect circle in screen coordinates. It
reads as a circle drawn **over** the blob — the rim ignores the surface it is
cutting, and the blob's noise displacement slides underneath it.

It was also brittle: the thresholds are angular, so their usable range depends on
the camera distance. An "open" value above ~0.26 erased the entire sphere,
because that is all the orb subtends at the hero camera.

**Decision.** Bore the hole in the orb's own object space. The camera position is
transformed into the points' local frame each frame (`uCamLocal` — recomputed
after the spin, from a fresh world matrix), and the shader measures each point's
radial distance from that axis:

```glsl
vec3 axis = normalize(uCamLocal);
float radial = length(pos - axis * dot(pos, axis));
float bore = mix(0.36, 0.56, uCore) * (1.0 + disp * 0.55);
float hole = smoothstep(bore, bore + 0.10, radial);
```

`pos` is the **displaced** position and the radius is modulated by the same `disp`
noise, so the rim rides the blob's surface and wobbles with it. Because the cut is
a cylinder rather than a disc, it removes front *and* back, so it is a genuine
tunnel — the far surface is visible through it.

**Consequences.** The radii are now fractions of the unit sphere, independent of
camera distance, and can be reasoned about directly: the logo plane's half-size
(0.35) simply has to stay under the open bore (0.56).

The axis must be recomputed **after** the per-frame spin, and `updateMatrixWorld()`
called first — otherwise the bore lags a frame behind the rotation and visibly
swims.

---

## ADR-0019 — Sequenced stages are derived from the clock, not keyframed

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** The 0→4 clock samples five keyframes at integer positions. Several
beats have to happen *in sequence inside a single keyframe span* — across 3→4 the
orb's core must open, hold, and only then sink. Keyframes cannot express that:
both would ramp together across the whole span.

Two further problems came from keyframing raw linear values:
- The camera keyed off raw `galaxyIn`, so it began retreating on the first pixel
  of scroll and yanked the orb into the distance while it was still half-visible.
  It read as the orb *vanishing* rather than dissolving.
- Linear `orbOut` snapped the hero apart immediately and popped it out at the end.

**Decision.** Keep the keyframes for the coarse shape, and express everything
that needs a curve or a phase offset as a **derived selector** over the clock:
`orbDissolve`, `orbAlpha`, `orbCoreOpen`, `orbSink`, `galaxyAppear`,
`galaxyAssemble`, `galaxyBlow`, `galaxyPresence`. Each is a pure function, so a
beat can be retimed by editing one `smoothstep` range.

Crucially `galaxyPresence` now tracks `galaxyAppear` rather than raw `galaxyIn` —
the camera stays with the orb until the orb has actually gone.

**Consequences.** Adding a beat no longer means adding a keyframe column and
re-timing every other key. The keyframe table stays a coarse skeleton; the feel
lives in the selectors.

> [!warning] Shader thresholds are not free parameters
> `uCore` opens the orb's hollow centre by widening an **angular** radius. The
> orb only spans ~0.26 of that at the hero camera distance, so an "open" value
> above it makes the cut-out swallow the whole sphere. Likewise the galaxy's
> assembly spawn radius is in galaxy-local units and is multiplied by
> `uScale` (0.18); too large and the inbound shell encloses the camera. Both were
> caught only by looking at rendered frames.

---

## ADR-0018 — Scene materials are constructed, not declared

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** Every scene object animated by writing to a memoised `uniforms`
object each frame and passing it as a prop:

```tsx
const uniforms = useMemo(() => ({ uAppear: { value: 0 } }), []);
<shaderMaterial uniforms={uniforms} … />
useFrame(() => { uniforms.uAppear.value = getIntro(); });
```

**r3f does not keep that object.** `material.uniforms !== uniforms`. Every
per-frame write landed in a detached object the GPU never read. Confirmed in a
real browser: `uAppear` on our object climbed to `0.993` while the material's
stayed at `0`.

The result was a scene that rendered nothing and never moved — the orb and galaxy
sat at `uAppear = 0` (fully transparent), the backdrop and atmosphere at
`uTime = 0` (frozen). It looked exactly like a broken shader, and read exactly
like "the particles aren't showing and aren't playing".

**Decision.** Build the `THREE.ShaderMaterial` in a `useMemo` and hand r3f the
instance: `<points geometry={geometry} material={material} />`. Three's
constructor assigns `parameters.uniforms` by reference (verified), so the object
stays live.

**Consequences.** All four scene objects (`Orb`, `Galaxy`, `Backdrop`,
`Atmosphere`) construct their own material. Never reintroduce
`<shaderMaterial uniforms={…}>` for anything animated from `useFrame`.

Two rendering bugs were found in the same investigation and fixed alongside:

- **Colour management.** The renderer runs `outputColorSpace = SRGBColorSpace`,
  so shader colours must be **linear**. The source scenes uploaded raw hex bytes
  on a `WebGL1Renderer` with no output encoding; carried over unchanged, every
  colour was encoded to sRGB twice. `#170a2b` — a near-black violet — rendered as
  washed lavender (raw `0.090` vs linear `0.009`, a 10× error). All palettes now
  go through `scene/color.ts`.
- **Bloom threshold is in linear light.** `luminanceThreshold: 0.22` was tuned
  against the doubly-encoded values; in linear space it caught the background and
  smeared the frame. Now `0.55`, with an explicit `radius` — `mipmapBlur`
  defaults to a near-full-screen radius.

---

## ADR-0017 — Two scene forms share one travelling camera

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** The hero orb and the spiral galaxy were authored as separate
standalone scenes, each with its own camera: the orb close (`z ≈ 3.8`, fov 50),
the galaxy far out (`z = 48`, diving to 18, fov 45). A single canvas can only
have one active camera, and the two forms must coexist on one scroll clock — the
orb even *returns* at the tail of the timeline while the galaxy disperses.

Three options: rescale one form to the other's camera distance; swap cameras at a
cut; or move the one camera between the two stations.

**Decision.** Move the camera. `CameraRig` interpolates its `z` between
`orbCameraZ` and the galaxy's diving `z` using `galaxyPresence`, and interpolates
the pointer sway between the orb's whisper (0.35) and the galaxy's orbit (4.0).

Rescaling was rejected because the orb's "oil" pointer disturbance is expressed
in world units against a unit sphere; scaling it would have meant scaling the
bulge, ripple, drag, and ray-cast radius in lockstep. A hard cut was rejected
because the timeline explicitly cross-fades the two forms.

**Consequences.** Each form keeps its authored scale and tuning. The galaxy's
dive reads as immersion rather than a fade, and because `galaxyPresence` returns
to 0 as the galaxy blows apart, the camera retreats to the orb exactly as the orb
re-forms — for free, with no extra keyframe.

The orb drifts vertically late in the timeline, so its shader takes a `uCentre`
uniform: the world-space oil disturbance resolves against the orb's actual centre
rather than assuming the origin.

Two smaller consequences of the same change:
- The source scenes composited their background + "flame" warp in a post pass
  after bloom. That is now a clip-space quad drawn beneath the additive
  particles — visually equivalent, and it gives the palette crossfade a home.
- `Stars` was deleted. It recycled stars against a static `camera.position.z`,
  which a travelling camera breaks. The `Atmosphere` motes both source scenes
  ship are camera-attached and work at any depth.

---

## ADR-0016 — The scroll clock is `p1 + 2·p2 + p3`

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** The landing page is driven by a single 0→4 "global clock"
that keyframes both the WebGL scene and the HUD. In the source it was built from
four `framer-motion` `useScroll` progresses, summed. Three of them measure a
viewport-tall track against the viewport *top*. The fourth measures the **third
track** against the viewport *bottom* — which resolves to exactly the same value
as the second track.

The clock is therefore `p1 + 2·p2 + p3`, not `p1 + p2 + p3 + p4` of four distinct
windows. It is piecewise-linear: 1× over the first track, **2× over the second**,
1× over the third. Every keyframe in the scene was authored against that shape.

**Decision.** Reproduce the clock exactly, duplicated track and all. Four
`useProgressTrigger` calls write into `sceneTimeline`, which sums them and
samples the keyframe track. `progressToTracks()` in `hud/windows.ts` inverts the
piecewise map so HUD reveal windows expressed in clock units can be turned back
into real scroll geometry.

**Consequences.** A "cleaner" port that maps one 0→1 scroll progress onto 0→4
would silently desynchronise every scene keyframe — the blob would scatter at the
wrong scroll depth, and the galaxy would assemble a full track early. The
duplicated track is preserved deliberately; do not "fix" it without re-timing all
five keyframes.

The scene reads the clock imperatively (`sceneTimeline.getState()`) inside
`useFrame` rather than through React state — a per-frame `setState` would
re-render the tree 60 times a second.

---

## ADR-0015 — React Compiler lint rules are scoped off for the WebGL scene

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** `react-hooks/immutability` and `react-hooks/purity` (the React
Compiler rules shipped with `eslint-config-next` 16) reject two things that are
the documented `@react-three/fiber` idiom: mutating meshes, uniforms, and the
camera inside `useFrame`, and seeding geometry with `Math.random()` while
building it. Together they produced 16 errors across the scene.

**Decision.** Turn both rules off for `src/views/home/scene/**` only, via a
scoped block in `eslint.config.mjs`. The rest of the app keeps them.

**Consequences.** The scene is exempt from compiler-assisted safety checks. That
is acceptable because it owns no React state — it is a render loop that reads a
store. Do not widen this override beyond the scene folder.

A genuine violation was found and fixed rather than suppressed: `loader.tsx` wrote
to a ref during render (`react-hooks/refs`), now moved into an effect.

---

## ADR-0014 — Third authorized engine edit: `ElementType` → opaque component cast

- **Status:** Accepted
- **Date:** 2026-07-10

**Context.** `@react-three/fiber` v9 augments JSX globally:

```ts
declare module 'react' { namespace JSX { interface IntrinsicElements extends ThreeElements {} } }
```

(and the same for `react/jsx-runtime` and `react/jsx-dev-runtime`). The moment any
file imports r3f, every three.js element joins `JSX.IntrinsicElements`. The
animation engine casts `animated[tag] as ElementType`; against the widened union
TypeScript resolves the tag's props to `never`, producing 34 errors across five
`#do-not-modify` files. Verified as caused by the import: on the pristine tree with
the dependencies installed `tsc` reports zero errors, and a single file importing
`@react-three/fiber` reproduces all 34.

There is no opt-out. The augmentation covers all three JSX entry points, and
declaration merging can add interface members but never remove them.

**Decision.** With explicit sign-off, the **third** authorized edit to the engine
(after ADR-0009 and ADR-0013). Six lines across five files:

```diff
- const Tag = animated[tag] as ElementType;
+ const Tag = animated[tag] as unknown as React.ComponentType<Record<string, unknown>>;
```

Type-only; no runtime behaviour changes. An opaque prop type stops the widened
union from dragging tag resolution into an SVG or three.js element.

**Consequences.** `tsc --noEmit` is clean. Props passed to spring components are
no longer checked against the specific tag's DOM props — an acceptable trade,
since the previous `ElementType` cast already erased most of that. The engine
otherwise stays vendored and protected.

---

## ADR-0013 — `<Inview>` self-observe fix; spring components honour resize

- **Status:** Accepted
- **Date:** 2026-06-07

**Context.** `<Inview>` only animated when an external `trigger` ref was passed.
Without one it never revealed. Root cause: `useDynamicInView` returns its target
attachment as a **callback ref** (`setNode`) in the first tuple slot, but
`in-view.tsx` destructured it as `inViewRef` and wrote `inViewRef.current = node`
in the JSX `ref` callback — assigning `.current` to a function instead of calling
it. `setNode` never ran, the observed `node` stayed `null`, and with no `trigger`
the observer had nothing to watch (`trigger?.current ?? node` → `null`). With a
`trigger` it worked only because `trigger.current` bypassed the dead `node` path.
TypeScript flagged this at build time (`Property 'current' does not exist on type
'TargetRefCallback'`), so the build was already failing.

Separately, `<Inview>`, `<Spring>`, and `<Hover>` tracked `width`
(`useWindowWidth()`) as a `useMemo`/`useEffect` dependency to re-evaluate mobile
gating on resize, but never passed it to `isMobileDisabled()` — so the value was
genuinely unused (ESLint `react-hooks/exhaustive-deps` warning) **and** resize
re-evaluation silently did nothing; the check always read `window.innerWidth` at
call time.

**Decision.** This is the second authorized edit to the `#do-not-modify` engine
(after ADR-0009). Two corrections:
1. In `in-view.tsx`, call the callback ref — `setInViewNode(node)` — instead of
   assigning `.current`, so the component observes itself when no `trigger` is
   given.
2. Pass the React-tracked `width` into every `isMobileDisabled(value, width)`
   call across `in-view.tsx`, `spring.tsx`, and `hover.tsx`. This is the
   documented second parameter of `isMobileDisabled` and makes the `width`
   dependency meaningful, fixing resize re-evaluation and clearing the lint
   warnings.

**Consequences.** `<Inview>` now works standalone (the common case). `yarn build`
and `yarn lint` are both clean (0 errors, 0 warnings). The springs folder remains
`#do-not-modify` by default — these were explicitly signed-off bug fixes.

---

## ADR-0012 — Styling lives in utilities and components, not `globals.css`

- **Status:** Accepted
- **Date:** 2026-05-22

**Context.** ADR-0004 made design tokens the styling currency and ruled that
"new values must be added to `globals.css` first." Combined with the
design-system guidance to *"extract repeated multi-class patterns to
`@layer components`"*, the path of least resistance for any repeated visual
pattern became a named class in `globals.css`. On an animation-heavy,
multi-section marketing site that grows the file without bound — a single
global stylesheet accumulating hundreds of component-specific classes that are
never deleted when their component is. The fix is a placement rule, not a
file-splitting trick: splitting `globals.css` into many files only spreads the
same bloat.

**Decision.** Styling follows a strict placement order; `globals.css` stays
bounded by design.

- One-off styling → **Tailwind utilities** in `className`. Nothing enters CSS.
- A repeated pattern with markup/structure/props → a **React component**
  (`components/ui/`), *not* a CSS class. This is the default answer to "this
  looks repeated" — e.g. an eyebrow label with a `::before` dot is an
  `<Eyebrow>` component, not a `.label-eyebrow` class.
- A repeated pure-utility combo with no structure → a Tailwind v4 `@utility`.
- `@layer components` is reserved **strictly** for what utilities and
  components genuinely cannot express: pseudo-elements (`::before`/`::after`),
  third-party DOM overrides (`!important` on library markup), complex
  descendant/state selectors.
- `globals.css` only ever holds: `@import`, tokens (`:root` + `@theme`), base
  element resets (`@layer base`), and the narrow `@layer components`
  exceptions above. If it grows past that, something was misplaced.
- CSS Modules were considered and **rejected** — a second styling mechanism
  for the rare bespoke-CSS case is not worth the extra mental model when
  motion is spring-based (no keyframes — ADR-0002) and utilities + components
  cover everything else.

**Consequences.** `globals.css` stays a few-hundred-line file indefinitely.
"Repeated thing" pressure now pushes toward React components — which the
project wants anyway. This **amends ADR-0004**: design *tokens* still go in
`globals.css` first, but component-specific *classes* no longer do.
[[design-system]] and [[component-conventions]] updated to match.

---

## ADR-0011 — API layer: `app/api` route handlers, secrets server-side

- **Status:** Accepted
- **Date:** 2026-05-22

**Context.** The starter had no API layer. It needs a convention for reaching
external services that keeps secret keys off the client and gives endpoints a
consistent shape.

**Decision.** External calls go through Next.js Route Handlers —
`src/app/api/<resource>/route.ts`:
- **The handler owns the work** — business logic, multiple upstream calls,
  filtering, and reading secret env vars all live in `route.ts`. No mandatory
  passthrough service layer; extract shared code only when genuinely reused.
- Secrets are safe in handlers because `route.ts` is never bundled to the
  browser. Secret env vars are **unprefixed**; `NEXT_PUBLIC_` only for
  browser-safe values.
- Every endpoint: validates input with `zod`, returns the `{ data }` /
  `{ error }` envelope via the shared `handle()` wrapper (`src/lib/api/`), runs
  on the Node runtime (not Edge).
- `src/env.ts` validates env with zod — `publicEnv` vs `getServerEnv()`.
- Client Components fetch via `apiFetch` (`src/lib/api-client.ts`), same-origin
  only. Render-time data is read in Server Components.
- Added `zod`. The example endpoint is `app/api/contact/route.ts`.
- Codified as **AGENTS.md hard rule #9**.

**Consequences.** A clear, secret-safe API convention (full note:
[[api-architecture]]). Server Actions were considered for mutations but
deferred — for now everything goes through `app/api`. The choice can be
revisited if forms need progressive enhancement. First server dependency
(`zod`) and first server-only env var (`CONTACT_ENDPOINT`) now exist.

---

## ADR-0010 — SEO & performance hardening

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** A review found gaps that would hurt a production marketing site:
`metadataBase` defaulted to `null` (relative OG/canonical URLs never resolved to
absolute — broken social previews); `themeColor` sat on the deprecated metadata
field; there was no `robots.txt`, `sitemap.xml`, or structured data; the
`next.config.ts` was empty; `ScrollLayout` leaked a `requestAnimationFrame`
loop; the home view was a top-level `"use client"` (violating hard rule #6);
and the animation-heavy starter ignored `prefers-reduced-motion`.

**Decision.**
- **Site config.** `src/lib/site.ts` (`siteConfig`) is the single source of
  truth for SEO, fed by `NEXT_PUBLIC_SITE_URL` (fallback `http://localhost:3000`).
- **Metadata.** `metadataBase` is always set; `themeColor` moved to a
  `generateViewport()` / `viewport` export; dead `keywords` / `other` tags
  dropped; OG dimensions corrected to match the asset.
- **Crawlability.** Added `app/robots.ts`, `app/sitemap.ts`, and a JSON-LD
  `Organization`+`WebSite` helper rendered once in the root layout.
- **App Router files.** Added `loading.tsx` (enables streaming), `error.tsx`,
  `not-found.tsx`.
- **Rendering.** `HomeView` is a Server Component; client-only animation moved
  to the `HomeShowcase` leaf — models hard rule #6 instead of breaking it.
- **Reduced motion.** `<ReducedMotion>` calls react-spring's `useReducedMotion`,
  toggling the global `skipAnimation` — one app-root mount covers every spring
  and `spring-text-engine`. Chosen over per-component handling for its reach.
- **Build config.** `next.config.ts` now sets `removeConsole` (prod),
  AVIF/WebP, `next/image` breakpoints aligned to the adaptive-grid widths, and
  `poweredByHeader: false`. React Compiler is left as a documented opt-in (needs
  `babel-plugin-react-compiler`).
- Fixed the `ScrollLayout` Lenis rAF leak (cancel on unmount).

**Consequences.** Social/SEO metadata is correct in production once
`NEXT_PUBLIC_SITE_URL` is set. The first project env var now exists (see
[[environment-variables]]). `isBot()` stays available but is discouraged — it
opts routes out of static rendering; reduced-motion is the preferred lever (see
[[seo-metadata]]). React Compiler remains opt-in pending a dependency install.

---

## ADR-0009 — Shared animation ticker; authorized engine performance refactor

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** A performance review of the animation engine found load issues that
scale with the number of animated components on a page:
- `useLoop` started a **private `requestAnimationFrame` loop per hook instance** —
  N scroll-driven components meant N rAF loops, none of which ever stopped.
- `useWindowWidth` attached a **separate debounced `resize` listener per call** —
  one per spring component.
- `useDynamicInView` re-created its `IntersectionObserver` **on every render**
  (effect keyed on an unstable `options` object), and a dead `Proxy` branch
  created observers that were never disconnected.
- `useLoop`'s mount-only effect captured a **stale `onRender`**, so prop changes
  after mount were ignored.
All of this lives under `src/hooks/animation/` and `src/components/animation/springs/`
— `#do-not-modify` (ADR-0002).

**Decision.** With explicit user sign-off, apply a one-time performance refactor
to the protected engine, and introduce a shared, unprotected loop primitive:
- New `src/lib/animation/ticker.ts` — a single app-wide, reference-counted rAF
  loop (`subscribeToTicker`). It starts on the first subscriber, stops on the
  last, and throttles each subscriber independently. **Not** `#do-not-modify` —
  it is the supported extension point.
- `useLoop` now subscribes to the ticker and reads `onRender` / `framerate`
  through refs (fixes the stale-closure bug). Public signature unchanged.
- `useDynamicInView` rewritten without the `Proxy`: one observer, re-created only
  when the observed element or options actually change; exposes a callback ref.
- `use-window-size.ts` (not protected) now serves all three hooks from one
  debounced `resize` listener via `useSyncExternalStore`. The unused
  `debounceDelay` parameter was dropped.
- `mode="forward"` `scroll` listeners in `<Spring>` / `<Inview>` made `passive`.
- Hard rule #2 amended: the engine stays protected by default; changes require
  explicit sign-off.

**Consequences.** A page with N animated components now runs **one** rAF loop and
**one** resize listener instead of N of each, with no observer churn. Public
hook/component APIs are unchanged except `useWindowWidth`/`Height`/`Size`, which
no longer take a `debounceDelay` argument (no caller passed one). This **amends
ADR-0002's** do-not-modify scope.

A follow-up pass then cleared all 13 pre-existing ESLint problems in the engine
(also authorized): `isMobileDisabled` gained an optional `viewportWidth`
argument, missing `disableOnMobile` effect deps were added, a
`trigger.current`-in-cleanup hazard in `<Hover>` was fixed, `<Handle>`'s
transition effects were ref-stabilised, and `useProgressTrigger` now returns
`progress` as a `RefObject<number>` (no consumer affected).

---

## ADR-0008 — Adaptive scaling grid via root font-size

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** An adaptive scaling system was dropped into `src/components/common/`
to keep a rem-based design proportional across viewports. It shipped as a
`styled-components` implementation (`createGlobalStyle`, a `css` `media` helper,
`rm`/`em` helpers, plus `colors.ts` / `fonts.ts` / `utils.ts`). `styled-components`
is not a project dependency, and global CSS belongs in `globals.css` per ADR-0004.

**Decision.** Keep only the scaling behaviour; rebuild it to the project stack.
- **Scale down** (viewport ≤ largest breakpoint) — `vw`-based `html { font-size }`
  media queries in `globals.css`, inside `@layer base`.
- **Scale up** (viewport > largest breakpoint) — a `<AdaptiveGrid>` client
  component (`useAdaptiveGrid` hook) sets an inline `html` font-size at runtime,
  reusing the existing `useResizeLoop` render loop.
- Breakpoints live in `grid.config.ts` as typed config; the `globals.css` media
  queries mirror them and must be kept in sync (formula in both files).
- The dropped `styled-components` files were deleted, not committed.

**Consequences.** A rem-based layout now scales as one unit on every viewport.
`styled-components` stays out of the dependency tree. The breakpoint set is
duplicated across `grid.config.ts` and `globals.css` by design — the CSS-only
config rule (ADR-0004) forbids generating the media queries from JS.

---

## ADR-0007 — Automate the vault workflow with Claude Code hooks

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** The "read the vault first, follow the relevant guide, update the docs
after every change" workflow depended on the user reminding the agent each time.
Documentation drifts the moment it relies on memory.

**Decision.** Encode the workflow as Claude Code hooks in `.claude/settings.json`
(committed, team-wide):
- `SessionStart` — injects a pointer to read the vault first.
- `UserPromptSubmit` — on every request, reminds the agent to consult the relevant
  guide and to update docs for any change made.
- `Stop` — at the end of every turn, blocks **once** to confirm the vault was
  updated. A `${TMPDIR}` marker keyed by session id guarantees it blocks at most
  once per turn (no infinite loop).

**Consequences.** The documentation workflow is enforced without user prompting.
`.claude/settings.json` is now a tracked project file. Hooks are reviewable and
disableable via `/hooks`. New hooks take effect on the next session start (or after
opening `/hooks`). See [[ai-agent-guide]].

---

## ADR-0006 — The vault is the single source of truth

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** ADR-0001 left dense spec files (`project-specs.md`, `text-engine-docs.md`)
at the repo root alongside the vault, creating duplication — the same conventions
existed both as terse specs and as expanded vault notes, which would drift.

**Decision.** The vault is the **only** documentation source.
- `project-specs.md` — deleted; its content was already decomposed into the
  `architecture/` and `frontend/` notes (and `environment-variables.md`).
- `text-engine-docs.md` — moved into the vault as [[text-engine-reference]].
- `generic-layout-prompt.md` — moved into the vault (see ADR via [[changelog]]).
- Root keeps only thin shims: `AGENTS.md` carries the breaking-change warning and
  hard rules and points into the vault; `CLAUDE.md` and `.cursorrules` both
  `@`-import `AGENTS.md`.

**Consequences.** No documentation duplication. Agents bootstrap from `AGENTS.md`
and read vault notes on demand. This **amends ADR-0001** — root files no longer
hold canonical spec content.

---

## ADR-0005 — Use standard `next/link` for navigation

- **Status:** Accepted
- **Date:** 2026-05-21

**Context.** Two conflicting conventions existed: `project-specs.md` specified
standard `next/link` / `useRouter`, while `generic-layout-prompt.md` specified
custom `<AnimLink>` / `useAnimRouter()` wrappers. The custom wrappers were never
built.

**Decision.** Use standard Next.js navigation — `<Link>` from `next/link` and
`useRouter` from `next/navigation`. The `AnimLink` / `useAnimRouter` convention is
dropped. See [[routing]].

**Consequences.** `generic-layout-prompt.md` §5 updated to match. No animated-route-
transition layer exists; if one is needed later, revisit with a new ADR.

---

## ADR-0001 — Adopt an Obsidian vault as the project brain

- **Status:** Accepted — amended by ADR-0006
- **Date:** 2026-05-21

**Context.** Project knowledge was scattered across root markdown files
(`project-specs.md`, `text-engine-docs.md`, `AGENTS.md`). New contributors and AI
agents had no structured map of the system.

**Decision.** Introduce `obsidian/` as an Obsidian vault — a linked, navigable
second brain. Root spec files remain as machine-read sources; the vault expands on
them. See [[ai-agent-guide]].

**Consequences.** Docs must now be maintained alongside code. The vault is the
canonical place to *understand* the project; root files stay canonical for *tooling*.

---

## ADR-0002 — All motion is spring-based (`@react-spring/web`)

- **Status:** Accepted (inherited from starter)
- **Date:** Project baseline

**Context.** Marketing sites need rich, interruptible, physically natural motion.
CSS transitions and keyframes are rigid; competing libraries add weight.

**Decision.** Use `@react-spring/web` for every animation. A custom component layer
(`src/components/animation/springs/`) wraps it. CSS transitions, CSS keyframes, and
`framer-motion` are **banned**.

**Consequences.** All animation goes through the [[animation-system]]. The springs
folder is `#do-not-modify`. Text animation is delegated to [[text-engine]].

---

## ADR-0003 — Routes delegate to Views

- **Status:** Accepted (inherited from starter)
- **Date:** Project baseline

**Context.** Mixing routing concerns with page UI makes `app/` files heavy and hard
to test.

**Decision.** `app/**/page.tsx` files only import and render a component from
`src/views/`. All layout/UI logic lives in the view. See [[routing]].

**Consequences.** Every route is a 3-line file. Views are the real page components.

---

## ADR-0004 — Tailwind v4 with CSS-based config

- **Status:** Accepted (inherited from starter)
- **Date:** Project baseline

**Context.** Tailwind v4 removes `tailwind.config.js` in favour of CSS-native config.

**Decision.** All theme tokens live in `globals.css` under `:root` and `@theme inline`.
No JS config file. Raw values in class names are banned. See [[design-system]].

**Consequences.** Design tokens are the only styling currency. New values must be
added to `globals.css` first.
