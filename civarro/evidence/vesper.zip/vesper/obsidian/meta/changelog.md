---
tags: [meta, changelog]
updated: 2026-07-12
---

# Changelog

Chronological log of notable changes to the project. Newest first.
This is a human-curated log — not a mirror of `git log`.

## 2026-07-12 — hover + press on every control; the dev "Colors" panel removed

See [[decisions-log]] ADR-0031.

- **The site had no hover states.** The header nav, the Send Request CTA, the FAQ
  rows and the footer's submit were all inert under the cursor. What existed was
  inconsistent: the footer links and cookie banner used bare `hover:` utilities
  (instant snaps), and `ui/button.tsx` wrapped itself in a `<Hover>` that **scaled
  it to 1.03**.
- **New `lib/springs/interaction.ts`** — the interaction vocabulary. Nine presets
  (`SOLID_CTA`, `GHOST`, `NAV_LINK`, `CARD_ROW`, …), each layering `hover` over
  `rest` and `press` over both.
- **New `components/ui/pressable.tsx`** — `<PressableLink>`, `<PressableButton>`,
  `usePressable`. Every control on the site now goes through it: header + mobile
  nav, both Send Request CTAs, the FAQ accordion, the footer's submit and link
  columns, `<Button>`, the cookie banner + modal, 404 and error.
- **Nothing scales.** Controls answer in colour and weight — the surface takes
  light, the border firms up, the ink shifts to the signal mint. The box never
  moves, so nothing reflows against the WebGL scene behind it.
- `usePressable` returns `{ style, bind }` separately, which is what makes the
  Send Request CTA work: the pointer meets the whole `<Link>` (block **and** arrow
  tile), but only the inner block is filled. Springing the block alone would leave
  the arrow inert.
- Fixes two real defects the old `<Hover>` had for controls: no press state, and on
  touch a tapped control lit up and **stayed lit** (`pointerenter` fires with no
  `pointerleave` behind it). Guarded on `pointerType` now.
- **The duplicated Send Request markup** in `hero.tsx` / `section-brain.tsx` is now
  `views/home/send-request.tsx`.
- **Focus rings on every pressable** (`focus-visible:outline-signal`), not sprung —
  an indicator that eases in is briefly wrong. The footer's inputs had
  `outline-none` with nothing put back; several controls sit on a live canvas where
  the UA default outline is invisible.
- **Removed the dev "Colors" panel** (`views/home/hud/color-panel.tsx`) on request —
  the bottom-right toggle, the per-form sliders, the "Copy JSON" export. It was
  dev-only and never shipped, so the built site is unchanged. **The colour store
  stays**: all five scene components read it every frame. Retuning a scene colour
  now means editing `lib/scene/constants.ts`, which was always the source of truth.
  Amends [[decisions-log]] ADR-0023.

## 2026-07-12 — responsive tablet/mobile, and a large performance pass

The look is unchanged at every width it already worked at; desktop is
pixel-identical. See [[decisions-log]] ADR-0028 / ADR-0029 / ADR-0030.

### The brain no longer ships a 4.67 MB GLB (ADR-0028)

- **`rotten-brain.glb` is deleted.** It was 4.67 MB, of which **4.5 MB was three
  PBR texture images the brain shader never read** — it samples geometry only. The
  actual mesh is 2,605 vertices / 4,850 triangles.
- **New `scripts/bake-brain.mjs`** parses the GLB container by hand, flattens it to
  world space, normalises it once (the same centroid + unit-radius transform the
  runtime used to recompute every load), and emits
  `public/assets/brain/brain-mesh.bin` — an indexed, `i16`-quantised mesh.
  **43 KB** (27 KB brotli). **172× smaller.**
- **`useGLTF` is gone.** It *suspends* — so the orb, the galaxy, the backdrop and
  the hero copy were all waiting behind that download, for a form that does not
  appear until the third act. `Brain` now `fetch`es its mesh and never blocks; a
  failed fetch logs and renders nothing instead of taking the scene down.
- Nothing in the scene goes through a three.js loader now, so `useProgress` reports
  `total: 0` and the loader runs on its minimum duration again.

### The frame gate was dropping every other frame (ADR-0030)

- `lib/animation/ticker.ts` throttled with `elapsed <= interval`. At `targetFps: 60`
  the interval is `16.6667` ms and a 60 Hz display delivers frames `16.6667` ms
  apart — so **the gate rejected frames that arrived exactly on time**, then passed
  the doubled gap. Replayed against perfect 60 Hz timestamps: **39 fps with a
  33 / 16.7 ms cadence**. That uneven cadence *is* the lag people felt.
- Fixed with a 1 ms tolerance. Desktop now genuinely runs 60 fps (was ~40); phone
  runs 30 (was ~24). This affected the scene loop, the scroll clock, and every
  scroll trigger — all of them run on this ticker.

### Paint and asset cost

- **The three section overlays go `visibility: hidden` when transparent.** They are
  `fixed inset-0`, always mounted, and their copy is split into per-letter spans
  each carrying an animated `filter: blur()`. At `opacity: 0` the browser still
  rasterised all of it over the WebGL canvas every frame — and two of the three are
  invisible at any moment. New `views/home/overlay.ts` (`useSceneClock`,
  `hiddenWhenClear`).
- **Dropped the 30px backdrop blur from the Financial and FAQ cards.** Both have
  opaque `bg-white`, so the blur was never visible — it only cost a full-card
  backdrop-filter pass per frame over the live scene.
- **`financial.png` (668 KB) now goes through `next/image`.** It was a raw `<img>`
  with an eslint-disable, while `next.config.ts` had AVIF/WebP + device sizes
  configured and unused. **668 KB → 8 KB on a phone, 18 KB on desktop** (AVIF).
- **Removed the Open Sans font** — three weights loaded in the root layout,
  referenced by nothing. `--font-display` now points at the Figma face.
- **Lenis runs on the shared ticker**, not its own rAF loop, at a new `scroll`
  priority so it writes the scroll position *before* the triggers read it back.
- **The FAQ asterisk's infinite spin is gated on in-view.** `loop: true` never
  rests, so it kept a spring — and the shared rAF loop — alive for the whole page.

### Responsive (ADR-0029)

- **Below 1024px the `vw` ladder stops.** Every Figma section is measured in `vw`
  against the 1440 artboard, which is right above 1024 and unusable below it: body
  copy at `1.111vw` is **4px on a 360px phone**, and the header pill is 14px tall.
  `html` goes back to `16px` under 1024 and each section gets a purpose-built stack
  in `rem` via `max-lg:` / `max-sm:` overrides. One DOM tree; the overrides are CSS.
- `TextEngine` hardcodes `position` inline, so the overlays use Tailwind's important
  modifier (`max-lg:static!`) to pull copy back into flow.
- **New `components/common/mobile-nav.tsx`** — burger + spring-driven drop panel,
  unmounts on rest, Escape closes. `SiteHeader` stays a Server Component.
- Hero, galaxy, brain, both white cards, the footer and the loader all reflow;
  the galaxy's four-column stat band becomes a 2×2 grid on tablet, one column on
  phone. No horizontal overflow at 1440 / 834 / 390.

## 2026-07-12 — footer heading + galaxy recoloured to the orb palette

- **Added a centred display heading to the footer** ("Let's talk.", above the
  contact form) — letter-by-letter `LETTER_REVEAL`, `font-general`, `justify-center`
  (in flow, so no `position` fix). `site-footer.tsx`.
- **Recoloured the galaxy to the orb's blue→mint gradient.** Its core was cyan
  (`#6bfdff`); now the **core is the orb's blue `#582eff`** and the arms stay mint
  `#52ffa5`, so the disc reads as the same blue→mint radial gradient (from centre
  out) as the orb and brain. One value in `GALAXY_CONFIG.colorCore`
  (`lib/scene/constants.ts`), which seeds the colour store → shader uniform.

## 2026-07-12 — Figma footer, transparent over the live shader

- **Replaced the footer with the Figma design** (`site-footer.tsx`, nodes 652-1475
  + 652-1438): a centred **contact form** (Name / Email / Contact Us — a header-style
  glass pill, `bg-black/80` + white/20 border + `backdrop-blur-8`, mint `text-signal`
  CTA), a full-width divider, then the logo + tagline (left) and three link columns
  pushed right (`justify-between`). Mulish (`font-tag`, uppercase white) for the
  tagline + headings, General Sans (`font-general`, white/70) for the links; all
  sizes in `vw` (÷14.4). The form has no backend yet — submit is a stubbed
  `preventDefault` (wire to a `/api/contact` route later).
- **Copy is on-theme**, not the Figma placeholder: tagline "A living interface that
  reads your presence and answers in motion, not chrome"; columns **Engine** /
  **Studio** / **Connect** with Vesper-flavoured links. In `homeFooter` (`legal` now
  optional and dropped — the design has none).
- **The footer is transparent, over the live background shader** (per request), so
  it no longer is the opaque surface that stopped the scene. Removed the
  `sceneCover` scroll trigger + `coverRef` from `scroll-stage.tsx`; the frame gate
  now keeps drawing the scene behind the closing content all the way down. See
  [[decisions-log]] ADR-0026 (updated).

## 2026-07-12 — softer, slower brain burst

- **The brain's exit burst was too fast and sharp** — a sliver of scroll detonated
  it. The `outro` clock that drives it ramped `0→1` over only half a viewport
  (`top bottom` → `top center`); widened to a full viewport (`top top`) so the
  scatter + camera-rush spread over ~2× the scroll. Also added a dead-zone to the
  brain's exit easing (`smoothstep(0.12, 1, outro)`) so the first sliver of scroll
  holds the assembled brain instead of bursting it. `scroll-stage.tsx`,
  `scene/brain/brain.tsx`. (`orb.tsx` also reads `outro`, but the orb is long gone
  by the closing sections, so the wider range is inconsequential there.)

## 2026-07-12 — white cards reveal with scale + blur + 3D tilt

- **The Financial and FAQ cards now animate themselves in**, not just their copy.
  Each card is wrapped in an `Inview` (`CARD_REVEAL`): it scales up (0.94→1),
  un-blurs (`blur(14px)`→0), and tilts on the horizontal axis (`rotateX 12°`→0) as
  it scrolls in — reversing on the way out (`mode="always"`). The tilt needs a
  perspective context, so the card's `<section>` became a `[perspective:1400px]`
  wrapper and the white box is the animated child (`origin-bottom` so it hinges
  from the base). `scale` / `rotateX` are react-spring transform shorthands, so
  they compose onto one `transform`. Preset in `views/home/reveal.ts`.

## 2026-07-12 — section copy aligned to the Vesper theme

- **Rewrote the hero / galaxy / brain / financial copy** — it was off-theme
  placeholder (fintech "money that moves", "financial momentum", AI "decisions").
  New copy follows the FAQ's actual product story: a living interface / rendering +
  interaction layer that reads presence (pointer, scroll, dwell) and answers in
  motion, not chrome. **Each block keeps its exact character count**, so the fixed
  `vw` boxes and per-letter/word reveals wrap identically. Brain still mirrors the
  hero + galaxy titles (the convergence idea); the Financial card's two columns are
  now two distinct bodies (what it is / how it performs) instead of one repeated.
- Galaxy stat band and hero tags reworded to match (particles / frame budget /
  cold start / fps; living-interface / motion-layer tags). Copy is still hardcoded
  in the section components (pre-existing pattern for these Figma overlays).

## 2026-07-12 — loader comets in the orb's colours

- **The preloader's falling streaks now rain down in the hero orb's gradient** —
  mint (`ORB_CONFIG.colorTop`) → cyan (`ORB.flameB`) → violet (`colorBottom`).
  Each streak samples one colour from that gradient by its `seed` (so the field
  spreads across all three at once); the head pushes ~30 % toward white so it still
  reads as a hot comet tip. Was flat white on black. `views/home/loader/star-fall.tsx`.

## 2026-07-11 — section copy reveal animations

- **Headings reveal per-letter, body copy per-word, via `spring-text-engine`.**
  Headings: letters cascade left→right with blur + opacity (no transform).
  Sub-heads / body / taglines: words rise bottom→up with blur + opacity. Very soft
  (long ease-out). Presets in `views/home/reveal.ts` (`LETTER_REVEAL`, `WORD_REVEAL`).
- **Keeping the layout put** — the engine forces `display:flex; flex-wrap:wrap` and
  `position:relative` on its container. So each absolutely-positioned reveal passes
  `style={{ position: "absolute" }}` (overrides the engine's inline `relative` —
  without it, `right-0` / centered copy falls back into flow and stacks on the left);
  flex **ignores `text-align`**, so centered / right-aligned copy gets
  `justify-center` / `justify-end`; and `columnGap` is `0.25em` to match the natural
  word space. Transforms ride the inner letter/word spans (never the container), so
  they don't fight `-translate-x-1/2` centering, and opacity-0 letters reserve space.
- **Non-text units** (Send Request CTA, stat labels, FAQ list) fade-rise with blur
  via `Inview`; the **Financial photo unmasks top→bottom** (`clip-path`).
- **Exit is the reverse of entry** — scroll cards (Financial, FAQ) use
  `mode="always"`. The fixed overlays (hero, galaxy, brain) can't use in-view, so
  they gate on a boolean via `enabled`: the **hero** on `introStarted` (reveals
  after the preloader on reload, `mode="once"`), the **galaxy/brain** on the clock
  window (`active`, `mode="always"` so they reverse when the window ends).
- The header is deliberately not animated. [[decisions-log]] ADR-0027.

## 2026-07-11 — brain gradient like the orb; loader truly black

- **Brain gradient now matches the orb.** `brain-shaders.ts` applied the vertical
  cool→warm tint at only 35% over an edge-coloured base, so it read flat. The
  gradient is now the **full-strength base** (`mix(uCool, uWarm, vt)`, like the
  orb's `mix(colBottom, colTop, vt)`), fading to the dark interior with a light
  edge lift on the rim — so the brain shows the same mint→cyan→violet gradient as
  the hero orb. [[decisions-log]] ADR-0024.
- **Loader is pure black.** The container was `bg-black`, but the `StarFall` canvas
  filled each frame with `rgba(23,10,43)` (the void purple) for its trail fade,
  tinting the whole curtain. That fill is now `rgba(0,0,0)`.

## 2026-07-11 — brain: side-on start + orb gradient

- **Recoloured to the orb's gradient.** `BRAIN_CONFIG` now uses the hero orb's form
  colours — indigo (`#582eff`) bottom → mint (`#52ffa5`) top, indigo edge — so the
  brain reads as the same soft gradient as the first scene (was indigo→cyan/mint).
  The colour store seeds from `BRAIN_CONFIG`, so the panel picks it up too.
- **Side-view start.** `baseRotationY` turned a further ~90° (`-1.309 - 1.5708`) so
  the formed brain comes in as a lateral profile rather than front-on. Flip the
  sign of the added term for the other profile. [[decisions-log]] ADR-0024.

## 2026-07-11 — brain motion made continuous (no pauses)

- **The brain no longer pauses between beats.** The spin used to start only after
  the assembly finished (clock `3.5→4.0`), leaving a rest before it, and the burst
  sat ~2 viewports of dead scroll later. Now the **spin overlaps the assembly**
  (`brain.tsx`, clock `2.7→4.0`) so it turns as it gathers, and the trailing scroll
  after the tracks was halved (`toLvh(1) → toLvh(0.5)` in `scroll-stage`) so the
  outro-driven burst + Financial card follow the spin right at clock 4 — assemble
  → spin → burst reads as one continuous scroll. [[decisions-log]] ADR-0024.

## 2026-07-11 — section polish pass

- **Header:** the row is `justify-between` so the logo→nav and nav→button gaps are
  equal; the Contact Us button `self-stretch`es inside a `py`-padded row so its
  top/right/bottom insets to the bar edge are equal (verified 9.6px each).
- **Hero line** thinned (`hero-line.tsx` thickness `1.2 → 0.6 / height`) to match
  the 1px section dividers.
- **Galaxy section** gained the horizontal rule across the top of the stat band.
- **Closing cards** now flow (each shorter than the viewport) and stack with a
  small `1.667vw` gap instead of sitting at the bottom of viewport-tall sections —
  the black gap between the Financial and FAQ cards shrank from ~170px to ~27px.
- **FAQ asterisk** spins slowly clockwise (looping spring).
- **Hero** support copy width matched to the Send Request button (`19.348vw`).
- **Loader** background is pure black now, and its text uses the sections' faces /
  sizes (General Sans + Mulish, `vw`).

## 2026-07-11 — FAQ rebuilt as a Figma white card over the scene

- **The FAQ is now a white card too.** `sections/faq-section.tsx` is restyled to
  the Figma card (inset white card, asterisk mark, centred "Frequently asked"
  title, accordion) in `vw` — matching the Financial card. The accordion keeps its
  sprung height + `+`→`×` marker; questions are Mulish uppercase, answers General
  Sans, on black.
- **The FAQ now floats over the live scene as well.** Moved it out of the opaque
  `bg-surface` wrapper — the shader shows around it — so only the **footer** is the
  opaque scene-covering content now (the `sceneCover` trigger sits there).
  [[decisions-log]] ADR-0026.

## 2026-07-11 — Figma "Financial" card floats over the live scene

- **The first closing section is rebuilt from Figma.** `sections/outro-section.tsx`
  ("Built to be felt.") is replaced by `sections/financial-section.tsx` — a white
  card inset from the viewport edges ("Financial momentum" title, a teal-lit image,
  two `[ 0n ]` paragraph columns). It floats up over the scene as the brain bursts.
- **The shader stays visible around the card.** Added a **`sceneCover`** clock to
  `outro.ts`, driven by a new trigger on the opaque FAQ/footer wrapper; the frame
  gate now stops on `sceneCover` (opaque content covers the scene) instead of on
  `outro` (the card sliding in). So the backdrop keeps drawing behind/around the
  card. The closing content is split: transparent Financial wrapper (drives
  `outro` → brain exit + overlay fades) then the opaque `bg-surface` FAQ/footer
  (drives `sceneCover`). [[decisions-log]] ADR-0026.

## 2026-07-11 — Figma section three (brain); HUD system removed

- **Section three is rebuilt from Figma.** `views/home/section-brain.tsx` is a new
  fixed overlay — the "convergence" screen: "Turn data into decisions" top-left,
  "Money that moves with you" bottom-right (right-aligned), the Send Request CTA
  bottom-left, and a Mulish tagline on each flank. Fades on the clock's brain
  window (`2.2→2.65` in, `3.6→4.1` out); `vw` (÷14.4) sizing like the others.
- **The HUD, Section, and text-reveal-band system are gone.** With all three
  sections now fixed overlays (`Hero` / `SectionGalaxy` / `SectionBrain`), the
  scroll-driven per-line `TextEngine` reveals are unused: deleted `hud/hud.tsx`,
  `hud/section.tsx`, `hud/section-cards.tsx`, `hud/section-meta.tsx`; trimmed
  `hud/windows.ts` to just the scroll-track scaling; and stripped the reveal-band
  machinery (bands / lineRefs) from `scroll-stage.tsx`. `homeSections` is no longer
  wired. [[decisions-log]] ADR-0025.

## 2026-07-11 — Figma section two (galaxy)

- **Section two is rebuilt from Figma.** The old scroll copy (HUD section index 1)
  is gone; `views/home/section-galaxy.tsx` is a new fixed overlay — centred title
  "Money that moves with you", centred support copy, and a four-stat band ("30k /
  Active teams", 2× "98% / Would recommend", "4.9 / Product Rating") with bright
  left accents (`border-white/80`) and faint column dividers (`border-white/20`).
  It fades against the clock's galaxy window (`SECTION_WINDOWS[1]`), and uses the
  same `vw` (÷14.4) scaling as the hero.
- Stat numerals are **Mulish Light** — added weight 300 to the Mulish font.
- The HUD now renders only the final brain section (skips indices 0 and 1).
  [[decisions-log]] ADR-0025.

## 2026-07-11 — hero polish: vw scaling, line behind orb, left-aligned copy

- **Hero + header scale proportionally now.** Switched their measurements from
  `rem` to **`vw`** (÷14.4): the adaptive root font-size resets its base per
  breakpoint, so `rem` shrank the 1440-authored hero between 1440–1920px. `vw`
  keeps the design proportions at every width.
- **The rule reads as behind the orb.** `hero-line.tsx` now fades out across the
  orb's centre footprint (additive particles can't occlude it), so it shows only
  to the sides, and its Y tracks the bottom text cluster (closer to the copy, per
  the design).
- **Bottom-right copy is left-aligned** (was right-aligned), matching the Figma.

## 2026-07-11 — Figma hero + fixed site-wide header

- **The hero is rebuilt from Figma.** The old HUD chrome (frame brackets, brand
  header, status footer, scroll hint) and the section-one copy are gone. A new
  `views/home/hero/hero.tsx` overlay carries the Figma hero — the "Turn data into
  decisions" display title, the tagline, the `[ … ]` tag row, the supporting copy,
  and the Send Request CTA — laid out at the Figma pixels in `rem` (÷16) so it
  rides the adaptive root font-size. It fades up with the intro and out past
  section one, like the old hero.
- **Fixed, site-wide header.** `components/common/site-header.tsx` (logo, nav,
  Contact Us) is rendered once in the root layout, `position: fixed`, so it floats
  above every section on scroll.
- **The horizontal rule sits behind the orb.** `scene/hero-line.tsx` draws the
  Figma line (white, 0.2 opacity) as a clip-space quad at renderOrder −0.5 — after
  the backdrop, before the particles — because the opaque canvas means a DOM line
  can't go behind the sphere.
- **Fonts.** General Sans (Light/Regular/Medium, self-hosted from Fontshare via
  `next/font/local`) and Mulish (`next/font/google`) added; tokens `--font-general`
  and `--font-tag` in `globals.css`.
- The stripped HUD now carries only the scroll-driven galaxy/brain copy;
  `hud/frame-brackets.tsx` and `hud/hud-motion.tsx` are deleted. [[decisions-log]]
  ADR-0025.

## 2026-07-11 — brain: smaller synapses, scroll-out burst, 15° nudge

- **Smaller synapse flickers.** The synapse flash size boost dropped `fire * 2.5 →
  0.8` in the brain vertex shader — a subtler twinkle.
- **Scroll-out: approach + burst, synced to the next section.** The brain now
  rushes toward the camera (`group.position.z → BRAIN_CONFIG.approach`) and bursts
  apart (`uExplode → 1`) driven by the **outro clock** — i.e. exactly as the
  closing section slides up over the scene. Its brightness holds through the
  approach, then fades as the section covers it. (The explode uniform already
  doubled as the assemble; now it also drives the exit.)
- **15° CCW resting nudge.** `baseRotationY` is `-90° + 15°` counter-clockwise.

## 2026-07-11 — brain colours in the panel; rests side-on, spins on scroll

- **Brain colours are now editable in the live panel.** Added a `brain` slice to
  the colour store and a "Brain scene" panel section — cool/warm tint, edge,
  interior, synapse, cursor, and a glow slider. `brain.tsx` subscribes like the
  other forms; the values export in the JSON with `orb`/`galaxy`.
- **Rests side-on, then spins on scroll.** The scroll spin used to start the
  instant the brain appeared, so it was already turned by the time it assembled.
  It now holds at `baseRotationY` (the source's lateral profile) through assembly
  and only spins once scrolled past clock ~3.5; `scrollSpin` raised `1.2 → 2.4`
  for a clearer turn. Tune the resting angle with `BRAIN_CONFIG.baseRotationY`.
  [[decisions-log]] ADR-0024.

## 2026-07-11 — third act is now a point-cloud brain

- **The returning orb + logo is replaced by a GLB-sampled brain.** New
  `scene/brain/`: `brain-geometry.ts` area-samples ~130k points (per tier) off a
  brain GLB with geometric normals; `brain-shaders.ts` is the source additive
  material (cool→warm tint, mint silhouette edge, white-hot synapse flashes,
  tangential flow); `brain.tsx` loads the GLB (drei `useGLTF`, vendored at
  `public/assets/brain/rotten-brain.glb`), and drives it from the clock —
  `brainAppear` (2.6→3.4) fades it in and doubles as an explode→converge assembly,
  so it gathers as the galaxy blows apart. Cursor halo/swivel + scroll spin included.
- **Recoloured to the palette:** indigo→cyan vertical tint, mint edge, black
  interior, cyan cursor neurons (`BRAIN_CONFIG`), uploaded linear via
  `hexToLinearVec3`.
- **Orb no longer returns.** Keyframes hold `orbOut` at 1 through the tail, and the
  `LogoPlane`/`logo-texture` files are deleted. Amends the clock's original
  return-shape. [[decisions-log]] ADR-0024, [[webgl-scene]].
- A real GLB (~4.7 MB) now loads, so the loader's `useProgress` finally gates on a
  real asset (it always anticipated this).

## 2026-07-11 — longer scroll per scene (more travel to hand off)

- **Scenes now take twice the scroll to switch.** Lowering `progressLerp` only
  smoothed the clock in time; the handoff still spanned the same scroll distance.
  Added `SCROLL_TRACK_LVH` (`windows.ts`, = 200): each of the four timeline tracks
  is now 200 lvh tall instead of one viewport, so advancing a clock unit needs 2×
  the scroll. The clock's `p1 + 2·p2 + p3` shape and 0→4 range are untouched — only
  pixels-per-unit changed — and the text-reveal bands derive from the same factor
  (`toLvh`), so copy stays synced. `scroll-stage` sizes the tracks from `toLvh(1)`.
  Bump the one constant to lengthen (or shorten) the whole timeline. [[webgl-scene]].

## 2026-07-11 — pointer no longer twitches, much slower scene handoff

- **Cursor deformation stopped twitching.** The jerk was the drag term
  (`uCursorVel`): it was the raw per-frame contact delta — noisy in direction —
  displacing every point in range, so the bulge yanked around, worst as the cursor
  crossed the sphere's silhouette (where the ray-hit jumps to the far limb).
  Fixes in `oil-pointer.ts`: the drag velocity is now **low-passed**, the viscous
  contact lerp is heavier (`0.15→0.1`) so it glides over the silhouette jump, and
  the energy attack is gentler. In `constants.ts` the drag (`oilDrag 1.35→0.95`)
  and ripple (`rippleSpeed 6→4`, `oilRipple 0.445→0.34`, `rippleFreq 13→11`) are
  calmed so the smear flows instead of vibrating.
- **Scene handoff is much smoother.** `progressLerp` lowered again — desktop
  `0.16→0.07`, laptop `0.18→0.08`, tablet `0.35→0.13`, phone `0.22→0.15`. The
  scene now trails the scroll by ~0.25 s so the orb→galaxy transition glides
  rather than snapping to the scroll position. [[webgl-scene]], [[decisions-log]]
  ADR-0023.

## 2026-07-11 — orb de-soap, cyan palette, smoother pointer

- **New palette applied** via the colour panel's export → `lib/scene/constants.ts`.
  Both scenes go cool: black wash, ice-blue/cyan flame (`#8b98fe` / `#6bfdff`),
  a mint→indigo orb (`#52ffa5` / `#582eff`) and a cyan-core / mint-arm galaxy.
  `ORB.bg` is now pure black; `--color-void` in `globals.css` is left as-is (it
  only shows for one pre-first-frame flash, and drives the content surfaces).
- **Orb no longer reads "soapy."** The point sprites had a wide soft falloff that,
  additively overlapped at a large size, washed into a blur regardless of DPR. The
  sprite falloff is now squared (tight bright core, thin halo, ×1.2 to keep peak
  brightness), `orbPointSize` trimmed per tier (`34→28` desktop … `24→21` phone),
  and **bloom tightened** (intensity `0.7→0.6`, threshold `0.55→0.6`, radius
  `0.35→0.3`) so only hot cores glow instead of the whole orb. Net GPU cost drops
  (`pointSize²`), which also eases the shared-rAF budget the DPR bump spent.
- **Smoother cursor deformation.** `oil-pointer.ts` energy now eases toward the
  motion drive with a soft attack + slow release instead of snapping to full the
  instant the cursor moves; the pointer/viscous lerps are frame-rate independent.
  The surface bulge swells and settles rather than popping. [[webgl-scene]].

## 2026-07-11 — sharper scene, smoother handoff, live colour panel

- **Higher render density.** Desktop/laptop DPR caps raised `1.5 → 2` and
  `1.35 → 1.75` — the old caps upscaled the point sprites and read soft on HiDPI
  screens. Tablet/phone unchanged (battery-bound). Cost is `∝ dpr²`, so 2 is the
  desktop ceiling. `scene/adaptive.ts`.
- **Smoother scene transition.** Desktop/laptop `progressLerp` lowered `1 → 0.16`
  and `0.55 → 0.18`, so the scroll clock eases toward the scroll position rather
  than snapping to it 1:1 — the orb→galaxy handoff now glides. Frame-rate
  independent, on the ticker. `scene/adaptive.ts`.
- **Live colour-authoring panel (dev only).** A new `ColorPanel` (bottom-right
  "Colors" toggle) retunes every scene and backdrop-shader colour at runtime —
  orb/galaxy wash, flame A/B + intensity, atmosphere, the orb gradient (top /
  bottom / edge) and galaxy core/arms, plus per-form brightness — and exports the
  result as JSON to paste into `lib/scene/constants.ts`. Backed by
  `lib/scene/color-store.ts` (a zustand store the scene subscribes to); the
  backdrop, atmosphere, orb, and galaxy refresh their uniforms in place via a new
  `setLinearVec3` helper. Tree-shaken out of production. [[decisions-log]] ADR-0023,
  [[webgl-scene]].

## 2026-07-11 — "Enter the unknown" orb exit

- **On the final section the orb rushes toward the camera and distorts** instead
  of sinking straight down. `orbSink` → `orbApproach` (0→1 over clock 3.4→4.0,
  held until the core has opened); it drives `group.position.z` toward the camera
  (`orbMoveY × ORB_CONFIG.approach`) and swells the displacement noise
  (`uDeform × (1 + approach × distortGain)`), so the surface churns as it nears.
  [[decisions-log]] ADR-0022.
- A hollow particle-sphere ("blob") was prototyped for the second scene and then
  reverted — the spiral galaxy's look and transition were the stronger read, so
  it stays. Only the orb exit above landed.

## 2026-07-10 — performance + responsive pass

- **Scene renders on demand.** `frameloop="demand"` plus a `FrameGate` that drives
  `invalidate()` from the shared ticker at a per-tier frame rate (60/60/45/30),
  and stops completely when the tab is hidden or the closing sections own the
  frame. Measured 320 draw calls / 3 s on the hero, **0** on the outro.
  [[decisions-log]] ADR-0021.
- **Four device tiers.** Live points 167k → **91k** desktop, **18.7k** phone. DPR
  capped 1.5 / 1.35 / 1.25 / 1.1 (phone floor 0.75). Bloom off on phones.
  `AdaptiveDpr` removed — it fights `demand`.
- **Scroll clock is now lerped**, harder on weaker tiers (1 / 0.55 / 0.35 / 0.22),
  frame-rate independently. Runs on the ticker, not the render loop, so the HUD
  never stalls while the scene is idle.
- **Fixed: particles read as black when they faded.** The blend is additive, so a
  point can only ever *add* light — an A/B against a hidden orb confirmed **0**
  darkened pixels of 48k sampled. What looked black was the near-black backdrop
  showing through wherever alpha collapsed: noise troughs and the far hemisphere
  bottomed out at 15% alpha. Alpha and colour now have floors, so dim points stay
  coloured instead of dropping out.
- **Closing sections sit on their own opaque surface** (`--surface`, a distinct
  purple from the scene's `--void`), so they read as a separate plane.
- **Metric cards moved to a right-hand column** beside section 02.
- **Responsive pass** — HUD chrome sheds its secondary labels on small screens,
  the title scale gains a mobile floor, cards and the spec panel hide below `lg`,
  the footer nav wraps, and the outro stat grid goes 1 → 2 → 3 up.
- Orb camera pulls back on tablet/phone so it does not crowd the copy.

## 2026-07-10 — content + polish pass

- **Orb assembly** is slower (intro 1800 → 2900 ms), with a wider per-point delay,
  and now spawns **at the camera**, splayed below centre — via a new `uCamLocal`
  uniform rather than a hardcoded offset.
- **The core cut-out moved into object space.** It was a view-space angular circle
  stamped over the blob; it is now a bore along the camera axis measured against
  the *displaced* surface, with its rim modulated by the displacement noise. It
  reads as a hole **in** the blob, wobbling with it, and you can see the far
  surface through it. [[decisions-log]] ADR-0020.
- **Section copy now lands before the galaxy does.** `SECTION_WINDOWS` retimed so
  section 2 is fully in at clock 0.52, ahead of the galaxy's 0.55 appear ramp, and
  the windows no longer overlap (both sections were on screen at once). Reveal
  windows are anchored to `fullIn` rather than spanning to `fullOut`, and the HUD
  counter thresholds were retimed to match.
- **Glassy metric cards** beside section 02, and a **right-hand spec panel**
  beside section 03. Both driven straight off the clock spring — no React state,
  so scrolling never re-renders them.
- **Cards are dark glass, not light.** `bg-chalk/8` over the galaxy's white-hot
  core rendered as solid white blocks; they also sit below the disc rather than
  dead-centre, where they collided with the title.
- **"THE UNKNOWN." holds two lines** — title size down, `--container-hud-section`
  up to 40rem.
- **New `<Button>` primitive** (`components/ui/`) with a spring hover, a CTA in the
  outro, and a one-line "Built to be felt."
- **New FAQ section** — spring-driven accordion (measured height, no CSS
  transitions), with proper `aria-expanded` / `aria-controls`.

## 2026-07-10 — immersion pass

- **New loader.** A field of angled, trailing star-streaks that lengthen and
  accelerate as the load progresses, then warp out as the curtain lifts. All
  other chrome is gone bar a hairline progress line at the foot of the frame.
  The field is a ticker-driven 2D canvas, not a spring — it is a continuous
  particle field, the same reasoning as the WebGL scene.
- **Orb reveal.** Points now fly in from the camera on staggered delays and
  gather into the sphere, instead of the form simply fading up.
- **Orb dissolve.** Rides outward along noise-warped normals with a travelling
  ripple, so it comes apart in liquid sheets and sweeps past the viewer.
- **Fixed: the orb vanished the moment the camera pulled back.** `galaxyPresence`
  keyed off raw `galaxyIn`, so the camera began retreating on the first pixel of
  scroll. It now tracks `galaxyAppear`. Visibility also gates on the eased alpha
  rather than on `orbOut`, so it is never cut off mid-fade.
- **Galaxy assembly.** Stars stream in from far out on per-star delays and settle
  into the disc, rather than fading on. The appear ramp is longer and later, so
  the inbound cloud no longer swamps the hero.
- **Orb core opens.** A real transparent cut-out in the centre, framing the VESPER
  mark on a rotating plane (a canvas texture — the project ships no logo art).
  The core opens, holds, and only then does the orb sink out of frame.
- **New closing sections.** A real scrolling outro section and a footer after the
  four scroll tracks. The HUD chrome and the orb both fade out as they arrive,
  driven by a new `outro` clock.
- **Type.** Orbitron → **Open Sans**; the techno display face read as costume at
  these sizes. Title tracking is now negative, leading looser, and a fluid type
  scale covers the new sections.
- **Sequenced beats are now derived selectors** over the clock rather than
  keyframe columns. [[decisions-log]] ADR-0019.
- **Fixed: outro body copy stacked one word per row** — the `flex-col` +
  `TextEngine` trap, again. See [[text-engine]].
- Loader now sits above the cookie banner.

## 2026-07-10

- **Fixed: nothing rendered and nothing animated.** `<shaderMaterial uniforms={…}>`
  does not keep the object you pass it — r3f gives the material a different one, so
  every per-frame uniform write was orphaned. Orb and galaxy sat at `uAppear = 0`
  (invisible); backdrop and motes sat at `uTime = 0` (frozen). All four objects now
  construct their `ShaderMaterial` and pass the instance. [[decisions-log]] ADR-0018.
- **Fixed: the loader curtain froze mid-fade, hiding the whole page.** The scene was
  heavy enough to starve `requestAnimationFrame`; react-spring is rAF-driven, so
  every spring on the page stopped — including the loader's exit, which stuck at
  `opacity 0.83`. Perf work below restored the frame loop.
- **Perf.** Dropped the galaxy's geometry index (`THREE.Points` was drawing 718,800
  sprites for 120,801 distinct stars — ~6× duplicates at identical positions;
  compensated exactly via additive linearity). Capped `dpr` at 1.5, disabled MSAA,
  reduced the bloom kernel.
- **Fixed: colours were encoded to sRGB twice.** The renderer sets
  `outputColorSpace = SRGBColorSpace`, but palettes were uploaded as raw hex bytes
  (as the source's `WebGL1Renderer` required). `#170a2b` rendered as washed lavender
  instead of near-black — a 10× error. New `scene/color.ts`. Bloom threshold retuned
  for linear light (0.22 → 0.55) with an explicit `radius`.
- Verified in a real browser (headless Chrome, software GL): hero orb, the galaxy
  dive, and the orb's return all render, and the frame loop no longer stalls.
- **Renamed the project to VESPER** (`V—0RB`). Wired through `package.json`,
  `lib/site.ts` (name, description, author, handle, `themeColor`),
  `public/manifest.json`, the HUD brand, and the loader. The palette moved to
  deep violet: `--void` / `--background` are now `#170a2b`, matching `ORB.bg`.
- **Replaced both 3D forms.** The hero blob → the **orb** from
  `getlayers-scenes/orb.html` (46k-point Fibonacci sphere, simplex-displaced,
  view-space gradient, viscous pointer "oil"). The universe → the **spiral
  galaxy** from `spiral-galaxy.html` (two arms + core bulge, cursor void).
  The 0→4 clock and all five keyframes are unchanged in shape, so the section
  transitions are identical — only the keys were retargeted
  (`blobOut` → `orbOut`, `universeIn/Out/Scale` → `galaxyIn/Out/Dive`).
- **Removed** the background `Grid`, the `Model` (and its 3.7 MB `logo.glb`),
  `Lights`, and `Stars`. Added `Backdrop` (background wash + flame warp) and
  `Atmosphere` (camera-attached motes) from the new source scenes.
- **One camera now travels between the two forms** rather than each keeping its
  own. That is what makes the galaxy's arrival immersive — the camera dives
  toward the core as the disc tips edge-on. See [[decisions-log]] ADR-0017.
- **Fixed: body copy stacked one word per row.** A `TextEngine` copies
  `className` onto every word, so the `block` class on the line wrappers hit each
  word inside a `flex-col`. Each authored line now gets its own engine and its
  own scroll reveal band (9 bands, staggered). See [[text-engine]].
- **Fixed: the loader would have hung forever.** It gated on `total > 0` from
  drei's `useProgress`; with `logo.glb` gone no three.js loader ever runs, so
  `total` stays `0`. "Nothing to load" now counts as loaded.
- **Fixed: no particles rendered** — `VALIDATE_STATUS false`, *"'vNormal' :
  undeclared identifier"*. The blob and universe materials injected
  `vNormal = normal;` into a `MeshPhysicalMaterial` vertex shader. Their point-cloud
  geometries carry no `normal` attribute, so three 0.185 auto-defines `FLAT_SHADED`
  and compiles the `vNormal` varying out; the assignment then failed to link and
  both particle systems vanished. Removed the assignment (always redundant — three's
  `normal_vertex` chunk assigns it when present). A r143 → 0.185 regression, not a
  port error. See [[webgl-scene]] *Gotchas*.
- **Ported the HELIOS / B—I0B landing page** from the `ithaca-bIob` source
  (Next 14 pages router, `@react-three/fiber` v8, `framer-motion`) onto this
  starter. The page is a fixed WebGL scene behind a fixed HUD, driven by four
  invisible scroll tracks. See [[decisions-log]] ADR-0016 for the scroll clock.
- **Added the r3f stack** — `three`, `@react-three/fiber` v9, `@react-three/drei`
  v10, `@react-three/postprocessing` v3, `postprocessing`. See [[tech-stack]].
- **Removed `framer-motion` entirely.** All five of its usages were replaced:
  - `motionValue` singletons → `SpringValue` (`lib/scene/intro.ts`) and a plain
    mutable store read per-frame (`lib/scene/timeline.ts`).
  - `useScroll` / `useTransform` → `useProgressTrigger` + keyframe sampling.
  - `motion.*` / `AnimatePresence` → `animated.*` + a spring-driven exit.
  - framer `useSpring` on 900 grid squares → bare `SpringValue`s sampled in one
    `useFrame`, and the per-square `needsUpdate = true` (which forced a shader
    recompile) was dropped — uniforms upload every frame regardless.
- **Replaced every CSS `@keyframes`** — `spin`, `pulse`, `arrow`, `blink`,
  `sweep` — with looping springs, per hard rule 1. No CSS animation remains.
- **Section copy now uses [[text-engine]]** in `progress` mode, scrubbed by
  dedicated reveal bands in the scroll document; the first section is gated on
  the intro spring instead.
- **New tokens** in `globals.css` for the HUD/loader palette, type scale, and
  frame spacing, plus `@utility loader-grain`, `loader-sweep`, `text-shadow-title`.
- **Third authorized engine edit** — see [[decisions-log]] ADR-0014.
- **React Compiler lint rules scoped off for the scene** — ADR-0015.
- **New dep `@types/three`** (dev). Node ≥ 22.13 needed to install (a transitive
  `eslint-visitor-keys` engine constraint).

## 2026-06-07

- **Fixed `<Inview>` standalone reveal + spring resize gating** — `<Inview>`
  never animated unless an external `trigger` ref was passed. The JSX `ref`
  callback wrote `inViewRef.current = node`, but that tuple slot is a *callback
  ref* (`setNode`), so the element was never observed and the `node` stayed
  `null`. Now calls `setInViewNode(node)`. This was also a build-breaking type
  error. Additionally, `<Inview>`, `<Spring>`, and `<Hover>` tracked `width` as a
  hook dependency but never passed it to `isMobileDisabled` — fixed by passing the
  tracked `width`, restoring resize re-evaluation and clearing the
  `react-hooks/exhaustive-deps` warnings. `yarn build` and `yarn lint` are now
  clean. See [[decisions-log]] ADR-0013 and [[components/animation-springs]].

## 2026-06-05

- **Home view emptied** — removed the animation showcase (`src/views/home-showcase.tsx`
  deleted) and reduced `HomeView` to an empty `<main>`. The home view is now the
  blank starting point for new work. Documented the convention — *if the project
  is empty and no other instructions are provided, start developing in the home
  view on route `/`* — in [[ai-agent-guide]] and [[new-page]].

## 2026-05-23

- **README — setup + Vercel deploy steps added** — *Getting started* expanded
  into a four-step flow (clone the template → delete bundled `.git` →
  initialise your own GitHub repo → install & run), with a macOS hint for
  revealing the hidden `.git` folder (`⇧ + ⌘ + .`). Added a *🚀 Deploy to
  Vercel* section covering the CLI flow (`vercel` / `vercel --prod`) and the
  dashboard import path, plus an `env pull` pointer to
  [[environment-variables]].
- **README rewritten to lead with the AI workflow** — root `README.md`
  reorganised so the AI usage guide is the first section: how the three
  `.claude/settings.json` hooks (`SessionStart`, `UserPromptSubmit`, `Stop`)
  enforce the vault workflow automatically, how to write a good request
  against this convention layer, and a cost-expectations note recommending
  **Claude Max (5×)** as the minimum plan (the vault-fan-out + hook
  re-injection on every turn is token-intensive by design). Technical
  *Getting started* and the existing AI-agents entry-point pointer stay
  below.

## 2026-05-22

- **Styling-placement convention added** — to stop `globals.css` accumulating
  hundreds of component-specific classes, styling now follows a strict
  placement order: one-offs are Tailwind utilities, repeated patterns become
  **React components** (not `@layer components` classes), and `@layer
  components` is reserved strictly for pseudo-elements and third-party
  overrides. `globals.css` stays bounded — `@import`, tokens, base resets only.
  No CSS Modules. Codified in [[decisions-log]] ADR-0012; [[design-system]]
  (new *Where a style goes* section) and [[component-conventions]] updated.
- **Semantic-HTML / SEO-markup convention added** — new [[html-semantics]]
  rulebook: landmarks, one `<h1>` + heading outline, native elements over
  `div`s, forms/images/ARIA, JSON-LD over microdata, a `data-*` convention, and
  passing a semantic `tag` to animation components. Codified as AGENTS.md hard
  rule #10; cross-linked from [[component-conventions]] and [[new-page]]. Fixed
  the demo (`home-showcase.tsx`) to a single `<h1>` to follow it.
- **API layer added** — a convention for reaching external services.
  `app/api/<resource>/route.ts` Route Handlers own their logic and read secret
  env vars directly (safe — route files never reach the browser). New: `zod`
  dependency; `src/env.ts` (validated env, public/server split); `src/lib/api/`
  (`handle` wrapper + `ApiError` + `{ data }`/`{ error }` envelope);
  `src/lib/api-client.ts` (typed same-origin fetch); example
  `app/api/contact/route.ts`. Codified as AGENTS.md hard rule #9. See
  [[decisions-log]] ADR-0011 and [[api-architecture]].

## 2026-05-21

- **Asset convention added** — site content assets (images, videos) now live
  under `public/assets/<section>/`, one folder per section; meta/PWA/SEO assets
  stay at the `public/` root. Documented in [[folder-structure]],
  [[component-conventions]], and the [[new-page]] playbook; `public/assets/`
  created with a `.gitkeep`.
- **SEO & performance hardening** — a broad pass on the starter. **SEO:** new
  `src/lib/site.ts` config (single source of truth, fed by `NEXT_PUBLIC_SITE_URL`);
  `metadataBase` is now always set (relative OG/canonical URLs resolve);
  `themeColor` moved to a `viewport` export; added `app/robots.ts`,
  `app/sitemap.ts`, and an `Organization`+`WebSite` JSON-LD helper; OG image
  dimensions corrected to match the asset; dead `keywords`/`other` tags dropped.
  **Performance:** populated `next.config.ts` (`removeConsole` in prod,
  AVIF/WebP, `next/image` breakpoints aligned to the grid, `poweredByHeader:
  false`); fixed a `requestAnimationFrame` leak in `ScrollLayout` (Lenis loop
  never cancelled on unmount); `HomeView` is now a Server Component with the
  animation demo split into the `HomeShowcase` client leaf; added
  `<ReducedMotion>` (honours `prefers-reduced-motion` via react-spring's global
  `skipAnimation`); removed a per-frame `console.log` from the demo; added
  `app/loading.tsx` / `error.tsx` / `not-found.tsx`. See [[decisions-log]]
  ADR-0010, [[seo-metadata]], and [[environment-variables]].
- **Animation engine — lint pass** — cleared all 13 pre-existing ESLint problems
  in the engine (2 errors + 11 warnings), an authorized engine edit (ADR-0009).
  `isMobileDisabled` now takes an optional `viewportWidth` argument, so the
  `active` memos in `<Spring>` / `<Hover>` / `<Inview>` / the trigger hooks
  depend on it genuinely. Added missing `disableOnMobile` effect deps; fixed a
  `trigger.current`-in-cleanup hazard in `<Hover>`; ref-stabilised `<Handle>`'s
  transition effects. **API change:** `useProgressTrigger` now returns `progress`
  as a `RefObject<number>` (read `.current`) instead of a render-time ref read —
  no consumer was affected (`<ProgressTrigger>` discards the return).
- **Animation engine — performance refactor** — fixed load issues that scaled
  with the number of animated components. Added `src/lib/animation/ticker.ts`, a
  single reference-counted `requestAnimationFrame` loop; `useLoop` (and all loop
  hooks) now subscribe to it instead of each starting its own rAF. `useWindowWidth`
  / `Height` / `Size` now share one debounced `resize` listener via a
  `useSyncExternalStore` store (the `debounceDelay` param was dropped — unused).
  `useDynamicInView` rewritten without the per-render `Proxy`/observer churn.
  Fixed a stale-closure bug in `useLoop`. `mode="forward"` scroll listeners made
  `passive`. This was an **authorized edit to `#do-not-modify` engine files** —
  hard rule #2 amended. See [[decisions-log]] ADR-0009 and [[animation-system]].
- **`spring-text-engine` updated** — bumped `^0.1.3` → `^0.1.5` (latest). The
  public API, types, and dependencies are unchanged between these versions
  (verified) — an internal-only patch bump, no code changes required.
- **Adaptive scaling grid added** — a root-font-size scaling system landed in
  `src/components/common/grid/` (`<AdaptiveGrid>` + `useAdaptiveGrid` hook +
  `grid.config.ts`), with `vw` media queries in `globals.css` for scale-down.
  It was dropped into `common/` as a `styled-components` system; ported to the
  project stack — config-driven TS + CSS-only Tailwind, no `styled-components`.
  The unused dropped files (`colors.ts`, `fonts.ts`, `utils.ts`, `index.ts`,
  the `styled-components` `grid.tsx`) were removed. Mounted via `<AdaptiveGrid>`
  in the root layout. See [[components/common]] and [[decisions-log]] ADR-0008.
- **Vault created** — `obsidian/` Obsidian vault initialised as the project's
  second brain. Architecture, frontend, and workflow docs populated. See [[decisions-log]] ADR-0001.
- **Root README rewritten** — replaced `create-next-app` boilerplate with a real
  project README that points into this vault.
- **`generic-layout-prompt.md` moved** — relocated from repo root to
  `obsidian/workflows/` as [[generic-layout-prompt]].
- **Navigation convention resolved** — standard `next/link` confirmed; the unbuilt
  `<AnimLink>` / `useAnimRouter()` convention dropped. See [[decisions-log]] ADR-0005.
- **Docs consolidated into the vault** — `project-specs.md` deleted (decomposed into
  vault notes + new [[environment-variables]]); `text-engine-docs.md` moved in as
  [[text-engine-reference]]. `AGENTS.md` rewritten as a thin shim; `.cursorrules`
  repointed to `@AGENTS.md`. The vault is now the single source of truth.
  See [[decisions-log]] ADR-0006.
- **Vault renamed & restructured** — vault folder `getlayers.io/` → `obsidian/`;
  number prefixes dropped from section folders (`00-meta` → `meta`, etc.). Project
  name standardised to **`next16-claude-starter`** across docs and `package.json`.
- **Components linked to docs** — every file in `src/components/` now carries a
  `// 📖 Docs:` pointer comment to its catalog note, so agents can jump from code
  to docs and back.
- **Vault workflow automated** — added `.claude/settings.json` with `SessionStart`,
  `UserPromptSubmit`, and `Stop` hooks that make agents read the vault first,
  follow the relevant guide, and update docs after every change — with no manual
  reminder. See [[decisions-log]] ADR-0007 and [[ai-agent-guide]].
- **Cookie component replaced** — the `react-cookie-consent`-based `cookie.tsx`
  was replaced by an in-house `Cookie/` component (banner + category preferences
  modal + Zustand store). `react-cookie-consent` removed from dependencies. The
  component shipped using `styled-components` + an external design system; it was
  ported to the project stack — Tailwind v4 tokens and `@react-spring/web` motion.
  Mounted via `<LazyCookie>`. See [[components/common]].
- **Fixed TextEngine spring type mismatch** — the `mode="once"` heading in
  `views/home.tsx` mixed `lineIn={{ y: 0 }}` (number) with `lineOut={{ y: "100%" }}`
  (string), throwing *"Cannot animate between _AnimatedString and _AnimatedValue"*.
  Changed to `y: "0%"`. The buggy pattern in [[text-engine]] / [[text-engine-reference]]
  examples was corrected and a type-matching gotcha note added.

## Project baseline (git history)

| Commit | Description |
|--------|-------------|
| `94b0870` | feat: update starter |
| `5280ef2` | fix: linter errors & build |
| `b2b84e6` | initial — `next16-claude-starter` scaffold |

> [!note]
> The starter shipped with: Next.js 16.2, React 19.2, Tailwind v4, `@react-spring/web`,
> `spring-text-engine`, Lenis, and Zustand. See [[tech-stack]] for the current state.
