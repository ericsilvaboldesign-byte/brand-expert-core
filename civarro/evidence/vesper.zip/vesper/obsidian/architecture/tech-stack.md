---
tags: [architecture, stable]
updated: 2026-05-21
---

# Tech Stack

Every dependency in `package.json`, what it does, and why it is here.
Package name: `vesper` · version `0.1.0` · private.

## Core framework

| Package | Version | Role |
|---------|---------|------|
| `next` | `16.2.0` | App Router framework. ⚠️ See warning below. |
| `react` / `react-dom` | `19.2.4` | UI runtime |
| `typescript` | `^5` | Type system — `any` is banned |

> [!warning] This is not the Next.js you may know
> `AGENTS.md` warns: APIs, conventions, and file structure may differ from older
> Next.js knowledge. Always check [[routing]] before writing routing code, and
> heed deprecation notices.

## Styling

| Package | Version | Role |
|---------|---------|------|
| `tailwindcss` | `^4` | Utility CSS — **no `tailwind.config.js`** |
| `@tailwindcss/postcss` | `^4` | PostCSS integration |

Tailwind v4 is configured entirely in `src/app/globals.css` via `@theme inline`.
See [[design-system]].

## Animation (the heart of the starter)

| Package | Version | Role |
|---------|---------|------|
| `@react-spring/web` | `^10.0.3` | Spring physics — drives **all** motion |
| `spring-text-engine` | `^0.1.5` | Scroll-aware spring text animation |

No `framer-motion`, no CSS transitions/keyframes. See [[animation-system]] and
[[text-engine]]. ADR: [[decisions-log]] ADR-0002.

Infinite ambient loops (a rotating mark, a pulsing status light) use
`useSpring({ loop: true })` / `loop: { reverse: true }` rather than
`@keyframes`. `utils/animation/cubic-bezier.ts` supplies a CSS-equivalent easing
for curves react-spring's named `easings` dictionary does not cover.

## 3D / WebGL

| Package | Version | Role |
|---------|---------|------|
| `three` | `^0.185.0` | WebGL renderer, geometry, materials |
| `@react-three/fiber` | `^9.6.1` | React renderer for three.js — `<Canvas>`, `useFrame` |
| `@react-three/drei` | `^10.7.7` | Helpers — `useProgress`, `PerspectiveCamera`, `Preload`. **No `useGLTF`** (ADR-0028) |
| `@react-three/postprocessing` | `^3.0.4` | Effect composer bindings |
| `postprocessing` | `^6.39.2` | `Bloom`, `KernelSize` — peer of the above |
| `@types/three` | `^0.185.0` | Types (dev) |

Used by the home view's scene (`src/views/home/scene/`). Two things to know:

> [!warning] r3f v9 augments JSX globally
> Importing `@react-three/fiber` anywhere merges `ThreeElements` into
> `JSX.IntrinsicElements` for the whole program. That broke the animation
> engine's `ElementType` casts — see [[decisions-log]] ADR-0014.

> [!warning] The scene is exempt from two lint rules
> `react-hooks/immutability` and `react-hooks/purity` are off under
> `src/views/home/scene/**`. See [[decisions-log]] ADR-0015.

Scene motion is still spring-driven: the render loop reads `lib/scene/timeline.ts`
(scroll-fed) and `lib/scene/intro.ts` (a `SpringValue`). ADR-0016.

> [!important] Node ≥ 22.13 to install
> A transitive `eslint-visitor-keys@5` declares `node ^20.19 || ^22.13 || >=24`.
> Installing on Node 20.17 fails the engine check.

## Scroll & state

| Package | Version | Role |
|---------|---------|------|
| `lenis` | `^1.3.19` | Smooth scrolling |
| `zustand` | `^5.0.12` | Lightweight global state (scroll store) |
| `resize-observer-polyfill` | `^1.5.1` | ResizeObserver fallback for animation hooks |
| `zod` | `^4.4.3` | Schema validation — env (`src/env.ts`) + API payloads. See [[api-architecture]] |

See [[smooth-scroll]] and [[data-flow]].

## Misc

No miscellaneous runtime dependencies. Cookie consent is an in-house component
(`src/components/common/Cookie/`) built on Zustand + `@react-spring/web` — the
former `react-cookie-consent` package was removed. See [[components/common]].

## Tooling

| Package | Role |
|---------|------|
| `eslint` `^9` + `eslint-config-next` | Linting — run `yarn lint` before commits |
| `@types/*` | Type definitions for node/react |

## Scripts

```bash
yarn dev      # next dev — local development
yarn build    # next build — production build
yarn start    # next start — serve production build
yarn lint     # eslint
```

Package manager: **Yarn** (`yarn.lock` is committed).

## Not yet in the stack

Auth, database/ORM, payments, i18n, data-fetching libraries. The original starter
spec listed these as "add as needed" placeholders. Document them here when adopted,
and add an ADR to [[decisions-log]].

## Related

[[system-overview]] · [[folder-structure]]
