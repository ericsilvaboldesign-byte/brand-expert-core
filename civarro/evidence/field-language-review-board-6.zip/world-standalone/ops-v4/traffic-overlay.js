// OPERATIONS — TRAFFIC OVERLAY (v3).
//
// Network/request traffic is a SEPARATE visual system from capacity:
//   capacity = population / field (the swarm on the world)
//   traffic  = events moving through the field (pulses on routes)
//
// This layer knows nothing about the swarm engine. It draws great-circle routes
// between points on the world and small pulses moving along them. Pulses stay
// deliberately unlike agents: tiny filled dots with a short fading tail — never
// triangles, never trails from the field.
//
// v3 adds exactly two things.
//
//   WORKLOAD IDENTITY. A route carries its workload's colour — the same colour
//   the right-hand legend prints beside that workload's name. Capacity state is
//   never coloured this way: FREE is neutral and ENGAGED is one accent, decided
//   elsewhere. Traffic is the only place categorical colour is allowed, because
//   "which workload" is the only question colour answers here.
//
//   SEMANTIC ZOOM. A route has a kind. 'inter' routes are the major regional
//   traffic and read at GLOBAL; from REGIONAL on they fade back unless they
//   touch the region you are looking at. 'local' routes join a region to its own
//   nodes and appear only once you are REGIONAL or LOCAL on that region, where
//   there is finally room to see discrete pulses entering and leaving a node.
//
// Restraint is a rule, not a preference: dashes stay thin, routes only exist
// while they carry traffic, and nothing glows.

import { project } from './vendor/swarm-core.js';

const o4 = new Float32Array(4);
const o4b = new Float32Array(4);

function norm3(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }

// slerp between two unit vectors, with an altitude bump so arcs read as routes
// OVER the world rather than chords through it
function arcPoint(ua, ub, t, SR, lift, out) {
  let dot = ua[0] * ub[0] + ua[1] * ub[1] + ua[2] * ub[2];
  dot = Math.max(-1, Math.min(1, dot));
  const om = Math.acos(dot), so = Math.sin(om) || 1e-6;
  const w1 = Math.sin((1 - t) * om) / so, w2 = Math.sin(t * om) / so;
  const r = SR * (1 + lift * Math.sin(Math.PI * t));
  out[0] = (ua[0] * w1 + ub[0] * w2) * r;
  out[1] = (ua[1] * w1 + ub[1] * w2) * r;
  out[2] = (ua[2] * w1 + ub[2] * w2) * r;
  return out;
}

export function makeTraffic(SR) {
  const routes = [];   // {ua, ub, on, want, kind, rids, color, lift}
  const pulses = [];   // {r, t, speed, dir}
  const p3 = new Float32Array(3), q3 = new Float32Array(3);

  // how much of a route belongs in the current reading. A workload route is
  // network-level information, so it speaks at GLOBAL; descending gives the
  // frame to the region you are on without silencing the others entirely.
  function weight(r, scale, focus) {
    if (r.kind === 'local') {
      if (scale === 'GLOBAL' || !focus || r.rids[0] !== focus) return 0;
      return scale === 'LOCAL' ? 1 : 0.62;
    }
    if (scale === 'GLOBAL') return 1;
    if (!focus) return 0.85;
    return r.rids.indexOf(focus) >= 0 ? 1 : 0.34;
  }

  // P1-T — TRAFFIC EMPHASIS BY SEMANTIC ZOOM, not a linear scale-up. Each reading
  // gets its own treatment of the same routes:
  //   GLOBAL   the network question: is activity happening, and whose? Routes
  //            read clearly, pulses are larger and fewer details compete, and a
  //            small aggregated activity ring sits on each SERVING node — so
  //            traffic never has to be discovered by zooming in.
  //   REGIONAL the destination question: the last stretch of each route resolves
  //            and a workload-coloured tick marks the node being served.
  //   LOCAL    the event question: discrete pulses with longer tails arriving at
  //            individual nodes, plus a brief arrival mark as each one lands.
  // Only nodes carrying active workload capacity have routes at all, so no idle
  // node can ever show traffic.
  const EMPH = {
    GLOBAL:   { line: 0.62, w: 1.15, dash: [2.4, 5], head: 1.5, tail: 2, tailA: 0.34, tailR: 0.85, ring: 1, tick: 0, arrive: 0 },
    REGIONAL: { line: 0.58, w: 1.05, dash: [2.2, 4.5], head: 1.7, tail: 3, tailA: 0.36, tailR: 0.95, ring: 0.45, tick: 1, arrive: 0.5 },
    LOCAL:    { line: 0.5, w: 1, dash: [2, 4], head: 1.9, tail: 4, tailA: 0.4, tailR: 1.05, ring: 0.2, tick: 1, arrive: 1 }
  };

  const T = {
    routes, pulses, t: 0,
    addRoute(a, b, o = {}) {
      const r = {
        ua: norm3(a), ub: norm3(b), on: 0, want: 0,
        kind: o.kind || 'inter',
        rids: o.rids || [],
        node: o.node || null,
        color: o.color || [255, 161, 0],
        lift: o.lift ?? 0.14
      };
      routes.push(r);
      return r;
    },
    spawn(route, dir = 1, speed = 0.45, color = null) {
      pulses.push({ r: route, t: dir > 0 ? 0 : 1, speed, dir, color });
    },
    update(dt) {
      T.t += dt;
      for (const r of routes) r.on += (r.want - r.on) * Math.min(1, dt / 0.8);
      for (let i = pulses.length - 1; i >= 0; i--) {
        const p = pulses[i];
        p.t += p.speed * p.dir * dt;
        if (p.t > 1.04 || p.t < -0.04) pulses.splice(i, 1);
      }
    },
    // camera-facing test so routes and pulses hide behind the world
    draw(ctx, cam, W, H, opts = {}) {
      const scale = opts.scale || 'GLOBAL';
      const focus = opts.focus || null;
      const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
      const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
      const fx = sy * cp, fy = sp, fz = cy * cp;
      const facing = (x, y, z) => {
        const l = Math.hypot(x, y, z) || 1;
        return -(x * fx + y * fy + z * fz) / l;
      };
      const paint = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
      const E = EMPH[scale] || EMPH.GLOBAL;
      // FLOWS: the route is a RESOLUTION CHAIN, not a pipe. The full path sits faint
      // under a progressive stroke that resolves origin -> model checkpoint -> node,
      // with holds at the handoffs; no throughput particles are drawn at all.
      const FLOWS = !!opts.flows;
      // 1 = whole route, 0 = fully retracted into its target node
      const drawK = opts.draw == null ? 1 : Math.max(0, Math.min(1, opts.draw));
      if (drawK <= 0.004) return;
      const t0 = 1 - drawK;
      // routes: faint dotted arcs in the workload's colour, only while carrying
      for (const r of routes) {
        const k = weight(r, scale, focus);
        const on = r.on * k;
        if (on < 0.03) continue;
        ctx.setLineDash([]);
        ctx.lineWidth = r.kind === 'local' ? 0.8 : E.w;
        ctx.beginPath();
        let pen = false;
        const steps = r.kind === 'local' ? 14 : 40;
        for (let s = 0; s <= steps; s++) {
          arcPoint(r.ua, r.ub, t0 + (1 - t0) * (s / steps), SR, r.lift, p3);
          if (facing(p3[0], p3[1], p3[2]) < 0.02) { pen = false; continue; }
          project(cam, p3[0], p3[1], p3[2], W, H, o4);
          pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
          pen = true;
        }
        ctx.strokeStyle = paint(r.color, (FLOWS ? 0.3 : 1) * E.line * on);
        ctx.stroke();
        ctx.setLineDash([]);
        // REGIONAL/LOCAL: the final stretch resolves into a solid approach, and
        // a small tick names the node actually being served
        if (E.tick && r.kind !== 'local') {
          ctx.beginPath();
          let pen2 = false;
          for (let s = 0; s <= 8; s++) {
            arcPoint(r.ua, r.ub, Math.max(t0, 0.86) + (1 - Math.max(t0, 0.86)) * (s / 8), SR, r.lift, p3);
            if (facing(p3[0], p3[1], p3[2]) < 0.02) { pen2 = false; continue; }
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            pen2 ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
            pen2 = true;
          }
          ctx.lineWidth = E.w;
          ctx.strokeStyle = paint(r.color, Math.min(1, 0.85 * on));
          ctx.stroke();
          if (facing(r.ub[0], r.ub[1], r.ub[2]) > 0.02) {
            project(cam, r.ub[0] * SR, r.ub[1] * SR, r.ub[2] * SR, W, H, o4);
            ctx.fillStyle = paint(r.color, Math.min(1, 0.9 * on));
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 1.8, 0, 6.2832); ctx.fill();
          }
        }
        // GLOBAL: an aggregated activity ring on the serving node — the presence
        // of workload traffic, readable without descending a scale
        if (E.ring > 0.02 && r.kind !== 'local' && facing(r.ub[0], r.ub[1], r.ub[2]) > 0.02) {
          project(cam, r.ub[0] * SR, r.ub[1] * SR, r.ub[2] * SR, W, H, o4);
          // one ring per workload served by this node, offset in phase, so a
          // shared node shows every identity using it without a second line
          const wls = (r.workloads && r.workloads.length) ? r.workloads : [{ color: r.color }];
          for (let k = 0; k < wls.length; k++) {
            const ph = (T.t * 0.55 + k / wls.length) % 1;
            ctx.strokeStyle = paint(wls[k].color, Math.min(1, (0.5 - 0.42 * ph) * on * E.ring));
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 2.5 + ph * 5, 0, 6.2832); ctx.stroke();
          }
        }
      }
      if (FLOWS) {
        // phase per route, staggered so the ambient reading breathes instead of
        // marching in step; the selected reading (opts.flowLabels) names the stages
        const seg = (a, b, x) => Math.max(0, Math.min(1, (x - a) / (b - a)));
        const ease = x => 1 - Math.pow(1 - x, 3);
        const pt = (r, t, out) => { arcPoint(r.ua, r.ub, t, SR, r.lift, out); return facing(out[0], out[1], out[2]) > 0.02; };
        const lab = opts.flowLabels;
        const font = opts.font || '500 11px "Source Sans 3", sans-serif';
        let idx = 0;
        for (const r of routes) {
          const k = weight(r, scale, focus); const on = r.on * k; idx++;
          if (on < 0.03) continue;
          const ph0 = ((T.t * 0.22) + idx * 0.19) % 1;
          // SELECTED: resolve once, then stay EXECUTING. The cycle only re-runs when the
          // route itself is rebuilt (scope / fixture change), i.e. when product state moves.
          if (lab && r._flowT0 == null) r._flowT0 = T.t;
          if (!lab) r._flowT0 = null;
          const ph = lab ? Math.min(0.9, (T.t - r._flowT0) * 0.3) : ph0;
          // 0-.32 resolve to the model checkpoint · hold · .42-.78 hand off to the node · hold
          const p = ph < 0.32 ? 0.5 * ease(seg(0, 0.32, ph)) : ph < 0.42 ? 0.5 : ph < 0.78 ? 0.5 + 0.5 * ease(seg(0.42, 0.78, ph)) : 1;
          const A = lab ? 1 : 0.55;
          // progressive stroke: the path exists only as far as it has resolved
          ctx.beginPath(); let pen = false;
          for (let s = 0; s <= 40; s++) { const t = p * s / 40; if (!pt(r, t, p3)) { pen = false; continue; } project(cam, p3[0], p3[1], p3[2], W, H, o4); pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]); pen = true; }
          ctx.lineWidth = E.w + 0.4; ctx.strokeStyle = paint(r.color, 0.9 * on * A); ctx.stroke();
          // ORIGIN: the control plane routing this workload — a hollow square, the
          // structural mark, never a node disc
          if (pt(r, 0, p3)) { project(cam, p3[0], p3[1], p3[2], W, H, o4); ctx.lineWidth = 1; ctx.strokeStyle = paint(r.color, 0.7 * on * A); ctx.strokeRect(o4[0] - 3, o4[1] - 3, 6, 6);
            // LOGICAL -> PHYSICAL HANDOFF: a dashed drop from the orchestration band down to
            // the origin of the geographic arc. The band itself names workload, control
            // plane and model; the globe only receives the resolved execution.
            ctx.setLineDash([3, 4]); ctx.lineWidth = 1; ctx.strokeStyle = paint(r.color, (lab ? 0.6 : 0.22) * on);
            ctx.beginPath(); ctx.moveTo(o4[0], o4[1] - 4); ctx.lineTo(o4[0], Math.min(o4[1] - 4, 112)); ctx.stroke(); ctx.setLineDash([]);
            if (lab && opts.workloadOf) { ctx.font = font; ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.8 * on); ctx.textAlign = 'right'; ctx.fillText(opts.ctrlOf ? (opts.ctrlOf(r) || '') : '', o4[0] - 10, o4[1] + 5); } }
          // MODEL checkpoint: a LOGICAL stage, not a place. Drawn as a tick across the
          // route with a hairline leader to its annotation, lifted off the arc — never
          // a disc, so it cannot read as a node or a location.
          if (false && p >= 0.5 && pt(r, 0.5, p3)) {
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            const grow = ph < 0.42 ? ease(seg(0.32, 0.42, ph)) : 1;
            // tangent of the arc at the checkpoint -> a short tick perpendicular to it
            pt(r, 0.52, q3); project(cam, q3[0], q3[1], q3[2], W, H, o4b);
            let tx = o4b[0] - o4[0], ty = o4b[1] - o4[1]; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
            const nx = -ty, ny = tx, L = 4 + 3 * grow;
            ctx.lineWidth = 1.4; ctx.strokeStyle = paint(r.color, 0.95 * on * A);
            ctx.beginPath(); ctx.moveTo(o4[0] - nx * L, o4[1] - ny * L); ctx.lineTo(o4[0] + nx * L, o4[1] + ny * L); ctx.stroke();
            if (lab && opts.modelOf) {
              // leader lifts the annotation off the globe surface: the model is read as
              // a decision on the route, not a point under it
              const lx = o4[0] + nx * 26, ly = o4[1] + ny * 26 - 14;
              ctx.lineWidth = 0.8; ctx.strokeStyle = paint(r.color, 0.55 * on);
              ctx.beginPath(); ctx.moveTo(o4[0] + nx * L, o4[1] + ny * L); ctx.lineTo(lx, ly); ctx.stroke();
              ctx.font = font; ctx.textAlign = 'left';
              ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.6 * on); ctx.fillText('MODEL', lx + 4, ly - 7);
              ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.95 * on); ctx.fillText(opts.modelOf(r) || '', lx + 4, ly + 6);
            }
          }
          // SERVING NODE: the chain completes; a landing ring holds while it executes
          if (p >= 1 && pt(r, 1, p3)) {
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            // EXECUTING: after landing the ring settles to a steady mark and holds
            const land = ease(seg(0.78, 0.9, ph));
            ctx.lineWidth = 1.2; ctx.strokeStyle = paint(r.color, (0.95 - 0.35 * land) * on * A);
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 3 + 3 * land, 0, 6.2832); ctx.stroke();
            if (lab) { ctx.font = font; ctx.textAlign = 'left'; ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.6 * on); ctx.fillText(land >= 1 ? 'EXECUTING' : 'HANDOFF', o4[0] + 9, o4[1] + 1); ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.95 * on); ctx.fillText((r.node || '') + (opts.regionOf ? ' · ' + (opts.regionOf(r) || '') : ''), o4[0] + 9, o4[1] + 14); }
          }
        }
        return;   // no throughput particles in Flows
      }
      // pulses: a bright head and a short fading tail, in the route's colour
      for (const p of pulses) {
        const k = weight(p.r, scale, focus);
        if (k < 0.2) continue;
        const tp = Math.max(0, Math.min(1, p.t));
        if (tp < 1 - drawK) continue;
        arcPoint(p.r.ua, p.r.ub, tp, SR, p.r.lift, p3);
        if (facing(p3[0], p3[1], p3[2]) < 0.02) continue;
        project(cam, p3[0], p3[1], p3[2], W, H, o4);
        const hx = o4[0], hy = o4[1];
        for (let g = 1; g <= E.tail; g++) {
          const tg = Math.max(0, Math.min(1, p.t - p.dir * g * 0.022));
          arcPoint(p.r.ua, p.r.ub, tg, SR, p.r.lift, q3);
          if (facing(q3[0], q3[1], q3[2]) < 0.02) continue;
          project(cam, q3[0], q3[1], q3[2], W, H, o4);
          ctx.fillStyle = paint(p.color || p.r.color, E.tailA * k * (1 - g / (E.tail + 0.4)));
          ctx.beginPath(); ctx.arc(o4[0], o4[1], E.tailR, 0, 6.2832); ctx.fill();
        }
        ctx.fillStyle = paint(p.color || p.r.color, Math.min(1, 0.98 * k));
        ctx.beginPath(); ctx.arc(hx, hy, p.r.kind === 'local' ? 1.4 : E.head, 0, 6.2832); ctx.fill();
        // LOCAL: the pulse LANDS — a brief mark as it reaches the node
        if (E.arrive > 0.02 && t0 > 0.9) {
          const f2 = (t0 - 0.9) / 0.1;
          ctx.strokeStyle = paint(p.color || p.r.color, Math.min(1, (1 - f2) * 0.7 * k * E.arrive));
          ctx.lineWidth = 0.8;
          ctx.beginPath(); ctx.arc(hx, hy, 2 + f2 * 4, 0, 6.2832); ctx.stroke();
        }
      }
    }
  };
  return T;
}
