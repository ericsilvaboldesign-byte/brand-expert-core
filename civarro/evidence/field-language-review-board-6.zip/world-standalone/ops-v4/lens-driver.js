// LENS DRIVER — one persistent spherical operational world, three lenses.
//
// SEMANTIC CONTRACT
//   MAP        where resources are and where activity is occurring
//   NODE STATS how those resources are performing (same world, telemetry forward)
//   SWARM      how distributed capacity is behaving collectively
//   ORCHESTRATION is a different screen; nothing here draws routing
//
// One world, one camera, one orientation, one zoom — lens switches ease
// emphasis weights (mapK/nodesK/swarmK) and never touch camera state.
// Capacity behaviour is the untouched v2 model (capacity-field.js verbatim).
//
// Camera: drag rotates (inertia); the wheel is a REAL magnifying zoom across
// three named operational scales — GLOBAL (world + regions), REGIONAL (region +
// participating capacity), LOCAL (settlements, node ids, node detail) — and
// Fit All returns to the wide overview. v2 fixes the earlier camera, whose fov
// tracked distance and so held the world at a constant screen size: zooming
// changed only foreshortening. Now zoom magnifies, and focusing a region turns
// the world to face it and descends the scales in one eased move.
// Traffic is geographic operational context: present in Map, a whisper in
// Swarm — short teal pulses, never capacity, never Orchestration's routes.

import * as core from './vendor/swarm-core.js';
import { T, setTheme, themeName, rgbaT } from './theme.js';
import { makeField } from './capacity-field.js';
import { buildLandStipple, buildLandStippleCap, fromSphereUnit, toSphere } from './geo-land.js';
import { buildGraticule, buildNodeMarks, drawSphereBase, drawLand, drawAgents, drawRegionMarks, drawNodeMarks, drawSideRegionLabels, drawYou, drawPlaces, drawCohortLabels, drawWorkloadCohorts, drawParticleStems, beginLabels, keepOut, keepOutRect, setUiScale, drawHistories, drawIsotherms } from './world-scene.js';
import { makeTraffic } from './traffic-overlay.js';
import * as sceneOrig from './scene-orig.js';
// the original's glyph table, verbatim
const GLYPHS = {
  Triangle: { kind: 'tri', scale: 1 },
  Dash: { kind: 'dash', scale: 1 },
  Circle: { kind: 'dot', scale: 1.15 },
  Diamond: { kind: 'dia', scale: 0.9 },
  Hexagon: { kind: 'hex', scale: 1 },
  'Circle filled': { kind: 'dot', scale: 1.15, fill: true },
  'Diamond filled': { kind: 'dia', scale: 0.9, fill: true }
};

const SR = 58;
const RDEF = [
  // Infrastructure groups are FIXED data: exactly these nodes, these names.
  // ctrl is the control-plane location co-sited with the group where one exists —
  // a location, never a compute node, never part of any node count. London is
  // ONLY a control plane: no compute nodes exist there and none are invented.
  { id: 'ohio', name: 'OHIO · US-EAST-2', ctrl: 'control-use2-1', code: 'use2', label: 'us-ohio · you', lat: 40.0, lon: -83.0, nodes: 4, mo: [17, -20], flowSign: 1 },
  { id: 'dublin', name: 'EU-WEST-1A', code: 'euw1', label: 'eu-west-1a', lat: 53.3, lon: -6.3, nodes: 3, mo: [-17, -20], flowSign: 1 },
  { id: 'london', name: 'LONDON · EU-WEST-2', ctrl: 'control-euw2-1', code: 'ukl', label: 'uk-london', lat: 51.5, lon: -0.1, nodes: 0, mo: [-16, 22], flowSign: 1 },
  { id: 'frankfurt', name: 'FRANKFURT · EU-CENTRAL-1', ctrl: 'control-euc1-1', code: 'euc1', label: 'de-frankfurt', lat: 50.1, lon: 8.7, nodes: 3, mo: [17, 20], flowSign: 1 }
];
const FIXTURES = {
  'BASELINE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0 },
  'OHIO ACTIVE': { ohio: 0.62, dublin: 0, london: 0, frankfurt: 0 },
  'FRANKFURT ACTIVE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0.66 },
  'MULTI-REGION ACTIVE': { ohio: 0.40, dublin: 0.55, london: 0, frankfurt: 0.78 },
  'HIGHER DEMAND': { ohio: 0.60, dublin: 0.80, london: 0.30, frankfurt: 0.95 },
  'RETURN TO BASELINE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0 }
};
const NODES_BY_REGION = {
  ohio: ['amd-0', 'sev-0', 'sev-1', 'sev-2'],
  dublin: ['sev-3', 'sev-4', 'sev-5'],
  frankfurt: ['gpu-1', 'gpu-2', 'sev-6']
};
const NODE_COUNTS = { ohio: 4, dublin: 3, frankfurt: 3, london: 0 };
// PROTOTYPE DATA — the model each node currently serves, as the node cards state it.
// This is a SNAPSHOT OF THE CURRENT RESOLVED STATE, not a permanent workload->model
// binding: the product routes per request.
const NODE_MODEL = {
  'amd-0': 'Qwen2.5 3B', 'gpu-1': 'Qwen2.5 7B', 'gpu-2': 'Qwen2.5 7B',
  'sev-0': 'Qwen2.5 3B', 'sev-1': 'Qwen2.5 3B', 'sev-2': 'Qwen2.5 3B', 'sev-3': 'Qwen2.5 3B',
  'sev-4': 'Qwen2.5 3B', 'sev-5': 'Qwen2.5 3B', 'sev-6': 'Qwen2.5 3B'
};
// place + infrastructure region, so the world and the panels can name a region
// unambiguously without inventing a new label
const REGION_DISPLAY = {
  ohio: ['Ohio', 'us-east-2'], frankfurt: ['Frankfurt', 'eu-central-1'],
  dublin: ['Dublin', 'eu-west-1a'], london: ['London', 'eu-west-2']
};
const SHORT2REG = {};
for (const rid in NODES_BY_REGION) for (const id of NODES_BY_REGION[rid]) SHORT2REG[id] = rid;
// secondary node detail, shown only where zoom allows — never invented beyond this
const NODE_HW = {
  'amd-0': 'AMD Radeon Pro V520 8GB',
  'gpu-1': 'NVIDIA L4 24GB',
  'gpu-2': 'NVIDIA L4 24GB',
  'sev-0': 'CPU · AMD EPYC / SEV-SNP',
  'sev-1': 'CPU · AMD EPYC / SEV-SNP',
  'sev-2': 'CPU · AMD EPYC / SEV-SNP',
  'sev-3': 'CPU · AMD EPYC / SEV-SNP',
  'sev-4': 'CPU · AMD EPYC / SEV-SNP',
  'sev-5': 'CPU · AMD EPYC / SEV-SNP',
  'sev-6': 'CPU · AMD EPYC / SEV-SNP'
};

// ---- WORKLOAD IDENTITY -----------------------------------------------------------
// SWARM IS WORKLOAD-ORIENTED. Workloads organise engaged capacity; regions only
// locate it. So the workload is the visual identity and it owns a colour that is
// the SAME in three places: the Active Workloads legend, the engaged capacity
// cohort on the globe, and the Map traffic. Free capacity is never coloured.
// The palette is small and categorical — blue, violet, green, cyan, magenta —
// with every reserved meaning avoided: no amber (structural / selection / YOU),
// no red (failure only), no neutral (free capacity). Amber took the primary role
// from teal, so the amber that used to sit in this palette moved to cyan.
const WL_COLORS = new Proxy({}, { get: (_, k) => T.workloads[k] });
const hexOf = c => '#' + c.map(v => Math.max(0, Math.min(255, v | 0)).toString(16).padStart(2, '0')).join('');
// The fixture's OWN workload entries, in fixture order: name + allocated slots,
// nothing else. Region is deliberately absent — the fixture does not declare
// workload -> region routing, so none is fabricated here. Slots are consumed in
// this order from the network's used slots, and each workload's capacity is
// simply wherever those slots physically live.
// ===== REVIEW FIXTURE ============================================================
// The review state, stated ONCE, explicitly, and isolated from all rendering.
//
// CANONICAL / SOURCE-BASED review values: 59 slots, 10 nodes, 10 used, 49 free
// (17% / 83%), the workload names and their slot counts.
// PROTOTYPE FIXTURE values (review stand-ins, NOT measured product data): the
// distribution of the 59 slots across individual nodes, the workload -> node
// assignments in `at`, the tok/s figures below, and the 1 slot = 5 particles
// visual scale — which makes 295 particles: 50 engaged, 245 free.
//
// Every engaged slot names its owner — node, region and workload — so ownership
// can never fall out of array order, animation or randomness. `ERIC 3` and
// `ERIC` stay separate records.
// `at` is [nodeId, slotIndexWithinThatNode]: the slot's permanent address in the
// capacity model's own ownership table (NETWORK -> REGION -> NODE -> SLOT).
// MAP TRAFFIC IS QUANTITATIVE: one moving traffic particle stands for a fixed
// number of tokens, so density is a reading of throughput rather than decoration.
// One global scale for every workload — no per-workload visual cheating — and a
// fixed visual persistence window, which is a rendering choice, not a metric.
const TOKEN_PARTICLE_SCALE = 50;      // tokens per traffic particle
// ---- LIVE TRAFFIC STATE ------------------------------------------------------
// SIMULATED live telemetry, NOT backend data. The fixture's tok/s figures are the
// NOMINAL BASE RATES; this layer varies each workload gently around its own base
// and publishes ONE state that the rail readings, the per-node route rates and
// the token-particle emission all read from. Nothing here animates text on its
// own — the numbers move because the traffic state moved, and the particles
// thicken and thin from the very same numbers.
// Replacing the simulation with real telemetry means feeding measured tok/s into
// setLive() and deleting the wave; every consumer below is unchanged.
const TRAFFIC_VARIATION = 0.10;   // ±10% around base
const TRAFFIC_RETARGET = 1.4;     // seconds between new targets
const TRAFFIC_SETTLE = 0.24;      // time constant of the approach (~0.7s to settle)
const trafficState = {
  base: {}, split: {}, live: {}, target: {}, totalTokPerSec: 0, workloads: {},
  _step: -1, _ready: false,
  // deterministic, smooth, and out of phase per workload: three low-frequency
  // components on mutually unrelated periods. No Math.random anywhere, so a
  // reload reproduces the same traffic behaviour for review.
  _wave(seed, t) {
    return 0.55 * Math.sin(t * 0.21 + seed * 1.7)
         + 0.30 * Math.sin(t * 0.37 + seed * 4.1)
         + 0.15 * Math.sin(t * 0.13 + seed * 2.6);
  },
  init(fixture) {
    this.base = {}; this.split = {}; this.live = {}; this.target = {}; this.workloads = {};
    const T = fixture.throughput || {};
    let i = 0;
    for (const wid in T) {
      const per = T[wid];
      let sum = 0;
      for (const nd in per) sum += per[nd];
      if (sum <= 0) continue;
      this.base[wid] = sum;
      this.split[wid] = {};
      for (const nd in per) this.split[wid][nd] = per[nd] / sum;   // fixture proportions, preserved
      this.live[wid] = sum;
      this.target[wid] = sum;
      this.workloads[wid] = { tokPerSec: sum, seed: ++i };
    }
    this._step = -1; this._ready = true;
    this._sum();
  },
  _sum() {
    let t = 0;
    for (const wid in this.live) { this.workloads[wid].tokPerSec = this.live[wid]; t += this.live[wid]; }
    this.totalTokPerSec = t;    // ALWAYS derived, never animated on its own
  },
  update(t, dt) {
    if (!this._ready) return;
    const step = Math.floor(t / TRAFFIC_RETARGET);
    if (step !== this._step) {
      this._step = step;
      const ts = step * TRAFFIC_RETARGET;
      for (const wid in this.base)
        this.target[wid] = this.base[wid] * (1 + TRAFFIC_VARIATION * this._wave(this.workloads[wid].seed, ts));
    }
    const k = 1 - Math.exp(-Math.max(0, dt) / TRAFFIC_SETTLE);
    for (const wid in this.base) this.live[wid] += (this.target[wid] - this.live[wid]) * k;
    this._sum();
  },
  // the per-node reading: the workload is the parent signal, its nodes keep the
  // fixture's own distribution ratios
  nodeRate(wid, node) {
    const s = this.split[wid];
    return s && s[node] ? this.live[wid] * s[node] : 0;
  }
};
const TRAFFIC_VISIBLE_WINDOW = 2;     // seconds a particle stays on its route
// PRODUCT vs DEV. false = the Civarro product interface: no fixture picker, no
// simulation controls, no model telemetry, no experimental instrument strip. The
// diagnostic code all survives behind this flag, so development keeps its tools
// without the product carrying them. Default MUST stay false.
const DEV_MODE = false;

const REVIEW_FIXTURE = {
  // CANONICAL SWARM REVIEW STATE — the single source of truth for slots, used,
  // free, workload names, slot counts, display percentages and the engaged
  // particle counts derived from them (1 slot = 5 particles).
  //   59 slots / 10 nodes · 10 used (17%) / 49 free
  //   295 capacity particles · 50 engaged / 245 free
  totals: { slots: 59, nodes: 10, used: 10, free: 49, perSlot: 5 },
  // the capacity model's ownership table names its nodes internally; these are
  // the SAME ten compute nodes the product shows. Stated here explicitly so no
  // rendering path has to infer it: 4 in Ohio, 3 in Frankfurt, 3 in EU-West.
  nodeIds: {
    'ohio-node-01': 'amd-0', 'ohio-node-02': 'sev-0', 'ohio-node-03': 'sev-1', 'ohio-node-04': 'sev-2',
    'frankfurt-node-01': 'gpu-1', 'frankfurt-node-02': 'gpu-2', 'frankfurt-node-03': 'sev-6',
    'dublin-node-01': 'sev-3', 'dublin-node-02': 'sev-4', 'dublin-node-03': 'sev-5'
  },
  // where a request enters the network: the control plane this screen is signed
  // into. It is a location, never a compute node, and never counted as one.
  source: { region: 'ohio', ctrl: 'control-use2-1' },
  // PROTOTYPE FIXTURE VALUES — tok/s per (workload, serving node). The source
  // snapshot carries no throughput figures, so these are review-fixture numbers
  // stated here explicitly and nowhere else; they are not product metrics and not
  // measured rates. A workload's total is DISTRIBUTED across its own nodes (never
  // repeated per route), so the sum below is the workload's total throughput.
  //   ERIC 3        250 tok/s      VISION PRO    250 tok/s
  //   CONF REMOTE   300 tok/s      CONF CARLOS   500 tok/s
  //   WORKLOAD      150 tok/s      ERIC (0 slots) idle, no route
  throughput: {
    'eric-1':        { 'amd-0': 100, 'sev-0': 100, 'sev-1': 50 },
    'vision-1':      { 'sev-2': 125, 'gpu-1': 125 },
    'conf-remote-1': { 'gpu-2': 150, 'sev-6': 150 },
    'workload-1':    { 'sev-3': 75, 'sev-4': 75 },
    'conf-carlos-1': { 'sev-5': 500 },
    'eric-2':        {}
  },
  // ACTIVE NODE COVERAGE: the 10 engaged slots take exactly one slot on each of
  // the ten compute nodes, so every node participates in active traffic and none
  // reads as disconnected. Per region that is Ohio 4, Frankfurt 3, EU-West 3 —
  // 10 used, 49 free. `ERIC 3` and `ERIC` are two distinct workload records; the
  // second holds 0 slots and therefore no capacity, no particles and no route.
  workloads: [
    { id: 'eric-1', name: 'ERIC 3', c: 'eric', slots: 3, pct: 5,
      at: [['ohio-node-01', 0], ['ohio-node-02', 0], ['ohio-node-03', 0]] },
    { id: 'vision-1', name: 'VISION PRO', c: 'vision', slots: 2, pct: 3,
      at: [['ohio-node-04', 0], ['frankfurt-node-01', 0]] },
    { id: 'conf-remote-1', name: 'CONFIDENTIAL COMPUTE FROM A REMOTE LOCATION', c: 'confRemote', slots: 2, pct: 3,
      at: [['frankfurt-node-02', 0], ['frankfurt-node-03', 0]] },
    { id: 'workload-1', name: 'WORKLOAD', c: 'workload', slots: 2, pct: 3,
      at: [['dublin-node-01', 0], ['dublin-node-02', 0]] },
    { id: 'conf-carlos-1', name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 1, pct: 2,
      at: [['dublin-node-03', 0]] },
    { id: 'eric-2', name: 'ERIC', c: 'eric', slots: 0, pct: 0, at: [] }
  ]
};

const WL_BY_FIXTURE = {
  'BASELINE': [],
  'OHIO ACTIVE': [
    { name: 'ERIC', c: 'eric', slots: 5 },
    { name: 'VISION PRO', c: 'vision', slots: 3 }],
  'FRANKFURT ACTIVE': [
    { name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 5 },
    { name: 'WORKLOAD', c: 'workload', slots: 3 }],
  // the review fixture: 59 slots / 10 used, partitioned exactly as the canonical
  // fixture states it — 3, 2, 2, 2, 1, 0. `ERIC 3` and `ERIC` stay separate.
  'MULTI-REGION ACTIVE': REVIEW_FIXTURE.workloads,
  'HIGHER DEMAND': [
    { name: 'ERIC', c: 'eric', slots: 9 },
    { name: 'VISION PRO', c: 'vision', slots: 8 },
    { name: 'CONFIDENTIAL COMPUTE FROM A REMOTE LOCATION', c: 'confRemote', slots: 8 },
    { name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 6 },
    { name: 'WORKLOAD', c: 'workload', slots: 3 }],
  'RETURN TO BASELINE': []
};
const TEAL = a => rgbaT('primary', a);   // legacy name; reads the primary role
const PR = () => (window.__ops3 && window.__ops3.props) || {};

const o4 = new Float32Array(4), o4c = new Float32Array(4), o4d = new Float32Array(4);
function boot(canvas0) {
  let canvas = canvas0;
  const $ = s => document.querySelector(s);
  const REGIONS = RDEF.map(r => {
    const p = toSphere(r.lat, r.lon, SR);
    const L = Math.hypot(p[0], p[1], p[2]);
    return { ...r, p, u: [p[0] / L, p[1] / L, p[2] / L] };
  });
  const REG = Object.fromEntries(REGIONS.map(r => [r.id, r]));
  const F = makeField({ n: 295, SR, regions: REGIONS });
  // CANONICAL REVIEW STATE: 59 slots over 10 nodes, 10 used / 49 free (17%),
  // 295 capacity particles / 50 engaged / 245 free. The engaged SLOT ADDRESSES
  // come from REVIEW_FIXTURE.workloads[].at and from nothing else.
  const SLOTS_TOTAL = 59;
  // PROTOTYPE DIAGNOSTIC FIXTURES ONLY — count-based demand states used to watch
  // capacity behaviour. They are NOT the canonical review state and must not
  // supply it: 'MULTI-REGION ACTIVE' is deliberately absent here, because that
  // fixture is driven by explicit slot addresses (see setFixture). Ohio owns 24
  // slots, Frankfurt 18, Dublin 17 (59), so every count below stays inside what
  // each region actually owns.
  const SLOTS_USED = {
    'BASELINE': {},
    'OHIO ACTIVE': { ohio: 8 },
    'FRANKFURT ACTIVE': { frankfurt: 8 },
    'HIGHER DEMAND': { frankfurt: 14, ohio: 12, dublin: 8 },
    'RETURN TO BASELINE': {}
  };
  F.setSlots(SLOTS_TOTAL, SLOTS_USED['BASELINE']);
  // one stipple, two readings: dense for Map, every-third for Swarm's whisper
  const land = buildLandStipple(SR * 1.002, 110000, 77);
  // GEOGRAPHIC LOD: as you zoom in, sample MORE real geography inside the patch
  // you are looking at, instead of stretching the same points apart. Rebuilt only
  // when the tier or the looked-at patch actually changes, and never more than
  // ~3x a second, so dragging stays smooth.
  let landLod = null, landLodKey = '', landLodAt = 0;
  function ensureLandLod(now) {
    const zl = Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6));
    if (zl < 0.18) { landLod = null; landLodKey = ''; return; }
    const capDeg = zl < 0.45 ? 60 : zl < 0.72 ? 34 : 20;
    const nPts = zl < 0.45 ? 50000 : zl < 0.72 ? 40000 : 34000;
    const f5 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
    const [lat, lon] = fromSphereUnit([-f5[0], -f5[1], -f5[2]]);
    const q = capDeg * 0.16;
    const key = capDeg + '|' + Math.round(lat / q) + '|' + Math.round(lon / q);
    if (key === landLodKey) return;
    if (now - landLodAt < 320) return;
    landLodKey = key; landLodAt = now;
    landLod = buildLandStippleCap(SR * 1.002, nPts, 91, lat, lon, capDeg);
  }
  const grat = buildGraticule(SR);
  const ALL_NODE_MARKS = buildNodeMarks(REGIONS, NODES_BY_REGION, SR, land);
  let nodeMarks = ALL_NODE_MARKS;
  const traffic = makeTraffic(SR);
  // ===== P1 — MAP WORKLOAD ROUTING ===============================================
  // ONE routing model, derived from REVIEW_FIXTURE and nothing else. The old
  // generic region-to-region arcs recoloured by "the region's dominant workload"
  // are gone: they collapsed several concurrent workloads into one line and threw
  // workload identity away.
  //
  //   CONTROL / REQUEST ORIGIN  (control-use2-1, the Ohio control plane)
  //             ↓
  //   WORKLOAD  (identity + persistent colour)
  //             ↓
  //   TARGET COMPUTE NODE(S)  (the nodes its slots actually sit on)
  //
  // One route per (workload, target node), so a workload may own several routes,
  // two workloads may reach the same node in their own colours, and the route
  // COUNT is a reading of the fixture — never a composition choice. Free capacity
  // generates nothing. Route topology is rebuilt only when the fixture changes.
  // ONE GEOMETRIC ROUTE PER TARGET NODE. A route is infrastructure geometry —
  // control plane -> compute node — so two workloads on one node share one line
  // and never draw parallel duplicates. The line stays neutral; workload identity
  // is carried by the moving pulses, one stream per workload on that node.
  let activeRoutes = [];
  // node -> a trace of the workload colour it serves (highest tok/s wins, so the
  // answer is deterministic). Used ONLY for the node's hairline activity ring.
  let nodeAccent = {};

  // ===== OPERATIONS SCOPE — ONE DERIVED FILTERED STATE ============================
  // The shell's filter chips (Location / Workload / Hardware / search) resolve ONE
  // set of visible nodes and workloads and publish it on `civarro:scope`. Every
  // region of the world reads THAT, and nothing filters on its own:
  //   engaged slot addresses -> capacity field -> cohorts -> routes, particles,
  //   node accents, capacity readings, workload legend
  //   scoped throughput      -> traffic rail rows, total, target count
  //   scoped node marks      -> node marks and region labels on the globe
  // SCOPE = null means unfiltered; the fixture is then used verbatim.
  // A node's region and hardware live in the shell's tables; this side only
  // consumes the resolved ids, so the two never disagree about a predicate.
  let SCOPE = null, scopeKey = 'all', NBR = NODES_BY_REGION;
  const ND2ID = REVIEW_FIXTURE.nodeIds;    // 'ohio-node-01' -> 'amd-0'
  const nodeOn = id => !SCOPE || SCOPE.nodes.has(id);
  const wlOn = id => !SCOPE || SCOPE.wl.has(id);
  // A WORKLOAD KEEPS EVERY SURVIVING PHYSICAL FOOTPRINT. Location narrows which of
  // its footprints are visible, never which region it "belongs" to; no workload is
  // ever given a home region here.
  function scopedWorkloads() {
    if (!SCOPE) return REVIEW_FIXTURE.workloads;
    const out = [];
    for (const w of REVIEW_FIXTURE.workloads) {
      if (!wlOn(w.id)) continue;
      const had = (w.at || []).length;
      const at = (w.at || []).filter(a => nodeOn(ND2ID[a[0]]));
      if (had && !at.length) continue;      // no footprint survives the filter
      out.push(Object.assign({}, w, { at: at, slots: at.length,
        pct: Math.round(at.length / SLOTS_TOTAL * 100) }));
    }
    return out;
  }
  function scopedThroughput() {
    const T0 = REVIEW_FIXTURE.throughput || {};
    if (!SCOPE) return T0;
    const out = {};
    for (const wid in T0) {
      if (!wlOn(wid)) continue;
      const per = {};
      for (const nd in T0[wid]) if (nodeOn(nd)) per[nd] = T0[wid][nd];
      if (Object.keys(per).length) out[wid] = per;
    }
    return out;
  }
  function applyScope() {
    nodeMarks = SCOPE ? ALL_NODE_MARKS.filter(m => nodeOn(m.id)) : ALL_NODE_MARKS;
    if (SCOPE) {
      NBR = {};
      for (const rid in NODES_BY_REGION) NBR[rid] = NODES_BY_REGION[rid].filter(nodeOn);
    } else NBR = NODES_BY_REGION;
    if (F.fixture === 'MULTI-REGION ACTIVE' && F.setUsedSlotAddresses) {
      const addrs = [];
      for (const w of scopedWorkloads()) for (const a of (w.at || [])) addrs.push(a);
      F.setUsedSlotAddresses(addrs);
    }
    asgKey = '';                 // cohorts re-derive from the new engaged set
    buildRoutes();               // routes + pulses of removed nodes are dropped
    const wb = $('[data-m-wl]'); if (wb) delete wb.dataset.k;
    flowKey = '';
    if (view !== 'swarm') { fillTrafficRail(); updateTrafficNumbers(); }
    fillFlowPanel();
  }
  window.addEventListener('civarro:scope', ev => {
    const d = ev.detail || {}, r = d.resolved, sc = d.scope || {};
    if (!r) return;
    const on = d.filtered !== undefined ? !!d.filtered
      : !!((sc.region || []).length || (sc.workload || []).length ||
           (sc.more || []).length || (sc.q || '').trim());
    // IDEMPOTENT. The shell re-renders its scope block on template re-renders and
    // re-publishes the same resolved sets; rebuilding routes on an unchanged scope
    // would drop every pulse in flight and the traffic would visibly restart.
    const key = on ? (r.nodes || []).join(',') + '/' + (r.wl || []).map(w => w.id).join(',') : 'all';
    if (key === scopeKey) return;
    scopeKey = key;
    SCOPE = on ? { nodes: new Set(r.nodes || []),
                   wl: new Set((r.wl || []).map(w => w.id)) } : null;
    applyScope();
  });

  // INCREMENTAL. A route is dropped only when its node stops carrying engaged
  // capacity, and a surviving route keeps its identity — so its pulses stay in
  // flight and the traffic does not blink out and refill on every filter change,
  // theme swap or reassignment.
  // ---- FLOWS ---------------------------------------------------------------------
  // The spatial summary of the CURRENT RESOLVED STATE, not Orchestration: for each
  // workload in scope, the origin now routing it, the model its nodes currently
  // serve, and where that compute physically is. Every value is read from the
  // prototype's own tables — no requirement set, no eligible set, no policy or trust
  // outcome, because the prototype workloads hold no such values.
  const opLens = () => (document.documentElement.dataset.opLens || 'map');
  let flowKey = '', flowRows = -1;
  function fillFlowPanel() {
    const box = $('[data-flow-wl]');
    if (!box) return;
    const key = F.fixture + '|' + scopeKey;
    if (flowKey === key && (flowRows === 0 || box.querySelector('[data-driver-rows] > *'))) return;
    flowKey = key;
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    const list = scopedWorkloads().filter(w => (w.at || []).length);
    const nodes = new Set(), regions = new Set();
    for (const w of list) for (const a of w.at) {
      const id = ND2ID[a[0]]; if (!id) continue;
      nodes.add(id); if (SHORT2REG[id]) regions.add(SHORT2REG[id]);
    }
    set('[data-flow-src]', REVIEW_FIXTURE.source.ctrl);
    // FLOWS reads the SAME scope the header facet publishes: one workload in scope is
    // the selected flow; several are the ambient reading. Every value below is derived
    // from the fixture's own tables (NODE_MODEL, SHORT2REG) — nothing is invented.
    const allModels = new Set(), allRegs = new Set(), allIds = new Set();
    for (const w of list) for (const a of w.at) {
      const i = ND2ID[a[0]]; if (!i) continue;
      allIds.add(i); if (NODE_MODEL[i]) allModels.add(NODE_MODEL[i]); if (SHORT2REG[i]) allRegs.add(SHORT2REG[i]);
    }
    set('[data-flow-sel]', list.length === 1 ? list[0].name : (list.length ? 'All workloads · ' + list.length : 'No workload in scope'));
    set('[data-flow-model]', [...allModels].join(' + ') || '—');
    set('[data-flow-region]', [...allRegs].map(r => (REGION_DISPLAY[r] || [r])[0] + ' · ' + ((REGION_DISPLAY[r] || ['', r])[1])).join(' + ') || '—');
    set('[data-flow-node]', [...allIds].join(', ') || '—');
    set('[data-flow-n]', String(list.length));
    set('[data-flow-nodes]', String(nodes.size));
    set('[data-flow-regions]', String(regions.size));
    const slot = rowSlot(box);
    for (const w of list) {
      const ids = w.at.map(a => ND2ID[a[0]]).filter(Boolean);
      const models = [...new Set(ids.map(i => NODE_MODEL[i]).filter(Boolean))];
      const regs = [...new Set(ids.map(i => SHORT2REG[i]).filter(Boolean))];
      const color = WL_COLORS[w.c] || [159, 176, 170];
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-width:0;';
      const head = document.createElement('span');
      head.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;align-self:stretch;min-width:0;';
      const dot = document.createElement('i');
      dot.dataset.wlc = w.c || '';
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(color) + ';';
      const nm = document.createElement('span');
      nm.setAttribute('data-wl-label', '');
      nm.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 1 auto;min-width:0;color:' + T.text1 + ';';
      nm.textContent = w.name;
      head.appendChild(dot); head.appendChild(nm);
      // the resolution chain, in the order it resolves
      const chain = document.createElement('span');
      chain.style.cssText = 'font-family:var(--md-sys-typescale-label-medium-font);font-weight:var(--md-sys-typescale-label-medium-weight);font-size:var(--md-sys-typescale-label-medium-size);line-height:var(--md-sys-typescale-label-medium-line-height);letter-spacing:var(--md-sys-typescale-label-medium-tracking);color:' + T.text2 + ';align-self:stretch;';
      chain.textContent = models.join(' + ') + ' → ' + ids.join(', ') + ' → '
        + regs.map(r => (REGION_DISPLAY[r] || [r])[0] + ' · ' + ((REGION_DISPLAY[r] || ['', r])[1])).join(' + ');
      row.appendChild(head); row.appendChild(chain);
      slot.appendChild(row);
    }
    if (!list.length) {
      const d0 = document.createElement('div');
      d0.style.cssText = 'color:' + T.text2 + ';font-family:var(--md-sys-typescale-body-medium-font);font-size:var(--md-sys-typescale-body-medium-size);line-height:var(--md-sys-typescale-body-medium-line-height);';
      d0.textContent = 'no workload resolves inside the current filters';
      slot.appendChild(d0);
    }
    flowRows = list.length;
    fillFlowBand(list);
  }
  // LOGICAL BAND. Every fixture workload with a footprint is listed; the ones outside
  // the current scope are subordinate (0.28). Fan-in to the one evidenced control
  // plane, fan-out to the models its nodes serve. Straight connectors: logical, not
  // geographic. Label roles: label-medium caps for stages, label-large for entities.
  function fillFlowBand(list) {
    const band = $('[data-flow-band]'); if (!band) return;
    const inScope = new Set(list.map(w => w.id));
    const all = REVIEW_FIXTURE.workloads.filter(w => (w.at || []).length);
    const LM = 'font-family:var(--md-sys-typescale-label-medium-font);font-weight:var(--md-sys-typescale-label-medium-weight);font-size:var(--md-sys-typescale-label-medium-size);line-height:var(--md-sys-typescale-label-medium-line-height);letter-spacing:var(--md-sys-typescale-label-medium-tracking);text-transform:uppercase;color:' + T.text2 + ';';
    const LL = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;color:' + T.text1 + ';';
    const modelNodes = {};
    for (const w of all) for (const a of w.at) { const i = ND2ID[a[0]], m = i && NODE_MODEL[i]; if (m) (modelNodes[m] = modelNodes[m] || new Set()).add(i); }
    const models = Object.keys(modelNodes);
    const wlModels = w => new Set(w.at.map(a => NODE_MODEL[ND2ID[a[0]]]).filter(Boolean));
    band.innerHTML = '<svg data-flow-lines style="position:absolute;inset:0;width:100%;height:100%;" fill="none"></svg>'
      + '<div style="position:absolute;left:28%;top:0;display:flex;flex-direction:column;gap:1px;"><span style="' + LM + '">Workload</span>'
      + all.map(w => '<span data-fb-wl="' + w.id + '" style="' + LL + 'display:flex;align-items:center;gap:8px;opacity:' + (inScope.has(w.id) ? 1 : 0.28) + ';"><i style="width:6px;height:6px;border-radius:50%;background:' + hexOf(WL_COLORS[w.c] || [159,176,170]) + ';"></i>' + w.name + '</span>').join('') + '</div>'
      + '<div data-fb-ctrl style="position:absolute;left:50%;top:0;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:2px;"><span style="' + LM + '">Control plane</span><i data-fb-ctrl-mark style="width:8px;height:8px;border:1.5px solid ' + T.text1 + ';margin-top:10px;"></i><span style="' + LL + '">' + REVIEW_FIXTURE.source.ctrl + '</span><span style="' + LM + 'text-transform:none;">routing · ' + (REGION_DISPLAY[REVIEW_FIXTURE.source.region] || [''])[0] + '</span></div>'
      + '<div style="position:absolute;left:62%;top:0;display:flex;flex-direction:column;gap:6px;"><span style="' + LM + '">Model</span>'
      + models.map(m => '<span data-fb-model="' + m + '" style="' + LL + 'border-top:1px solid ' + T.text2 + ';padding-top:3px;">' + m + ' <span style="color:' + T.text2 + ';">· ' + modelNodes[m].size + (modelNodes[m].size === 1 ? ' node' : ' nodes') + '</span></span>').join('') + '</div>';
    // connectors after layout: row right edge -> control mark -> model left edge.
    // The band is filled while still hidden (the lens applies before the rail
    // motion shows it), so the measurement waits until it has real geometry.
    let tries = 0;
    const wire = () => {
      const svg = band.querySelector('[data-flow-lines]'); if (!svg) return;
      const B = band.getBoundingClientRect();
      if ((!B.width || getComputedStyle(band).display === 'none') && tries++ < 40) { setTimeout(wire, 150); return; }
      const ck = band.querySelector('[data-fb-ctrl-mark]').getBoundingClientRect();
      const cx = ck.left + ck.width / 2 - B.left, cy = ck.top + ck.height / 2 - B.top;
      let d = '';
      for (const w of all) {
        const el = band.querySelector('[data-fb-wl="' + w.id + '"]'); if (!el) continue;
        const r = el.getBoundingClientRect(), x0 = r.right - B.left + 8, y0 = r.top + r.height / 2 - B.top;
        const col = hexOf(WL_COLORS[w.c] || [159,176,170]), a = inScope.has(w.id) ? 0.85 : 0.2;
        d += '<path d="M' + x0 + ' ' + y0 + ' C ' + (x0 + (cx - x0) * 0.6) + ' ' + y0 + ', ' + (cx - 30) + ' ' + cy + ', ' + (cx - 6) + ' ' + cy + '" stroke="' + col + '" stroke-opacity="' + a + '" stroke-width="1.2"/>';
        for (const m of wlModels(w)) {
          const me = band.querySelector('[data-fb-model="' + m + '"]'); if (!me) continue;
          const mr = me.getBoundingClientRect(), x1 = mr.left - B.left - 8, y1 = mr.top - B.top + 2;
          d += '<path d="M' + (cx + 6) + ' ' + cy + ' C ' + (cx + 40) + ' ' + cy + ', ' + (x1 - 40) + ' ' + y1 + ', ' + x1 + ' ' + y1 + '" stroke="' + col + '" stroke-opacity="' + (a * 0.8) + '" stroke-width="1.2"/>';
        }
      }
      svg.innerHTML = d;
    };
    requestAnimationFrame(wire);
  }
  // SCOPED CAPACITY. Read off the field's OWN slot table so a filtered reading is
  // the model's arithmetic, never an invented per-node figure.
  function scopedSlots() {
    const s = F.slots;
    if (!SCOPE || !F.slotTable) {
      return { total: s.total, used: s.used, free: s.free, usedPct: s.usedPct,
               nodes: F.ownership().network.nodes };
    }
    let total = 0, used = 0;
    for (const r of F.slotTable()) {
      const id = ND2ID[r.node];
      if (!id || !nodeOn(id)) continue;
      total++; if (r.used) used++;
    }
    return { total: total, used: used, free: total - used,
             usedPct: total ? Math.round(used / total * 100) : 0, nodes: SCOPE.nodes.size };
  }
  function buildRoutes() {
    const src = REG[REVIEW_FIXTURE.source.region];
    // the unique set of compute nodes carrying engaged workload capacity, and
    // which workloads each one serves — derived from the fixture, nothing else
    const byNode = new Map();
    if (src) for (const co of assign().cohorts) {
      for (const id of co.nodes || []) {
        if (!nodeMarks.some(n => n.id === id)) continue;   // never invent a destination
        const e = byNode.get(id) || { node: id, workloads: [] };
        if (!e.workloads.some(w => w.id === co.id)) e.workloads.push(co);
        byNode.set(id, e);
      }
    }
    for (let i = activeRoutes.length - 1; i >= 0; i--) {
      const r = activeRoutes[i];
      if (byNode.has(r.target)) continue;
      for (let j = traffic.pulses.length - 1; j >= 0; j--)
        if (traffic.pulses[j].r === r) traffic.pulses.splice(j, 1);
      const k = traffic.routes.indexOf(r);
      if (k >= 0) traffic.routes.splice(k, 1);
      activeRoutes.splice(i, 1);
    }
    for (const [id, e] of byNode) {
      const m = nodeMarks.find(n => n.id === id);
      let r = activeRoutes.find(x => x.target === id);
      if (!r) {
        r = traffic.addRoute(src.p, m.p, {
          rids: [REVIEW_FIXTURE.source.region, m.rid], node: id, lift: 0.022
        });
        r.color = [140, 156, 150];             // replaced below by its dominant workload
        r.sourceControlId = REVIEW_FIXTURE.source.ctrl;
        r.target = id; r.targetRegion = m.rid;
        r.streams = [];
        activeRoutes.push(r);
      }
      r.workloads = e.workloads;               // the identities sharing this path
      // one quantitative stream per workload on this node: tok/s -> particles/s.
      // An existing stream keeps its emission budget, so continuity survives.
      const prev = r.streams || [];
      r.streams = e.workloads.map(co => {
        // seeded from the fixture, then refreshed from the live state every frame
        const tps = ((REVIEW_FIXTURE.throughput[co.id] || {})[id]) || 0;
        const s = prev.find(p => p.co && p.co.id === co.id);
        if (s) { s.co = co; s.tokPerSec = tps; s.rate = tps / TOKEN_PARTICLE_SCALE; return s; }
        return { co, node: id, tokPerSec: tps, rate: tps / TOKEN_PARTICLE_SCALE, budget: 0, emitted: 0 };
      });
    }
    nodeAccent = {};
    for (const r of activeRoutes) {
      let best = null, bv = -1;
      for (const s of r.streams) if (s.tokPerSec > bv) { bv = s.tokPerSec; best = s.co; }
      if (best && best.color) { nodeAccent[r.target] = best.color; r.color = best.color; }
    }
  }
  // FLATTER PRODUCT LENS. Screen size of the globe is set by R0 and compensated in
  // cam.fov (fov = zoom * R0 * dist / SR), so pulling the camera back changes only
  // the PERSPECTIVE: at dist ≈ 4×SR the sphere bulged like a fisheye shot, pushing
  // Ohio and Europe apart and wrapping the limb. At ≈ 21×SR the projection is
  // effectively orthographic — the limb and the continents read like a true globe
  // plate, and the transatlantic band sits flat and horizontal, the way an
  // operations interface should read rather than a cinematic globe render.
  // THE WORLD SCALES WITH THE STAGE. Projection is s = fov / dist with a constant
  // fov, so a fixed fit distance drew the sphere at a FIXED pixel size — on a large
  // viewport the globe sat small in a mostly empty frame. The fit distance is now
  // solved from the stage, so the sphere always fills the same fraction of its
  // shorter side. Nothing else changes: node marks, labels and agent glyphs are
  // sized in screen units and keep exactly the weight they have now — only the
  // world and the spacing between its nodes grow.
  const FIT_DIST = 1240;
  const cam = core.makeCam({ yaw: 0, pitch: 0.24, dist: FIT_DIST, tx: 0, ty: 0, tz: 0 });
  let W = 0, H = 0, dpr = 1, ctx = null;
  function bind() {
    const r = canvas.parentElement.getBoundingClientRect();
    W = Math.max(320, Math.round(r.width)); H = Math.max(240, Math.round(r.height));
    dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  bind();
  window.addEventListener('resize', () => setTimeout(bind, 120));

  // ---- lenses: emphasis weights over ONE world; camera state never touched ----
  let view = 'map';
  const K = { map: 1, nodes: 0, swarm: 0 };
  let lensMix = 0;                 // 0 = Traffic (flow), 1 = Capacity (allocation)
  const LENS_DUR = 0.82;           // seconds, same either direction
  let tabEls = [];
  function styleTabs() {
    // read the DOM, not a list captured at boot: the driver loads from <helmet>,
    // before the template's own markup exists, so a cached list can be empty and
    // the control would keep the template's default state forever
    const els = document.querySelectorAll('[data-lens]');
    if (els.length) tabEls = [...els];
    for (const el of tabEls) {
      const on = el.dataset.lens === view;
      // the segmented control owns the frame; a tab only fills when selected, and
      // that fill is the one shared quiet surface the chips and cards also use
      if (el.tagName === 'MD-OUTLINED-SEGMENTED-BUTTON') {
        el.selected = on;
      } else if (el.tagName === 'MD-SECONDARY-TAB' || el.tagName === 'MD-PRIMARY-TAB') {
        if (on) el.setAttribute('active', ''); else el.removeAttribute('active');
      } else {
        el.style.background = on ? 'var(--selected)' : 'transparent';
        el.style.color = on ? 'var(--on-selected)' : 'var(--text-2)';
      }
      const ck = el.querySelector('[data-check]');
      if (ck) { ck.style.display = on ? 'block' : 'none'; ck.style.opacity = '1'; ck.style.transition = ''; }
    }
  }
  function setView(name) {
    view = name;
    styleTabs();
    applyNodesEmphasis();
    // the quantitative panel and the summary strip interpret CAPACITY, and Swarm
    // is the only lens that draws capacity, so they belong to it and to no other
    applyLensPanels();
  }
  // WHICH RAIL THE LENS SHOWS. Split out of setView and re-run from the frame:
  // the driver loads from <helmet>, before the template's own markup exists, so
  // the boot call found no panels and both rails kept their inline display:none
  // until the user happened to switch lenses. Idempotent and cheap.
  // 0..1 -> the rail content's own transition, derived from the same progress
  function lensRailMotion() {
    const fp = document.querySelector('[data-flow-panel]');
    const flows = opLens() === 'flows';
    if (fp) fp.style.display = flows ? 'flex' : 'none';
    const fb = document.querySelector('[data-flow-band]'); if (fb) fb.style.display = flows ? 'block' : 'none';
    const mp = document.querySelector('[data-map-panel]');
    const sp = document.querySelector('[data-cap-panel]');
    if (!mp || !sp) return;
    // FLOWS is a third reading of the SAME world: the rails and the globe stay,
    // only the supporting region changes to the resolution chain.
    if (flows) { mp.style.display = 'none'; sp.style.display = 'none'; return; }
    const m = lensMix;
    const show = (el, k) => {
      el.style.display = k > 0.001 ? 'flex' : 'none';
      if (k <= 0.001) return;
      const e = 1 - Math.pow(1 - k, 3);
      el.style.opacity = String(Math.max(0, Math.min(1, e * 1.35 - 0.35)));
      el.style.transform = 'translateY(' + ((1 - e) * -7).toFixed(2) + 'px)';
      el.style.willChange = 'transform';
    };
    show(mp, 1 - m);
    show(sp, m);
  }
  let chipRO = null, chipMore = null, chipTries = 0;
  let chipSig = '', chipBusy = false;
  function fitHeaderChips(force) {
    if (chipBusy) return;          // re-entry guard: the fit writes styles as it runs
    chipBusy = true;
    try { fitHeaderChipsInner(force); } finally { chipBusy = false; }
  }
  function fitHeaderChipsInner(force) {
    const strip = document.querySelector('[data-h-chips]');
    if (!strip) return;
    const sig = strip.clientWidth + '|' + strip.scrollWidth + '|' + strip.children.length + '|' +
      document.querySelectorAll('[data-node-chip][style*="none"]').length;
    if (!force && sig === chipSig) return;
    chipSig = sig;
    const chips = [...strip.querySelectorAll('[data-node-chip]')];
    if (!chips.length) return;
    // A strip with no width cannot be fitted: measuring now would hide every
    // chip and leave a bare "+11" over an empty row. Retry a bounded number of
    // times in case layout simply has not settled, then give up and take the
    // whole strip out — a counter with nothing to count is noise, not information.
    if (strip.clientWidth < 40) {
      chipSig = '';
      if (chipTries++ < 30) { setTimeout(() => fitHeaderChips(true), 32); return; }
      strip.style.display = 'none';
      if (chipMore) chipMore.style.display = 'none';
      return;
    }
    chipTries = 0;
    if (strip.style.display === 'none') strip.style.display = '';
    if (!chipRO && window.ResizeObserver) { /* installed below on first pass */ }
    if (!chipMore || !chipMore.isConnected) {
      chipMore = document.querySelector('[data-chip-more]');
      if (!chipMore) return;   // the template owns it; nothing to create
    }
    // measure against the row the strip actually has, with every chip laid out
    const gap = parseFloat(getComputedStyle(strip).gap) || 8;
    chipMore.style.display = 'none';
    for (const c of chips) c.style.display = 'inline-flex';
    const avail = strip.clientWidth - gap;
    let used = 0, shown = 0;
    const widths = chips.map(c => c.getBoundingClientRect().width);
    for (let i = 0; i < chips.length; i++) {
      const w = widths[i] + (i ? gap : 0);
      if (used + w > avail) break;
      used += w; shown++;
    }
    // if anything is hidden, the counter needs its own room — give it back a chip
    if (shown < chips.length) {
      chipMore.style.display = 'inline-flex';
      chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
      const mw = chipMore.getBoundingClientRect().width + gap * 2;
      while (shown > 0 && used + mw > avail) { used -= widths[shown - 1] + (shown > 1 ? gap : 0); shown--; }
      chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
      chipMore.title = chips.slice(shown).map(c => c.dataset.nodeChip).join(' · ');
    }
    for (let i = 0; i < chips.length; i++) chips[i].style.display = i < shown ? 'inline-flex' : 'none';
    // verify against the laid-out row, not the predicted one
    {
      const sb = strip.getBoundingClientRect();
      for (let i = shown - 1; i >= 0; i--) {
        const b = chips[i].getBoundingClientRect();
        if (b.right <= sb.right + 0.5 && b.left >= sb.left - 0.5) break;
        chips[i].style.display = 'none';
        shown = i;
      }
      if (shown < chips.length) {
        chipMore.style.display = 'inline-flex';
        chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
        chipMore.title = chips.slice(shown).map(c => c.dataset.nodeChip).join(' · ');
      } else {
        chipMore.style.display = 'none';
      }
    }
    chipSig = strip.clientWidth + '|' + strip.scrollWidth + '|' + strip.children.length + '|' +
      document.querySelectorAll('[data-node-chip][style*="none"]').length;
    if (!chipRO && window.ResizeObserver) {
      let chipPending = false;
      chipRO = new ResizeObserver(() => {
        if (chipPending) return;
        chipPending = true;
        requestAnimationFrame(() => { chipPending = false; fitHeaderChips(true); });
      });
      chipRO.observe(strip);
      // a template re-render restores the chips without changing the strip's
      // width, so the resize observer never sees it — watch the subtree too
      new MutationObserver(() => {
        if (chipPending) return;
        chipPending = true;
        requestAnimationFrame(() => { chipPending = false; fitHeaderChips(true); });
      }).observe(strip, { childList: true });   // NOT attributes: the fit writes style itself
      if (window.customElements && customElements.whenDefined)
        customElements.whenDefined('md-assist-chip').then(() => setTimeout(fitHeaderChips, 60));
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => fitHeaderChips());
    }
  }
  // THEME. Both halves of the role layer move together; nothing else is touched, so
  // the particles, telemetry, camera, selection and lens carry straight through.
  function applyTheme(name) {
    if (!setTheme(name)) return;
    document.documentElement.setAttribute('data-theme', name);
    document.documentElement.classList.toggle('light', name === 'light');
    document.documentElement.classList.toggle('dark', name !== 'light');
    lastKey = '';                 // node cards repaint from the new roles
    asgKey = '';                  // engaged capacity re-derives its colours
    try { buildRoutes(); } catch (_) { }   // route colours come from the new table
    if (chipMore) { chipMore.remove(); chipMore = null; }
    const wb = document.querySelector('[data-m-wl]'); if (wb) delete wb.dataset.k;
    // rail rows are REPAINTED, never rebuilt: a rebuild would restart telemetry
    for (const el of document.querySelectorAll('[data-wlc]')) {
      const c = WL_COLORS[el.dataset.wlc];
      if (!c) continue;
      const hex = hexOf(c);
      if (el.tagName === 'I') el.style.background = hex; else el.style.color = hex;
    }
    try { styleTabs(); applyNodesEmphasis(); } catch (_) { }
  }
  if (typeof window !== 'undefined') {
    window.__ops = window.__ops || {};
    window.__setTheme = applyTheme;
  }
  let __delegated = false;
  function bindControls() {
    if (__delegated) return;
    __delegated = true;
    document.addEventListener('click', ev => {
      const t = ev.target;
      const v = t.closest && t.closest('[data-lens]');
      if (v && v.dataset.lens) { setView(v.dataset.lens); return; }
      const z = t.closest && t.closest('[data-zoom]');
      if (z) { setZoom(zoomT * (z.dataset.zoom === 'in' ? 1.9 : 1 / 1.9), true); return; }
      if (t.closest && t.closest('[data-theme-toggle]')) {
        applyTheme(themeName() === 'dark' ? 'light' : 'dark'); return;
      }
      const wc = t.closest && t.closest('[data-wl]');
      if (wc && !(t.closest('md-icon-button') || t.closest('md-assist-chip') || t.closest('button'))) {
        activateWorkloadCard(wc); return;
      }
      const nc = t.closest && t.closest('[data-node]');
      if (nc && !(t.closest('md-icon-button') || t.closest('md-assist-chip') || t.closest('button'))) {
        activateNodeCard(nc); return;
      }
      const f = t.closest && t.closest('[data-fit]');
      if (f) { computeFitFrame(); fit = true; drag = null; vyaw = 0; vpitch = 0;
        distT = FIT_DIST; manualHold = 0; focusId = null; zoomT = 1; }
    });
  }
  function bindThemeToggle() {
    const el = document.querySelector('[data-theme-toggle]');
    if (!el || el.dataset.bound) return;
    el.dataset.bound = '1';
    // click is handled by the delegate in bindControls — binding it here too made
    // every click flip the theme twice. Only the keys the delegate cannot see.
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        applyTheme(themeName() === 'dark' ? 'light' : 'dark');
      }
    });
  }
  let lastOpLens = '';
  function applyLensPanels() {
    // FLOWS reads the resolved state, so it needs the routes on the world: entering
    // it settles the world on the map reading. Camera, zoom and orientation are
    // untouched, exactly as with the other two lenses.
    const ol = opLens();
    if (ol !== lastOpLens) {
      lastOpLens = ol;
      if (ol === 'flows' && view !== 'map') setView('map');
    }
    const sw = view === 'swarm';
    const lg = $('[data-legend]'); if (lg) lg.style.display = 'none';
    // display is owned by lensRailMotion so a panel can be mid-transition; this
    // only keeps the traffic rail's contents current before it becomes visible
    if (!sw) fillTrafficRail();
    fillFlowPanel();
    lensRailMotion();
    const st = $('[data-strip]'); if (st) st.style.display = (sw && DEV_MODE) ? 'flex' : 'none';
    const ss = $('[data-swarm-state]'); if (ss) ss.style.display = sw ? 'flex' : 'none';
    const wc = $('[data-wl-card]'); if (wc) wc.style.display = 'none';
    // the persistent region shortcut row is gone from the product UI (the wrapper
    // stays as an empty hook); focusRegion() itself is untouched
    const rg = $('[data-regions]'); if (rg) rg.style.display = 'none';
  }
  let railTab = 'nodes';
  function styleRail() {
    for (const el of document.querySelectorAll('[data-rail]')) {
      const on = el.dataset.rail === railTab;
      const lab = el.querySelector('[data-rail-label]');
      if (lab && lab.parentElement) lab.parentElement.style.color = on ? T.primaryInk : T.ink2;
      const ind = el.querySelector('[data-rail-ind]');
      if (ind) ind.style.display = on ? 'block' : 'none';
    }
  }
  function applyNodesEmphasis() {
    // THE RAIL IS THE INVENTORY, AND EVERY CARD READS THE SAME. The Nodes / Stats
    // tabs are gone: a rail that switches between a compact list and a detailed one
    // asked the user to choose a density instead of just showing the inventory, and
    // mixed card heights are harder to scan than a uniform column that scrolls.
    const on = true;
    for (const el of document.querySelectorAll('[data-stats]')) el.style.display = on ? 'flex' : 'none';
    for (const el of document.querySelectorAll('[data-compact]')) el.style.display = on ? 'none' : 'flex';
    for (const t of document.querySelectorAll('[data-tele]')) t.style.display = on ? 'block' : 'none';
    for (const c of document.querySelectorAll('[data-node]')) {
      c.style.background = '';
    }
  }

  // ---- camera: drag rotate + inertia, wheel = constrained zoom, in EVERY lens --
  let drag = null, manualHold = 0, vyaw = 0, vpitch = 0, distT = cam.dist, fit = false;
  // FIT ALL = THE APPROVED OPERATIONAL FRAME, identical in Map and Swarm.
  // Reviewed and locked from the live view: a squarely-faced transatlantic globe
  // (yaw 0.1075, pitch 0.0332) at the flat lens distance, zoom 1. Ohio sits left
  // with YOU beside it, Europe right, the routed arc across the upper third and a
  // substantial globe below. Earlier passes derived this from the node centroid;
  // the derivation kept fighting the composition (too polar, or clusters on the
  // rim), so the reviewed frame is the definition now. Constant means the button
  // is trustworthy: same frame every press, in either lens, whatever the user was
  // looking at. The node-spread figure is still measured, as a review hook only.
  const FIT_YAW = 0.1075, FIT_PITCH = 0.0332;
  let fitYaw = FIT_YAW, fitPitch = FIT_PITCH;
  function computeFitFrame() {
    fitYaw = FIT_YAW; fitPitch = FIT_PITCH;
    if (typeof window !== 'undefined') {
      const cx = -Math.sin(fitYaw) * Math.cos(fitPitch), cy = -Math.sin(fitPitch), cz = -Math.cos(fitYaw) * Math.cos(fitPitch);
      let worst = 0;
      for (const m of nodeMarks) {
        const d = Math.max(-1, Math.min(1, m.u[0] * cx + m.u[1] * cy + m.u[2] * cz));
        worst = Math.max(worst, Math.sin(Math.acos(d)));
      }
      window.__fitDbg = { yaw: fitYaw, pitch: fitPitch, dist: FIT_DIST, worstNodeRadiusFrac: +worst.toFixed(3), nodes: nodeMarks.length };
    }
  }
  // real magnification, independent of dist: 1 = fit-all, 9 = street scale
  const ZMIN = 0.95, ZMAX = 44;
  let zoom = 1, zoomT = 1, focusId = null, focusHold = 0, aimHold = 0;
  const scaleName = z => z < 1.8 ? 'GLOBAL' : z < 6 ? 'REGIONAL' : 'LOCAL';
  function setZoom(v, keepFocus) {
    zoomT = Math.max(ZMIN, Math.min(ZMAX, v));
    fit = false; manualHold = 30;
    if (!keepFocus && zoomT < 1.5) focusId = null;
  }
  function focusRegion(id, z) {
    if (!REG[id]) return;    focusId = id; fit = false; focusHold = 1;
    drag = null; vyaw = 0; vpitch = 0;
    zoomT = Math.max(ZMIN, Math.min(ZMAX, z ?? 3.4));
  }
  function attachCanvas() {
  canvas.style.touchAction = 'none';
  canvas.onpointerdown = e => {
    drag = { x: e.clientX, y: e.clientY, yaw: cam.yaw, pitch: cam.pitch, t: performance.now(), px: e.clientX, py: e.clientY };
    vyaw = 0; vpitch = 0; fit = false; focusId = null;
    try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
  };
  canvas.onpointerup = e => { drag = null; try { canvas.releasePointerCapture(e.pointerId); } catch (_) { } };
  canvas.onpointermove = e => {
    if (!drag) return;
    manualHold = 30;                    // the lean waits until you are done
    const now = performance.now(), dts = Math.max(0.008, (now - drag.t) / 1000);
    cam.yaw = drag.yaw - (e.clientX - drag.x) * 0.006;
    cam.pitch = Math.max(-0.9, Math.min(0.9, drag.pitch + (e.clientY - drag.y) * 0.005));
    vyaw = -(e.clientX - drag.px) * 0.006 / dts;
    vpitch = (e.clientY - drag.py) * 0.005 / dts;
    drag.t = now; drag.px = e.clientX; drag.py = e.clientY;
  };
  // CURSOR ZOOM = THE CLICK BEHAVIOUR. A wheel-in does exactly what clicking a
  // region does: the thing nearest the cursor is taken as the focus, the world
  // turns to face it and it settles in the CENTRE of the panel while the
  // magnification rises. Same camera in Map, Node stats and Swarm, so the
  // gesture reads identically in every lens. Zooming back out releases the
  // focus once the reading returns to GLOBAL, which restores the wide framing.
  function pickUnderCursor(mx, my) {
    const f = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
    const r = [Math.cos(cam.yaw), 0, -Math.sin(cam.yaw)];
    const u = [-Math.sin(cam.yaw) * Math.sin(cam.pitch), Math.cos(cam.pitch), -Math.cos(cam.yaw) * Math.sin(cam.pitch)];
    const dx = (mx - W * 0.5) / cam.fov, dy = (H * 0.5 - my) / cam.fov;
    const D = [f[0] + r[0] * dx + u[0] * dy, f[1] + r[1] * dx + u[1] * dy, f[2] + r[2] * dx + u[2] * dy];
    const O = [-f[0] * cam.dist, -f[1] * cam.dist, -f[2] * cam.dist];
    const a = D[0] * D[0] + D[1] * D[1] + D[2] * D[2];
    const b = 2 * (O[0] * D[0] + O[1] * D[1] + O[2] * D[2]);
    const c = O[0] * O[0] + O[1] * O[1] + O[2] * O[2] - SR * SR;
    const disc = b * b - 4 * a * c;
    // a miss (outside the limb) still gives a direction: the closest point on
    // the ray, projected onto the sphere, so zooming near the rim behaves
    const t = disc >= 0 ? (-b - Math.sqrt(disc)) / (2 * a) : -b / (2 * a);
    const P = [O[0] + D[0] * t, O[1] + D[1] * t, O[2] + D[2] * t];
    const L = Math.hypot(P[0], P[1], P[2]) || 1;
    return [P[0] / L, P[1] / L, P[2] / L];
  }
  // the closest region to a direction on the sphere — the region OWNS its nodes,
  // so focusing it is what brings that group of nodes to the centre
  function nearestRegion(p) {
    let best = null, bd = -2;
    for (const rg of REGIONS) {
      const d = rg.u[0] * p[0] + rg.u[1] * p[1] + rg.u[2] * p[2];
      if (d > bd) { bd = d; best = rg.id; }
    }
    return best;
  }
  canvas.onwheel = e => {
    e.preventDefault();
    const step = -e.deltaY * 0.0026;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top - 16;   // the world sits 16px down
    setZoom(zoomT * Math.exp(step), true);
    if (step > 0) {
      const id = nearestRegion(pickUnderCursor(mx, my));
      if (id) {
        focusId = id; focusHold = 1;
        drag = null; vyaw = 0; vpitch = 0; fit = false; aimHold = 0;
      }
    } else if (zoomT < 1.5) {
      focusId = null;                            // back at GLOBAL: the wide framing
    }
    manualHold = Math.max(manualHold, 30);
  };
  // click a region mark to descend the scales onto it
  canvas.onclick = e => {
    const r = canvas.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top - 16;
    let bi = null, bd = 34 * 34;
    for (const rg of REGIONS) {
      const u = rg.u;
      const f2 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
      if (-(u[0] * f2[0] + u[1] * f2[1] + u[2] * f2[2]) < 0.05) continue;
      const o = core.project(cam, rg.p[0], rg.p[1], rg.p[2], W, H, new Float32Array(4));
      const dd = (o[0] - mx) * (o[0] - mx) + (o[1] - my) * (o[1] - my);
      if (dd < bd) { bd = dd; bi = rg.id; }
    }
    if (bi) focusRegion(bi, focusId !== bi ? 3.4 : zoom < 2.4 ? 3.4 : zoom < 8 ? 24 : 1.1);
  };
  }
  attachCanvas();

  // ---- workload allocation + route identity --------------------------------------
  function activeWorkloads() {
    return F.fixture === 'MULTI-REGION ACTIVE' ? scopedWorkloads() : (WL_BY_FIXTURE[F.fixture] || []);
  }


  // ---- WORKLOAD -> CAPACITY ASSIGNMENT --------------------------------------------
  // P0: resolved ONCE per fixture, never inside the animation loop, and never
  // from array order, randomness or particle position. A workload's slots are
  // read from the review fixture's explicit [node, slotIndex] addresses; where a
  // diagnostic fixture states only counts, the slots are taken in the capacity
  // model's own permanent ownership order — still deterministic, still stable
  // across frames and reloads.
  //
  // Each cohort also gets a PERSISTENT SEMANTIC ANCHOR: a fixed direction on the
  // world derived once from the infrastructure its slots live on (its region,
  // offset by a deterministic angle so two cohorts in one region separate). The
  // anchor rotates with the globe, and it does NOT move when particles move — so
  // the workload label has nothing to jitter against.
  let asg = null, asgKey = '';
  function assign() {
    const N = F.sim.N;
    const key = F.fixture + '|' + Object.values(F.usedByRegion()).join(',');
    if (asg && key === asgKey) return asg;
    asgKey = key;
    const wlc = new Int16Array(N * 3).fill(-1);
    const cohorts = [];
    const regionColor = {};
    const table = F.slotTable ? F.slotTable() : null;
    const list = activeWorkloads();
    if (table && list.length) {
      // the slot's permanent address: [node, index within that node]
      const perNode = {};
      const byAddr = {};
      for (const s of table) {
        const k = (perNode[s.node] = (perNode[s.node] ?? -1) + 1);
        byAddr[s.node + '#' + k] = s;
      }
      const used = table.filter(s => s.used);
      const taken = new Set();
      let si = 0;
      const perRegion = {};
      for (const w of list) {
        const co = { id: w.id || w.name, name: w.name, color: WL_COLORS[w.c] || [159, 176, 170], slots: w.slots, parts: [], rids: {} };
        const mine = [];
        if (w.at) {
          for (const [node, idx] of w.at) {
            const s = byAddr[node + '#' + idx];
            if (s && s.used && !taken.has(s.id)) mine.push(s);
          }
        }
        while (mine.length < w.slots && si < used.length) {   // count-only fixtures
          const s = used[si++];
          if (!taken.has(s.id) && !mine.includes(s)) mine.push(s);
        }
        co.nodes = [];
        for (const s of mine) {
          taken.add(s.id);
          co.rids[s.region] = (co.rids[s.region] || 0) + 1;
          const nd = REVIEW_FIXTURE.nodeIds[s.node];
          if (nd && !co.nodes.includes(nd)) co.nodes.push(nd);
          for (const i of s.ids) {
            co.parts.push(i);
            const o = i * 3;
            wlc[o] = co.color[0]; wlc[o + 1] = co.color[1]; wlc[o + 2] = co.color[2];
          }
          const tally = regionColor[s.region] || (regionColor[s.region] = {});
          tally[w.c] = (tally[w.c] || 0) + 1;
        }
        if (!co.parts.length) continue;
        // DERIVED PHYSICAL FOOTPRINTS. One workload record, but its capacity may
        // live in several regions; each footprint states where that capacity
        // actually is. Nothing downstream may relocate it.
        co.footprints = [];
        {
          const byReg = {};
          for (const s of mine) {
            const fp = byReg[s.region] || (byReg[s.region] = { regionId: s.region, slots: 0, nodeIds: [], particleIds: [] });
            fp.slots++;
            const nd2 = REVIEW_FIXTURE.nodeIds[s.node];
            if (nd2 && !fp.nodeIds.includes(nd2)) fp.nodeIds.push(nd2);
            for (const i of s.ids) fp.particleIds.push(i);
          }
          co.footprints = Object.values(byReg);
        }
        // the cohort's DOMINANT region: metadata only — a reading of where most
        // of its capacity sits. It is never used to move particles or to gather
        // distributed capacity into one place.
        let home = null, hv = -1;
        for (const rid in co.rids) if (co.rids[rid] > hv) { hv = co.rids[rid]; home = rid; }
        co.region = home;
        const k = (perRegion[home] = (perRegion[home] || 0));
        perRegion[home] = k + 1;
        co.slotInRegion = k;
        cohorts.push(co);
      }
      // one persistent anchor per workload FOOTPRINT. The field stations each
      // footprint in the region that actually owns its capacity (see
      // setCohortStations); the label anchors on the workload's primary
      // footprint, and every footprint carries the same workload colour.
      const centres = F.setCohortStations ? F.setCohortStations(cohorts) : {};
      const spread = {};
      for (const co of cohorts) spread[co.region] = (spread[co.region] || 0) + 1;
      for (const co of cohorts) {
        if (centres[co.id]) { co.anchor = centres[co.id]; continue; }
        const rg = REG[co.region];
        if (!rg) { co.anchor = [0, 1, 0]; continue; }
        const u = rg.u;
        let e1 = [u[1], -u[0], 0];
        let L = Math.hypot(e1[0], e1[1], e1[2]);
        if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
        e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
        const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
        const n = Math.max(1, spread[co.region]);
        const th = n === 1 ? 0 : 0.13;                       // arc offset, radians
        const ph = (co.slotInRegion / n) * 6.2832 + 0.7;
        const ct = Math.cos(th), st = Math.sin(th);
        const a0 = [
          u[0] * ct + (e1[0] * Math.cos(ph) + e2[0] * Math.sin(ph)) * st,
          u[1] * ct + (e1[1] * Math.cos(ph) + e2[1] * Math.sin(ph)) * st,
          u[2] * ct + (e1[2] * Math.cos(ph) + e2[2] * Math.sin(ph)) * st
        ];
        const al = Math.hypot(a0[0], a0[1], a0[2]) || 1;
        co.anchor = [a0[0] / al, a0[1] / al, a0[2] / al];
      }
    }
    const domByRegion = {};
    for (const rid in regionColor) {
      let bk = null, bv = -1;
      for (const k in regionColor[rid]) if (regionColor[rid][k] > bv) { bv = regionColor[rid][k]; bk = k; }
      if (bk) domByRegion[rid] = WL_COLORS[bk] || [159, 176, 170];
    }
    asg = { wlc, cohorts, domByRegion };
    return asg;
  }

  // ---- fixtures (diagnostics, not product states) -------------------------------
  let paused = false, timeScale = 1;
  function setFixture(name, fromClick) {
    if (!FIXTURES[name]) return;
    F.fixture = name;
    F.setLevels(FIXTURES[name]);
    if (name === 'MULTI-REGION ACTIVE' && F.setUsedSlotAddresses) {
      // the review state names its slots; every other fixture is a count-based
      // diagnostic and keeps the model's own ordering
      const addrs = [];
      for (const w of scopedWorkloads()) for (const a of (w.at || [])) addrs.push(a);
      F.setUsedSlotAddresses(addrs);
    } else {
      F.setSlots(SLOTS_TOTAL, SLOTS_USED[name] || {});
    }
    asgKey = '';
    buildRoutes();
    const wb = $('[data-m-wl]'); if (wb) delete wb.dataset.k;
    // a regional fixture is a statement about capacity behaviour: show the lens
    // that reads it, without touching the camera (same world, same orientation)
    if (fromClick) {
      const lv = FIXTURES[name];
      let pick = null, ax = 0, ay = 0, az = 0, tot = 0;
      for (const id in lv) {
        if (lv[id] <= 0.2) continue;
        if (!pick || lv[id] > lv[pick]) pick = id;
        const u = REG[id].u, w = lv[id];
        ax += u[0] * w; ay += u[1] * w; az += u[2] * w; tot += w;
      }
      if (pick) {
        if (view !== 'swarm') setView('swarm');
        // the activity centroid, so every coordinating region stays in frame
        const l = Math.hypot(ax, ay, az) || 1;
        const cx = ax / l, cy = ay / l, cz = az / l;
        cam.yawT = Math.atan2(-cx, -cz);
        cam.pitchT = Math.asin(Math.max(-1, Math.min(1, -cy)));
        aimHold = 1.6;
        drag = null; vyaw = 0; vpitch = 0; fit = false;
      }
    }
    for (const el of document.querySelectorAll('[data-fx]')) {
      const on = el.dataset.fx === name;
      el.style.color = on ? T.primaryInk : T.text2;
      el.style.borderColor = on ? rgbaT('primary', .5) : T.border;
    }
  }
  // ---- node cards -----------------------------------------------------------------
  let lastKey = '';
  function syncUI() {
    const S = F.state();
    const used = F.usedByRegion();
    const key = Object.values(used).join('|') + '|' + F.fixture + '|' + view;
    if (key !== lastKey) {
      lastKey = key;
      for (const [rid, ids] of Object.entries(NODES_BY_REGION)) {
        const busy = (used[rid] || 0) > 0;
        for (const id of ids) {
          const card = document.querySelector(`[data-node="${id}"]`);
          const name = card && card.querySelector('[data-node-name]');
          const stat = document.querySelector(`[data-rate="${id}"]`);
          if (!card) continue;
          if (busy) card.dataset.serving = '1'; else delete card.dataset.serving;
          if (card.style.background) card.style.background = '';
          if (name) name.style.color = T.text1;
          if (stat) {
            // the rate is the first thing to go when the rail is narrow: a
            // clipped "e…" says nothing, so it is shown only when it fits whole
            const room = stat.parentElement ? stat.parentElement.clientWidth : 0;
            const fits = room >= 300;
            stat.textContent = (busy && fits) ? 'engaged' : '';
            const sep = stat.previousElementSibling;
            if (sep && sep.tagName === 'I') sep.style.display = (busy && fits) ? 'block' : 'none';
          }
        }
      }
      // P0 DATA BINDING: the card's workload identity comes from the SAME source
      // as the Active Workloads legend — the review fixture — never from static
      // markup. Name and dot show the largest active workload; with no active
      // workload the card carries no invented identity.
      {
        const co = assign().cohorts.slice().sort((p, q) => q.slots - p.slots)[0];
        const nm = $('[data-wl-name]'), dt = $('[data-wl-dot]'), card = $('[data-wl-card]');
        if (nm) nm.textContent = co ? 'workload · ' + co.name.toLowerCase() : 'no active workload';
        if (dt) dt.style.background = co ? hexOf(co.color) : T.ink2;
        // the floating caption is retired: the right rail carries this reading now
        if (card) card.style.display = 'none';
      }
      const busy = Object.keys(used).filter(id => used[id] > 0).map(id => REG[id].label.split(' · ')[0]);
      $('[data-wl-status]').textContent = busy.length
        ? 'adaptive · engaging ' + busy.join(', ')
        : 'adaptive · distributed';
      const fxc = $('[data-fx-chip]'); if (fxc) fxc.textContent = F.fixture;
      // the node badge is the file's own Material 3 component; its label is a prop
      // on the mount, so the count is written to the mount, not into its markup
      // the badge is the file's own Material 3 component, mounted from the bundle;
      // its label element is the only thing the driver touches, so the count stays
      // real fixture data instead of a number typed into the markup
      const nc = $('[data-nodes-head] .sc-host-x span');
      if (nc) {
        // the badge counts what the collection SHOWS, so it can never disagree with
        // the cards under it (supersedes the 2026-08-31 collection-total note)
        const n = String(SCOPE ? SCOPE.nodes.size : F.ownership().network.nodes);
        if (nc.textContent !== n) nc.textContent = n;
      }
    }
    const sc = $('[data-scale]');
    if (sc) {
      sc.textContent = scaleName(zoom) + (focusId ? ' · ' + (REG[focusId].label || focusId) : '');
      sc.style.color = zoom > 1.5 ? T.textHi : T.text2;
    }
    for (const el of document.querySelectorAll('[data-focus]')) {
      const on = el.dataset.focus === focusId;
      el.style.color = on ? T.primaryInk : T.text2;
      el.style.borderColor = on ? rgbaT('primary', .5) : T.border;
    }
    syncPanels(S);
    // The rails are filled from the frame, not only on a lens switch: the driver
    // boots from <helmet>, before the template's own markup exists, so the very
    // first fill finds no container. Both fills self-guard on a key, so this costs
    // one property read per frame once they are populated.
    applyLensPanels();
    applyNodesEmphasis();
    if (view !== 'swarm') { fillTrafficRail(); updateTrafficNumbers(); drawThroughputSpark(performance.now()); }

    const dbg = $('[data-dbg]');
    if (dbg && dbg.style.display !== 'none') {
      dbg.textContent = 'prototype simulation values (not product metrics) — '
        + `capacityParticipation ${S.capacityParticipation.toFixed(2)} · `
        + `crowding engaged ${S.crowding.toFixed(1)} vs field ${S.crowdingAll.toFixed(1)} · `
        + `heading change ${S.turnEngaged.toFixed(2)} vs ${S.turnResting.toFixed(2)} rad/s · `
        + S.regions.filter(r => r.activityLevel > 0.05)
          .map(r => `${r.id} activity ${r.activityLevel.toFixed(2)} coherence ${r.coherence.toFixed(2)} spread ${r.spread.toFixed(2)}`)
          .join(' · ');
    }
  }

  // ---- DRIVER-OWNED ROW SLOTS ---------------------------------------------------
  // A rail container may already carry placeholder rows from the template. Wiping
  // it with textContent='' detaches nodes the template's renderer still owns, and
  // its next reconcile then fails to remove them — which took the whole view down
  // in a render-error loop. So the driver never touches the template's children:
  // it appends ONE slot of its own and rewrites only that, hiding the placeholder
  // rows it supersedes.
  function rowSlot(box) {
    let slot = null;
    for (const el of box.children) if (el.hasAttribute && el.hasAttribute('data-driver-rows')) { slot = el; break; }
    if (!slot) {
      slot = document.createElement('div');
      slot.setAttribute('data-driver-rows', '');
      slot.style.cssText = 'display:flex;flex-direction:column;';
      box.appendChild(slot);
    }
    for (const el of box.children) if (el !== slot) el.style.display = 'none';
    const g = getComputedStyle(box).rowGap;      // inherit the rail's own spacing
    slot.style.gap = (g && g !== 'normal') ? g : '16px';
    slot.textContent = '';
    return slot;
  }

  // ---- the quantitative legend ----------------------------------------------------
  // The right-hand panel and the strip under the world are the SAME numbers at two
  // densities: the strip is the immediate summary, the panel is the detail plus the
  // workload legend. Both read F.slots and the fixture's own workload table, so no
  // two readouts in the frame can disagree. No simulation value reaches either.
  function syncPanels(S) {
    const s = scopedSlots();
    const own = F.ownership();
    const list = activeWorkloads();
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    set('[data-m-cap]', String(s.total));
    set('[data-m-nodes]', String(s.nodes));
    set('[data-m-used]', String(s.usedPct));
    set('[data-m-usedn]', String(s.used));
    set('[data-m-free]', String(s.free));
    // the indicator is the Figma artwork at its own 340x12 scale: the active wave
    // is clipped at the used fraction, and the track picks up 6px after it
    {
      // flat indicator: active bar, 6px gap, track running to the stop at x=334
      const act = $('[data-bar-active]'), track = $('[data-bar-track]');
      const span = 336 - 2;                       // 2px padding, stop excluded
      const aw = Math.max(0, Math.min(span, (s.usedPct / 100) * span));
      if (act && act.getAttribute('width') !== String(aw)) act.setAttribute('width', String(aw));
      if (track) {
        const x = Math.min(330, 2 + aw + 6), w = Math.max(0, 330 - x);
        if (track.getAttribute('x') !== String(x)) { track.setAttribute('x', String(x)); track.setAttribute('width', String(w)); }
      }
    }
    const box = $('[data-m-wl]');
    if (box && box.dataset.k !== F.fixture + '|' + scopeKey) {
      box.dataset.k = F.fixture + '|' + scopeKey;
      const slot = rowSlot(box);
      // ACTIVE means it holds capacity in this snapshot. A workload with 0 slots
      // stays in the fixture (it exists in the review state) but it is not active,
      // so it is not listed here.
      const active = list.filter(w => w.slots > 0);
      if (!active.length) {
        const d0 = document.createElement('div');
        d0.style.cssText = 'color:' + T.text3 + ';font-size:10.5px;';
        d0.textContent = 'none · all capacity free';
        slot.appendChild(d0);
      }
      for (const w of active) {
        const c = { name: w.name, wlc: w.c, color: WL_COLORS[w.c] || [159, 176, 170] };
        const FS = "'Source Sans 3',sans-serif";
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;flex-direction:row;align-items:flex-start;gap:24px;min-height:14px;';
        const nm = document.createElement('span');
        nm.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;flex:1 1 auto;min-width:0;';
        const dot = document.createElement('i');
        dot.dataset.wlc = c.wlc || '';
        dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(c.color) + ';';
        const nmT = document.createElement('span');
        nmT.setAttribute('data-wl-label','');
        // owner 2026-09-01: colour lives in the DOT only; the label stays neutral
        nmT.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:' + T.text1 + ';';
        nmT.textContent = c.name;
        nm.appendChild(dot); nm.appendChild(nmT);
        const q = document.createElement('span');
        q.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:16px;flex:0 0 auto;';
        const numCss = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);text-align:right;color:' + T.ink2 + ';font-variant-numeric:tabular-nums;';
        const qs = document.createElement('span');
        qs.style.cssText = numCss;
        qs.textContent = String(w.slots);
        const sep = document.createElement('i');
        sep.style.cssText = 'width:2px;height:2px;border-radius:50%;background:' + T.ink2 + ';flex:0 0 auto;';
        const qp = document.createElement('span');
        qp.style.cssText = numCss;
        qp.textContent = (w.pct ?? Math.round(w.slots / s.total * 100)) + '%';
        q.appendChild(qs); q.appendChild(sep); q.appendChild(qp);
        row.appendChild(nm); row.appendChild(q);
        slot.appendChild(row);
      }
    }
  }

  // ---- bottom swarm micro-metrics ---------------------------------------------
  // The strip is the ORIGINAL prototype's instrument line, not a dashboard:
  // RELEASE (a discrete behavioural state over five ticks), Cₐ(t) (the MOST
  // ACTIVE REGION's measured coherence — a regional coordination signal, not a
  // per-workload cohort measure, and named that way here so the code stops
  // claiming otherwise) and Nₐ/N (engaged-to-total capacity, as a segmented
  // micro-bar). All three are read from the model; none are quantities the HUD
  // already prints.
  const REL_NAMES = ['DISTRIBUTED', 'ENGAGING', 'COORDINATING', 'STEADY', 'RELEASE'];
  const caBuf = new Float32Array(96);
  let caLen = 0, caAcc = 1, sparkEl = null, sparkCtx = null;
  function syncStrip(dtRaw) {
    const st = $('[data-swarm-state]');
    if (!st || st.style.display === 'none') return;
    const s = F.slots;
    // Cₐ(t) = the coherence of the ENGAGED capacity: every region that actually
    // holds used slots, weighted by how much of the engaged capacity it holds.
    // (It used to report the single most active region's coherence and call it a
    // cohort measure; that claim is gone — this is the engaged aggregate.)
    const usedBy = F.usedByRegion ? F.usedByRegion() : {};
    let cw = 0, cs = 0;
    for (const r of F.regions) {
      const wgt = usedBy[r.id] || 0;
      if (wgt > 0) { cs += Math.max(0, Math.min(1, r.coherence)) * wgt; cw += wgt; }
    }
    let ca = cw ? cs / cw : 0;
    if (!cw) { // nothing engaged: fall back to the field's resting coherence
      let n = 0, acc = 0;
      for (const r of F.regions) { acc += Math.max(0, Math.min(1, r.coherence)); n++; }
      ca = n ? acc / n : 0;
    }
    let eSum = 0, eN = 0;
    for (let i = 0; i < F.sim.N; i++) if (F.alloc[i]) { eSum += F.sim.eng[i]; eN++; }
    const engMean = eN ? eSum / eN : 0;
    let rel;
    if (!s.used && engMean < 0.15) rel = 0;
    else if (!s.used) rel = 4;
    else if (engMean < 0.6) rel = 1;
    else rel = ca > 0.55 ? 3 : 2;
    const rn = $('[data-rel-name]');
    if (rn && rn.textContent !== REL_NAMES[rel]) rn.textContent = REL_NAMES[rel];
    const dots = document.querySelectorAll('[data-rel-dots] i');
    for (let i = 0; i < dots.length; i++) {
      const bg = i === rel ? T.text1 : i < rel ? T.barOn : T.barOff;
      if (dots[i].dataset.on !== bg) { dots[i].dataset.on = bg; dots[i].style.background = bg; }
    }
    const cv = $('[data-ca]');
    if (cv) { const t2 = ca.toFixed(2); if (cv.textContent !== t2) cv.textContent = t2; }
    caAcc += dtRaw;
    if (caAcc < 0.25) return;
    caAcc = 0;
    if (caLen < caBuf.length) caBuf[caLen++] = ca;
    else { caBuf.copyWithin(0, 1); caBuf[caBuf.length - 1] = ca; }
    const el = $('[data-spark]');
    if (!el) return;
    if (el !== sparkEl) { sparkEl = el; sparkCtx = el.getContext('2d'); }
    { const r0 = el.getBoundingClientRect();
      const d0 = Math.min(2, window.devicePixelRatio || 1);
      const ww = Math.round(r0.width * d0), hhh = Math.round(r0.height * d0);
      if (ww && (el.width !== ww || el.height !== hhh)) { el.width = ww; el.height = hhh; } }
    const w2 = el.width, h2 = el.height;
    sparkCtx.clearRect(0, 0, w2, h2);
    sparkCtx.strokeStyle = T.telemetry;
    sparkCtx.lineWidth = (window.devicePixelRatio || 1) * 1.5;   // 1.5 CSS px — owner 2026-09-01: every telemetry line
    sparkCtx.lineJoin = 'round'; sparkCtx.lineCap = 'round';
    sparkCtx.beginPath();
    for (let i = 0; i < caLen; i++) {
      const x2 = (i / (caBuf.length - 1)) * (w2 - 2) + 1;
      const y2 = h2 - 2 - caBuf[i] * (h2 - 4);
      i ? sparkCtx.lineTo(x2, y2) : sparkCtx.moveTo(x2, y2);
    }
    sparkCtx.stroke();
    if (caLen) {
      const x2 = ((caLen - 1) / (caBuf.length - 1)) * (w2 - 2) + 1;
      const y2 = h2 - 2 - caBuf[caLen - 1] * (h2 - 4);
      sparkCtx.fillStyle = T.telemetryHi;
      sparkCtx.fillRect(x2 - 1.2, y2 - 1.2, 2.4, 2.4);
    }
  }

  // ---- controls (re-hooked after any template remount) ------------------------------
  function hookControls() {
    // PRODUCT MODE IS THE DEFAULT. The prototype harness — diagnostic fixtures,
    // pause/speed, tuning sliders, the sim-values readout and the experimental
    // bottom instrument strip — stays in the code (it is still how the model gets
    // tested) but never appears in the product surface. Everything the harness owns
    // carries data-dev-only; the strip is handled in setView. Flip DEV_MODE to true
    // in source to get the harness back. There is deliberately no in-product toggle.
    for (const el of document.querySelectorAll('[data-dev-only]')) el.style.display = DEV_MODE ? 'flex' : 'none';
    tabEls = [...document.querySelectorAll('[data-lens]')];
    for (const el of tabEls) el.onclick = () => setView(el.dataset.lens);
    for (const el of document.querySelectorAll('[data-rail]'))
      el.onclick = () => { railTab = el.dataset.rail; styleRail(); applyNodesEmphasis(); };
    styleRail();
    const fb = $('[data-fit]');
    if (fb) fb.onclick = () => {
      computeFitFrame();
      fit = true; drag = null; vyaw = 0; vpitch = 0;
      distT = FIT_DIST; manualHold = 0; focusId = null; zoomT = 1;
    };
    for (const el of document.querySelectorAll('[data-zoom]'))
      el.onclick = () => setZoom(zoomT * (el.dataset.zoom === 'in' ? 1.9 : 1 / 1.9), true);
    for (const el of document.querySelectorAll('[data-focus]'))
      el.onclick = () => focusRegion(el.dataset.focus,
        el.dataset.focus !== focusId ? 3.4 : zoom < 2.4 ? 3.4 : zoom < 8 ? 24 : 1.1);
    for (const el of document.querySelectorAll('[data-fx]'))
      el.onclick = () => setFixture(el.dataset.fx, true);
    const pb = $('[data-pause]');
    if (pb) pb.onclick = e => { paused = !paused; e.target.textContent = paused ? 'Play' : 'Pause'; };
    const sb = $('[data-slow]');
    if (sb) sb.onclick = e => {
      timeScale = timeScale === 1 ? 0.25 : 1;
      e.target.style.color = timeScale !== 1 ? T.primaryInk : T.text2;
      e.target.style.borderColor = timeScale !== 1 ? rgbaT('primary', .5) : T.border;
    };
    const db = $('[data-debug]');
    if (db) db.onclick = e => {
      const d = $('[data-dbg]');
      const show = d.style.display === 'none';
      d.style.display = show ? 'block' : 'none';
      e.target.style.color = show ? T.primaryInk : T.text2;
      e.target.style.borderColor = show ? rgbaT('primary', .5) : T.border;
    };
    const tf = $('[data-tn-flow]');
    if (tf) tf.oninput = e => { F.tune.flow = parseFloat(e.target.value); };
    const tc = $('[data-tn-chroma]');
    if (tc) tc.oninput = e => { F.tune.chroma = parseFloat(e.target.value); };
  }
  hookControls();

  // the DC template can remount on a hot edit: reacquire the canvas and every
  // hook, restore lens/fixture styling, keep the world and camera untouched
  function rewire() {
    const c = document.querySelector('[data-stage]');
    if (!c || !c.parentElement) return false;
    canvas = c;
    attachCanvas();
    hookControls();
    bind();
    styleTabs();
    applyNodesEmphasis();
    setFixture(F.fixture);
    setView(view);
    const wb2 = $('[data-m-wl]'); if (wb2) delete wb2.dataset.k;
    const pb = $('[data-pause]'); if (pb) pb.textContent = paused ? 'Play' : 'Pause';
    const tf = $('[data-tn-flow]'); if (tf) tf.value = F.tune.flow;
    const tc = $('[data-tn-chroma]'); if (tc) tc.value = F.tune.chroma;
    lastKey = '';
    return true;
  }

  // ---- MAP RAIL: network traffic -----------------------------------------------
  // Origin, total throughput, target count and the per-workload split, all read
  // from REVIEW_FIXTURE. The tok/s figures are PROTOTYPE FIXTURE values (review
  // stand-ins), never measured product rates; the workload totals are the source
  // of truth and the headline total is their sum.
  let trafficKey = '';
  let trafficCells = [], railRows = -1;
  // The rail reads the live state; rows, labels, colours and positions never move.
  // Values are whole tok/s and the underlying signal is already smoothed, so the
  // digits count toward the new reading instead of flickering.
  function updateTrafficNumbers() {
    if (!trafficCells.length || !trafficState._ready) return;
    for (const c of trafficCells) {
      const t = Math.round(trafficState.live[c.wid] || 0).toLocaleString('en-US') + ' tok/s';
      if (c.el.textContent !== t) c.el.textContent = t;
    }
    const tot = $('[data-t-total]');
    if (tot) {
      const t = Math.round(trafficState.totalTokPerSec).toLocaleString('en-US');
      if (tot.textContent !== t) tot.textContent = t;
    }
  }
  // ---- THROUGHPUT HISTORY ------------------------------------------------------
  // The same live state the readings and the particle emission consume, sampled on
  // a slow clock and drawn as one hairline. Not a chart component: no axis, no
  // grid, no fill, no glow — the rail's own vocabulary, in its neutral grey.
  const SPARK_N = 48;             // samples held
  const SPARK_EVERY = 700;        // ms between samples -> ~34s of history
  const spark = [];
  let sparkTook = 0;
  function drawThroughputSpark(now) {
    const cv = $('[data-t-spark]');
    if (!cv || !trafficState._ready) return;
    if (now - sparkTook >= SPARK_EVERY) {
      sparkTook = now;
      spark.push(trafficState.totalTokPerSec);
      if (spark.length > SPARK_N) spark.shift();
    }
    const r = cv.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = Math.round(r.width * dpr), H = Math.round(r.height * dpr);
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const g = cv.getContext('2d');
    g.clearRect(0, 0, W, H);
    if (spark.length < 2) return;
    let lo = Infinity, hi = -Infinity, sum = 0;
    for (const v of spark) { if (v < lo) lo = v; if (v > hi) hi = v; sum += v; }
    const mean = sum / spark.length;
    const floor = Math.max(1, mean * 0.02);
    if (hi - lo < floor) { const c = (hi + lo) / 2; lo = c - floor / 2; hi = c + floor / 2; }
    const span = hi - lo;
    lo -= span * 0.06; hi += span * 0.06;
    g.beginPath();
    for (let i = 0; i < spark.length; i++) {
      const px = (i / Math.max(1, spark.length - 1)) * (W - dpr) + dpr / 2;
      const py = H - dpr / 2 - ((spark[i] - lo) / (hi - lo)) * (H - dpr);
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    }
    g.strokeStyle = T.telemetry;
    g.lineWidth = dpr * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
    g.stroke();
  }
  function fillTrafficRail() {
    const box = $('[data-t-wl]');
    if (!box) return;
    const key = F.fixture + '|' + scopeKey;
    if (trafficKey === key && (railRows === 0 || box.querySelector('[data-driver-rows] > *'))) return;
    trafficKey = key;
    trafficCells = [];
    const T = scopedThroughput();
    trafficState.init({ throughput: T });
    const rows = [];
    const nodes = new Set();
    let total = 0;
    for (const w of scopedWorkloads()) {
      const per = T[w.id] || {};
      let sum = 0;
      for (const nd in per) { sum += per[nd]; nodes.add(nd); }
      if (sum > 0) { rows.push({ wid: w.id, name: w.name, wlc: w.c, color: WL_COLORS[w.c] || [159, 176, 170], tok: sum }); total += sum; }
    }
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    set('[data-t-src]', REVIEW_FIXTURE.source.ctrl);
    set('[data-t-total]', total.toLocaleString('en-US'));
    set('[data-t-targets]', String(nodes.size));
    const slot = rowSlot(box);
    const FS = "'Source Sans 3',sans-serif";
    for (const r of rows) {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;flex-direction:row;align-items:flex-start;gap:24px;min-height:14px;';
      const nm = document.createElement('span');
      nm.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;flex:1 1 auto;min-width:0;';
      const dot = document.createElement('i');
      dot.dataset.wlc = r.wlc || '';
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(r.color) + ';';
      const t = document.createElement('span');
      t.setAttribute('data-wl-label','');
      // owner 2026-09-01: colour lives in the DOT only; the label stays neutral
      t.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:' + T.text1 + ';';
      t.textContent = r.name;
      nm.appendChild(dot); nm.appendChild(t);
      const v = document.createElement('span');
      v.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);text-align:right;white-space:nowrap;color:' + T.ink2 + ';flex:0 0 auto;font-variant-numeric:tabular-nums;';
      v.textContent = Math.round(r.tok).toLocaleString('en-US') + ' tok/s';
      trafficCells.push({ el: v, wid: r.wid });     // only the numbers change later
      row.appendChild(nm); row.appendChild(v);
      slot.appendChild(row);
    }
    railRows = rows.length;   // a legitimate zero-result rebuild stays cached
  }

  // ---- node card sparklines ---------------------------------------------------
  // PROTOTYPE TELEMETRY: each card plots a short cpu (red) / mem (teal) history
  // seeded from that node's stated utilisation. Crisp: the canvas is sized in
  // device pixels and the strokes sit on the half-pixel grid.
  const sparkSeries = new Map();
  // canvas strokeStyle cannot parse var() — resolve tokens against computed style
  const cssCol = c => {
    if (!c || c.indexOf('var(') !== 0) return c;
    const v = getComputedStyle(document.documentElement).getPropertyValue(c.slice(4, -1).trim()).trim();
    return v || null;
  };
  let sparkAt = 0;
  // WHILE THE RAIL IS MOVING, LEAVE IT ALONE. Twenty canvases redrawing mid-scroll
  // is what made the column stutter: each redraw invalidates the masked layer the
  // compositor is trying to slide. The plots hold their last frame during the
  // gesture and resume ~180ms after it stops — no visible loss, the series moves
  // slowly anyway.
  let scrollingUntil = 0;
  let scrollBound = false;
  function bindNodeScroll() {
    if (scrollBound) return;
    const el = $('[data-node-list]');
    if (!el) return;
    scrollBound = true;
    el.addEventListener('scroll', () => { scrollingUntil = performance.now() + 180; }, { passive: true });
  }
  function drawNodeSparks(now) {
    bindNodeScroll();
    if (now < scrollingUntil) return;
    if (now - sparkAt < 220) return;
    sparkAt = now;
    for (const cv of document.querySelectorAll('[data-spark-node]')) {
      const id = cv.dataset.sparkNode;
      let st = sparkSeries.get(id);
      if (!st) { st = { cpu: [], mem: [], p: Math.random() * 6.28 }; sparkSeries.set(id, st); }
      const base = { cpu: +cv.dataset.cpu || 0, mem: +cv.dataset.mem || 0 };
      st.p += 0.35;
      const jit = (a, k) => Math.min(100, Math.max(0, a + Math.sin(st.p * k) * 1.6 + (Math.random() - 0.5) * 1.2));
      st.cpu.push(jit(base.cpu, 1)); st.mem.push(jit(base.mem, 0.6));
      if (st.cpu.length > 64) { st.cpu.shift(); st.mem.shift(); }
      const r = cv.getBoundingClientRect();
      if (!r.width) continue;
      const d = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const g = cv.getContext('2d');
      g.clearRect(0, 0, w, hh);
      const top = Math.max(2, Math.max(...st.cpu, ...st.mem, 8)) * 1.25;
      const plot = (arr, col) => {
        g.beginPath();
        for (let i = 0; i < arr.length; i++) {
          const x = (i / Math.max(1, arr.length - 1)) * (w - d) + d / 2;
          const y = hh - d / 2 - (arr[i] / top) * (hh - d);
          i ? g.lineTo(x, y) : g.moveTo(x, y);
        }
        g.strokeStyle = col; g.lineWidth = d * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
        g.stroke();
      };
      // one neutral for both series: the row labels carry the category
      plot(st.mem, T.telemetry);
      plot(st.cpu, T.telemetry);
    }
    // UTILISATION BANDS, on the reading only — never the card, the node id or the
    // neighbouring rows. Neutral below 75, amber to 89, the system's error red from
    // 90 up, where a resource is effectively saturated.
    const levelColor = v => v >= 90 ? 'var(--md-sys-color-error)'
    : v >= 75 ? 'var(--md-sys-color-tertiary)'
    : T.text1;
    for (const cv of document.querySelectorAll('[data-spark-metric]')) {
      const key = cv.dataset.sparkMetric;
      let st = sparkSeries.get(key);
      if (!st) { st = { v: [], p: Math.random() * 6.28 }; sparkSeries.set(key, st); }
      const base = +cv.dataset.val || 0;
      st.p += 0.4;
      st.v.push(Math.min(100, Math.max(0, base + Math.sin(st.p) * (base * 0.06 + 1.4) + (Math.random() - 0.5) * 1.6)));
      if (st.v.length > 64) st.v.shift();
      const r = cv.getBoundingClientRect();
      if (!r.width) continue;
      const d = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const g = cv.getContext('2d');
      g.clearRect(0, 0, w, hh);
      const top = Math.max(...st.v, 8) * 1.2;
      g.beginPath();
      for (let i = 0; i < st.v.length; i++) {
        const x = (i / Math.max(1, st.v.length - 1)) * (w - d) + d / 2;
        const y = hh - d / 2 - (st.v[i] / top) * (hh - d);
        i ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      const nowV = Math.round(st.v[st.v.length - 1]);
      g.strokeStyle = nowV >= 90 ? cssCol('var(--md-sys-color-error)') : nowV >= 75 ? rgbaT('warn', 0.85) : (cssCol(cv.dataset.col) || T.telemetry);
      g.lineWidth = d * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
      g.stroke();
      // THE NUMBER IS THE SERIES. The reading was static text while the line beside
      // it moved, so a card could show 16% over a plot that was clearly elsewhere.
      // It now reports the sample just plotted, and takes its colour from the level.
      const cur = Math.round(st.v[st.v.length - 1]);
      const col = levelColor(cur);
      const vEl = document.querySelector('[data-mval="' + key + '"]');
      if (vEl) {
        const t = cur + '%';
        if (vEl.textContent !== t) vEl.textContent = t;
        if (vEl.style.color !== col) vEl.style.color = col;
      }
      const card = cv.closest('[data-node]');
      const metric = key.split(':')[1];
      if (card) {
        const sEl = card.querySelector('[data-msum="' + metric + '"]');
        if (sEl) {
          const t = metric + ' ' + cur + '%';
          if (sEl.textContent !== t) sEl.textContent = t;
          if (sEl.style.color !== col) sEl.style.color = col;
        }
      }
    }
  }

  // ---- loop --------------------------------------------------------------------------
  setView('map');
  setFixture('MULTI-REGION ACTIVE');
  buildRoutes();   // the review build opens on the canonical fixture: 10 / 59 used
  // the product opens ON the Fit All frame, so the first thing seen is the same
  // infrastructure-framed composition the button returns to
  computeFitFrame();
  cam.yaw = fitYaw; cam.pitch = fitPitch;
  let tempMask = null;
  let last = performance.now();
  // the frame loop can return before its fit call, so the first run — which is also
  // what installs the observers that keep it correct — is kicked from boot
  const __chipsBoot = () => { try { fitHeaderChips(true); } catch (_) { } };
  setTimeout(__chipsBoot, 32);
  setTimeout(__chipsBoot, 300);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(__chipsBoot);
  // resize fires in bursts; one coalesced pass per burst instead of one per event
  let __chipsT = 0;
  window.addEventListener('resize', () => {
    clearTimeout(__chipsT);
    __chipsT = setTimeout(__chipsBoot, 120);
  });

  // scheduled here, immediately after its definition, so no later failure in boot()
  // can leave the render loop unstarted. Its own first guard handles a canvas that
  // is not attached yet.
  // rAF does not fire in a hidden tab, so the loop needs a pulse that survives it.
  // frame() stamps __tick every pass; the interval pumps ONLY when that stamp has
  // gone stale, so a healthy rAF loop is never doubled and a frozen one is revived.
  // ONE loop, always. rAF does not fire in a hidden tab, so the interval can revive
  // a frozen loop — but it must cancel the outstanding frame first, or each revival
  // leaves another permanent chain running and the page grinds to a halt.
  let __tick = 0, __raf = 0, __to = 0;
  // DUAL SCHEDULER. rAF does not fire reliably in this runtime, and a loop that
  // reschedules itself with rAF alone paints one frame and dies — the watchdog below
  // then revives it about once a second, which reads as frozen. Every frame arms
  // BOTH a rAF and a timer; whichever lands first cancels the other, so a healthy
  // rAF still drives the loop at display rate and a dead one costs nothing.
  const __sched = () => {
    if (__raf) cancelAnimationFrame(__raf);
    if (__to) clearTimeout(__to);
    __raf = requestAnimationFrame(__onFrame);
    __to = setTimeout(() => __onFrame(performance.now()), 24);
  };
  function __onFrame(now) {
    if (__raf) { cancelAnimationFrame(__raf); __raf = 0; }
    if (__to) { clearTimeout(__to); __to = 0; }
    try { frame(now); } catch (_) { }
  }
  const __pump = () => { __onFrame(performance.now()); };
  __pump();
  // ~30fps fallback: fires only when rAF has not ticked for longer than a frame, so
  // it never competes with a healthy loop and never leaves a throttled one at 1fps
  setInterval(() => { if (performance.now() - __tick > 400) __pump(); }, 250);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) __pump(); });

  let lastSizeCheck = 0, lastHookCheck = 0;
  function frame(now) {
    __tick = now;
    __sched();
    if (!canvas || !canvas.isConnected) {
      let ok = false;
      try { ok = rewire(); } catch (_) { ok = false; }
      if (!ok) return;
    }
    if (now - lastHookCheck > 250) {
      lastHookCheck = now;
      const probe = document.querySelector('[data-lens="swarm"]');
      if (probe && !probe.onclick) { hookControls(); styleTabs(); }
    }
    if (now - lastSizeCheck > 250) {
      lastSizeCheck = now;
      const pr = canvas.parentElement.getBoundingClientRect();
      const wantW = Math.round(Math.max(320, Math.round(pr.width)) * dpr);
      const wantH = Math.round(Math.max(240, Math.round(pr.height)) * dpr);
      if (canvas.width !== wantW || canvas.height !== wantH) bind();
    }
    drawNodeSparks(now);
    const dtRaw = Math.min(1 / 30, Math.max(1 / 240, (now - last) / 1000));
    const dt = dtRaw * timeScale;
    last = now;
    const S = F.state();
    const lv = Object.fromEntries(S.regions.map(r => [r.id, r.activityLevel]));
    // OCCUPANCY, not activity. A fixture's activity number describes motion; the
    // used-slot count describes capacity. Everything the product shows — labels,
    // marks, counts, traffic, node chips — reads the slots, so a region can never
    // be presented as busy while none of its capacity is engaged.
    const usedBy = F.usedByRegion();
    const ownR = F.ownership().regions;
    const rinfo = {}, lvq = {};
    for (const r of REGIONS) {
      const o = ownR[r.id];
      rinfo[r.id] = {
        name: r.name || r.id.toUpperCase(),
        used: usedBy[r.id] || 0,
        total: o ? o.slots : 0,
        nodes: o ? o.nodes : (NODE_COUNTS[r.id] || 0)
      };
      lvq[r.id] = o && o.slots ? (usedBy[r.id] || 0) / o.slots : 0;
    }
    const props = PR();
    F.tune.orbit = props.orbitStrength ?? 1.3;

    // TRAFFIC <-> CAPACITY: one progress, 0 = flow, 1 = allocation. Advanced at a
    // fixed rate so the duration is the same whichever way it runs, and eased once
    // here so every consumer below shares the same curve.
    {
      const want = view === 'swarm' ? 1 : 0;
      const step = dtRaw / LENS_DUR;
      lensMix += Math.max(-step, Math.min(step, want - lensMix));
      lensMix = Math.max(0, Math.min(1, lensMix));
    }
    const LM = lensMix < 0.5 ? 4 * lensMix * lensMix * lensMix
                             : 1 - Math.pow(-2 * lensMix + 2, 3) / 2;   // cubic in-out
    K.swarm = LM; K.map = 1 - LM;
    K.nodes += ((view === 'nodes' ? 1 : 0) - K.nodes) * Math.min(1, dtRaw / 0.3);
    // PHASE WINDOWS, all cut from LM so they overlap instead of queueing:
    //   flow finishes -> routes retract -> capacity expands -> stems -> labels
    const win = (a, b) => Math.max(0, Math.min(1, (LM - a) / (b - a)));
    const eOut = x => 1 - Math.pow(1 - x, 3);
    const routeDraw = 1 - win(0.22, 0.55);      // route contracts into its node
    const trafFade  = 1 - win(0.12, 0.42);      // flow hands off as it arrives
    const emergeK   = eOut(win(0.30, 0.68));    // capacity grows out of its anchor
    const stemK     = eOut(win(0.48, 0.78));    // stem draws along the normal
    const labelK    = win(0.62, 0.90);          // label resolves last
    try { lensRailMotion(); } catch (_) { }
    try { fitHeaderChips(); } catch (_) { }
    try { bindControls(); } catch (_) { }
    const mapK = Math.min(1, K.map + K.nodes * 0.9);   // geography emphasis
    const swarmK = K.swarm;

    if (!paused) {
      try { F.update(dt); } catch (err) { if (!window.__fieldErr) { window.__fieldErr = (err && err.stack) || String(err); console.error(err); } }
      const scaleNow = scaleName(zoom);
      // a route carries traffic only while the capacity it describes is engaged;
      // its cadence follows that workload's own slot count and nothing else
      // ONE STATE, THREE CONSUMERS. The live rates advance once per frame here;
      // the rail readings, the per-node stream rates and the emission budget below
      // all read the result, so a rise in the panel IS a rise in particle density.
      trafficState.update(F.sim.t, dt);
      for (const r of activeRoutes) {
        r.want = lvq[r.targetRegion] > 0.01 ? 1 : 0;
        if (!r.want) continue;
        for (const st of r.streams) {
          st.tokPerSec = trafficState.nodeRate(st.co.id, st.node);
          st.rate = st.tokPerSec / TOKEN_PARTICLE_SCALE;
        }
        // TOKENS, not decoration: particles/s = tok/s / TOKEN_PARTICLE_SCALE, run
        // through an emission budget so fractional rates (75 tok/s -> 1.5 p/s)
        // stay mathematically correct instead of rounding away
        for (const st of r.streams) {
          if (st.rate <= 0) continue;
          st.budget += st.rate * dt;
          let guard = 0;
          while (st.budget >= 1 && guard++ < 8) {
            traffic.spawn(r, 1, 1 / TRAFFIC_VISIBLE_WINDOW, st.co.color);
            st.budget -= 1;
            st.emitted++;
          }
        }
      }
      traffic.update(dt);
    }

    // camera integrates on real time so drag/zoom stay live while paused
    if (!drag && (Math.abs(vyaw) > 1e-4 || Math.abs(vpitch) > 1e-4)) {
      cam.yaw += vyaw * dtRaw;
      cam.pitch = Math.max(-0.9, Math.min(0.9, cam.pitch + vpitch * dtRaw));
      const k = Math.exp(-4.5 * dtRaw);
      vyaw *= k; vpitch *= k;
    }
    cam.dist += (distT - cam.dist) * Math.min(1, dtRaw * 6);
    // one eased magnification: transitions between scales read as intentional
    {
      const lz = Math.log(zoom), lt = Math.log(zoomT);
      zoom = Math.exp(lz + (lt - lz) * Math.min(1, dtRaw * 3.0));
      if (Math.abs(zoomT - zoom) < zoomT * 0.002) zoom = zoomT;
    }
    if (fit) {
      const kf = Math.min(1, dtRaw * 4);
      let dy = fitYaw - cam.yaw;
      while (dy > Math.PI) dy -= 6.2831853;
      while (dy < -Math.PI) dy += 6.2831853;
      cam.yaw += dy * kf;
      cam.pitch += (fitPitch - cam.pitch) * kf;
      if (Math.abs(dy) < 0.004 && Math.abs(cam.pitch - fitPitch) < 0.005 && Math.abs(zoom - 1) < 0.02) fit = false;
    }
    if (aimHold > 0 && cam.yawT != null && !drag) {
      let dy = cam.yawT - cam.yaw;
      while (dy > Math.PI) dy -= 2 * Math.PI;
      while (dy < -Math.PI) dy += 2 * Math.PI;
      const k = Math.min(1, dtRaw * 4.5);
      cam.yaw += dy * k;
      cam.pitch += (cam.pitchT - cam.pitch) * k;
      aimHold = Math.max(0, aimHold - dtRaw);
      manualHold = Math.max(manualHold, 0.2);
    }

    // FOCUS: turn the world so the region faces the viewer, then hold it there
    // FOCUS: turn the world so the region faces the viewer, then hold it there.
    // NOT DEAD-ON: a site turned to exactly face the camera puts its radial pole
    // straight down the view axis, where the flag foreshortens to nothing. The
    // geometry stays honestly radial and the FRAMING does the work — the focus
    // target is offset to a three-quarter view, so poles and flags are seen at an
    // angle and read in perspective (owner 2026-09-11).
    if (focusId && REG[focusId] && !drag) {
      const u = REG[focusId].u;
      const wy = Math.atan2(-u[0], -u[2]), wp = Math.asin(Math.max(-1, Math.min(1, -u[1])));
      let dy = wy - cam.yaw;
      while (dy > Math.PI) dy -= 2 * Math.PI;
      while (dy < -Math.PI) dy += 2 * Math.PI;
      const kf = Math.min(1, dtRaw * (focusHold > 0.4 ? 3.4 : 2.2));
      cam.yaw += dy * kf;
      cam.pitch += (wp - cam.pitch) * kf;
      focusHold = Math.max(0, focusHold - dtRaw);
      manualHold = Math.max(manualHold, 0.2);
    }
    if (manualHold > 0) manualHold = Math.max(0, manualHold - dtRaw);
    // P0-I: the review state has NO automatic camera behaviour. No lean toward
    // activity, no auto-centring on workloads, no drift, no hidden rebalancing.
    // The camera moves only when the user drags, zooms or focuses a region.
    // (props.autoLean must be explicitly turned on to restore the old lean.)
    else if (props.autoLean === true && !fit && !focusId && zoom < 1.6) {
      let ax = 0, ay = 0, az = 0, tot = 0;
      for (const r of S.regions) {
        if (r.activityLevel < 0.1) continue;
        const u = REG[r.id].u, w = r.activityLevel;
        ax += u[0] * w; ay += u[1] * w; az += u[2] * w; tot += w;
      }
      if (tot > 0) {
        // focus on the zone of interest: turn to the activity centroid, and
        // zoom so that ALL active regions stay in frame — one region: close;
        // activity spread across the Atlantic: wide enough to hold everything
        const l = Math.hypot(ax, ay, az) || 1;
        const cx2 = ax / l, cy2 = ay / l, cz2 = az / l;
        let spread = 0;
        for (const r of S.regions) {
          if (r.activityLevel < 0.1) continue;
          const u = REG[r.id].u;
          const dotc = Math.max(-1, Math.min(1, u[0] * cx2 + u[1] * cy2 + u[2] * cz2));
          spread = Math.max(spread, Math.acos(dotc));
        }
        const want = Math.atan2(-cx2, -cz2);
        let d = want - cam.yaw;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d < -Math.PI) d += 2 * Math.PI;
        cam.yaw += d * Math.min(1, dt * 0.7);
        cam.pitch += (-0.30 - cam.pitch) * Math.min(1, dt * 0.6);
      } else {
        // no drift: rest at the framing that holds all regions
        let d0 = -cam.yaw;
        while (d0 > Math.PI) d0 -= 2 * Math.PI;
        while (d0 < -Math.PI) d0 += 2 * Math.PI;
        cam.yaw += d0 * Math.min(1, dt * 0.4);
        cam.pitch += (0.24 - cam.pitch) * Math.min(1, dt * 0.5);
      }
    }
    // globe screen radius = zoom · R0. At fit-all the world nearly fills the
    // panel (the reference's presence); zooming genuinely magnifies it.
    // the canvas scales with its panel, like the rest of the design
    // KNOWN-GOOD SWARM GEOMETRY: the world at its original projected radius and
    // the glyphs at their original viewport scale. Every attempt to enlarge the
    // globe regressed the engaged-cohort rendering; if it is retried, glyph size,
    // station pitch and the separation solver must all move together.
    const uiMul = 1;
    setUiScale(Math.min(W, H) / 700);
    // THE WORLD'S SCREEN RADIUS — the one place the globe's size is decided, every
    // frame. The height term binds on a wide stage, so it is what makes the world
    // read large; the width term only takes over on a narrow one. Raised from
    // 0.40/0.34: the sphere now fills ~0.94 of the shorter side instead of ~0.79,
    // and still never crops. Nothing else moves with it — agent glyphs are a fixed
    // 3.2px, node marks and labels are sized in screen units, and the one place
    // that reads the projected scale normalises it against fov/dist.
    const shortView = (window.innerHeight || H) <= 1000;
    let R0;
    if (shortView) {
      // free band between the columns, in canvas pixels
      const cvw = (canvas && canvas.getBoundingClientRect().width) || W;
      const px = W / cvw;                                  // canvas px per css px
      const L = document.querySelector('[data-nodes-rail]');
      const Rr = document.querySelector('[data-map-panel]') || document.querySelector('[data-cap-panel]');
      let band = 0;
      if (L && Rr) {
        const lb = L.getBoundingClientRect(), rb = Rr.getBoundingClientRect();
        band = Math.max(0, rb.left - lb.right) * px;
      }
      // the height term is a floor, not a cap: it keeps the world from collapsing
      // on a window too narrow to hold both columns, and never shrinks the band
      R0 = Math.max(Math.min(band, H * 1.30) / 2, H * 0.55);
    } else {
      R0 = Math.min(W * 0.44, (H - 16) * 0.47);            // large screen: exactly as before
    }
    cam.fov = zoom * R0 * cam.dist / SR;
    if (typeof window !== 'undefined') window.__stageDbg = { R0: +R0.toFixed(1), dia: +(2 * R0).toFixed(1), W, H, short: shortView, ratio: +((2 * R0) / H).toFixed(3) };
    // the formation's spacing follows the screen: pitch = glyph + a small gap
    {
      const pxPerWorld = R0 / SR;
      const uiK = Math.max(1, Math.min(1.55, Math.min(W, H) / 700 * uiMul));
      const glyphPx = (2.8 + 0.55) * 1.24 * 1.1 * 2 * (props.agentScale ?? 1) * uiK;
      F.setStationPitch((glyphPx + 2.4) / (1.7320508 * pxPerWorld));
    }
    // the existing semantic-zoom thresholds speak in distance: give them one
    const sdist = 262 - Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6)) * 90;
    // SWARM ZOOMS ONTO NODES TOO. At GLOBAL, Swarm stays workload-led — no node
    // marks, no infrastructure ids. But descending a scale is the same gesture in
    // both lenses, so from REGIONAL onward the compute nodes come up in Swarm
    // exactly as they do in Map (marks first, hardware detail at LOCAL), which is
    // what lets you zoom onto the node a cohort is actually sitting on.
    const swarmNodesA = swarmK * Math.max(0, Math.min(1, (zoom - 1.9) / 1.1));

    if (ctx) try {
      ctx.clearRect(0, 0, W, H);
      ctx.save();
      ctx.translate(0, 16);            // drop the world below the panel head
      // v3: geography is never absent, only quieter. Map and Node stats carry the
      // full reading (filled land, coasts, graticule); Swarm keeps a third of the
      // stipple's base layer, which is enough to know WHERE a cohort is without
      // competing with it. mapK stays 0 in Swarm, so only that base layer draws.
      // ONE WORLD, TWO LENSES. The geography is the same cartography in Swarm as in
      // Map: same point density, same dot size, same alpha. Swarm used to draw a
      // third of the stipple at a third of the weight, which left the capacity
      // cohorts floating over a hint of a globe rather than over countries.
      const geoK = Math.min(1, K.map + K.nodes + swarmK);
      // THE LIMB IS THE SAME IN EVERY LENS. The globe's outline is the world's
      // edge, not a geography detail, so it draws at full strength in Swarm too
      // (the stipple below still fades to a third there).
      {
        const rimA = Math.min(1, K.map + K.nodes + swarmK);
        if (rimA > 0.01) {
          ctx.save();
          ctx.globalAlpha = rimA;
          drawSphereBase(ctx, cam, W, H, SR, grat, mapK);
          ctx.restore();
        }
      }
      if (geoK > 0.01) {
        ctx.save();
        ctx.globalAlpha = geoK;
        try { ensureLandLod(performance.now()); } catch (_) { }
        // THE ORIGINAL CARTOGRAPHY IS THE CARTOGRAPHY. The filled-continent layer
        // tried here was reverted by direction: geography stays the restrained
        // dotted point-cloud, contextual infrastructure rather than subject. All
        // new information (stems, ids, YOU, traffic) sits ABOVE this quiet layer.
        // the density term drives both the infill thirds and the dot size, so Swarm
        // passes its own lens weight through it and gets Map's cartography verbatim
        const geoDensity = Math.min(1, Math.max(mapK, swarmK));
        drawLand(ctx, cam, W, H, land, F.sim.t, props.landAlpha ?? 1, geoDensity, zoom, landLod);
        ctx.restore();
      }

      // traffic: geographic context in Map, a whisper in Swarm
      // SWARM IS NOT MAP: token traffic is Map's system only. Swarm shows capacity
      // state, so no routes and no token particles are drawn here.
      const trafA = 0.95 * Math.min(1, trafFade + K.nodes);
      if (trafA > 0.02) {
        ctx.save(); ctx.globalAlpha = trafA;
        traffic.draw(ctx, cam, W, H, { scale: scaleName(zoom), focus: focusId, draw: routeDraw,
          flows: opLens() === 'flows',
          flowLabels: opLens() === 'flows' && scopedWorkloads().filter(w => (w.at || []).length).length === 1,
          modelOf: r => NODE_MODEL[r.target], regionOf: r => (REGION_DISPLAY[r.targetRegion] || [r.targetRegion])[0],
          workloadOf: r => (r.workloads && r.workloads[0]) ? r.workloads[0].name : '', ctrlOf: r => r.sourceControlId || '',
          fontStrong: '600 12px "Source Sans 3", sans-serif',
          ink: [232, 234, 233] });
        ctx.restore();
      }
      // capacity: only the Swarm lens shows it — Map is infrastructure
      if (swarmK > 0.03) {
        ctx.save();
        ctx.globalAlpha = swarmK;
        // node and region marks are hard obstacles: capacity flows around them
        const avoid = [];
        {
          const uiK2 = Math.max(1, Math.min(1.55, Math.min(W, H) / 700 * uiMul));
          const glyphD = ((2.8 + 1.0) * (props.agentScale ?? 1) * uiK2) * 2 + 1.6 * uiK2;
          // the ball's hollow core, in px — the obstacle must fit inside it so
          // it can never displace the body it sits in
          let coreW = Infinity;
          for (const rg of F.regions) if (rg.ballR) coreW = Math.min(coreW, rg.ballR * 0.42);
          if (!isFinite(coreW)) coreW = F.stationPitch * 0.65;
          const rMax = Math.max(4, coreW * (R0 / SR) - glyphD * 0.5);
          const rNode = Math.min(11, rMax);
          for (const m of nodeMarks) {
            core.project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
            avoid.push([o4[0], o4[1], rNode]);
          }
        }
        // ORIENTATION TICKS — the free capacity field only. Engaged capacity now
        // carries its structure explicitly: the radial spokes out of its
        // workload's anchor. A second, per-particle stroke system on top of that
        // read as arbitrary scribble, so it is gone from engaged marks.
        {
          const f3 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
          const sim3 = F.sim;
          ctx.lineWidth = 0.75;
          for (let i = 0; i < sim3.N; i++) {
            if (F.alloc[i]) continue;                  // engaged: the spokes speak
            if (i % 4) continue;                       // free field: a sparse quarter
            const x3 = sim3.px[i], y3 = sim3.py[i], z3 = sim3.pz[i];
            const pl3 = Math.hypot(x3, y3, z3) || 1;
            const fc = -(x3 * f3[0] + y3 * f3[1] + z3 * f3[2]) / pl3;
            if (fc < 0.22) continue;
            // the tick starts just OFF the glyph and runs outward along the normal.
            // A radial line foreshortens to nothing at the disc centre (it points
            // at the camera), so the projected stroke is stretched to a small
            // minimum length — the mark stays a subtle tick at every latitude.
            const k0 = 1 + 0.35 / pl3;
            const kk = 1 + (0.35 + 1.15) / pl3;
            core.project(cam, x3 * k0, y3 * k0, z3 * k0, W, H, o4c);
            core.project(cam, x3 * kk, y3 * kk, z3 * kk, W, H, o4d);
            let dx3 = o4d[0] - o4c[0], dy3 = o4d[1] - o4c[1];
            const L3 = Math.hypot(dx3, dy3);
            const Lmin = 3.2;
            if (L3 < 0.4) continue;                    // dead-on: no honest direction
            if (L3 < Lmin) { dx3 *= Lmin / L3; dy3 *= Lmin / L3; }
            ctx.strokeStyle = `rgba(159,176,170,${(0.16 * fc).toFixed(3)})`;
            ctx.beginPath(); ctx.moveTo(o4c[0], o4c[1]); ctx.lineTo(o4c[0] + dx3, o4c[1] + dy3); ctx.stroke();
          }
        }
        const realTemp = F.sim.temp;
        if (!tempMask || tempMask.length !== realTemp.length) tempMask = new Float32Array(realTemp.length);
        let tmax = 0;
        for (let i = 0; i < realTemp.length; i++) {
          const v = F.alloc[i] ? F.chroma[i] : 0;   // v3: the accent, not the thermal field
          tempMask[i] = v;
          if (v > tmax) tmax = v;
        }
        const realMax = F.sim.tempMax;
        F.sim.temp = tempMask; F.sim.tempMax = tmax;
        F.sim.wlc = assign().wlc;            // per-particle workload identity
        // RADIAL LIFT, FOR DRAWING ONLY. Engaged capacity is shown standing a
        // little way up its workload's filament, along the local normal, so the
        // cohort reads as a plume emerging from the sphere. The physics keeps
        // running on the shell: positions are restored immediately after the
        // draw, so the lift can never fight the docking or accumulate.
        const lf = F.lift;
        let sv = null;
        {
          const s5 = F.sim;
          sv = [Float32Array.from(s5.px), Float32Array.from(s5.py), Float32Array.from(s5.pz)];
          // origin of the emergence, per particle: its own anchor on the sphere
          const org = F.emergeOrigins ? F.emergeOrigins() : null;
          const em = emergeK;
          for (let i = 0; i < s5.N; i++) {
            let x = s5.px[i], y = s5.py[i], z = s5.pz[i];
            if (em < 0.999 && org) {
              const o = i * 3;
              const ax = org[o] * SR, ay = org[o + 1] * SR, az = org[o + 2] * SR;
              if (ax || ay || az) { x = ax + (x - ax) * em; y = ay + (y - ay) * em; z = az + (z - az) * em; }
            }
            const h = lf ? lf[i] * em : 0;
            if (h) { const L0 = Math.hypot(x, y, z) || 1; const kk = (L0 + h) / L0; x *= kk; y *= kk; z *= kk; }
            s5.px[i] = x; s5.py[i] = y; s5.pz[i] = z;
          }
        }
        sceneOrig.drawScene(ctx, W, H, F.sim, {
          cam,
          keepCanvas: true,
          hideInstrument: true,
          isotherms: false,          // v3: thermal contours read as failure, not coordination
          // TRAILS OFF. Capacity marks stand on the sphere with their own normal
          // stems; a tail behind each one added motion blur on top of that and made
          // the field read as smeared rather than as discrete standing capacity.
          trails: props.trails ?? false,
          trailCfg: {
            n: Math.min(F.sim.TL, props.trailLength ?? 15),
            stride: props.trailEvery ?? 4,
            w: props.trailWidth ?? 0.55,
            alpha: props.trailOpacity ?? 0.2,
            ticks: props.trailTicks ?? true,
            depth: props.trailDepth ?? true,
            taper: props.trailTaper ?? false,
            speedK: props.trailSpeedK ?? false
          },
          glyph: GLYPHS[props.glyph ?? 'Hexagon'] || GLYPHS.Hexagon,
          glyphK: props.agentScale ?? 1
        }, null, null, { on: 0, phase: 0 });
        // PER-PARTICLE SPHERE NORMALS: every engaged mark carries the same
        // geometry as its workload stem — a line straight out along its own
        // normal — but markedly fainter and shorter, so the structure reads
        // workload-stem first and particle-stem second. Drawn while the draw-only
        // radial lift is still applied, so each starts at its own glyph.
        drawParticleStems(ctx, cam, F.sim, W, H, F.alloc, swarmK, SR);
        if (sv) { F.sim.px.set(sv[0]); F.sim.py.set(sv[1]); F.sim.pz.set(sv[2]); }
        F.sim.temp = realTemp; F.sim.tempMax = realMax;
        ctx.restore();
      }
      // ONE label layer, in priority order: cohorts claim their slots and
      // reserve their footprint first, then region names, then place names.
      // where the colony's response actually sits, so the mark is in the swarm
      let ballAt = null;
      if (F.sim.perturb > 0.02) {
        let dm = null;
        for (const rg of S.regions) if (!dm || rg.activityLevel > dm.activityLevel) dm = rg;
        if (dm && dm.activityLevel > 0.1) ballAt = { id: dm.id, r: F.sim.shellR * 1.35, p: [F.sim.probe.x, F.sim.probe.y, F.sim.probe.z] };
      }
      beginLabels(ctx);
      {
        const cr = canvas.getBoundingClientRect();
        // The rails are opaque chrome, and world-scene's placer treats panels and
        // control rails as the one thing a fixed-offset label may dodge — but they
        // were never handed in, so labels (the YOU lockup most visibly) slid under
        // the node rail. Registering them lets the label flip to its free side.
        for (const sel of ['[data-scale]', '[data-focus]', '[data-cap-panel]', '[data-strip]', '[data-wl-card]', '[data-nodes-rail]', '[data-map-panel]']) {
          for (const el of document.querySelectorAll(sel)) {
            const r = el.getBoundingClientRect();
            keepOutRect(r.left - cr.left - 4, r.top - cr.top - 16 - 3, r.width + 8, r.height + 6);
          }
        }
        keepOutRect(0, -16, W, 58);          // panel head: lens tabs and Fit All
      }
      // node markers reserve their spot only AFTER the regional labels are
      // placed: a regional label must be able to sit BESIDE its own anchor, and
      // the node discs cluster exactly there. Node ids come last and yield.
      const reserveNodes = () => {
        const f4 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
        for (const m of nodeMarks) {
          if (-(m.u[0] * f4[0] + m.u[1] * f4[1] + m.u[2] * f4[2]) < 0.1) continue;
          core.project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
          keepOut(o4[0], o4[1], 5);
        }
      };
      // WHERE / WHAT / HOW MUCH — rinfo and lvq are built at the top of the frame
      // from the ownership model, so the labels, the marks and the panels are all
      // printing the same numbers.
      const scaleTxt = scaleName(zoom);
      // P0-F: the label layout is only re-solved when the camera meaningfully
      // moves. Quantising yaw/pitch/zoom gives a key that is constant while the
      // user is not touching anything, so stored placements simply persist.
      const camKey = (Math.round(cam.yaw * 24) + '|' + Math.round(cam.pitch * 24) + '|' + Math.round(Math.log(zoom) * 8) + '|' + view);
      const zz = Math.max(0, Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6)));
      // collision priority order: YOU first, then cohort cards, then regions,
      // then node ids (serving first), then secondary hardware detail
      // MAP: YOU and its location are ONE context block, and it is the only
      // explicit location text on the lens. SWARM: the word YOU alone, because
      // the region prints its own spatial reference there.
      const mapLensA = Math.min(1, K.map + K.nodes);
      // GLOBAL SWARM is workload-led, with NO operator/location layer: the YOU
      // lockup (and with it control-use2-1 and its Ohio context) belongs to Map
      // only, where geography, control and nodes are the reading. In Swarm it
      // would compete with the workload identities, so its alpha is the Map/Nodes
      // lens alpha alone — it fades out entirely as Swarm takes over.
      drawYou(ctx, cam, W, H, REG.ohio.u, SR, zz, mapLensA, {
        combined: mapLensA > 0.5,
        region: REG.ohio.name, nodes: rinfo.ohio.nodes, ctrl: REG.ohio.ctrl
      });
      // P0 PRIORITY LAYERS, in order: YOU / control reference, then the
      // infrastructure regions, then the workload cohorts, then node detail. A
      // lower layer can never displace a higher one, so moving capacity cannot
      // push an infrastructure label around.
      // no regional anchors on the Map: a mark that is not a compute node must
      // not look like one. Ohio's context is the YOU block; Europe is read from
      // its own nodes and their traffic.
      // NO REGIONAL ANCHOR MARKERS, in either lens: a mark that is not a compute
      // node must not look like one. Regions are named in text in Swarm; Ohio's
      // context is the YOU lockup. Only the 10 real nodes carry node marks.
      // REGION NAMES: Swarm keeps them as its spatial reference (it has no
      // basemap to orient against); on the geographic Map they are contextual
      // only — at GLOBAL the reading is YOU + nodes + workload traffic, and the
      // names arrive when you descend a scale or focus a region.
      // region names: SWARM only. The Map has no persistent FRANKFURT /
      // EU-WEST overlays — geography plus the real nodes carry the location.
      // LOCATION LABELS ARE CONTEXTUAL, NOT PERSISTENT. In GLOBAL Swarm the only
      // location text is the YOU lockup: the globe and the distribution of
      // capacity already carry the spatial reading, so FRANKFURT / EU-WEST would
      // only compete with workload state. Other regions name themselves once you
      // descend a scale or focus one — and Ohio never repeats itself, because the
      // YOU lockup is already saying it.
      const namedRegions = (scaleTxt === 'GLOBAL' && !focusId)
        ? []
        : REGIONS.filter(r => r.id !== 'ohio');
      // SEMANTIC ZOOM ON REGION NAMES: full weight only while the world is the
      // subject; at REGIONAL they drop to a third as node ids take over, and at
      // LOCAL they go entirely — the node context already says where you are.
      const regionFade = scaleTxt === 'LOCAL' ? 0 : scaleTxt === 'REGIONAL' ? 0.34 : 1;
      drawSideRegionLabels(ctx, cam, W, H, namedRegions, NBR, 0.52 * swarmK * regionFade, rinfo, camKey);
      reserveNodes();
      drawNodeMarks(ctx, cam, W, H, nodeMarks, lvq, Math.min(1, Math.max(K.map, swarmNodesA)), K.nodes, sdist, F.sim.t, scaleTxt, focusId, zz, NODE_HW, Math.min(1, K.map + K.nodes) > 0.5, nodeAccent);
      // workload labels sit BELOW node ids in priority: activity yields to
      // infrastructure identity, never the other way round
      // WORKLOAD NAMES ARE A SWARM READING ONLY. On the geographic Map the workload
      // is already stated twice — by its token colour on the route and by Traffic by
      // workload in the right rail — so repeating the names over the geography was
      // pure duplication. Hard gate on the lens, not just on its eased weight.
      const wlLabelA = K.map > 0.5 ? 0 : swarmK;
      {
        const _st = F.cohortStructures ? F.cohortStructures() : null;
        if (typeof window !== 'undefined' && _st) {
          // review hook: how many footprints each workload actually has on the world
          const fp = {}; for (const k in _st) fp[k] = (_st[k].all || [_st[k]]).length;
          window.__fpDbg = fp;
        }
        drawWorkloadCohorts(ctx, cam, W, H, F.sim, assign().cohorts, wlLabelA, SR, camKey, _st, stemK, labelK);
      }
      // AUXILIARY CITY NAMES: off. This is an abstract operational world, not a
      // cartographic gazetteer — geographic context comes from the YOU lockup and
      // the real node ids, so scattered town names are pure noise.
      // drawPlaces(ctx, cam, W, H, SR, focusId, ...) intentionally not called.
      ctx.restore();
    } catch (err) {
      if (!window.__drawErr) { window.__drawErr = (err && err.stack) || String(err); console.error(err); }
      try { ctx.restore(); } catch (_) { }
    }
    try { syncUI(); } catch (err) { if (!window.__syncErr) { window.__syncErr = (err && err.stack) || String(err); console.error(err); } }
    try { syncStrip(dtRaw); } catch (_) { }
  }

  // review/testing hook
  window.__ops = {
    // review hook: the resolved scope and the capacity reading derived from it
    get scope() {
      return { key: scopeKey, nodes: SCOPE ? [...SCOPE.nodes] : null,
               wl: SCOPE ? [...SCOPE.wl] : null, slots: scopedSlots(), lens: opLens(), view: view };
    },
    get state() {
      return {
        ...F.state(), view,
        lens: { map: +K.map.toFixed(3), nodes: +K.nodes.toFixed(3), swarm: +K.swarm.toFixed(3) },
        yaw: +cam.yaw.toFixed(4), pitch: +cam.pitch.toFixed(4), dist: +cam.dist.toFixed(1),
        zoom: +zoom.toFixed(2), scale: scaleName(zoom), focus: focusId, fov: Math.round(cam.fov),
        slots: F.slots, audit: F.audit(), ownership: F.ownership(),
        stationPitch: +F.stationPitch.toFixed(3),
        geometry: F.geometry(),
        motor: F.motor(),
        pulses: traffic.pulses.length,
        // P1 review hook: the derived route table, explicit ownership included
        tokenScale: TOKEN_PARTICLE_SCALE,
        visibleWindow: TRAFFIC_VISIBLE_WINDOW,
        routes: activeRoutes.map(r => ({
          sourceControlId: r.sourceControlId,
          targetNodeId: r.target, targetRegionId: r.targetRegion,
          workloads: r.workloads.map(w => ({ workloadId: w.id, name: w.name, color: w.color })),
          streams: r.streams.map(s => ({
            workloadId: s.co.id, tokPerSec: s.tokPerSec,
            particlesPerSec: +s.rate.toFixed(3), emitted: s.emitted
          }))
        }))
      };
    },
    // review hook: step the field without the animation frame, so a headless
    // check can settle the model deterministically before measuring it
    advance(sec) {
      const n = Math.max(1, Math.round((sec || 1) * 60));
      for (let i = 0; i < n; i++) F.update(1 / 60);
      return +F.sim.t.toFixed(2);
    },
    setView, 
    setTheme: applyTheme, theme: themeName,
    setFixture, focusRegion, setZoom,
    fitAll() { computeFitFrame(); fit = true; focusId = null; zoomT = 1; drag = null; manualHold = 0; },
    get zoom() { return zoom; },
    get scale() { return scaleName(zoom); },
    setTimeScale(v) { timeScale = v; },
    fixtures: Object.keys(FIXTURES)
  };
}

// boot only once the template has fully streamed: [data-dbg] is the last
// interactive element in the DC, so its presence means every hook exists
(function wait() {
  const c = document.querySelector('[data-stage]');
  if (c && c.parentElement && document.querySelector('[data-fit]')) {
    // ONE INSTANCE. The helmet script can be evaluated more than once across a
    // remount, and two live drivers share one DOM: both write the fixture chip,
    // both style the tabs and both draw, so the page appears to fight itself and
    // to revert state at random. The first boot wins; a second is a no-op.
    if (window.__opsBooted) return;
    window.__opsBooted = 1;
    boot(c);
  } else setTimeout(wait, 32);
})();

// NODE LIST TOP FADE (owner 2026-09-01): the top edge only fades once the list is
// actually scrolled — at rest the first card shows whole.
// Capture-phase at document level so it survives any remount of the list node.
document.addEventListener('scroll',e=>{
  const el=e.target;
  if(!(el instanceof Element)||!el.hasAttribute||!el.hasAttribute('data-node-list'))return;
  if(el.scrollTop>2) el.setAttribute('data-scrolled',''); else el.removeAttribute('data-scrolled');
},{capture:true,passive:true});


// CHIP FIT — LATE MEASURE. The strip is measured at boot, before the chips are
// upgraded custom elements, so their widths read 0 and nothing looks clipped.
// Force one more fit when the definitions and the webfont land.
(function lateChipFit(){
  const again = () => { try { fitHeaderChips(true); } catch (_) {} };
  if (window.customElements) customElements.whenDefined('md-icon').then(again).catch(() => {});
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(again).catch(() => {});
  window.addEventListener('load', again);
  setTimeout(again, 600);
})();


// NODE CARD ACTIVATION. The cards are interactive (owner, 2026-09-01), so they
// are reachable by keyboard and they act on a capability the product already
// has: focusing the node's region in the world. No new behaviour is invented —
// this is the same focusRegion the canvas uses.
(function nodeCardActivation(){
  const REGION_OF = { ohio: 'ohio', frankfurt: 'frankfurt', dublin: 'dublin' };
  const NODE_REGION = {
    'amd-0':'ohio','sev-0':'ohio','sev-1':'ohio','sev-2':'ohio',
    'gpu-1':'frankfurt','gpu-2':'frankfurt','sev-6':'frankfurt',
    'sev-3':'dublin','sev-4':'dublin','sev-5':'dublin'
  };
  window.activateNodeCard = function (card) {
    const id = card && card.dataset && card.dataset.node;
    const reg = id && REGION_OF[NODE_REGION[id]];
    if (reg && window.__ops && window.__ops.focusRegion) window.__ops.focusRegion(reg);
  };
  const arm = () => {
    const cards = document.querySelectorAll('[data-node]');
    if (!cards.length) { setTimeout(arm, 60); return; }
    for (const c of cards) {
      if (c.dataset.kbd) continue;
      c.dataset.kbd = '1';
      c.tabIndex = 0;
      c.setAttribute('role', 'button');
      c.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.activateNodeCard(c); }
      });
    }
  };
  arm();
  setInterval(arm, 1000);   // the rail re-renders; new cards get the same reach
})();


// WORKLOAD CARD ACTIVATION. Same contract as the node cards: whole card, pointer
// or Enter/Space, nested controls exempt. The outcome is the product's current
// workload — recorded on <html> so one source of truth drives whatever the
// workspace grows into. No visual treatment is attached to it yet.
(function workloadCardActivation(){
  window.activateWorkloadCard = function (card) {
    const id = card && card.dataset && card.dataset.wl;
    if (!id) return;
    document.documentElement.dataset.currentWorkload = id;
    window.dispatchEvent(new CustomEvent('civarro:workload', { detail: { id } }));
  };
  const arm = () => {
    const cards = document.querySelectorAll('[data-wl]');
    if (!cards.length) { setTimeout(arm, 60); return; }
    for (const c of cards) {
      if (c.dataset.kbd) continue;
      c.dataset.kbd = '1';
      c.tabIndex = 0;
      c.setAttribute('role', 'button');
      c.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.activateWorkloadCard(c); }
      });
    }
  };
  arm();
  setInterval(arm, 1000);
})();


// PERSISTENT SELECTION. One selected entity per collection: activating a card
// clears its siblings and marks itself. The treatment is the kit's focused
// recipe, reused by owner decision, so nothing new is drawn.
(function persistentSelection(){
  // Owner 2026-09-11: node cards no longer carry a persistent selection — the
  // state was dropped, not restyled. Activation behaviour is untouched. Workload
  // cards keep theirs: the Workloads destination renders from the current one.
  function select(card, group) {
    for (const s of document.querySelectorAll('[' + group + '][data-selected]')) {
      if (s !== card) s.removeAttribute('data-selected');
    }
    card.setAttribute('data-selected', '');
  }
  for (const s of document.querySelectorAll('[data-node][data-selected]')) s.removeAttribute('data-selected');
  const wlAct = window.activateWorkloadCard;
  if (wlAct) window.activateWorkloadCard = function (card) { select(card, 'data-wl'); return wlAct(card); };
})();


// WORKLOADS — navigator selection, tabs, search and the wide evidence drawer.
// Every value rendered comes from REVIEW_FIXTURE; nothing is synthesised.


// WORKLOADS — selection, filters, search, summary and serving-node composition.
// Every figure is REVIEW_FIXTURE or arithmetic on it; nothing is synthesised.


// WORKLOADS ACTIVE — populated. Node identity, region, per-node throughput, slots
// and share come from REVIEW_FIXTURE; invoice, evidence marks, engine counters and
// the five series come from the demo content module. One renderer, so every region
// of the screen is driven by the same selected workload.

// WORKLOADS ACTIVE — populated. Node identity, region, per-node throughput, slots
// and share come from REVIEW_FIXTURE; invoice figures, evidence marks, engine
// counters and the five series come from ops-v4/workload-demo.js. One renderer, so
// every region of the screen is driven by the same selected workload.
(function workloadsActive(){
  const NODE={'ohio-node-01':['amd-0','Ohio'],'ohio-node-02':['sev-0','Ohio'],'ohio-node-03':['sev-1','Ohio'],'ohio-node-04':['sev-2','Ohio'],'frankfurt-node-01':['gpu-1','Frankfurt'],'frankfurt-node-02':['gpu-2','Frankfurt'],'frankfurt-node-03':['sev-6','Frankfurt'],'dublin-node-01':['sev-3','EU-West'],'dublin-node-02':['sev-4','EU-West'],'dublin-node-03':['sev-5','EU-West']};
  const HW={'amd-0':'AMD Radeon Pro V520 8GB','gpu-1':'NVIDIA L4 24GB','gpu-2':'NVIDIA L4 24GB','sev-0':'CPU · AMD EPYC / SEV-SNP','sev-1':'CPU · AMD EPYC / SEV-SNP','sev-2':'CPU · AMD EPYC / SEV-SNP','sev-3':'CPU · AMD EPYC / SEV-SNP','sev-4':'CPU · AMD EPYC / SEV-SNP','sev-5':'CPU · AMD EPYC / SEV-SNP','sev-6':'CPU · AMD EPYC / SEV-SNP'};
  const COLOR={'eric-1':'eric','vision-1':'vision','conf-remote-1':'confRemote','workload-1':'workload','conf-carlos-1':'confCarlos','eric-2':'eric'};
  const T=function(r){return 'font-family:var(--md-sys-typescale-'+r+'-font);font-weight:var(--md-sys-typescale-'+r+'-weight);font-size:var(--md-sys-typescale-'+r+'-size);line-height:var(--md-sys-typescale-'+r+'-line-height);letter-spacing:var(--md-sys-typescale-'+r+'-tracking);';};
  const byId={}; for(const w of REVIEW_FIXTURE.workloads) byId[w.id]=w;
  const esc=function(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');};
  const CUR='$';

  function spark(seed,color,w,h){
    let s=seed,pts=[],n=40;
    for(let i=0;i<n;i++){ s=(s*1103515245+12345)&0x7fffffff; const v=(s%1000)/1000;
      pts.push((i/(n-1)*w).toFixed(1)+','+(h-4-v*(h-8)).toFixed(1)); }
    return '<svg viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" style="width:100%;height:'+h+'px;display:block;overflow:visible;"><polyline points="'+pts.join(' ')+'" fill="none" stroke="'+color+'" stroke-width="1.25" vector-effect="non-scaling-stroke"/></svg>';
  }
  const lab=function(t){return '<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--md-sys-color-on-surface-variant);">'+t+'</span>';};
  const over=function(t){return '<span style="'+T('label-large')+'text-transform:uppercase;color:var(--text-1);">'+t+'</span>';};
  function markHTML(t,tone){
    const col = tone==='error' ? 'var(--md-sys-color-error)' : tone==='accent' ? 'var(--md-sys-color-primary)' : 'var(--md-sys-color-on-surface-variant)';
    const bd  = tone==='error' ? 'var(--md-sys-color-error)' : 'var(--md-sys-color-outline-variant)';
    return '<span data-custom="status-indicator" style="display:inline-flex;align-items:center;height:28px;padding:0 10px;box-shadow:inset 0 0 0 1px '+bd+';border-radius:var(--md-sys-shape-corner-small);'+T('label-medium')+'color:'+col+';white-space:nowrap;">'+esc(t)+'</span>';
  }
  // RESIDENCY — the concise violation summary shown in the invoice is derived from
  // the same allowlist string the policy carries, counted against the jurisdictions
  // of the nodes actually serving. The verbose allowlist stays available as the
  // element's title, so no policy detail is lost.
  function residency(nodes,ND,rule){
    const allow=(rule.match(/\b[A-Z]{2}\b/g)||[]);
    const bad=[]; for(const p of nodes){ const j=(ND[p[0]]||{}).juris; if(j&&allow.indexOf(j)<0&&bad.indexOf(j)<0) bad.push(j); }
    let n=0; for(const p of nodes){ const j=(ND[p[0]]||{}).juris; if(j&&allow.indexOf(j)<0) n++; }
    if(!n) return '';
    return n+' of '+nodes.length+' serving nodes outside the allowed regions ('+bad.join(', ')+')';
  }
  function figHTML(l,v,s){
    return '<div style="min-width:0;display:flex;flex-direction:column;gap:4px;">'
      +'<span style="'+T('label-large')+'text-transform:uppercase;color:var(--text-2);">'+l+'</span>'
      +'<span data-fig="'+l+'" style="'+T('headline-medium')+'color:var(--text-1);font-variant-numeric:tabular-nums;">'+v+'</span>'
      +'<span data-figsub="'+l+'" style="'+T('body-medium')+'color:var(--text-2);">'+s+'</span></div>';
  }
  function render(id){
    const w=byId[id]; if(!w) return;
    const DM=window.WORKLOAD_DEMO, ND=window.NODE_DEMO;
    if(!DM||!ND) return;
    const pane=document.querySelector('[data-wl-pane="active"]'); if(!pane) return;
    const INV=DM.invoice;
    const nodes=(w.at||[]).map(function(a){return NODE[a[0]];}).filter(Boolean);
    const thr=REVIEW_FIXTURE.throughput[w.id]||{};
    let tot=0; for(const k in thr) tot+=thr[k];
    // TOTALS ARE DERIVED FROM THE ROWS ON SCREEN. This section exists to reconcile
    // two tallies, so a headline that disagrees with its own rows defeats it. The
    // spec's $0.1434 / $1.71 / 166 fall out of the sum when its six nodes are the
    // row set; they are never pinned over a different one.
    let gw=0, eng=0, reqs=0;
    for(const p of nodes){ const nd=ND[p[0]]||{};
      gw+=parseFloat(nd.amt||0); eng+=parseFloat(nd.eamt||0); reqs+=(nd.reqs||0); }
    const feePct=parseFloat(INV.fee)||50;
    const provider=gw/(1+feePct/100), fee=gw-provider;
    const f4=function(x){return x.toFixed(4);}, f2=function(x){return x.toFixed(2);};
    const wlCol='var(--wl-'+(COLOR[w.id]||'eric')+')';
    const resid=residency(nodes,ND,DM.failedRule);

    // MEASUREMENT — one shared small-multiple for all five metrics. Fixed 0..1
    // visual domain (never auto-scaled per metric), same 40px chart height, same
    // 40-sample window, same type roles. Reading order is label -> value -> avg
    // -> trend, so the figure outranks the chart. The dashed hairline is the mean
    // of the plotted window; semantic error colour appears only where the value
    // is itself an alert state (s.alert).
    const seriesHTML=DM.series.map(function(s){
      const w=120,h=40,n=40; let x=s.seed, raw=[];
      for(let i=0;i<n;i++){ x=(x*1103515245+12345)&0x7fffffff; raw.push((x%1000)/1000); }
      const Y=function(v){return (h-4-v*(h-8)).toFixed(1);};
      const pts=raw.map(function(v,i){return (i/(n-1)*w).toFixed(1)+','+Y(v);}).join(' ');
      let m=0; for(const v of raw) m+=v; const my=Y(m/n);
      const stroke=s.alert?'var(--md-sys-color-error)':wlCol;
      const vcol=s.alert?'var(--md-sys-color-error)':(s.value==='\u2014'?'var(--md-sys-color-on-surface-variant)':'var(--md-sys-color-on-surface)');
      return '<div style="min-width:0;display:flex;flex-direction:column;gap:12px;">'
      +'<div style="display:flex;flex-direction:column;gap:2px;">'
      +lab(s.label)
      +'<span style="'+T('headline-small')+'color:'+vcol+';font-variant-numeric:tabular-nums;">'+esc(s.value)+'</span>'
      +'<span style="'+T('body-small')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+esc(s.avg)+'</span></div>'
      +'<svg viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" style="width:100%;height:'+h+'px;display:block;overflow:visible;">'
      +'<line x1="0" y1="'+my+'" x2="'+w+'" y2="'+my+'" stroke="var(--md-sys-color-outline-variant)" stroke-width="1" stroke-dasharray="2 3" vector-effect="non-scaling-stroke"/>'
      +'<polyline points="'+pts+'" fill="none" stroke="'+stroke+'" stroke-width="1.25" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>'
      +'<circle cx="'+w+'" cy="'+Y(raw[n-1])+'" r="1.75" fill="'+stroke+'"/></svg></div>';}).join('');

    const nodeRows=nodes.map(function(pair){
      const n=pair[0], reg=pair[1], nd=ND[n]||{}, v=thr[n]||0, share=tot?Math.round(v/tot*100):0;
      // per-row evidence keeps only what differs between nodes; the workload-level
      // confidentiality / meter / time marks are stated once above the table
      const ev=[(HW[n]||''), reg+' \u00b7 '+(nd.juris||''), nd.inst+' \u00b7 '+CUR+nd.rate+'/hr'].join('  \u00b7  ');
      return '<div data-nrow><div data-nline>'
        +'<span data-cell="node" style="'+T('body-large')+'color:var(--md-sys-color-on-surface);">'+n+'</span>'
        +'<span data-cell="act" style="display:block;">'+spark(parseInt(nd.gpuS,10)||7,wlCol,56,18)+'</span>'
        +'<span data-cell="gpu" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.gpuS+'</span>'
        +'<span data-cell="tok" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.tok+'</span>'
        +'</div><div data-nev><span style="'+T('body-small')+'color:var(--md-sys-color-on-surface-variant);">'+esc(ev)+'</span></div></div>';}).join('');

    const sotRows=nodes.map(function(pair){
      const n=pair[0], nd=ND[n]||{};
      return '<div data-sotrow>'
        +'<span style="'+T('body-large')+'color:var(--md-sys-color-on-surface);">'+n+'</span>'
        +'<span style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+CUR+nd.amt+'</span>'
        +'<span data-sotcell="prompt" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.prompt+'</span>'
        +'<span data-sotcell="gen" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.gen+'</span>'
        +'<span style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.egpu+'</span>'
        +'<span style="text-align:right;'+T('body-large')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+nd.eamt+'</span>'
        +'<span data-sotcell="link" style="text-align:right;"><a href="#" aria-label="Open engine metrics for '+n+'" style="'+T('label-medium')+'color:var(--md-sys-color-primary);text-decoration:none;white-space:nowrap;">metrics \u2197</a></span>'
        +'</div>';}).join('');

    pane.innerHTML=
      '<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'
      +'<div style="display:flex;flex-direction:row;align-items:baseline;justify-content:space-between;gap:24px;flex-wrap:wrap;">'
      +over('Invoice')+'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);">'+esc(INV.job)+'</span></div>'
      +'<div style="display:flex;flex-direction:row;align-items:baseline;gap:16px;flex-wrap:wrap;">'
      +'<span style="'+T('display-small')+'color:var(--text-1);font-variant-numeric:tabular-nums;">'+CUR+f4(gw)+'</span>'
      +markHTML(INV.state,'accent')+'</div>'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+reqs+' metered requests · provider cost '+CUR+f4(provider)+' + '+feePct+'% platform fee = '+CUR+f4(gw)+'</span>'
      +'<div style="display:flex;flex-direction:row;align-items:center;gap:8px;flex-wrap:wrap;">'
      +markHTML(DM.attestation)+'</div>'
      +'<div style="display:flex;flex-direction:column;align-items:flex-start;gap:4px;">'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-'+(resid?'error':'on-surface-variant')+');">'+(resid?'\u2717 Residency policy violation':'Residency policy not yet applicable')+'</span>'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">'+esc(resid||'No serving nodes to place, so no region can be checked.')+'</span>'
      +'<md-text-button data-policy-toggle aria-expanded="false" aria-controls="wl-policy-detail">Policy detail</md-text-button>'
      +'<span id="wl-policy-detail" data-policy-detail hidden style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">Required: '+esc(DM.failedRule)+'</span></div>'
      +'<div style="display:flex;flex-direction:row;align-items:center;gap:8px;flex-wrap:wrap;padding-top:4px;">'
      +'<md-filled-button>Send test request</md-filled-button><md-outlined-button>Close and sign invoice</md-outlined-button><md-outlined-button>Verify ledger signatures</md-outlined-button></div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Measurement')
      +'<div style="align-self:stretch;display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:clamp(16px,2vw,32px);">'+seriesHTML+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Allocation')
      +'<div data-summary style="align-self:stretch;display:grid;grid-template-columns:repeat(auto-fit,minmax(168px,1fr));align-items:flex-start;gap:clamp(20px,3vw,48px) clamp(24px,3vw,48px);">'
      +figHTML('Allocated capacity', w.slots===0?'None':w.slots+(w.slots===1?' slot':' slots'), w.slots===0?'no capacity allocated':'of 59 across the fabric')
      +figHTML('Share of fabric', w.pct+'%', 'by allocated slots')
      +figHTML('Throughput', tot.toLocaleString('en-US')+' tok/s', 'gateway rate')
      +figHTML('Serving nodes', String(nodes.length), 'of 10 compute nodes')+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Serving nodes')
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);">'+esc([DM.tier,DM.meter,DM.timeAttestation].join('  \u00b7  '))+' \u2014 same for every node in this workload</span>'
      +'<div data-noderows style="align-self:stretch;display:flex;flex-direction:column;"><div data-nhead>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Node</span>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Activity</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">GPU seconds</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Tokens</span>'
      +'</div>'+nodeRows+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Source of truth')
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">Two independent tallies for the same work, node by node: what the gateway metered, and what the node\u2019s own inference engine counted. Bill = compute-seconds × provider on-demand rate + '+DM.platformFeePct+'% platform fee.</span>'
      +'<div data-sotrows style="align-self:stretch;display:flex;flex-direction:column;"><div data-sothead>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Node</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Gateway amount</span>'
      +'<span data-sotcell="prompt" style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Prompt</span>'
      +'<span data-sotcell="gen" style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Generated</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">GPU seconds</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Engine amount</span>'
      +'<span data-sotcell="link"></span></div>'+sotRows+'</div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;align-items:flex-start;gap:8px;padding-top:8px;">'
      +'<span style="display:grid;grid-template-columns:minmax(0,140px) auto;align-items:baseline;gap:16px;">'+lab('Gateway amount \u00b7 metered')+'<span style="text-align:right;'+T('title-medium')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+f4(gw)+'</span></span>'
      +'<span style="display:grid;grid-template-columns:minmax(0,140px) auto;align-items:baseline;gap:16px;">'+lab('Engine amount \u00b7 independent')+'<span style="text-align:right;'+T('title-medium')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+f4(eng)+'</span></span>'
      +'<md-outlined-button style="margin-top:8px;">Bill from engine \u00b7 '+CUR+f2(eng)+'</md-outlined-button></div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:row;align-items:center;gap:8px;">'
      +'<md-outlined-button data-open-log>View request log</md-outlined-button>'
      +'<md-outlined-button data-copy-key data-key="'+esc(DM.apiKey||'')+'" aria-label="Copy API key for this workload">Copy API key</md-outlined-button>'
      +'<span data-key-note aria-live="polite" style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);"></span></div>';
  }
  function detail(id){
    const w=byId[id]; if(!w) return;
    const t=document.querySelector('[data-wl-title]'); if(t) t.textContent=w.name;
    const nodesFor=(w.at||[]).map(function(a){return NODE[a[0]];}).filter(Boolean);
    const regs=[...new Set(nodesFor.map(function(n){return n[1];}))];
    // HEADER — name plus the headline verdict, nothing else. Node count and region
    // are canonical in Allocation and Serving nodes; the API key moved to the
    // invoice line as an operational identifier.
    const DM=window.WORKLOAD_DEMO||{};
    const mt=document.querySelector('[data-wl-meta]');
    if(mt) mt.remove();
    const hm=document.querySelector('[data-wl-headmarks]');
    const bad=/non-?compliant|fail/i.test(DM.verdict||'');
    if(hm) hm.innerHTML=markHTML(DM.verdict,bad?'error':null);
    render(id);
  }
  let rebuilding=false, lastPane=null;
  function paint(){
    const pane=document.querySelector('[data-wl-pane="active"]');
    if(!pane||!window.WORKLOAD_DEMO||rebuilding) return;
    if(pane===lastPane && !pane.querySelector('[data-seed]')) return;
    lastPane=pane; rebuilding=true;
    try{ detail(document.documentElement.dataset.currentWorkload||'eric-1'); }
    finally{ rebuilding=false; }
  }
  const settle=function(){ setTimeout(paint,0); setTimeout(paint,80); setTimeout(paint,300); };
  // observe a stable ancestor: the runtime replaces the pane node itself, and an
  // observer bound to the pane dies with it
  const watch=new MutationObserver(function(){ if(!rebuilding) paint(); });
  const arm=function(){
    const host=document.querySelector('[data-destination="Workloads"]');
    if(!host||!window.WORKLOAD_DEMO){ setTimeout(arm,50); return; }
    watch.observe(host,{childList:true,subtree:true});
    paint(); settle();
  };
  arm();
  window.addEventListener('load',settle);
  function applyFilters(){
    const el=document.querySelector('[data-wl-search]');
    const s=((el&&el.value)||'').trim().toLowerCase();
    const on={}; for(const c of document.querySelectorAll('[data-wlfilter]')) on[c.dataset.wlfilter]=!!c.selected;
    for(const it of document.querySelectorAll('[data-wl]')){
      const w=byId[it.dataset.wl];
      let ok=!s||(w&&((w.name||'').toLowerCase().indexOf(s)>=0||(w.id||'').toLowerCase().indexOf(s)>=0));
      if(ok&&on.cap) ok=it.dataset.cap==='1';
      if(ok&&on.multi) ok=it.dataset.multi==='1';
      it.style.display=ok?'flex':'none';
    }
  }
  document.addEventListener('click',function(ev){
    const t=ev.target;
    if(t.closest&&t.closest('[data-open-log]')){
      document.querySelector('[data-eviscrim]').style.display='block';
      const dr=document.querySelector('[data-evidrawer]'); dr.style.display='flex';
      const c=dr.querySelector('[data-close-log]'); if(c)c.focus(); return;
    }
    if((t.closest&&t.closest('[data-close-log]'))||t.matches('[data-eviscrim]')){
      document.querySelector('[data-eviscrim]').style.display='none';
      document.querySelector('[data-evidrawer]').style.display='none'; return;
    }
    const pt=t.closest&&t.closest('[data-policy-toggle]');
    if(pt){
      const det=document.querySelector('[data-policy-detail]');
      if(det){ const open=det.hasAttribute('hidden'); if(open) det.removeAttribute('hidden'); else det.setAttribute('hidden',''); pt.setAttribute('aria-expanded',String(open)); }
      return;
    }
    const ck=t.closest&&t.closest('[data-copy-key]');
    if(ck){
      const note=document.querySelector('[data-key-note]');
      const done=function(ok){ if(note) note.textContent=ok?'API key copied':'Copy unavailable — key: '+ck.dataset.key; };
      if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(ck.dataset.key).then(function(){done(true);},function(){done(false);});
      else done(false);
      return;
    }
    if(t.closest&&t.closest('[data-wlfilter]')){ setTimeout(applyFilters,0); return; }
    const tab=t.closest&&t.closest('[data-ctab]');
    if(tab){
      const tabs=[...document.querySelectorAll('[data-ctab]')];
      tabs.forEach(function(x){x.setAttribute('aria-selected',String(x===tab)); if('active' in x) x.active=(x===tab);});
      const names=['active','invoices','attestation'], which=names[tabs.indexOf(tab)];
      for(const n of names){ const p=document.querySelector('[data-wl-pane="'+n+'"]'); if(p) p.style.display=n===which?'flex':'none'; }
    }
  },true);
  document.addEventListener('keydown',function(ev){
    if(ev.key==='Escape'){
      const dr=document.querySelector('[data-evidrawer]');
      if(dr&&dr.style.display!=='none'){ document.querySelector('[data-eviscrim]').style.display='none'; dr.style.display='none'; }
    }
  });
  // delegated: the runtime may replace the field node on a template re-render, so
  // the listener lives on the document and matches the hook, not the node
  document.addEventListener('input',function(ev){ if(ev.target&&ev.target.closest&&ev.target.closest('[data-wl-search]')) applyFilters(); },true);
  const armSearch=function(){};
  armSearch();
  // ONE binding site for pointer and keyboard, re-run because the runtime replaces
  // the cards on re-render. Nested controls stay exempt.
  const armCards=function(){
    const cards=document.querySelectorAll('[data-wl]');
    for(const c of cards){
      if(c.dataset.wlArmed) continue;
      c.dataset.wlArmed='1';
      c.tabIndex=0; c.setAttribute('role','option');
      c.addEventListener('click',function(e){
        if(e.target.closest('md-icon-button')||e.target.closest('md-filter-chip')||e.target.closest('button')) return;
        window.activateWorkloadCard(c);
      });
      c.addEventListener('keydown',function(e){
        if(e.key==='Enter'||e.key===' '){ e.preventDefault(); window.activateWorkloadCard(c); }
      });
    }
    setTimeout(armCards,600);
  };
  armCards();
  window.activateWorkloadCard=function(card){
    const id=card&&card.dataset&&card.dataset.wl; if(!id) return;
    for(const s2 of document.querySelectorAll('[data-wl][data-selected]')) if(s2!==card) s2.removeAttribute('data-selected');
    card.setAttribute('data-selected','');
    document.documentElement.dataset.currentWorkload=id;
    lastPane=document.querySelector('[data-wl-pane="active"]');
    rebuilding=true;
    try{ detail(id); } finally{ rebuilding=false; }
  };
})();


// headerHeightToken — the rail's height is bounded by the viewport minus the real
// header; --header-h was never defined, so it silently used a wrong fallback.
(function headerHeightToken(){
  const set=function(){
    const h=document.querySelector('header');
    if(h) document.documentElement.style.setProperty('--header-h', Math.round(h.getBoundingClientRect().height)+'px');
    // the navigator rail is bounded by ITS SCROLL PORT, not by the viewport: the
    // host's content box is what the rail may occupy without the footer clipping it
    const port=document.querySelector('[data-wl-scroll]');
    if(port){
      const cs=getComputedStyle(port);
      const inner=port.clientHeight-parseFloat(cs.paddingTop||0)-parseFloat(cs.paddingBottom||0);
      const sb=Math.max(0, Math.round(port.offsetWidth-port.clientWidth));
      document.documentElement.style.setProperty('--wl-sb', sb+'px');
    }
  };
  set(); window.addEventListener('resize',set); window.addEventListener('load',set);
  setTimeout(set,300); setTimeout(set,1200);
})();


// HEADER GEOMETRY, MEASURED. The New workload overlay hangs off row 1's bottom
// edge and the app ground hangs off the header's, so both offsets are published
// from the RENDERED boxes instead of constants: row 1 wraps at narrow widths, and
// any constant is wrong the moment it does (verifier, 2026-09-11 — a 96px
// constant cut the panel through the middle of a 144px row).
(function headerGeometry(){
  const arm = () => {
    const h = document.querySelector('header');
    const r1 = h && h.children[0];
    if (!r1) { setTimeout(arm, 60); return; }
    const publish = () => {
      const a = Math.round(r1.getBoundingClientRect().height);
      const b = Math.round(h.getBoundingClientRect().height);
      const st = document.documentElement.style;
      if (a) st.setProperty('--header-row1-height', a + 'px');
      if (b) st.setProperty('--header-height', b + 'px');
    };
    publish();
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(publish);
      ro.observe(h); ro.observe(r1);
    }
    window.addEventListener('resize', publish);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(publish).catch(() => {});
  };
  arm();
})();
