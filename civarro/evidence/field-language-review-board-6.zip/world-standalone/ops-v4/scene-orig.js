// QUIET SCENE — planar comb, colony, one red event point, one instrument that
// rides the cursor.
//
// Reading order: the comb plane, the colony inside it, the pinned event, the
// instrument. No frames, no rings around the swarm, no grids, no persistent
// diagnostics. The only chroma is the event point and the thermal arc.

import { project, degC, isolines } from './vendor/swarm-core.js';
import { rgbaT } from './theme.js';

const o4 = new Float32Array(4), o4b = new Float32Array(4);
const FONT = "px 'Share Tech Mono', ui-monospace, monospace";
const TAN_HALF = Math.tan(35.2644 * Math.PI / 180);

const HEAT_ON = 0.2;
// v3: ONE controlled engagement accent instead of the thermal ramp. Engaged
// capacity is coordinated capacity, not a thermal event, so the scale stays in
// a single hue and never reaches amber or red. Red is reserved for failure.
const STOPS = [[0.2, 106, 150, 136], [0.45, 96, 196, 165], [0.68, 84, 219, 179], [0.85, 111, 231, 194], [1, 150, 243, 214]];
export function heatRGB(T) {
  if (!(T >= HEAT_ON)) return null;
  for (let i = 1; i < STOPS.length; i++) {
    const a = STOPS[i - 1], b = STOPS[i];
    if (T <= b[0] || i === STOPS.length - 1) {
      const u = Math.max(0, Math.min(1, (T - a[0]) / (b[0] - a[0])));
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  return null;
}
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const INK = a => rgbaT('ink', a);
const DIM = a => rgbaT('dim', a);
const RED = a => rgbaT('critical', a);
const LIT = a => rgbaT('lit', a);   // white = the measurement event
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// The cursor IS the intruder, so its readout reports the intruder's own
// condition — what the colony is doing to it — not the colony's perception.
// The colony's state stays where it belongs, in the scene label.
export function intruderState(sim, ev) {
  if (ev && ev.dead > 0) return 'COMPLETE';
  if (sim.tempMax > HEAT_ON) return 'ACTIVE';
  if (sim.committed > 8) return 'COORDINATED';
  if (sim.pin) return 'COMMITTED';
  if (sim.perturb > 0.15) return 'REGISTERED';
  return 'SIGNAL';
}

// The arc is a latched phase machine, not a set of instantaneous thresholds:
// each step holds long enough to be read, the sequence only ever advances while
// the intruder lives, and RELEASE stays latched until the field is cold again.
const PHASES = ['DISTRIBUTED', 'SIGNAL', 'COMMIT', 'COORDINATE',
  'ACTIVE', 'PEAK', 'RELEASE'];
export function sceneState(sim, ev) {
  const e = ev || {};
  if (e.phase == null) { e.phase = 0; e.phaseAt = -9; }
  const now = sim.t, held = now - e.phaseAt;
  const go = p => { if (p !== e.phase) { e.phase = p; e.phaseAt = now; } return PHASES[p]; };

  if (e.dead > 0) return go(6);                       // burning out
  if (e.phase === 6) {                                // latched until cold and gone
    if (!sim.pin && sim.tempMax < 0.05) return go(sim.perturb > 0.15 ? 1 : 0);
    return PHASES[6];
  }
  if (sim.pin) {
    let want = 2;
    if (sim.committed > 8) want = 3;
    if (sim.tempMax > HEAT_ON) want = 4;
    if (sim.tempMax > 0.82) want = 5;
    if (want <= e.phase) return PHASES[e.phase];
    // minimum dwell, so convergence is never skipped past on the way to heat
    if (e.phase >= 2 && held < 0.9 && want < 5) return PHASES[e.phase];
    return go(want);
  }
  if (e.phase >= 2 && sim.tempMax > 0.05) return go(6);   // pin lifted while warm
  return go(sim.perturb > 0.15 ? 1 : 0);
}

// ------------------------------------------------------------ planar comb
// The comb is FLAT: a plane facing the viewer, laid out in screen space, so it
// never turns with the camera and never reads as an object in perspective.
// An irregular mass with a ragged edge and a few detached cells.
export function buildLattice(W, H, o = {}) {
  const R = o.r ?? Math.max(44, Math.min(104, 68 * (W / 1240)));
  const dx = R * Math.sqrt(3), dy = R * 1.5;
  const cx = W * 0.5, cy = H * 0.5;
  const cols = Math.ceil(W / dx) + 3, rows = Math.ceil(H / dy) + 3;
  let s = 991137 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const cells = [];
  // Flat: the lattice covers the central zone the colony occupies.
  // Curved: the same lattice is read as a spherical shell seen from inside —
  // arc length maps through sin(), so cells crowd and foreshorten toward the rim
  // and the surface recedes past the frame. It sits BEHIND the colony and stays
  // open toward the viewer: a world that continues, not a container.
  const Rs = Math.max(W, H) * 0.40, lim = o.curve ? 3.4 : 1.04;
  for (let r = -rows * 2; r <= rows * 2; r++) for (let c = -cols * 2; c <= cols * 2; c++) {
    const fx = c * dx + (Math.abs(r) & 1 ? dx * 0.5 : 0), fy = r * dy;
    const rad = Math.hypot(fx / (W * 0.30), fy / (H * 0.42));
    if (rad > lim) continue;
    rnd();
    let x = cx + fx, y = cy + fy, cr = R;
    if (o.curve) {
      const d0 = Math.hypot(fx, fy * 1.14);
      const th = Math.min(1.42, d0 / Rs);
      const k = d0 > 0.001 ? (Rs * Math.sin(th)) / d0 : 1;
      x = cx + fx * k; y = cy + fy * k * 0.92;
      cr = R * Math.max(0.30, Math.cos(th));
      if (th > 1.40) continue;
    }
    cells.push({ x, y, r: cr, amp: 0, chg: 0, rate: 0.6 + rnd() * 1.5, occ: 0, fore: o.curve ? Math.cos(Math.min(1.42, Math.hypot(fx, fy * 1.14) / Rs)) : 1 });
  }
  return { R, W, H, cells, active: 0, curve: !!o.curve };
}

export function updateLattice(lat, sim, dt, allow, cam, W, H, cur) {
  const R2 = lat.R * lat.R, thr = Math.max(0.34, (sim.phiG || 0.4) + 0.1);
  for (const c of lat.cells) c.occ = 0;
  // The cursor reveals the comb as it passes: proximity charges a cell, and the
  // charge decays behind it at each cell's own rate, so the trace is a fading
  // wake rather than a highlight.
  if (cur) {
    const rr = lat.R * 2.3, rr2 = rr * rr;
    for (const c of lat.cells) {
      const dx = c.x - cur[0], dy = c.y - cur[1], d2 = dx * dx + dy * dy;
      if (d2 < rr2) c.rev = Math.min(1.7, (c.rev || 0) + dt * 2.3 * (1 - Math.sqrt(d2) / rr));
    }
  }
  // long, uneven fade: the wake stays on screen for seconds and thins out
  for (const c of lat.cells) c.rev = Math.max(0, (c.rev || 0) - dt / (7.5 * c.rate));
  if (cam) {
    for (let i = 0; i < sim.N; i++) {
      const coh = sim.phi[i] - thr;
      project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
      for (const c of lat.cells) {
        const ddx = o4[0] - c.x, ddy = o4[1] - c.y;
        if (ddx * ddx + ddy * ddy < R2) {
          // any agent crossing a cell wakes it, well below the cursor; a
          // coordinated one also charges it toward crystallisation
          c.pas = Math.min(0.9, (c.pas || 0) + dt * 2.2);
          if (coh > 0) c.occ += coh * 2.4;
          break;
        }
      }
    }
  }
  for (const c of lat.cells) c.pas = Math.max(0, (c.pas || 0) - dt / 2.0);
  let live = 0;
  for (const c of lat.cells) {
    const on = allow && c.occ > 1.2;
    c.chg += on ? dt / 1.3 : -dt / (0.9 * c.rate);
    if (c.chg > 1.25) c.chg = 1.25; else if (c.chg < 0) c.chg = 0;
    c.amp = smooth(0.05, 0.95, Math.max(c.chg, c.rev || 0, (c.pas || 0) * 0.62));
    if (c.amp > 0.02) live++;
  }
  lat.active = live;
}

function comb(ctx, lat, k) {
  if (lat.sphere) return combSphere(ctx, lat, k);
  // The cell is a plane, not an outline: a very faint fill, no stroke, so the
  // comb registers as area the colony has claimed rather than as drawn geometry.
  for (const c of lat.cells) {
    if (c.amp <= 0.02) continue;                 // invisible until revealed
    ctx.fillStyle = INK(c.amp * 0.05 * k);
    ctx.beginPath();
    for (let s = 0; s < 6; s++) {
      const a = Math.PI / 6 + s * Math.PI / 3;
      const X = c.x + Math.cos(a) * c.r * 0.965, Y = c.y + Math.sin(a) * c.r * 0.965;
      s ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
    ctx.fill();
    if (c.amp > 0.42) {
      ctx.strokeStyle = INK((c.amp - 0.42) * 0.34 * c.vis * k);
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }
}

// ------------------------------------------------------------------- behaviour
// Pathlines exactly as treatment I draws them in v1: every fourth agent, the
// whole history shortened to its recent third and softened: history should
// register as recent movement, not as a web of long strokes.
function histories(ctx, cam, sim, W, H, cfg) {
  const c = cfg || {};
  const TL = sim.TL, head = sim.head;
  const n = Math.max(3, Math.min(TL, Math.round(c.n ?? 15)));
  const stride = Math.max(1, Math.round(c.stride ?? 4));
  const w = c.w ?? 0.55, alpha = c.alpha ?? 0.2;
  const ticks = c.ticks !== false, tick = 7, tickA = alpha;
  const depth = c.depth !== false;
  for (let i = 0; i < sim.N; i += stride) {
    const hc = hcOf(sim, i);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - o4[2]) / (sim.R * 1.8)));
    if (dl < 0.04) continue;
    const av = depth ? alpha * (0.3 + dl * 0.7) : alpha;
    if (c.taper) {
      const sw = c.speedK ? Math.max(0.12, Math.min(1, sim.spd[i] / (sim.SPD * 2.4))) : 1;
      let hx = 0, hy = 0;
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        if (a < n - 1) {
          const u = 1 - a / n;                       // 0 at the tail, 1 at the head
          const t2 = u * u;
          ctx.lineWidth = w * (0.35 + 1.05 * t2) * (depth ? 0.55 + dl * 0.85 : 1);
          const aa = Math.min(1, av * 2.6 * t2 * sw);
          ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.5)) : INK(aa);
          ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
        }
        hx = o4[0]; hy = o4[1];
      }
    } else {
      ctx.beginPath();
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        a === n - 1 ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
      }
      ctx.lineWidth = depth ? w * (0.55 + dl * 0.85) : w;
      ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 1.6)) : INK(av);
      ctx.stroke();
    }
    if (!ticks) continue;
    ctx.lineWidth = 0.6;
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 2.2)) : INK(tickA * (depth ? 0.3 + dl * 0.7 : 1));
    for (let a = n - 2; a >= 1; a -= tick) {
      const oA = (i * TL + ((head - a - 1 + TL * 2) % TL)) * 3;
      const oB = (i * TL + ((head - a + 1 + TL * 2) % TL)) * 3;
      project(cam, sim.trail[oA], sim.trail[oA + 1], sim.trail[oA + 2], W, H, o4);
      project(cam, sim.trail[oB], sim.trail[oB + 1], sim.trail[oB + 2], W, H, o4b);
      const mx = (o4[0] + o4b[0]) / 2, my = (o4[1] + o4b[1]) / 2;
      const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
      const tk = 1.9 * (1 - a / n * 0.55);
      ctx.beginPath();
      ctx.moveTo(mx + dy / L * tk, my - dx / L * tk);
      ctx.lineTo(mx - dy / L * tk, my + dx / L * tk);
      ctx.stroke();
    }
  }
}

// Glyphs exactly as treatment I draws them in v1: an open 70.529-degree
// triangle built in screen space from the projected heading, drawn back to
// front, size 3.1 px scaled by depth.
let SX, SY, SD, SHX, SHY, ORD;
// Primitive set, as in v1: the shape is a control, the semantics are not.
function prim(ctx, kind, x, y, hx, hy, sz, fill) {
  const px_ = -hy, py_ = hx;
  if (kind === 'dash') {
    const L = sz * 1.35;
    ctx.beginPath();
    ctx.moveTo(x - hx * L, y - hy * L); ctx.lineTo(x + hx * L, y + hy * L);
    ctx.stroke(); return;
  }
  ctx.beginPath();
  if (kind === 'dot') {
    ctx.arc(x, y, sz * 0.5, 0, 6.2832);
  } else if (kind === 'dia') {
    const a = sz * 1.15, b = a / Math.SQRT2;
    ctx.moveTo(x + hx * a, y + hy * a);
    ctx.lineTo(x + px_ * b, y + py_ * b);
    ctx.lineTo(x - hx * a, y - hy * a);
    ctx.lineTo(x - px_ * b, y - py_ * b);
    ctx.closePath();
  } else if (kind === 'hex') {
    const r = sz * 0.82, a0 = Math.atan2(hy, hx);
    for (let k = 0; k < 6; k++) {
      const a = a0 + k * Math.PI / 3;
      const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
      k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
  } else {                                   // 'tri' — apex 70.529 degrees
    const Hh = sz * 1.25, b = TAN_HALF * Hh;
    ctx.moveTo(x + hx * Hh * 0.66, y + hy * Hh * 0.66);
    ctx.lineTo(x - hx * Hh * 0.34 + px_ * b, y - hy * Hh * 0.34 + py_ * b);
    ctx.lineTo(x - hx * Hh * 0.34 - px_ * b, y - hy * Hh * 0.34 - py_ * b);
    ctx.closePath();
  }
  if (fill) ctx.fill(); else ctx.stroke();
}

function agents(ctx, cam, sim, W, H, gl, gk = 1) {
  const N = sim.N;
  if (!SX || SX.length !== N) {
    SX = new Float32Array(N); SY = new Float32Array(N); SD = new Float32Array(N);
    SHX = new Float32Array(N); SHY = new Float32Array(N);
    ORD = Array.from({ length: N }, (_, i) => i);
  }
  for (let i = 0; i < N; i++) {
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    project(cam, sim.px[i] + sim.vx[i] * 0.3, sim.py[i] + sim.vy[i] * 0.3, sim.pz[i] + sim.vz[i] * 0.3, W, H, o4b);
    SX[i] = o4[0]; SY[i] = o4[1]; SD[i] = o4[2];
    const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
    SHX[i] = dx / L; SHY[i] = dy / L;
  }
  ORD.sort((a, b) => SD[b] - SD[a]);
  // FAR SIDE. The globe is not opaque, so without this every particle behind it
  // read as if it were in front. A particle's own surface normal against the
  // camera direction says which hemisphere it is on: the near side draws at full
  // strength, the limb crosses over smoothly, the far side stays faint enough to
  // read as "behind".
  const _cy = Math.cos(cam.yaw), _sy = Math.sin(cam.yaw);
  const _cp = Math.cos(cam.pitch), _sp = Math.sin(cam.pitch);
  const ffx = _sy * _cp, ffy = _sp, ffz = _cy * _cp;
  for (let k = 0; k < N; k++) {
    const i = ORD[k];
    const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
    const facing = -((sim.px[i] / pl) * ffx + (sim.py[i] / pl) * ffy + (sim.pz[i] / pl) * ffz);
    // the rim of the visible hemisphere used to fall to 16% and the free capacity
    // there read as dust; the floor is lifted so quiet still means legible
    const side = 0.44 + 0.56 * Math.max(0, Math.min(1, (facing + 0.06) / 0.22));
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - SD[i]) / (sim.R * 1.8)));
    if (dl <= 0.01) continue;
    // no depth cueing: every agent reads at one size and one opacity
    const al = sim.meas[i];                     // alerted by the intruder
    const s = (3.2 + (al > 0.08 ? 0.9 : 0)) * gk;
    const a = (0.78 + (al > 0.08 ? Math.min(0.22, al * 0.9) : 0)) * side;
    const hc = hcOf(sim, i);
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, a * 1.55)) : INK(a);
    ctx.lineWidth = al > 0.08 ? 1.05 : 0.9;
    if (hc) ctx.fillStyle = rgba(hc, Math.min(1, a * 1.35)); else ctx.fillStyle = INK(a * 0.9);
    // an ENGAGED mark is FILLED in the warm accent (and a touch larger): the
    // cohort reads instantly, while free capacity keeps the quiet outline
    prim(ctx, (gl && gl.kind) || 'tri', SX[i], SY[i], SHX[i], SHY[i], s * ((gl && gl.scale) || 1) * (hc ? 1.12 : 1), !!(gl && gl.fill) || !!hc);
  }
}

// ------------------------------------------------------ event point + instrument
// A filament burning out: a surge, a few hard irregular flickers with real dark
// gaps between them, then a dim ember that fades. Keyframed, so it is the same
// death every time and never reads as a smooth pulse.
const BURNOUT = [
  [0.00, 1.75], [0.05, 0.04], [0.09, 1.35], [0.15, 0.06],
  [0.24, 1.05], [0.28, 0.03], [0.50, 0.80], [0.54, 0.02],
  [0.86, 0.50], [0.89, 0.02], [1.10, 0.26], [1.16, 0.02],
  [1.34, 0.14], [1.44, 0.02], [1.60, 0.00]
];
function burnout(t) {
  for (let i = BURNOUT.length - 1; i >= 0; i--) if (t >= BURNOUT[i][0]) {
    const v = BURNOUT[i][1];
    // the ember steps decay inside their own segment; the flashes stay hard
    const nx = BURNOUT[i + 1];
    if (v < 0.3 && nx) return v * (1 - (t - BURNOUT[i][0]) / (nx[0] - BURNOUT[i][0]) * 0.8);
    return v;
  }
  return 0;
}

function eventPoint(ctx, cam, sim, W, H, ev) {
  const a = ev.on;
  if (a < 0.02) return null;
  // ALWAYS the pin. The probe is not a position of record: swarm-core can
  // re-arm its own moving stimulus, and drawing that made the dead intruder walk.
  const C = sim.pin || ev.lastC;
  if (!C) return null;
  ev.lastC = C.slice ? C.slice() : C;
  project(cam, C[0], C[1], C[2], W, H, o4);
  const px = o4[0], py = o4[1];
  let k = 1;
  if (ev.dead > 0) k = burnout(ev.deadT);
  if (k < 0.02) {
    // spent: the filament is out, and what is left is the carcass — a hollow
    // grey point with an outline. It does not vanish with the light.
    if (ev.dead <= 0) return [px, py];
    ctx.fillStyle = INK(0.12 * a);
    ctx.beginPath(); ctx.arc(px, py, 3.1, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = INK(0.5 * a); ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.arc(px, py, 3.1, 0, 6.2832); ctx.stroke();
    ctx.strokeStyle = INK(0.22 * a);
    ctx.beginPath(); ctx.arc(px, py, 5.4, 0, 6.2832); ctx.stroke();
    return [px, py];
  }
  const flare = Math.max(0, k - 1);                        // over-bright surge
  ctx.fillStyle = RED(Math.min(1, 0.9 * a * k));
  ctx.beginPath(); ctx.arc(px, py, 3.1 + flare * 2.6, 0, 6.2832); ctx.fill();
  ctx.strokeStyle = RED(Math.min(1, 0.5 * a * k)); ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.arc(px, py, 5.4 + flare * 4.2, 0, 6.2832); ctx.stroke();
  return [px, py];
}

// The instrument rides the cursor. At rest it is present but says nothing:
// a ring, a quiet disc, and the invitation. It only carries a reading once an
// event exists, and then a leader ties it back to the pinned point.
function instrument(ctx, sim, W, H, ev, cur, anchor, view_ = {}) {
  // Before the pointer has ever moved there is no cursor: park the resting
  // instrument in clear space on the right shoulder rather than at the centre
  // of the format, where it would sit on the densest part of the colony.
  let gx = cur ? cur[0] : W * 0.80, gy = cur ? cur[1] : H * 0.30;
  const on = ev.on, base = 1;
  const gr = 15 * (view_.cursorK ?? 1);
  const kk = view_.cursorK ?? 1;

  // The instrument never sits on the event: it would cover the ball it reports.
  // When the cursor is on the pinned point, the ring moves out to a shoulder
  // and the leader carries the connection.
  if (anchor) {
    const dx0 = gx - anchor[0], dy0 = gy - anchor[1], L0 = Math.hypot(dx0, dy0), MIN = 112;
    if (L0 < MIN) {
      const ux = L0 > 1 ? dx0 / L0 : 0.94, uy = L0 > 1 ? dy0 / L0 : -0.34;
      gx = Math.max(gr + 10, Math.min(W - gr - 10, anchor[0] + ux * MIN));
      gy = Math.max(gr + 10, Math.min(H - gr - 10, anchor[1] + uy * MIN));
    }
  }

  if (anchor) {                              // the leader, drawn behind the ring
    ctx.strokeStyle = INK(0.28 * on); ctx.lineWidth = 0.6;
    const dx = anchor[0] - gx, dy = anchor[1] - gy, L = Math.hypot(dx, dy) || 1;
    if (L > gr + 14) {
      ctx.beginPath();
      ctx.moveTo(gx + dx / L * (gr + 5), gy + dy / L * (gr + 5));
      ctx.lineTo(anchor[0] - dx / L * 7, anchor[1] - dy / L * 7);
      ctx.stroke();
    }
  }

  // Detected: while the colony has registered the prowling cursor but no
  // intrusion is pinned, the instrument pulses — a halo leaving the ring.
  const det = (!sim.pin && ev.dead <= 0) ? Math.max(0, Math.min(1, (sim.perturb || 0) * 1.6)) : 0;
  if (det > 0.04) {
    const ph = (sim.t * 1.15) % 1;
    ctx.strokeStyle = LIT(0.62 * det * (1 - ph)); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(gx, gy, gr + 2 + ph * 15, 0, 6.2832); ctx.stroke();
  }
  // detection takes the brightest step the palette has: white is the
  // measurement event, so the instrument goes white the moment it is registered
  ctx.strokeStyle = det > 0.04 ? LIT((0.55 + det * 0.45) * base) : DIM(0.6 * base);
  ctx.lineWidth = det > 0.04 ? 1.1 : 0.7;
  ctx.beginPath(); ctx.arc(gx, gy, gr, 0, 6.2832); ctx.stroke();

  const T = sim.tempMax, heat = on > 0.05 ? heatRGB(T) : null;
  if (heat) {
    ctx.strokeStyle = rgba(heat, 0.95 * on); ctx.lineWidth = 1.7;
    const frac = Math.max(0, Math.min(1, (T - HEAT_ON) / (1 - HEAT_ON)));
    ctx.beginPath(); ctx.arc(gx, gy, gr, -Math.PI / 2, -Math.PI / 2 + frac * 6.2832); ctx.stroke();
  }

  const agit = Math.max(0, Math.min(1, sim.agit || 0)) * on;
  ctx.fillStyle = det > 0.04 ? LIT(0.42 + det * 0.4) : INK(0.34 + agit * 0.4);
  const rr = 5.6 + agit * 2.8 * (0.6 + 0.4 * Math.abs(Math.sin(sim.t * 8.6)));
  ctx.beginPath(); ctx.arc(gx, gy, rr, 0, 6.2832); ctx.fill();

  const left = gx > W - 260;
  const tx = left ? gx - gr - 12 : gx + gr + 12;
  ctx.textAlign = left ? 'right' : 'left';
  ctx.font = (10.5 * kk) + FONT;
  const st = intruderState(sim, ev);
  if (on < 0.05) {
    // the label reports the intruder's condition at every stage
    ctx.fillStyle = det > 0.04 ? LIT(0.95) : DIM(st === 'SIGNAL' ? 0.6 : 0.95);
    ctx.fillText(st, tx, gy + 1);
  } else {
    ctx.fillStyle = DIM(1 * on);
    ctx.fillText(st, tx, gy - 8);
    ctx.font = (12 * kk) + FONT;
    ctx.fillStyle = INK(0.92 * on);
    ctx.fillText('C\u2090 ' + Math.max(0, Math.min(1, T / 1.15)).toFixed(2) + '   AT WORKLOAD', tx, gy + 5);
    ctx.font = (10 * kk) + FONT;
    ctx.fillStyle = DIM(0.85 * on);
    ctx.fillText('N\u2090 ' + sim.committed + '   \u03a6 ' + (sim.phiG || 0).toFixed(2)
      + '   RESPONSE ' + Math.round(Math.max(0, Math.min(1, sim.dose || 0)) * 100) + '%', tx, gy + 19);
  }
  ctx.textAlign = 'left';
}

// Isotherms exactly as treatment I draws them in v1: five continuous levels
// scaled to the current maximum, hairline, and the critical one doubled with a
// dashed companion. Temperature is sampled with max, never a sum.
let TB, TGW, TGH;
const SEGS = [];
function isotherms(ctx, cam, sim, W, H) {
  if (sim.tempMax < 0.06) return;
  const cell = 7;
  const gw = Math.max(8, Math.round(W / cell)), gh = Math.max(6, Math.round(H / cell));
  if (TGW !== gw || TGH !== gh) { TGW = gw; TGH = gh; TB = new Float32Array(gw * gh); }
  TB.fill(0);
  for (let i = 0; i < sim.N; i++) {
    if (sim.temp[i] < 0.02) continue;
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const x0 = Math.round(o4[0] / W * gw), y0 = Math.round(o4[1] / H * gh);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = x0 + dx, y = y0 + dy;
      if (x < 0 || y < 0 || x >= gw || y >= gh) continue;
      const v = sim.temp[i] * Math.exp(-(dx * dx + dy * dy) / 1.5);
      if (v > TB[y * gw + x]) TB[y * gw + x] = v;
    }
  }
  const kx = W / gw, ky = H / gh, n = 5;
  const stroke = () => {
    ctx.beginPath();
    for (let s = 0; s < SEGS.length; s += 2) {
      ctx.moveTo(SEGS[s][0] * kx, SEGS[s][1] * ky);
      ctx.lineTo(SEGS[s + 1][0] * kx, SEGS[s + 1][1] * ky);
    }
    ctx.stroke();
  };
  for (let l = 0; l < n; l++) {
    const lv = HEAT_ON + (sim.tempMax - HEAT_ON) * ((l + 0.6) / n);
    if (lv <= HEAT_ON) continue;
    const c = heatRGB(lv); if (!c) continue;
    isolines(TB, gw, gh, lv, SEGS);
    if (!SEGS.length) continue;
    const crit = lv > 0.82;
    ctx.strokeStyle = rgba(c, crit ? 0.95 : 0.5 + (l / n) * 0.32);
    ctx.lineWidth = crit ? 1.1 : 0.55;
    stroke();
    if (crit) {
      ctx.setLineDash([2, 3]); ctx.lineWidth = 0.5;
      stroke();
      ctx.setLineDash([]);
    }
  }
}

function scaleBar(ctx, W, H) {
  const L = Math.min(240, W * 0.16), x = W / 2 - L / 2, y = H - Math.max(70, Math.min(124, H * 0.2));
  ctx.strokeStyle = DIM(0.5); ctx.lineWidth = 0.7;
  ctx.beginPath();
  ctx.moveTo(x, y); ctx.lineTo(x + L, y);
  for (let i = 0; i <= 4; i++) {
    const tx = x + L * i / 4;
    ctx.moveTo(tx, y); ctx.lineTo(tx, y - (i % 2 ? 3.5 : 6));
  }
  ctx.stroke();
}

// Each phase carries its own animated signature, so the step is legible from
// the drawing alone. All hairline grey except the critical band, which is the
// one place chroma is allowed.
function phaseCues(ctx, cam, sim, W, H, ev, cursor) {
  if (!ev) return;
  const ph = ev.phase || 0, held = sim.t - (ev.phaseAt ?? 0);
  let px = 0, py = 0, sc = 1;
  if (sim.pin) {
    project(cam, sim.pin[0], sim.pin[1], sim.pin[2], W, H, o4);
    px = o4[0]; py = o4[1]; sc = cam.fov / o4[2];
  }
  const shell = Math.max(8, sim.shellR) * sc;

  // 1 · DETECTED — alarm spreading outward from the prowling intruder
  if (ph === 1 && cursor) {
    for (let q = 0; q < 2; q++) {
      const u = ((sim.t / 1.6) + q * 0.5) % 1;
      ctx.strokeStyle = INK(0.26 * (1 - u) * (1 - u));
      ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.arc(cursor[0], cursor[1], 16 + u * 150, 0, 6.2832); ctx.stroke();
    }
  }
  // 2 · LOCKED — one dashed ring snapping inward onto the point
  if (ph === 2 && sim.pin) {
    const u = Math.min(1, held / 0.6);
    ctx.strokeStyle = INK(0.44 * (1 - u * 0.55)); ctx.lineWidth = 0.8;
    ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.arc(px, py, 156 - 126 * u * u, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]);
    if (u > 0.75) {
      ctx.strokeStyle = INK(0.5 * (u - 0.75) / 0.25);
      for (let q = 0; q < 4; q++) {
        const a = q * Math.PI / 2;
        ctx.beginPath();
        ctx.moveTo(px + Math.cos(a) * 15, py + Math.sin(a) * 15);
        ctx.lineTo(px + Math.cos(a) * 22, py + Math.sin(a) * 22);
        ctx.stroke();
      }
    }
  }
  // 3 · CONVERGENCE — approach vectors on the agents still flying in
  if (ph === 3 && sim.pin) {
    ctx.lineWidth = 0.6;
    for (let i = 0; i < sim.N; i++) {
      if (sim.def[i] < 0.3) continue;
      project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4b);
      const dx = px - o4b[0], dy = py - o4b[1], L = Math.hypot(dx, dy) || 1;
      if (L < shell * 1.3) continue;                 // arrived: no vector
      const u = Math.min(1, (L - shell) / 130);
      const len = Math.min(17, L * 0.24);
      ctx.strokeStyle = INK(0.36 * u);
      ctx.beginPath();
      ctx.moveTo(o4b[0], o4b[1]);
      ctx.lineTo(o4b[0] + dx / L * len, o4b[1] + dy / L * len);
      ctx.stroke();
    }
  }
  // 5 · CRITICAL BAND — the lethal threshold breathes, dashed, in motion
  if (ph === 5 && sim.pin) {
    const b = 0.5 + 0.5 * Math.sin(sim.t * 4.4);
    ctx.strokeStyle = RED(0.26 + 0.3 * b); ctx.lineWidth = 0.9;
    ctx.setLineDash([2.5, 3.5]); ctx.lineDashOffset = -sim.t * 16;
    ctx.beginPath(); ctx.arc(px, py, shell * 1.55, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]); ctx.lineDashOffset = 0;
  }
  // 6 · RELEASE — one ring expanding away from the spent event
  if (ph === 6 && ev.lastC) {
    const u = held / 1.8;
    if (u < 1) {
      ctx.strokeStyle = INK(0.3 * (1 - u)); ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.arc(ev.lastC[0], ev.lastC[1], 12 + u * 180, 0, 6.2832); ctx.stroke();
    }
  }
}

// PER-PARTICLE COLOUR — workload identity first, generic engaged accent second.
// sim.wlc is an Int16Array of rgb triples (-1 = no workload assignment), written
// by the driver from the fixture's own workload table. When a particle carries a
// workload it takes that workload's exact colour — the same one the Active
// Workloads legend and the Map traffic print — so several cohorts read as
// several workloads instead of one undifferentiated engaged state.
function hcOf(sim, i) {
  const c = sim.wlc;
  if (c) {
    const o = i * 3;
    if (c[o] >= 0 && sim.temp[i] > 0.01) return [c[o], c[o + 1], c[o + 2]];
  }
  return heatRGB(sim.temp[i]);
}

export function drawScene(ctx, W, H, sim, view, lat, hive, ev) {
  const cam = view.cam;
  if (!view.keepCanvas) ctx.clearRect(0, 0, W, H);
  const k = view.combK ?? view.hiveK ?? 1;
  if (lat && k > 0) comb(ctx, lat, k);
  phaseCues(ctx, cam, sim, W, H, ev, view.cursor);
  // the intruder is drawn UNDER the colony, so the defensive ball covers it
  const anchor = eventPoint(ctx, cam, sim, W, H, ev);
  if (view.trails !== false) histories(ctx, cam, sim, W, H, view.trailCfg);
  if (view.isotherms !== false) isotherms(ctx, cam, sim, W, H);   // v3: off in Operations
  agents(ctx, cam, sim, W, H, view.glyph, view.glyphK ?? 1);
  if (!view.hideInstrument) instrument(ctx, sim, W, H, ev, view.cursor, anchor, view);
}


// ---------------------------------------------------------------- THE WORLD
// The hive is a world: comb cells tile the surface of a sphere the colony lives
// on. Cells are only revealed by proximity, exactly as on the flat lattice, and
// the whole surface turns with the camera because every cell is a world point.
export const WORLD_R = 58;

export function buildSphereLattice(o = {}) {
  const n = o.n ?? 150, R = o.R ?? WORLD_R;
  const rc = R * Math.sqrt(Math.PI / n) * 1.06;    // cell radius that tiles the sphere
  const cells = [];
  let s = 991137 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const GOLD = 2.399963229728653;
  for (let k = 0; k < n; k++) {
    const z = 1 - 2 * (k + 0.5) / n, r = Math.sqrt(Math.max(0, 1 - z * z)), a = GOLD * k;
    const u = [r * Math.cos(a), z, r * Math.sin(a)];
    // a tangent basis, so the hexagon lies flat on the surface
    let tx = -u[2], ty = 0, tz = u[0];
    let tl = Math.hypot(tx, ty, tz);
    if (tl < 1e-4) { tx = 1; ty = 0; tz = 0; tl = 1; }
    tx /= tl; ty /= tl; tz /= tl;
    const bx = u[1] * tz - u[2] * ty, by = u[2] * tx - u[0] * tz, bz = u[0] * ty - u[1] * tx;
    cells.push({
      u, t: [tx, ty, tz], b: [bx, by, bz], rc,
      x: u[0] * R, y: u[1] * R, z: u[2] * R,
      amp: 0, chg: 0, rev: 0, rate: 0.6 + rnd() * 1.5, occ: 0,
      sx: 0, sy: 0, ss: 1, vis: 0
    });
  }
  // direction lookup: nearest cell per (azimuth, elevation) bucket, so an agent
  // finds its cell in constant time instead of scanning the whole surface
  const LA = 64, LE = 32, lut = new Int16Array(LA * LE);
  for (let ia = 0; ia < LA; ia++) for (let ie = 0; ie < LE; ie++) {
    const az = (ia + 0.5) / LA * Math.PI * 2, el = Math.acos(1 - 2 * (ie + 0.5) / LE);
    const dx = Math.sin(el) * Math.cos(az), dy = Math.cos(el), dz = Math.sin(el) * Math.sin(az);
    let bi = 0, bd = -2;
    for (let k = 0; k < cells.length; k++) {
      const u = cells[k].u, d = u[0] * dx + u[1] * dy + u[2] * dz;
      if (d > bd) { bd = d; bi = k; }
    }
    lut[ia * LE + ie] = bi;
  }
  return { sphere: true, R, rc, cells, active: 0, lut, LA, LE };
}

const _o = new Float32Array(4);
export function updateSphereLattice(lat, sim, dt, allow, cam, W, H, cur, project) {
  const thr = Math.max(0.34, (sim.phiG || 0.4) + 0.1);
  lat.prj = (x, y, z, o) => project(cam, x, y, z, W, H, o);
  // camera forward, to cull the far side of the world
  const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  const fx = sy * cp, fy = sp, fz = cy * cp;
  for (const c of lat.cells) {
    c.occ = 0;
    const facing = -(c.u[0] * fx + c.u[1] * fy + c.u[2] * fz);
    c.vis = facing > 0.06 ? Math.min(1, (facing - 0.06) / 0.28) : 0;
    if (!c.vis) { c.rev = Math.max(0, c.rev - dt / (1.9 * c.rate)); c.amp = 0; continue; }
    const gw = lat.grow ?? 1;
    project(cam, c.x * gw, c.y * gw, c.z * gw, W, H, _o);
    c.sx = _o[0]; c.sy = _o[1]; c.ss = _o[3];
  }
  // the cursor reveals the surface it passes over
  if (cur) {
    for (const c of lat.cells) {
      if (!c.vis) continue;
      const rr = c.rc * c.ss * 1.9, d = Math.hypot(c.sx - cur[0], c.sy - cur[1]);
      if (d < rr) c.rev = Math.min(1.7, c.rev + dt * 2.6 * (1 - d / rr));
    }
  }
  // and so does traffic: agents crossing a cell wake it a third as strongly
  for (let i = 0; i < sim.N; i++) {
    const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
    const L = Math.hypot(x, y, z) || 1;
    const el = Math.acos(Math.max(-1, Math.min(1, y / L)));
    let az = Math.atan2(z / L, x / L); if (az < 0) az += Math.PI * 2;
    const ia = Math.min(lat.LA - 1, (az / (Math.PI * 2) * lat.LA) | 0);
    const ie = Math.min(lat.LE - 1, ((1 - Math.cos(el)) / 2 * lat.LE) | 0);
    const c = lat.cells[lat.lut[ia * lat.LE + ie]];
    if (!c.vis) continue;
    c.occ += 1; c.rev = Math.min(0.50, c.rev + dt * 0.85);
  }
  let live = 0;
  for (const c of lat.cells) {
    if (!c.vis) continue;
    c.rev = Math.max(0, c.rev - dt / (2.2 * c.rate));
    const on = allow && c.occ > 2 && (sim.phiG || 0) > thr;
    c.chg += on ? dt / 1.3 : -dt / (0.9 * c.rate);
    if (c.chg > 1.25) c.chg = 1.25; else if (c.chg < 0) c.chg = 0;
    const v = Math.max(c.chg, c.rev);
    c.amp = v <= 0.20 ? 0 : Math.min(1, (v - 0.20) / 0.62);
    if (c.amp > 0.02) live++;
  }
  lat.active = live;
}

function combSphere(ctx, lat, k) {
  for (const c of lat.cells) {
    if (c.amp <= 0.02 || !c.vis) continue;
    ctx.fillStyle = INK(c.amp * 0.15 * c.vis * k);
    // the hexagon is built in the cell's own tangent plane and projected, so it
    // foreshortens toward the limb like a face on a globe
    const gw = lat.grow ?? 1;
    const r = c.rc * 0.94 * gw, u = c.u, t = c.t, b = c.b, R = lat.R * gw;
    ctx.beginPath();
    for (let s = 0; s < 6; s++) {
      const a = Math.PI / 6 + s * Math.PI / 3;
      const ct = Math.cos(a) * r, cb = Math.sin(a) * r;
      const X = u[0] * R + t[0] * ct + b[0] * cb;
      const Y = u[1] * R + t[1] * ct + b[1] * cb;
      const Z = u[2] * R + t[2] * ct + b[2] * cb;
      lat.prj(X, Y, Z, _o);
      s ? ctx.lineTo(_o[0], _o[1]) : ctx.moveTo(_o[0], _o[1]);
    }
    ctx.closePath();
    ctx.fill();
    if (c.amp > 0.42) {
      ctx.strokeStyle = INK((c.amp - 0.42) * 0.34 * c.vis * k);
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }
}
