// CAPACITY FIELD — the Swarm view's adapter over the untouched engine.
//
// WHAT CHANGED IN v2, AND WHY
//
// v1 expressed regional demand by letting the engine COMMIT agents to a
// probe: the engine's commitment machinery pulls committed agents onto slot
// vectors around one anchor. Reshaping those slots spread the mass out, but
// the underlying force was still "collect capacity at a place", so higher
// demand always tended toward a denser, brighter patch — the orange blob.
//
// v2 removes that force entirely. The engine runs permanently in its RESTING
// regime (probe 0, shell 0, engage 0, compress 0, thermal 0), so there is no
// attractor anywhere in the system and commitment never fires. Nothing can
// clump, structurally.
//
// Engagement is instead a BEHAVIOURAL treatment applied to velocities after
// the engine has stepped:
//
//   1. SHARED FLOW TENDENCY — engaged capacity near a region blends its
//      heading toward a common tangential circulation of that region, so many
//      independent wanderers become one legible sweep. Position is never a
//      target; capacity coordinates while continuing to travel.
//   2. REDUCED WANDER — the engine's OU angular noise is low-passed in
//      proportion to engagement, so engaged paths straighten and trails align.
//   3. MOTION SYNCHRONISATION — engaged capacity in a region shares one slow
//      speed phase, so the region breathes together.
//   4. CHROMA — a capped secondary cue only. Colour never carries the reading
//      on its own, and it never saturates.
//
// Regions hold PERSISTENT, INDEPENDENT levels: several regions can sit at
// different activity at the same time. There is no lifecycle, no acts, no
// story — the field is always running and the levels are just where they are.
//
// SIMULATION VALUES ARE PROTOTYPE-ONLY: activityLevel / engagement /
// capacityParticipation / coherence describe this simulation. They are not
// Civarro product metrics and are not mapped to GPU %, tok/s or request rate.
//
// vendor/swarm-core.js is byte-identical to the supplied prototype.
//
// DEVIATION FROM v2 (owner direction, 2026-08-25): ORBITAL ASSEMBLY.
// Engaged capacity may temporarily assemble into a loose orbital formation
// around the regional centre. Each agent targets its OWN ring radius (a band,
// never the centre point), so the formation stays porous and individually
// resolvable; the density relief and crowd escape stay active underneath and
// keep it from ever collapsing into a mass. When activity falls, engagement
// decays and the formation dissolves back into the ambient field.

import * as core from './vendor/swarm-core.js';
import { makeHive } from './hive.js';

const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;

// Engagement falloff around a region, in radians of arc on the world. The
// field GROWS with activity: at moderate activity it stays tight enough that
// two active regions read separately, and at higher demand it reaches further
// out, so more distant capacity genuinely joins in rather than the same
// capacity merely getting brighter.
//
// Tightened in the final pass for regional legibility: in a one-region state
// the coordinated portion should visibly BELONG to that region, with the rest
// of the sphere carrying on independently. Tightening the cone changes only
// who participates — there is still no attractor, so nothing densifies.
// v2 refinement pass: TIGHTER still. Frankfurt active must read as a
// Frankfurt-area phenomenon, so the cone that decides who participates is
// roughly half the previous solid angle. Nothing else changes: no attractor,
// no densification — only membership narrows.
// Refinement: recruit MORE nearby capacity (a wider intake) while the assembled
// body itself gets SMALLER and fully packed — concentration comes from filling a
// tighter footprint, never from bigger glyphs.
const angIn = lv => 0.15 + 0.095 * lv;
const angOut = lv => 0.35 + 0.26 * lv;

export function makeField(opts = {}) {
  const SR = opts.SR ?? 58;
  const HIVE = makeHive();                        // containment math only, never drawn
  const sim = core.createSystem({ n: opts.n ?? 520, hive: HIVE, worldR: 70, speed: 0.34 });
  // v3 — THE TWO KNOBS, SEPARATED.
  //
  // In v2 one number did two jobs: the arc position decided BOTH how strongly
  // capacity adheres to the formation and how small that formation is. Pushing
  // the arc up to get a real formation therefore always produced a critical
  // mass, and pulling it down to open the formation up dissolved the formation
  // entirely. So the two are now separate:
  //
  //   sim.dwell (below)  how strongly engaged capacity holds the formation
  //   sim.shellK (here)  how BIG that formation is
  //
  // Adherence stays high, so the cohort is unmistakably one coordinated body;
  // the envelope is more than twice v2's radius, so the same population occupies
  // roughly six times the area and every mark stays individually resolvable.
  // compact by direction (Swarm pass): the cohort reads as ONE contained,
  // efficient formation — most of the group near the coordinated core, only a
  // minority at the rim. Still porous (compression stays low, so no solid mass,
  // no vibration, no heat), but the envelope is clearly smaller than before.
  sim.shellK = 0.50;                              // envelope scale
  sim.PATCH.length = 0; sim.sites.length = 0;     // ABC / resource sites off
  sim.probe.auto = 0;
  const N = sim.N;
  const SPD0 = sim.SPD * 0.5;

  // deterministic per-agent character
  let s = 20260825 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };

  const eng = new Float32Array(N);                // engagement, 0..1
  const chroma = new Float32Array(N);             // secondary colour cue, 0..~0.7
  const bias = new Float32Array(N);               // participation propensity
  const tauE = new Float32Array(N);               // engagement time constant
  const prevH = new Float32Array(N * 3);          // last frame's heading (wander low-pass)
  const turn = new Float32Array(N);               // measured heading change rate, rad/s
  const home = new Int8Array(N).fill(-1);
  const slotOf = new Int16Array(N).fill(-1);      // formation station, -1 = none
  const slotReg = new Int8Array(N).fill(-1);
  const arr = new Uint8Array(N);                  // 1 = docked at its station
  const lift = new Float32Array(N);               // radial height off the shell
  let EMERGE = null;                              // lens-transition origins
  const ctr = new Float32Array(N * 3);            // the particle's OWN cohort centre
  const hasCtr = new Uint8Array(N);
  // DIRECT PLACEMENT of engaged capacity (see placeEngaged below): its own polar
  // address inside its workload's cloud, plus a per-particle motion phase.
  const pcoh = new Int16Array(N).fill(-1);
  const prho = new Float32Array(N);
  const pphi = new Float32Array(N);
  const pphs = new Float32Array(N);
  const ppx = new Float32Array(N), ppy = new Float32Array(N), ppz = new Float32Array(N);
  const asmT = new Float32Array(N);               // recruitment countdown, s
  const curve = new Float32Array(N);              // own approach curvature bias
  const hold = new Float32Array(N);               // time spent in transit
  const saz = new Float32Array(N);                // slot azimuth on the patch
  const srad = new Float32Array(N);               // radial fraction, RMIN..1
  const swirl = new Float32Array(N);              // per-agent flow-band phase
  const occ = new Int16Array(64);                 // equal-area occupancy cells
  const ocx = new Float32Array(64), ocy = new Float32Array(64), ocz = new Float32Array(64);
  const cell = new Int8Array(N);
  for (let i = 0; i < N; i++) {
    bias[i] = 0.40 + rnd() * 0.85;                // some capacity stays independent even in a busy region
    tauE[i] = 1.1 + rnd() * 1.5;
    swirl[i] = rnd() * 6.283;
  }

  const REG = (opts.regions || []).map(r => ({
    id: r.id, u: r.u.slice(), p: r.p.slice(),
    activityLevel: 0, target: 0, phase: rnd() * 6.283,
    flowSign: r.flowSign ?? 1,
    coherence: 0, participation: 0, spread: 0,
    rotPhase: rnd() * 6.283, e1: null, e2: null, ballR: 0, docked: 0
  }));
  for (const r of REG) {
    let e1 = [r.u[1], -r.u[0], 0];
    let L2 = Math.hypot(e1[0], e1[1], e1[2]);
    if (L2 < 1e-3) { e1 = [1, 0, 0]; L2 = 1; }
    r.e1 = [e1[0] / L2, e1[1] / L2, e1[2] / L2];
    r.e2 = [r.u[1] * r.e1[2] - r.u[2] * r.e1[1], r.u[2] * r.e1[0] - r.u[0] * r.e1[2], r.u[0] * r.e1[1] - r.u[1] * r.e1[0]];
  }
  // FORMATION — the original swarm's own mechanics, re-aimed at the coordinated
  // region instead of the cursor. Each committed agent keeps a persistent SLOT:
  // an azimuth on the region's tangent plane plus a radial fraction in
  // [RMIN, 1] of the ball radius. The cube-root distribution fills the annulus
  // evenly instead of crowding the rim, and RMIN leaves a hollow core, so the
  // body forms AROUND the node and never touches it. The ball grows with the
  // population it holds (√n, as in the original) and turns as one via rotPhase.
  const RMIN = 0.22;                               // a FILLED disc with a small core — never a ring
  const CAP = 42;                                  // members per cohort
  // The original sized its ball with a √n law for a 3D volume. Here the body is
  // an annulus ON the surface, so the radius follows the AREA the population
  // needs at the glyph pitch, with the hollow core discounted:
  //   n·0.866·pitch² = π·R²·(1 − RMIN²)
  function ballRadius(n) {
    const need = Math.max(1, n) * 0.866;
    return F.stationPitch * 1.22 * Math.max(1.6, Math.sqrt(need / (Math.PI * (1 - RMIN * RMIN))));
  }

  const RIX = Object.fromEntries(REG.map((r, i) => [r.id, i]));

  function toSurface() {
    for (let i = 0; i < N; i++) {
      const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
      const L = Math.hypot(x, y, z) || 1, k = SR / L;
      sim.px[i] = x * k; sim.py[i] = y * k; sim.pz[i] = z * k;
      const nx = x / L, ny = y / L, nz = z / L;
      const rad = sim.vx[i] * nx + sim.vy[i] * ny + sim.vz[i] * nz;
      sim.vx[i] -= rad * nx; sim.vy[i] -= rad * ny; sim.vz[i] -= rad * nz;
    }
  }

  // ===== CAPACITY OWNERSHIP MODEL ==========================================
  // NETWORK -> REGION -> NODE -> SLOT -> PARTICLES -> FREE/ENGAGED.
  //
  // Ownership comes BEFORE state. Every slot has a permanent node and region;
  // every particle inherits that ownership from its slot and never leaves it.
  // Position, proximity, movement, density and animation cannot change it.
  // Only the SLOT's allocation decides FREE vs ENGAGED, and it decides for all
  // five of its particles at once.
  //
  // PROTOTYPE FIXTURE — a stand-in for backend slot ownership, not a claim
  // about production capacity: 59 slots over 10 nodes.
  const PER_SLOT = 5;
  const NODE_SLOTS = [
    { region: 'ohio', node: 'ohio-node-01', slots: 6 },
    { region: 'ohio', node: 'ohio-node-02', slots: 6 },
    { region: 'ohio', node: 'ohio-node-03', slots: 6 },
    { region: 'ohio', node: 'ohio-node-04', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-01', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-02', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-03', slots: 6 },
    { region: 'dublin', node: 'dublin-node-01', slots: 6 },
    { region: 'dublin', node: 'dublin-node-02', slots: 6 },
    { region: 'dublin', node: 'dublin-node-03', slots: 5 }
  ];
  // the slot table, and the particle ids each slot permanently owns
  const SLOTS = [];
  const ownerOf = new Int16Array(N).fill(-1);       // region index, immutable
  const slotOfParticle = new Int16Array(N).fill(-1);
  {
    let pid = 0;
    for (const nd of NODE_SLOTS) {
      const rk = RIX[nd.region];
      for (let s = 0; s < nd.slots; s++) {
        const ids = [];
        for (let k = 0; k < PER_SLOT && pid < N; k++, pid++) {
          ids.push(pid);
          ownerOf[pid] = rk;
          slotOfParticle[pid] = SLOTS.length;
        }
        SLOTS.push({ id: SLOTS.length, node: nd.node, region: nd.region, rk, ids, used: 0 });
      }
    }
  }
  let ballAt = null;                                // per-agent ball centre
  const slotsTotal = SLOTS.length;
  const alloc = new Uint8Array(N);                  // 1 = ENGAGED
  const usedBy = {};
  for (const r of REG) usedBy[r.id] = 0;
  let allocKey = '';
  let slotsUsed = 0;

  // the engine assigns a solid-angle slot on commitment; because membership is
  // declared here, the direction is handed out here too — indexed by the
  // particle's rank within its own region's engaged set, so each cohort fills
  // its ball evenly and the same identities always take the same places
  const GOLD = Math.PI * (3 - Math.sqrt(5));
  const _sl = new Float32Array(3);
  function fibSlot(k, n, out) {
    const z = 1 - 2 * (k + 0.5) / Math.max(1, n);
    const r = Math.sqrt(Math.max(0, 1 - z * z));
    const a = k * GOLD;
    out[0] = Math.cos(a) * r; out[1] = z; out[2] = Math.sin(a) * r;
  }

  // FREE/ENGAGED is set at SLOT level. A region's used slots can only come from
  // the slots that region already owns.
  function applyUsed(perRegion) {
    alloc.fill(0);
    lift.fill(0);
    hasCtr.fill(0);
    pcoh.fill(-1);
    slotsUsed = 0;
    for (const r of REG) {
      const own = SLOTS.filter(s => s.region === r.id);
      const want = Math.max(0, Math.min(own.length, Math.round(perRegion[r.id] || 0)));
      usedBy[r.id] = want;
      slotsUsed += want;
      let rank = 0;
      for (let k = 0; k < own.length; k++) {
        const s = own[k];
        s.used = k < want ? 1 : 0;
        if (!s.used) continue;
        for (const i of s.ids) alloc[i] = 1;
      }
      const total = want * PER_SLOT;
      for (let k = 0; k < own.length; k++) {
        const s = own[k];
        if (!s.used) continue;
        for (const i of s.ids) {
          fibSlot(rank++, total, _sl);
          sim.slot[i * 3] = _sl[0]; sim.slot[i * 3 + 1] = _sl[1]; sim.slot[i * 3 + 2] = _sl[2];
        }
      }
    }
  }

  // ADDRESSED ALLOCATION. applyUsed() above takes a count per region and marks
  // that region's first N slots; a review fixture instead names the exact slots
  // it engages, by their permanent address [nodeId, indexWithinNode]. Same
  // ownership model, same per-slot particles, no counts inferred — the fixture
  // decides which nodes participate.
  function applyUsedAddresses(list) {
    const byAddr = {};
    const perNode = {};
    for (const s of SLOTS) {
      const k = (perNode[s.node] = (perNode[s.node] ?? -1) + 1);
      byAddr[s.node + '#' + k] = s;
    }
    alloc.fill(0);
    lift.fill(0);
    hasCtr.fill(0);
    pcoh.fill(-1);
    slotsUsed = 0;
    for (const r of REG) usedBy[r.id] = 0;
    for (const s of SLOTS) s.used = 0;
    for (const [node, idx] of list) {
      const s = byAddr[node + '#' + idx];
      if (!s || s.used) continue;
      s.used = 1;
      slotsUsed++;
      usedBy[s.region] = (usedBy[s.region] || 0) + 1;
      for (const i of s.ids) alloc[i] = 1;
    }
    // formation slots, per region, over that region's engaged particles
    for (const r of REG) {
      const own = SLOTS.filter(s => s.region === r.id && s.used);
      const total = own.length * PER_SLOT;
      let rank = 0;
      for (const s of own) for (const i of s.ids) {
        fibSlot(rank++, total, _sl);
        sim.slot[i * 3] = _sl[0]; sim.slot[i * 3 + 1] = _sl[1]; sim.slot[i * 3 + 2] = _sl[2];
      }
    }
  }

  // ---- ONE COHORT PER WORKLOAD FOOTPRINT ---------------------------------------
  // OWNERSHIP IS AUTHORITATIVE. A slot permanently belongs to a node and a
  // region; its five particles inherit that ownership and nothing here may move
  // them out of it. An earlier build tallied a workload's regions, picked a HOME
  // region and gathered ALL of its capacity there so each workload would have
  // exactly one cloud. That contradicted the model: capacity allocated on a
  // Frankfurt node was drawn in Ohio.
  // So a workload is split into FOOTPRINTS — one per region it actually holds
  // capacity in — and each footprint is stationed in ITS OWN region. VISION PRO
  // with a slot on sev-2 (Ohio) and one on gpu-1 (Frankfurt) therefore shows
  // capacity in both places. It remains ONE workload record with ONE colour and
  // ONE label: the label anchors on the PRIMARY footprint (most particles; ties
  // resolve by lowest region index, so the choice is deterministic), and the
  // other footprints are recognised by the shared workload colour.
  let COHORTS = [];
  function setCohortStations(groups) {
    const byReg = new Map();
    for (const g of groups || []) {
      const mine = [];
      const tally = new Map();
      for (const i of g.parts || []) {
        if (!alloc[i]) continue;
        const k = ownerOf[i];
        if (k < 0) continue;
        mine.push(i);
        tally.set(k, (tally.get(k) || 0) + 1);
      }
      if (!mine.length) continue;
      let home = -1, hv = -1;
      for (const [k, n] of tally) if (n > hv || (n === hv && k < home)) { hv = n; home = k; }
      mine.sort((a, b2) => a - b2);
      if (!byReg.has(home)) byReg.set(home, []);
      byReg.get(home).push({ id: g.id, parts: mine });
    }
    const centres = {};
    COHORTS = [];
    for (const [k, list] of byReg) {
      const r = REG[k];
      const G = list.length;
      const ballR = ballRadius(list.reduce((n, g) => n + g.parts.length, 0));
      // the region's own tangent frame: sub-cohorts separate ALONG the surface,
      // never radially — engaged capacity is projected onto the sphere, so a
      // radial split would collapse into the same screen area
      let e1x = -r.u[2], e1y = 0, e1z = r.u[0];
      let e1l = Math.hypot(e1x, e1y, e1z);
      if (e1l < 1e-4) { e1x = 1; e1y = 0; e1z = 0; e1l = 1; }
      e1x /= e1l; e1y /= e1l; e1z /= e1l;
      const e2x = r.u[1] * e1z - r.u[2] * e1y;
      const e2y = r.u[2] * e1x - r.u[0] * e1z;
      const e2z = r.u[0] * e1y - r.u[1] * e1x;
      const SEP = G === 1 ? 0 : 0.8;             // sector centre, in ball radii
      for (let gi = 0; gi < G; gi++) {
        const g = list[gi];
        const thg = (gi / G) * 6.2832 + 0.4;
        const bx = Math.cos(thg) * e1x + Math.sin(thg) * e2x;
        const by = Math.cos(thg) * e1y + Math.sin(thg) * e2y;
        const bz = Math.cos(thg) * e1z + Math.sin(thg) * e2z;
        const M = g.parts.length;
        // ONE COMPACT CLOUD per workload, around its own anchor: a fibonacci fill
        // of a small tangential patch, so every particle still holds a DISTINCT
        // station (which is what stops the engine's spacing forces from scattering
        // a cohort) while the group reads as ONE cloud. No branches, no spokes, no
        // scaffold: the only structure is the single sphere-normal stem the
        // renderer raises from the anchor to carry the label.
        // CLOUD RADIUS — owner 2026-09-11: 1.05 / 0.52 still read as too separated
        // in Capacity, both between particles and from the node they belong to.
        // Tightened to ~2/3, and the inner ring pulled closer to the anchor, so a
        // cohort sits ON its node instead of orbiting wide of it. Particles still
        // resolve individually — the ring band and the golden-angle spacing are
        // unchanged, only the radius shrinks.
        const SPR = G === 1 ? 0.68 : 0.34;       // cloud radius, in ball radii
        const RC = ballR * SPR;                  // cloud radius, world units
        for (let j = 0; j < M; j++) {
          const i = g.parts[j];
          // sqrt keeps the fill area-even (no dense core); the 0.4 floor pushes the
          // innermost ring off the anchor so nothing piles up on the marker
          const fr = 0.3 + 0.7 * Math.sqrt((j + 0.5) / M);
          const rho = SPR * fr;
          const ph = j * GOLD;
          const cx2 = Math.cos(ph) * rho, sy2 = Math.sin(ph) * rho;
          let dx = bx * SEP + e1x * cx2 + e2x * sy2 + r.u[0] * 0.05;
          let dy = by * SEP + e1y * cx2 + e2y * sy2 + r.u[1] * 0.05;
          let dz = bz * SEP + e1z * cx2 + e2z * sy2 + r.u[2] * 0.05;
          const dl = Math.hypot(dx, dy, dz) || 1;
          const cap = Math.min(1, dl);
          sim.slot[i * 3] = dx / dl * cap;
          sim.slot[i * 3 + 1] = dy / dl * cap;
          sim.slot[i * 3 + 2] = dz / dl * cap;
          lift[i] = 0;
          hasCtr[i] = 1;
          // its polar address inside its OWN cloud, and its own motion phase
          pcoh[i] = COHORTS.length;
          prho[i] = RC * fr;
          pphi[i] = ph;
          pphs[i] = (j * 2.399963) % 6.2832;
        }
        // THE WORKLOAD ANCHOR: one point on the sphere. The renderer raises a
        // single stem from it along THIS point's own normal.
        const axw = r.u[0] * SR + bx * ballR * SEP;
        const ayw = r.u[1] * SR + by * ballR * SEP;
        const azw = r.u[2] * SR + bz * ballR * SEP;
        const al2 = Math.hypot(axw, ayw, azw) || 1;
        const co = {
          id: g.id, reg: k, n: M,
          c: [axw / al2 * SR, ayw / al2 * SR, azw / al2 * SR],
          // the cloud's own tangent frame at the anchor, for direct placement
          t1: null, t2: null, rc: RC
        };
        {
          const nx = axw / al2, ny = ayw / al2, nz = azw / al2;
          let ax2 = -nz, ay2 = 0, az2 = nx;
          let al3 = Math.hypot(ax2, ay2, az2);
          if (al3 < 1e-4) { ax2 = 1; ay2 = 0; az2 = 0; al3 = 1; }
          co.t1 = [ax2 / al3, ay2 / al3, az2 / al3];
          co.t2 = [ny * co.t1[2] - nz * co.t1[1], nz * co.t1[0] - nx * co.t1[2], nx * co.t1[1] - ny * co.t1[0]];
        }
        for (const i of g.parts) {
          ctr[i * 3] = axw / al2; ctr[i * 3 + 1] = ayw / al2; ctr[i * 3 + 2] = azw / al2;
        }
        COHORTS.push(co);
        const cl = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
        const prev = centres[g.id];
        // PRIMARY FOOTPRINT for the label: most particles wins; a tie goes to the
        // lowest region index, so the anchor never depends on iteration luck
        if (!prev || M > prev.n || (M === prev.n && k < prev.k)) {
          centres[g.id] = { n: M, k, u: [co.c[0] / cl, co.c[1] / cl, co.c[2] / cl] };
        }
      }
    }
    const out = {};
    for (const id in centres) out[id] = centres[id].u;
    return out;
  }
  // live structures in world space, read AFTER this frame's body rotation. One
  // entry per workload id: its PRIMARY footprint (most particles, ties to the
  // lowest region index) — the label anchors there, the other footprints keep
  // their own clouds where their capacity actually lives.
  function cohortStructures() {
    const out = {};
    for (const co of COHORTS) {
      const l = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
      const u = [co.c[0] / l, co.c[1] / l, co.c[2] / l];
      const s = { u, p: co.c, n: co.n, reg: co.reg };
      const prev = out[co.id];
      if (!prev) { out[co.id] = s; s.all = [s]; continue; }
      const all = prev.all;
      all.push(s);
      if (co.n > prev.n || (co.n === prev.n && co.reg < prev.reg)) {
        out[co.id] = s; s.all = all;          // the primary, still carrying the set
      }
    }
    return out;
  }

  // ---- DIRECT PLACEMENT OF ENGAGED CAPACITY ------------------------------------
  // THE REASON NOTHING BEFORE THIS WORKED. swarm-core owns the positions of every
  // committed particle and organises them around ONE anchor for the whole engine
  // (sim.probeAnchor = the dominant region's point). Every previous attempt only
  // set station vectors and velocity nudges, which the engine consumes as hints
  // inside its own single ball — so the clouds kept sliding off their anchors and
  // interleaving, no matter what the stations said.
  // So engaged capacity is no longer asked: it is PLACED. Each particle sits at
  // its own polar address inside its workload's cloud, around that workload's own
  // anchor, and the only motion is a small deterministic wobble of its angle,
  // radius and height. Free capacity is untouched — the engine still owns all 245.
  function placeEngaged(t) {
    let unplaced = 0;
    for (let i = 0; i < N; i++) {
      const ci = pcoh[i];
      if (!alloc[i]) continue;
      if (ci < 0 || ci >= COHORTS.length) { unplaced++; continue; }
      const co = COHORTS[ci];
      const ph = pphs[i];
      // ORBIT. Each particle circles its own workload anchor — the angle advances
      // continuously at its own rate, so the cloud is in permanent local motion
      // instead of merely trembling — while its radius breathes on a different
      // period. Coordinated (all one way) but never in lockstep.
      const om = 0.34 + 0.22 * ((i * 0.618034) % 1);          // rad/s, per particle
      const phi = pphi[i] + t * om + 0.18 * Math.sin(t * 1.1 + ph);
      const rr = prho[i] * (1 + 0.24 * Math.sin(t * 0.85 + ph * 1.7) + 0.08 * Math.sin(t * 2.3 + ph));
      const hi = co.rc * 0.05 * (0.5 + 0.5 * Math.sin(t * 0.8 + ph * 0.9));
      const cs = Math.cos(phi) * rr, sn = Math.sin(phi) * rr;
      let x = co.c[0] + co.t1[0] * cs + co.t2[0] * sn;
      let y = co.c[1] + co.t1[1] * cs + co.t2[1] * sn;
      let z = co.c[2] + co.t1[2] * cs + co.t2[2] * sn;
      const l = Math.hypot(x, y, z) || 1;
      const k2 = (SR + hi) / l;
      x *= k2; y *= k2; z *= k2;
      // velocity from the actual displacement, so glyph headings and wakes stay honest
      sim.vx[i] = (x - (ppx[i] || x)) * 60;
      sim.vy[i] = (y - (ppy[i] || y)) * 60;
      sim.vz[i] = (z - (ppz[i] || z)) * 60;
      ppx[i] = x; ppy[i] = y; ppz[i] = z;
      sim.px[i] = x; sim.py[i] = y; sim.pz[i] = z;
    }
    if (typeof window !== 'undefined') {
      // how far each engaged particle sits from its OWN cohort centre: the number
      // that says whether any colour has been stranded away from its anchor
      let far = 0, maxArc = 0;
      for (let i = 0; i < N; i++) {
        const ci = pcoh[i];
        if (ci < 0 || !alloc[i] || ci >= COHORTS.length) continue;
        const co = COHORTS[ci];
        const l = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
        const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
        const cd = (co.c[0] * sim.px[i] + co.c[1] * sim.py[i] + co.c[2] * sim.pz[i]) / (l * pl);
        const arc = Math.acos(Math.max(-1, Math.min(1, cd))) * 57.2958;
        if (arc > maxArc) maxArc = arc;
        if (arc > 12) far++;
      }
      let eng = 0; for (let i = 0; i < N; i++) if (alloc[i]) eng++;
      window.__engDbg = { unplaced, cohorts: COHORTS.length, engaged: eng, strayOver12deg: far, maxArcDeg: +maxArc.toFixed(1) };
    }
  }

  const F = {
    sim, SR, eng, chroma, home, regions: REG,
    alloc, PER_SLOT, lift,
    get slots() {
      const engaged = slotsUsed * PER_SLOT;
      const tot = slotsTotal * PER_SLOT;
      return {
        total: slotsTotal, used: slotsUsed, free: slotsTotal - slotsUsed,
        particlesTotal: tot, particlesEngaged: engaged, particlesFree: tot - engaged,
        usedPct: slotsTotal ? Math.round(slotsUsed / slotsTotal * 100) : 0,
        freePct: slotsTotal ? Math.round((slotsTotal - slotsUsed) / slotsTotal * 100) : 0
      };
    },
    // the slot table, read-only, for consumers that must map a slot's OWN
    // particles to something outside the model (e.g. workload identity)
    slotTable() { return SLOTS.map(s => ({ id: s.id, node: s.node, region: s.region, used: s.used, ids: s.ids })); },
    setCohortStations, cohortStructures,
    emergeOrigins() {
      if (!EMERGE) EMERGE = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        const o = i * 3;
        let u = null;
        if (alloc[i] && hasCtr[i]) u = [ctr[o], ctr[o + 1], ctr[o + 2]];
        else { const k = ownerOf[i]; if (k >= 0) u = REG[k].u; }
        if (u) { EMERGE[o] = u[0]; EMERGE[o + 1] = u[1]; EMERGE[o + 2] = u[2]; }
        else { EMERGE[o] = 0; EMERGE[o + 1] = 0; EMERGE[o + 2] = 0; }
      }
      return EMERGE;
    },
    // ownership: permanent, and independent of any fixture
    ownership() {
      const out = { network: { slots: slotsTotal, particles: slotsTotal * PER_SLOT, nodes: NODE_SLOTS.length }, regions: {} };
      for (const r of REG) {
        const own = SLOTS.filter(s => s.region === r.id);
        if (!own.length) continue;
        out.regions[r.id] = {
          nodes: new Set(own.map(s => s.node)).size,
          slots: own.length,
          particles: own.length * PER_SLOT,
          usedSlots: usedBy[r.id],
          freeSlots: own.length - usedBy[r.id],
          engagedParticles: usedBy[r.id] * PER_SLOT,
          freeParticles: (own.length - usedBy[r.id]) * PER_SLOT
        };
      }
      return out;
    },
    audit() {
      const byRegion = {};
      for (const r of REG) byRegion[r.id] = 0;
      for (let i = 0; i < N; i++) if (alloc[i] && ownerOf[i] >= 0) byRegion[REG[ownerOf[i]].id]++;
      let a = 0, c = 0, hot = 0;
      for (let i = 0; i < N; i++) {
        if (alloc[i]) a++;
        if (sim.cmt[i]) c++;
        if (chroma[i] > 0) hot++;
      }
      return { N, allocated: a, committed: c, coloured: hot, byRegion, expected: slotsUsed * PER_SLOT };
    },
    // perRegion: { regionId: usedSlots }. Only the regions whose count changed
    // are recomputed, so no region loses capacity because another gained it.
    // perRegion: { regionId: usedSlots } — the quantitative source of truth
    setSlots(_total, perRegion) {
      const key = REG.map(r => r.id + '=' + (perRegion[r.id] || 0)).join(',');
      if (key !== allocKey) { allocKey = key; applyUsed(perRegion); }
    },
    usedByRegion() { return { ...usedBy }; },
    // engage exactly these slot addresses ([nodeId, indexWithinNode] pairs)
    setUsedSlotAddresses(list) {
      const key = 'addr:' + list.map(a => a.join('#')).join(',');
      if (key !== allocKey) { allocKey = key; applyUsedAddresses(list); }
    },
    occupancyPeak: 0,
    tune: { flow: 1.7, wander: 0.55, sync: 0.18, chroma: 1.0, orbit: 1.0 },
    stationPitch: 3.3,
    // called from the render loop: the pitch that keeps a constant screen gap
    setStationPitch(v) {
      const w = Math.max(0.18, Math.min(7, v));
      if (Math.abs(w - this.stationPitch) / this.stationPitch > 0.05) this.stationPitch = w;
    },
    fixture: 'BASELINE',

    // ---- persistent state: set a region's activity, leave the others alone ----
    setLevel(id, v) { const k = RIX[id]; if (k !== undefined) REG[k].target = clamp01(v); },
    setLevels(map) { for (const r of REG) r.target = clamp01(map[r.id] ?? 0); },
    level(id) { const k = RIX[id]; return k === undefined ? 0 : REG[k].activityLevel; },

    update(dt) {
      // USE THE ENGINE'S OWN RESPONSE ARC. swarm-core already carries the
      // approved animation — hysteretic commitment, the converge → enclose →
      // peak walk, volumetric slots inside a contracting ball, incoming agents
      // dashing and settling members vibrating. Earlier revisions switched all
      // of that off and re-implemented a station grid by hand; this drives the
      // engine instead. The only change is WHERE it points: the anchor is the
      // coordinated region's own surface point, not the cursor.
      {
        let dom = null;
        for (const r of REG) if (!dom || r.activityLevel > dom.activityLevel) dom = r;
        const lvDom = dom ? dom.activityLevel : 0;
        if (dom && lvDom > 0.06) {
          sim.probeAnchor = [dom.p[0], dom.p[1], dom.p[2]];
          // v3 — A REGIME OF OUR OWN, NOT A POINT ON THE ARC.
          //
          // The engine's arc moves four things together: adherence to the
          // formation (shell), contraction (compress), heat (thermal) and global
          // alignment (align). v2 rode that arc, so the only way to get a real
          // formation was to accept the contraction, the vibration and the heat
          // that come with it — which is exactly the overload reading. The terms
          // are independent inputs to the model, so they are now set
          // independently:
          //
          //   shell    HIGH   the cohort genuinely holds one formation
          //   compress LOW    no contraction, no slowdown, no shell vibration
          //   thermal  ~0     nothing heats, so nothing can read as failure
          //   align    LOW    free capacity stays evenly distributed instead of
          //                   flocking into streams and knots of its own
          //
          // thermal sits a hair above zero on purpose: swarm-core substitutes its
          // own arc for any pinned regime whose thermal is exactly 0, and this
          // regime has to survive as written.
          const q = Math.min(1, lvDom);
          sim.regime = {
            probe: 1, flee: 0,
            engage: 0.78 + 0.22 * q,
            shell: 0.72 + 0.28 * q,
            compress: 0.06 + 0.06 * q,
            thermal: 0.0001,
            align: 0.20 + 0.12 * q
          };
          sim.dwell = q;                       // demand, for the engine's own use
        } else {
          sim.regime = core.REGIMES.rest;
          sim.dwell = 0;
        }
        sim.probe.auto = 0; sim.probe.lastInput = sim.t;
        sim.pointer = 0;
        sim.dose = 0; sim.neutralised = false; sim.neutralFor = 0;
      }

      {
        if (!ballAt) ballAt = new Float32Array(N * 3);
        for (let i = 0; i < N; i++) {
          const k = ownerOf[i];
          const p = k >= 0 ? REG[k].p : null;
          if (p) { ballAt[i * 3] = p[0]; ballAt[i * 3 + 1] = p[1]; ballAt[i * 3 + 2] = p[2]; }
          else { ballAt[i * 3] = sim.probe.x; ballAt[i * 3 + 1] = sim.probe.y; ballAt[i * 3 + 2] = sim.probe.z; }
        }
        sim.ballAt = ballAt;
      }
      // ---- ONE TURNING BODY --------------------------------------------------
      // Shared direction was the part the old build could not show: agents docked
      // at fixed stations and vibrated, so the cohort read as a cluster holding
      // still (or, at higher demand, as a mass contracting). The stations
      // themselves now rotate slowly about the region's own axis, so every
      // engaged mark travels the same way at the same time and the formation
      // reads as ONE coordinated body in motion. Rotating the stations costs
      // nothing in density: the formation keeps its shape and its spacing exactly.
      // ---- FIXED FORMATION, LIVING PARTICLES ---------------------------------
      // The stations used to revolve slowly around each region's axis, which read
      // as the workloads themselves drifting across the world: anchors, clouds and
      // labels all travelled. Semantic structure must not move, so that rotation
      // is off. Life comes from the engine's own local wander and coordination
      // inside each cloud, not from moving the structure.
      const BODY_TURN = 0;
      for (let k = 0; BODY_TURN && k < REG.length; k++) {
        const r = REG[k];
        const qr = Math.min(1, r.activityLevel);
        if (qr < 0.05) continue;
        // slow coherent drift of the whole body — legible shared motion, and far
        // below anything that could read as an orbit or a spiral
        const th = (0.07 + 0.09 * qr) * dt * (r.flowSign >= 0 ? 1 : -1);
        const c = Math.cos(th), sn = Math.sin(th), u = r.u, om = 1 - c;
        for (let i = 0; i < N; i++) {
          if (!alloc[i] || ownerOf[i] !== k) continue;
          const o = i * 3;
          const x = sim.slot[o], y = sim.slot[o + 1], z = sim.slot[o + 2];
          const du = u[0] * x + u[1] * y + u[2] * z;
          sim.slot[o] = x * c + (u[1] * z - u[2] * y) * sn + u[0] * du * om;
          sim.slot[o + 1] = y * c + (u[2] * x - u[0] * z) * sn + u[1] * du * om;
          sim.slot[o + 2] = z * c + (u[0] * y - u[1] * x) * sn + u[2] * du * om;
        }
        // the cohort structures turn with the same body, so the drawn spokes and
        // the stations their particles hold stay locked together
        for (const co of COHORTS) {
          if (co.reg !== k) continue;
          const rot = v => {
            const x2 = v[0], y2 = v[1], z2 = v[2];
            const d2 = u[0] * x2 + u[1] * y2 + u[2] * z2;
            v[0] = x2 * c + (u[1] * z2 - u[2] * y2) * sn + u[0] * d2 * om;
            v[1] = y2 * c + (u[2] * x2 - u[0] * z2) * sn + u[1] * d2 * om;
            v[2] = z2 * c + (u[0] * y2 - u[1] * x2) * sn + u[2] * d2 * om;
          };
          rot(co.c);
        }
      }
      sim.step(dt);
      // ONE MEMBERSHIP. The engine recruits by proximity and hysteresis, which
      // produced a second, different population from the allocation: free marks
      // inside the response and engaged marks outside it. Its commitment array
      // is now the allocation, so the same identities that render ENGAGED are
      // the identities the response animates.
      for (let i = 0; i < N; i++) {
        sim.cmt[i] = alloc[i];
        if (alloc[i]) { if (sim.act[i] < 0.5) sim.act[i] = 0.5; }
        else { sim.eng[i] = 0; sim.act[i] = 0; }
      }
      toSurface();
      // engaged capacity is placed directly, after the engine has run: its clouds
      // belong to their workload anchors, not to the engine's single ball
      placeEngaged(sim.t || 0);

      for (const r of REG) {
        r.activityLevel += (r.target - r.activityLevel) * Math.min(1, dt / 1.5);
        r.phase += dt * (0.5 + 0.55 * r.activityLevel);
        r.rotPhase += dt * (0.05 + 0.04 * r.activityLevel);   // the composition's own slow turn
        r._cohSum = 0; r._cohN = 0; r._part = 0; r._spread = 0;
        r.docked = 0;
      }
      for (let i2 = 0; i2 < N; i2++) if (slotReg[i2] >= 0) REG[slotReg[i2]].docked++;
      for (const r of REG) r.ballR = ballRadius(r.docked);

      // the ACTUAL centre of each engaged cohort, on the surface — the cohort
      // card anchors here, so its leader always ends on the visible group
      for (const r of REG) { r._cx = 0; r._cy = 0; r._cz = 0; r._cn = 0; }
      for (let i = 0; i < N; i++) {
        if (!alloc[i]) continue;
        const k2 = ownerOf[i]; if (k2 < 0) continue;
        const g2 = REG[k2];
        g2._cx += sim.px[i]; g2._cy += sim.py[i]; g2._cz += sim.pz[i]; g2._cn++;
      }
      for (const r of REG) {
        if (!r._cn) { r.centroid = null; continue; }
        const l2 = Math.hypot(r._cx, r._cy, r._cz) || 1;
        r.centroid = [r._cx / l2 * SR, r._cy / l2 * SR, r._cz / l2 * SR];
      }

      // ---- v3 COORDINATION TREATMENT ------------------------------------------
      // Coordination has to be legible with the colour taken away. After the
      // engine has stepped, engaged capacity (1) blends its heading toward its
      // OWN region's shared circulation, (2) low-passes that heading so paths
      // straighten, and (3) shares one slow regional speed phase so the cohort
      // breathes together. All three act on VELOCITY. None of them is a position
      // target, so none of them can accumulate capacity anywhere.
      for (const r of REG) r._sync = Math.sin(r.phase * 0.8);
      for (let i = 0; i < N; i++) {
        if (!alloc[i]) continue;
        const k = ownerOf[i]; if (k < 0) continue;
        const r = REG[k];
        const e = Math.min(1, sim.eng[i]);
        if (e < 0.02) continue;
        const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
        const qx = sim.px[i] / pl, qy = sim.py[i] / pl, qz = sim.pz[i] / pl;
        // MEMBERSHIP IS LOCAL, AND IT IS THE WORKLOAD'S. An engaged particle
        // belongs WITH its own cohort: its home is its workload anchor (not the
        // region centre), and one that strays past its cohort envelope steers
        // back along the great circle at raised speed instead of wandering. That
        // is what keeps every colour wrapped around the anchor that names it.
        const cosd = qx * r.u[0] + qy * r.u[1] + qz * r.u[2];
        const dArc = Math.acos(Math.max(-1, Math.min(1, cosd))) * SR;
        if (dArc > sim.shellR * 1.12) {
          let gx = r.u[0] - qx * cosd, gy = r.u[1] - qy * cosd, gz = r.u[2] - qz * cosd;
          const gl = Math.hypot(gx, gy, gz) || 1e-6;
          gx /= gl; gy /= gl; gz /= gl;
          const wf = 1 - Math.exp(-dt * 4.5);
          const spd0 = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
          let mx2 = sim.vx[i] / spd0 * (1 - wf) + gx * wf;
          let my2 = sim.vy[i] / spd0 * (1 - wf) + gy * wf;
          let mz2 = sim.vz[i] / spd0 * (1 - wf) + gz * wf;
          const ml2 = Math.hypot(mx2, my2, mz2) || 1;
          const sp2 = spd0 * (1 + 0.55 * Math.min(1, dArc / sim.shellR - 1.12));
          sim.vx[i] = mx2 / ml2 * sp2; sim.vy[i] = my2 / ml2 * sp2; sim.vz[i] = mz2 / ml2 * sp2;
          continue;
        }
        // ITS OWN ANCHOR, NOT THE REGION'S CENTRE. A soft, continuous pull toward
        // the particle's WORKLOAD anchor once it drifts past that cohort's own
        // envelope: it acts on velocity only, never as a hard position target, so
        // the cloud stays wrapped around the anchor that names it while all the
        // organic motion below still runs.
        if (hasCtr[i]) {
          const cxh = ctr[i * 3], cyh = ctr[i * 3 + 1], czh = ctr[i * 3 + 2];
          const cd = qx * cxh + qy * cyh + qz * czh;
          const aArc = Math.acos(Math.max(-1, Math.min(1, cd))) * SR;
          const env = Math.max(3, sim.shellR * 0.42);
          if (aArc > env) {
            let gx = cxh - qx * cd, gy = cyh - qy * cd, gz = czh - qz * cd;
            const gl = Math.hypot(gx, gy, gz) || 1e-6;
            gx /= gl; gy /= gl; gz /= gl;
            const wf = (1 - Math.exp(-dt * 2.2)) * Math.min(1, (aArc - env) / env);
            const spd0 = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
            let mx2 = sim.vx[i] / spd0 * (1 - wf) + gx * wf;
            let my2 = sim.vy[i] / spd0 * (1 - wf) + gy * wf;
            let mz2 = sim.vz[i] / spd0 * (1 - wf) + gz * wf;
            const ml2 = Math.hypot(mx2, my2, mz2) || 1;
            sim.vx[i] = mx2 / ml2 * spd0; sim.vy[i] = my2 / ml2 * spd0; sim.vz[i] = mz2 / ml2 * spd0;
          }
        }
        let tx = r.u[1] * qz - r.u[2] * qy;
        let ty = r.u[2] * qx - r.u[0] * qz;
        let tz = r.u[0] * qy - r.u[1] * qx;
        const tl = Math.hypot(tx, ty, tz);
        if (tl < 1e-4) continue;
        const sgn = r.flowSign >= 0 ? 1 / tl : -1 / tl;
        tx *= sgn; ty *= sgn; tz *= sgn;
        const spd = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
        // deliberately modest: a stronger blend would cancel the engine's own
        // convergence and the cohort would never gather at all
        const w = Math.min(0.14, 0.08 * F.tune.flow * e);
        let nx = sim.vx[i] / spd * (1 - w) + tx * w;
        let ny = sim.vy[i] / spd * (1 - w) + ty * w;
        let nz = sim.vz[i] / spd * (1 - w) + tz * w;
        const h3 = i * 3;
        const hx = prevH[h3], hy = prevH[h3 + 1], hz = prevH[h3 + 2];
        if (hx || hy || hz) {
          // a strong heading low-pass: this is what makes engaged paths visibly
          // straighter than free ones, and it is measurable (turnEngaged < turnResting)
          const lp = Math.min(0.52, 0.95 * e * F.tune.wander);
          nx = nx * (1 - lp) + hx * lp; ny = ny * (1 - lp) + hy * lp; nz = nz * (1 - lp) + hz * lp;
        }
        const nl = Math.hypot(nx, ny, nz) || 1;
        const sp = spd * (1 + 0.09 * e * r._sync);
        sim.vx[i] = nx / nl * sp; sim.vy[i] = ny / nl * sp; sim.vz[i] = nz / nl * sp;
      }
      // heading change rate, measured for EVERY agent off the final velocity, so
      // the engaged / resting comparison in the diagnostics is a fair one: the
      // whole claim of the treatment is that engaged paths turn LESS.
      for (let i = 0; i < N; i++) {
        const h3 = i * 3;
        const vl = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1;
        const nxh = sim.vx[i] / vl, nyh = sim.vy[i] / vl, nzh = sim.vz[i] / vl;
        const px2 = prevH[h3], py2 = prevH[h3 + 1], pz2 = prevH[h3 + 2];
        if (px2 || py2 || pz2) {
          const dot = Math.max(-1, Math.min(1, px2 * nxh + py2 * nyh + pz2 * nzh));
          turn[i] += (Math.acos(dot) / Math.max(1e-3, dt) - turn[i]) * Math.min(1, dt / 0.4);
        }
        prevH[h3] = nxh; prevH[h3 + 1] = nyh; prevH[h3 + 2] = nzh;
      }

      const kE = dt;
      const kS = Math.min(1, dt / 0.45);
      const kC = Math.min(1, dt / 0.7);

      // mean crowding of the resting field, used to keep coordination from
      // becoming accumulation (see the relief term below)
      let nbSum0 = 0;
      for (let i = 0; i < N; i++) nbSum0 += sim.nb[i];
      const nbMean = nbSum0 / N || 1;

      // OCCUPANCY: how many agents share each of 64 equal-area cells of the
      // world. This is the honest knot detector. Local neighbour counts cannot
      // tell a coherent STREAM from a KNOT — riding side by side raises both —
      // but a stream crosses many cells while a knot fills one.
      occ.fill(0); ocx.fill(0); ocy.fill(0); ocz.fill(0);
      for (let i = 0; i < N; i++) {
        const zb = Math.min(7, ((sim.py[i] / SR + 1) * 4) | 0);          // equal-area in z
        const ab = Math.min(7, (((Math.atan2(sim.pz[i], sim.px[i]) / Math.PI + 1) * 4) | 0));
        const c = zb * 8 + ab;
        cell[i] = c; occ[c]++;
        ocx[c] += sim.px[i]; ocy[c] += sim.py[i]; ocz[c] += sim.pz[i];
      }
      let oMax = 0;
      for (let k = 0; k < 64; k++) {
        if (occ[k] > oMax) oMax = occ[k];
        if (occ[k]) { ocx[k] /= occ[k]; ocy[k] /= occ[k]; ocz[k] /= occ[k]; }
      }
      F.occupancyPeak += (oMax - F.occupancyPeak) * Math.min(1, dt / 0.5);
      const expect = N / 64;

      // Engagement and colour are READ from the engine: sim.eng is its own
      // hysteretic commitment and sim.temp its response heat, so an orange mark
      // is a committed member of the ball — exactly the original's reading.
      // COLOUR IS TEMPERATURE, exactly as in the original scene: the response's
      // own thermal field is what the glyphs and the isotherms both read, so the
      // ball carries a real amber-to-red gradient instead of one flat orange.
      // No membership test of mine sits in between — temp only rises inside the
      // envelope, which is precisely why the original looks the way it does.
      // Colour follows ALLOCATION, gated by identity: an engaged particle keeps
      // its response colour wherever it goes, and a free particle never takes
      // one however close it drifts to an active region. Within the engaged set
      // the engine's own thermal gradient still reads.
      for (let i = 0; i < N; i++) {
        eng[i] = sim.eng[i];
        // v3: ENGAGED is ONE controlled engagement accent, not a thermal ramp.
        // The value still breathes a little so the cohort has internal life, but
        // it can never travel to the alarm end of any scale.
        chroma[i] = alloc[i] ? (0.40 + 0.15 * Math.min(1, sim.eng[i])) * F.tune.chroma : 0;
      }
      {
        // attribute committed capacity to the region the ball is centred on
        let dom = null;
        for (const r of REG) if (!dom || r.activityLevel > dom.activityLevel) dom = r;
        for (const r of REG) { r._part = 0; r._cohN = 0; r._cohSum = 0; r._spread = 0; }
        if (dom) {
          dom._part = sim.committed || 0;
          dom._cohN = 1;
          dom._cohSum = sim.closure || 0;
          dom._spread = sim.coverage || 0;
        }
      }

      for (const r of REG) {
        r.coherence = r._cohN ? r._cohSum / r._cohN : 0;
        r.participation = r._part / N;
        r.spread = r._cohN ? r._spread / r._cohN : 0;
      }
    },

    // review instrumentation: the motor's own state, so a dead response can be
    // told apart from a loose one
    motor() {
      return {
        dwell: +sim.dwell.toFixed(3),
        gate: sim.hiveGate == null ? null : +sim.hiveGate.toFixed(3),
        probeOn: sim.probe.on,
        perturb: +sim.perturb.toFixed(3),
        shellR: +sim.shellR.toFixed(2),
        committed: sim.committed,
        neutralised: sim.neutralised,
        tempMax: +sim.tempMax.toFixed(3),
        cmt: (() => { let n = 0; for (let i = 0; i < N; i++) if (sim.cmt[i]) n++; return n; })(),
        engMean: (() => { let s2 = 0, n = 0; for (let i = 0; i < N; i++) if (alloc[i]) { s2 += sim.eng[i]; n++; } return n ? +(s2 / n).toFixed(3) : 0; })()
      };
    },

    // review instrumentation: the actual geometry of each cohort, so the
    // formation can be judged by measurement instead of by eye
    geometry() {
      const out = {};
      for (let k = 0; k < REG.length; k++) {
        const r = REG[k];
        const ds = [];
        for (let i = 0; i < N; i++) {
          if (!alloc[i] || ownerOf[i] !== k) continue;
          const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
          const dot = (sim.px[i] * r.u[0] + sim.py[i] * r.u[1] + sim.pz[i] * r.u[2]) / pl;
          ds.push(Math.acos(Math.max(-1, Math.min(1, dot))) * SR);   // arc distance
        }
        if (!ds.length) continue;
        ds.sort((x, y) => x - y);
        out[r.id] = {
          n: ds.length,
          median: +ds[ds.length >> 1].toFixed(1),
          p90: +ds[Math.min(ds.length - 1, Math.floor(ds.length * 0.9))].toFixed(1),
          max: +ds[ds.length - 1].toFixed(1),
          shellR: +sim.shellR.toFixed(1)
        };
      }
      return out;
    },

    // prototype diagnostics only — never product metrics
    state() {
      let engaged = 0, cSum = 0, cMax = 0, nbSum = 0, nbN = 0, nbBase = 0, nbBaseN = 0;
      let phiE = 0, phiB = 0, tE = 0, tB = 0, nbAll = 0;
      // the knot detector: mean of the densest few neighbourhoods in the field.
      // A knot spikes this; a coherent stream barely moves it.
      const TOPK = 8, top = new Float32Array(TOPK);
      for (let i = 0; i < N; i++) {
        nbAll += sim.nb[i];
        const v = sim.nb[i];
        if (v > top[TOPK - 1]) {
          let k = TOPK - 1;
          while (k > 0 && top[k - 1] < v) { top[k] = top[k - 1]; k--; }
          top[k] = v;
        }
        if (eng[i] > 0.3) { engaged++; nbSum += v; phiE += sim.phi[i]; tE += turn[i]; nbN++; }
        else { nbBase += v; phiB += sim.phi[i]; tB += turn[i]; nbBaseN++; }
        cSum += chroma[i]; if (chroma[i] > cMax) cMax = chroma[i];
      }
      let peak = 0;
      for (let k = 0; k < TOPK; k++) peak += top[k];
      peak /= TOPK;
      return {
        fixture: F.fixture,
        N,
        engaged,
        capacityParticipation: engaged / N,
        chromaMean: cSum / N,
        chromaMax: cMax,
        crowding: nbN ? nbSum / nbN : 0,          // mean neighbours of engaged capacity
        crowdingBase: nbBaseN ? nbBase / nbBaseN : 0,
        crowdingAll: nbAll / N,                   // whole-field density, the stable comparator
        crowdingPeak: peak,                       // densest neighbourhoods (streams raise this too)
        occupancyPeak: F.occupancyPeak,           // fullest equal-area cell — the knot detector
        // measured witnesses that coordination lives in MOTION, not in colour:
        // heading change rate should fall for engaged capacity (steadier paths)
        turnEngaged: nbN ? tE / nbN : 0,
        turnResting: nbBaseN ? tB / nbBaseN : 0,
        // the engine's own local order parameter, for reference: the resting
        // field is already locally flocked, so this is NOT the discriminator
        phiEngaged: nbN ? phiE / nbN : 0,
        phiResting: nbBaseN ? phiB / nbBaseN : 0,
        t: +sim.t.toFixed(2),
        regions: REG.map(r => ({
          id: r.id,
          activityLevel: +r.activityLevel.toFixed(3),
          coherence: +r.coherence.toFixed(3),
          spread: +r.spread.toFixed(3),
          participation: +r.participation.toFixed(3)
        }))
      };
    }
  };

  for (let i = 0; i < 150; i++) F.update(1 / 60);   // settle the resting field
  return F;
}
