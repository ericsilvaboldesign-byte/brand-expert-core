// CIVARRO WORLD — flattened from world-standalone/ops-v4/*.js (ES modules) for a
// single-file bundle. Edit the modules, re-run the flatten, do not edit this.
const __M = {};

// ===== vendor/swarm-core.js =====
__M["vendor/swarm-core.js"] = (() => {
// FIELD LANGUAGE — simulation core.
// Behaviour only. Nothing here knows how anything is drawn.
//
// State contract consumed by the drawing layer (names/types/semantics fixed):
//   px py pz  vx vy vz  phi spd meas wag nb role tgt  trail head
//   sites probe  slPts slSpd slSeed  t frame phiG perturb  SL SLN TL
//   temp def dwell shellR tempMax tempMean  regime cycle probeAnchor
// Added fields (safe to ignore downstream): act eng slot dance v0 tau ...

const TL = 44;
const SAMPLE_DT = 0.075;     // trace sampling on a fixed TIME interval
const SUBSTEP = 1 / 60;      // fixed integration substep
const MAX_SUBSTEPS = 4;

const ANGLES = { acute: 70.5288, obtuse: 109.4712, half: 35.2644 };
const SQ2 = Math.SQRT2;

// ---- documented clamps -----------------------------------------------------
const CLAMP = {
  omegaMax: 2.6,        // rad/s, magnitude cap on each OU angular-velocity channel
  turnMax: 1.9,         // rad/s, steering rate toward the desired heading
  turnMaxCommitted: 7.0,
  turnMaxDancing: 12.0, // the return loops need this to close
  elMax: 1.30,          // |asin(uy)| ceiling, radians
  elMaxCommitted: 1.57, // altitude preference fully suppressed under commitment
  speedLo: 0.30,        // × v0
  speedHi: 2.20,        // × v0_effective
  sigmaClip: 3,         // stochastic increments clipped to ±3σ
  lambdaDt: 0.30        // rate→probability conversion cap
};

// FCC <110> direction family — 12 unit vectors
const FCC_DIRS = (() => {
  const out = [], s = 1 / Math.SQRT2;
  for (const [i, j] of [[0, 1], [1, 2], [0, 2]])
    for (const si of [1, -1]) for (const sj of [1, -1]) {
      const v = [0, 0, 0]; v[i] = si * s; v[j] = sj * s; out.push(v);
    }
  return out;
})();

// 12 rhombic-dodecahedron faces (Voronoi cell of FCC), unit scale.
// Diagonals sqrt(2):1, acute angle 70.5288 deg.
const RD_FACES = (() => {
  const F = [];
  for (const [i, j, k] of [[0, 1, 2], [1, 2, 0], [0, 2, 1]])
    for (const si of [1, -1]) for (const sj of [1, -1]) {
      const A = [0, 0, 0]; A[i] = si;
      const B = [0, 0, 0]; B[j] = sj;
      const C = [0, 0, 0]; C[i] = si * 0.5; C[j] = sj * 0.5; C[k] = 0.5;
      const D = [0, 0, 0]; D[i] = si * 0.5; D[j] = sj * 0.5; D[k] = -0.5;
      F.push([A, C, B, D]);
    }
  return F;
})();

// ---- weak ambient field ----------------------------------------------------
// Environmental term only. It is NOT the motor of alignment: agents are steered
// by their own heading dynamics and by neighbours; this contributes a small
// drift written on the FCC <110> sums.
const A_ = 0.0175;
function field(x, y, z, t, out) {
  const ph = t * 0.085;
  const c1 = Math.cos(A_ * (x + y) + ph);
  const c2 = Math.cos(A_ * (y + z) + ph * 1.31);
  const c3 = Math.cos(A_ * (z + x) + ph * 0.77);
  let vx = (c1 - c3) * 14, vy = (c2 - c1) * 14, vz = (c3 - c2) * 14;
  vx += -z * 0.075; vz += x * 0.075;
  if (out) { out[0] = vx; out[1] = vy; out[2] = vz; return out; }
  return [vx, vy, vz];
}

// RK4, four stages at the same t. Integrates whatever field fn is handed in.
const _k = [new Float64Array(3), new Float64Array(3), new Float64Array(3), new Float64Array(3)];
function rk4(x, y, z, h, t, out, fn) {
  const F = fn || field;
  F(x, y, z, t, _k[0]);
  F(x + h * 0.5 * _k[0][0], y + h * 0.5 * _k[0][1], z + h * 0.5 * _k[0][2], t, _k[1]);
  F(x + h * 0.5 * _k[1][0], y + h * 0.5 * _k[1][1], z + h * 0.5 * _k[1][2], t, _k[2]);
  F(x + h * _k[2][0], y + h * _k[2][1], z + h * _k[2][2], t, _k[3]);
  out[0] = x + h / 6 * (_k[0][0] + 2 * _k[1][0] + 2 * _k[2][0] + _k[3][0]);
  out[1] = y + h / 6 * (_k[0][1] + 2 * _k[1][1] + 2 * _k[2][1] + _k[3][1]);
  out[2] = z + h / 6 * (_k[0][2] + 2 * _k[1][2] + 2 * _k[2][2] + _k[3][2]);
  return out;
}

// ---- camera ----------------------------------------------------------------
function makeCam(o = {}) {
  return { yaw: 0.5, pitch: 0.28, dist: 340, fov: 900, tx: 0, ty: 0, tz: 0, ...o };
}
function project(cam, x, y, z, W, H, out) {
  x -= cam.tx; y -= cam.ty; z -= cam.tz;
  const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
  const X = x * cy - z * sy; let Zr = x * sy + z * cy;
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  const Y = y * cp - Zr * sp; Zr = y * sp + Zr * cp;
  const d = Zr + cam.dist, s = cam.fov / Math.max(50, d);
  out[0] = W * 0.5 + X * s; out[1] = H * 0.5 - Y * s; out[2] = d; out[3] = s;
  return out;
}
function unproject(cam, sx, sy, W, H, out) {
  const s = cam.fov / cam.dist;
  const X = (sx - W * 0.5) / s, Y = (H * 0.5 - sy) / s;
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  const y = Y * cp, Zr = -Y * sp;
  const cy = Math.cos(cam.yaw), sy2 = Math.sin(cam.yaw);
  out[0] = X * cy + Zr * sy2 + cam.tx;
  out[1] = y + cam.ty;
  out[2] = -X * sy2 + Zr * cy + cam.tz;
  return out;
}

// ---- defensive-response regimes -------------------------------------------
// Forcing parameters. They scale terms the model already has; they do not
// introduce behaviour of their own.
const REGIMES = {
  rest:     { probe: 0, engage: 0.00, flee: 0, shell: 0.0, compress: 0.0, thermal: 0.00, align: 0.18 },
  detect:   { probe: 1, engage: 0.45, flee: 1, shell: 0.0, compress: 0.0, thermal: 0.00, align: 0.30 },
  converge: { probe: 1, engage: 0.85, flee: 0, shell: 0.6, compress: 0.2, thermal: 0.12, align: 0.52 },
  enclose:  { probe: 1, engage: 1.00, flee: 0, shell: 1.0, compress: 0.6, thermal: 0.62, align: 0.72 },
  peak:     { probe: 1, engage: 1.00, flee: 0, shell: 1.0, compress: 1.0, thermal: 1.00, align: 0.95 }
};
const NEUTRAL = { probe: 0, engage: 0, flee: 1, shell: 0, compress: 0, thermal: 0, align: null };

function lerpR(a, b, u) {
  return {
    probe: 1, flee: 0,
    engage: a.engage + (b.engage - a.engage) * u,
    shell: a.shell + (b.shell - a.shell) * u,
    compress: a.compress + (b.compress - a.compress) * u,
    thermal: a.thermal + (b.thermal - a.thermal) * u,
    align: a.align + (b.align - a.align) * u
  };
}
// Dwell time of the intruder walks the regimes continuously.
function arcRegime(e) {
  if (e < 0.08) return REGIMES.detect;
  const u = (e - 0.08) / 0.92;
  return u < 0.5
    ? lerpR(REGIMES.converge, REGIMES.enclose, u / 0.5)
    : lerpR(REGIMES.enclose, REGIMES.peak, (u - 0.5) / 0.5);
}

// core temperature of a defensive ball, degrees celsius
const T_AMBIENT = 35, T_TOP = 48;
const degC = T => T_AMBIENT + Math.max(0, Math.min(1, T)) * (T_TOP - T_AMBIENT);

// ---- helpers ---------------------------------------------------------------
const smoothstep = (a, b, x) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
const GOLD = 2.399963229728653;
function fibSlot(k, out) {
  const n = 512, z = 1 - 2 * ((k % n) + 0.5) / n;
  const r = Math.sqrt(Math.max(0, 1 - z * z)), a = GOLD * k;
  out[0] = r * Math.cos(a); out[1] = z; out[2] = r * Math.sin(a);
}

// ---- the system ------------------------------------------------------------
function createSystem(cfg = {}) {
  const N = cfg.n ?? 560;
  const R = cfg.worldR ?? 106;
  // Optional environmental domain (see hive.js). Absent => the open field the
  // earlier boards run in; present => containment, probe clamp and threshold
  // gating come from the cavity instead. Behaviour terms are untouched either way.
  const HIVE = cfg.hive || null;
  // nominal cruise, world units / s. cfg.speed scales the whole population's
  // preferred speed without touching any behaviour term (default 1 = unchanged).
  const SPD = 26 * (cfg.speed ?? 1);

  // --- state (contract) ---
  const px = new Float32Array(N), py = new Float32Array(N), pz = new Float32Array(N);
  const vx = new Float32Array(N), vy = new Float32Array(N), vz = new Float32Array(N);
  const phi = new Float32Array(N), spd = new Float32Array(N), meas = new Float32Array(N);
  const wag = new Float32Array(N), nb = new Float32Array(N);
  const temp = new Float32Array(N), def = new Float32Array(N);
  const role = new Uint8Array(N), tgt = new Int8Array(N);
  const trail = new Float32Array(N * TL * 3);

  // --- added state ---
  const v0 = new Float32Array(N);           // preferred speed, dispersed ±30%
  const tauW = new Float32Array(N);         // heading persistence time constant
  const oa = new Float32Array(N), ob = new Float32Array(N); // OU angular velocities
  const act = new Float32Array(N);          // threat activation
  const eng = new Float32Array(N);          // engagement 0..1 (hysteretic)
  const cmt = new Uint8Array(N);            // committed to the envelope
  const slot = new Float32Array(N * 3);     // persistent solid-angle slot
  const rdisp = new Float32Array(N);        // per-agent shell radius dispersion
  const phiRaw = new Float32Array(N);
  const cool = new Float32Array(N);         // dance cooldown, seconds
  const refr = new Float32Array(N);         // refractory after leaving the ball
  const trials = new Int16Array(N);
  const assist = new Float32Array(N);       // dwell next to a dancer

  // Two independent RNG streams: the visual layer must not consume the model's.
  let rs = 20250821 >>> 0, vs = 991137 >>> 0;
  const rnd = () => { rs = (rs * 1664525 + 1013904223) >>> 0; return rs / 4294967296; };
  const vrnd = () => { vs = (vs * 1664525 + 1013904223) >>> 0; return vs / 4294967296; };
  let gCache = null;
  const gauss = () => {                     // Box–Muller, clipped to ±3σ
    if (gCache !== null) { const g = gCache; gCache = null; return g; }
    const u = Math.max(1e-7, rnd()), w = rnd() * 6.283185307;
    const m = Math.sqrt(-2 * Math.log(u));
    gCache = Math.max(-3, Math.min(3, m * Math.sin(w)));
    return Math.max(-3, Math.min(3, m * Math.cos(w)));
  };

  const tmp = new Float32Array(3), tmp2 = new Float32Array(3), tmp3 = new Float32Array(3);

  // --- resource landscape: static, so ABC fitness is not circular ---
  const PATCH = [];
  for (let k = 0; k < 4; k++) {
    let x, y, z, d;
    do { x = rnd() * 2 - 1; y = rnd() * 2 - 1; z = rnd() * 2 - 1; d = x * x + y * y + z * z; }
    while (d > 1 || d < 0.05);
    const s = (R * 0.82) / Math.sqrt(d);
    PATCH.push({ x: x * s, y: y * s * 0.6, z: z * s, a: 0.55 + rnd() * 0.45, sg: 22 + rnd() * 12 });
  }
  function resource(x, y, z) {
    let f = 0;
    for (const p of PATCH) {
      const dx = x - p.x, dy = y - p.y, dz = z - p.z;
      f += p.a * Math.exp(-(dx * dx + dy * dy + dz * dz) / (2 * p.sg * p.sg));
    }
    return f;
  }

  // --- init ---
  for (let i = 0; i < N; i++) {
    let x, y, z, d;
    do { x = rnd() * 2 - 1; y = rnd() * 2 - 1; z = rnd() * 2 - 1; d = x * x + y * y + z * z; }
    while (d > 1 || d < 1e-4);
    const s = (R * 0.78 * Math.cbrt(rnd())) / Math.sqrt(d);
    if (HIVE) {   // the colony occupies the interior volume, concentrated toward
      // its middle rather than filling the cavity evenly: a uniform box gives
      // local densities too low for a defensive ball to read anywhere
      const bias = () => { const u = rnd() * 2 - 1; return u * Math.pow(Math.abs(u), 0.55); };
      px[i] = bias() * HIVE.hx * 0.70;
      py[i] = bias() * HIVE.hy * 0.62;
      pz[i] = HIVE.hz * 0.06 + bias() * HIVE.hz * 0.62;
    } else { px[i] = x * s; py[i] = y * s * 0.86; pz[i] = z * s; }

    // random initial heading — no field imprint, so alignment has to be earned
    let hx, hy, hz, hd;
    do { hx = rnd() * 2 - 1; hy = (rnd() * 2 - 1) * 0.92; hz = rnd() * 2 - 1; hd = hx * hx + hy * hy + hz * hz; }
    while (hd < 1e-4);
    hd = Math.sqrt(hd);
    v0[i] = SPD * (0.7 + rnd() * 0.6);
    tauW[i] = 0.55 + rnd() * 1.35;
    vx[i] = hx / hd * v0[i]; vy[i] = hy / hd * v0[i]; vz[i] = hz / hd * v0[i];
    spd[i] = v0[i];
    role[i] = rnd() < 0.14 ? 1 : 0;
    tgt[i] = -1;
    rdisp[i] = 0.70 + Math.cbrt(rnd()) * 0.30;   // radial fill: the ball is a packed volume, not a shell
    cool[i] = rnd() * 20;
    for (let k = 0; k < TL; k++) {
      const o = (i * TL + k) * 3; trail[o] = px[i]; trail[o + 1] = py[i]; trail[o + 2] = pz[i];
    }
  }

  // --- neighbour hash ---
  const CELL = 17, CS = R + 40, G = Math.ceil((2 * CS) / CELL), NC = G * G * G;
  const cnts = new Int32Array(NC + 1), starts = new Int32Array(NC + 1);
  const items = new Int32Array(N), cellOf = new Int32Array(N);
  const ci = (x, y, z) => {
    let a = ((x + CS) / CELL) | 0, b = ((y + CS) / CELL) | 0, c = ((z + CS) / CELL) | 0;
    a = a < 0 ? 0 : a >= G ? G - 1 : a; b = b < 0 ? 0 : b >= G ? G - 1 : b; c = c < 0 ? 0 : c >= G ? G - 1 : c;
    return (a * G + b) * G + c;
  };

  // --- measured direction field (what the streamlines integrate) ---
  const MG = 12, MCELL = (2 * CS) / MG, MN = MG * MG * MG;
  const mU = new Float32Array(MN * 3), mC = new Float32Array(MN);
  const accU = new Float32Array(MN * 3), accN = new Float32Array(MN);
  const mi = (x, y, z) => {
    let a = ((x + CS) / MCELL) | 0, b = ((y + CS) / MCELL) | 0, c = ((z + CS) / MCELL) | 0;
    a = a < 0 ? 0 : a >= MG ? MG - 1 : a; b = b < 0 ? 0 : b >= MG ? MG - 1 : b; c = c < 0 ? 0 : c >= MG ? MG - 1 : c;
    return (a * MG + b) * MG + c;
  };
  function measuredField(x, y, z, t, out) {
    const k = mi(x, y, z) * 3, c = mC[mi(x, y, z)];
    if (c > 0.02) {
      const m = SPD * (0.35 + 0.65 * c);
      out[0] = mU[k] * m; out[1] = mU[k + 1] * m; out[2] = mU[k + 2] * m;
    } else {
      field(x, y, z, t, out);
      out[0] *= 0.25; out[1] *= 0.25; out[2] *= 0.25;
    }
    return out;
  }

  // --- streamlines: seeded ON agents, integrating the measured field ---
  const SL = 46, SLN = 58;
  const slPts = new Float32Array(SL * SLN * 3);
  const slSpd = new Float32Array(SL * SLN);
  const slSeed = new Float32Array(SL * 3);
  let slNext = 0;
  const so = new Float32Array(3);
  function buildStreamline(k) {
    const i = Math.min(N - 1, (vrnd() * N) | 0);   // visual RNG stream
    let cx = px[i], cy = py[i], cz = pz[i];
    slSeed[k * 3] = cx; slSeed[k * 3 + 1] = cy; slSeed[k * 3 + 2] = cz;
    const h = 0.16;
    for (let s = 0; s < SLN / 2; s++) { rk4(cx, cy, cz, -h, sys.t, so, measuredField); cx = so[0]; cy = so[1]; cz = so[2]; }
    for (let s = 0; s < SLN; s++) {
      const o = (k * SLN + s) * 3;
      slPts[o] = cx; slPts[o + 1] = cy; slPts[o + 2] = cz;
      measuredField(cx, cy, cz, sys.t, tmp3);
      slSpd[k * SLN + s] = Math.hypot(tmp3[0], tmp3[1], tmp3[2]);
      rk4(cx, cy, cz, h, sys.t, so, measuredField); cx = so[0]; cy = so[1]; cz = so[2];
    }
  }

  // --- sites (ABC food sources) and dances ---
  const sites = [];          // {x,y,z,q,trials,pop}
  const SITE_MAX = 5, LIMIT = 220;   // LIMIT counted in ABC iterations (10 Hz) => ~22 s
  const dances = [];         // active dancers, capacity 3
  const FLOOR = 3, COOLDOWN = 26;

  // dance geometry: run length scales with normalised distance r
  const DANCE_PERIOD = 3.0;  // seconds per full circuit
  const RUN_MIN = 14, RUN_SPAN = 10, LOBE = 6.0;
  function danceGuide(D, s, out) {
    // s in [0,1) over the circuit: run, left loop, run, right loop
    const L = D.L, b = LOBE, a = L * 0.5;
    const pr = 2 * L, pl = 2 * (Math.PI * 0.5 * (1.5 * (a + b) - Math.sqrt(a * b)));
    const total = pr + pl;
    let d = s * total, u = 0, side = 1, seg = 0;
    if (d < L) { seg = 0; u = d / L; }
    else if (d < L + pl * 0.5) { seg = 1; u = (d - L) / (pl * 0.5); side = 1; }
    else if (d < 2 * L + pl * 0.5) { seg = 2; u = (d - L - pl * 0.5) / L; }
    else { seg = 3; u = (d - 2 * L - pl * 0.5) / (pl * 0.5); side = -1; }
    let al, cr;
    if (seg === 0 || seg === 2) { al = -a + 2 * a * u; cr = 0; }
    else { const th = Math.PI * u; al = a * Math.cos(th); cr = side * b * Math.sin(th); }
    out[0] = D.cx + D.ax * al + D.bx * cr;
    out[1] = D.cy + D.ay * al + D.by * cr;
    out[2] = D.cz + D.az * al + D.bz * cr;
    out[3] = seg === 0 || seg === 2 ? 1 : 0;   // 1 = on a run segment
    return out;
  }
  const gpt = new Float32Array(4);

  const probe = { on: 0, x: 0, y: 0, z: 0, str: 0, auto: 1, lastInput: -1e9 };

  const sys = {
    N, R, SPD, px, py, pz, vx, vy, vz, phi, spd, meas, wag, nb, role, tgt, trail,
    temp, def, sites, probe, TL, SL, SLN, slPts, slSpd, slSeed,
    act, eng, cmt, slot, dances, PATCH, resource, measuredField,
    t: 0, frame: 0, head: 0, phiG: 0.4, alignW: 1, perturb: 0,
    tempMax: 0, tempMean: 0, dwell: 0, pointer: 0, shellR: 34,
    dose: 0, neutralised: false, neutralFor: 0,
    coverage: 0, closure: 0,
    probeHold: 2.5,                       // seconds a set stimulus stays live
    committed: 0, maxDisp: 0, simplexDrift: 0, popErr: 0,
    regime: cfg.regime || null, cycle: cfg.cycle || null,
    probeAnchor: cfg.probeAnchor || [0, 0, 0],
    anchorAt: cfg.anchorAt || null,
    hive: HIVE, hiveGate: 1,
    setProbe(x, y, z) {
      if (HIVE) {
        // the probe may legitimately sit OUTSIDE the cavity — that is the point
        const m = 1.2;
        x = Math.max(-HIVE.hx * m, Math.min(HIVE.hx * m, x));
        y = Math.max(-HIVE.hy * m, Math.min(HIVE.hy * m, y));
        z = Math.max(-HIVE.hz * 1.9, Math.min(HIVE.hz * m, z));
        probe.x = x; probe.y = y; probe.z = z;
        probe.on = 1; probe.auto = 0; probe.lastInput = sys.t; sys.pointer = sys.probeHold;
        return;
      }
      // keep the intruder inside the field: an unprojected pointer can land far
      // outside it, which both breaks the response and pans a camera into void
      const L = Math.hypot(x, y, z), M = R * 0.82;
      if (L > M) { const k = M / L; x *= k; y *= k; z *= k; }
      probe.x = x; probe.y = y; probe.z = z;
      probe.on = 1; probe.auto = 0; probe.lastInput = sys.t; sys.pointer = sys.probeHold;
    },
    // pin a stationary stimulus indefinitely (an intruder that does not flee)
    pinStimulus(x, y, z) { sys.probeHold = 1e9; sys.setProbe(x, y, z); },
    releaseProbe() {
      probe.on = 0; sys.pointer = 0; sys.probeHold = 2.5;
      sys.dose = 0; sys.neutralised = false; sys.neutralFor = 0;
    },
    step
  };

  for (let k = 0; k < SL; k++) buildStreamline(k);

  // ==== integration ========================================================
  let sampleAcc = 0, slotSeq = 0;

  function substep(dt, RG) {
    // --- neighbour hash rebuild ---
    cnts.fill(0);
    for (let i = 0; i < N; i++) { const c = ci(px[i], py[i], pz[i]); cellOf[i] = c; cnts[c]++; }
    let s0 = 0;
    for (let c = 0; c < NC; c++) { starts[c] = s0; s0 += cnts[c]; }
    starts[NC] = s0;
    for (let c = 0; c < NC; c++) cnts[c] = starts[c];
    for (let i = 0; i < N; i++) items[cnts[cellOf[i]]++] = i;

    const RN = 17, RN2 = RN * RN, SEP = 7.4, SEP2 = SEP * SEP;
    const SIG = 26;
    accU.fill(0); accN.fill(0);

    let phiSum = 0, tSum = 0, tMax = 0, committed = 0, maxDisp = 0, drift = 0, onShell = 0;

    for (let i = 0; i < N; i++) {
      const x = px[i], y = py[i], z = pz[i];
      let cxs = 0, cys = 0, czs = 0, sx = 0, sy = 0, sz = 0;
      let ux = 0, uy = 0, uz = 0, cnt = 0, maxNbAct = 0;
      let danceNear = -1;

      const a0 = ((x + CS) / CELL) | 0, b0 = ((y + CS) / CELL) | 0, c0 = ((z + CS) / CELL) | 0;
      for (let da = -1; da <= 1; da++) {
        const a = a0 + da; if (a < 0 || a >= G) continue;
        for (let db = -1; db <= 1; db++) {
          const b = b0 + db; if (b < 0 || b >= G) continue;
          for (let dc = -1; dc <= 1; dc++) {
            const c = c0 + dc; if (c < 0 || c >= G) continue;
            const cell = (a * G + b) * G + c;
            for (let p = starts[cell], e = starts[cell + 1]; p < e; p++) {
              const j = items[p]; if (j === i) continue;
              const dx = px[j] - x, dy = py[j] - y, dz = pz[j] - z;
              const d2 = dx * dx + dy * dy + dz * dz;
              if (d2 > RN2) continue;
              cnt++;
              cxs += px[j]; cys += py[j]; czs += pz[j];
              const L = spd[j] || 1;
              ux += vx[j] / L; uy += vy[j] / L; uz += vz[j] / L;
              if (d2 < SEP2) {
                const inv = 1 / Math.max(1.2, Math.sqrt(d2));
                sx -= dx * inv; sy -= dy * inv; sz -= dz * inv;
              }
              if (act[j] > maxNbAct) maxNbAct = act[j];
              if (wag[j] > 0.5 && d2 < 34 * 34) danceNear = j;
            }
          }
        }
      }
      nb[i] = cnt;

      // --- phi_i: measured, damped, gated, filtered ---
      const raw = cnt ? Math.hypot(ux, uy, uz) / cnt : 0;
      const damped = raw * Math.min(1, cnt / 4);
      const gated = smoothstep(0.10, 0.70, damped);
      phiRaw[i] = damped;
      phi[i] += (gated - phi[i]) * Math.min(1, dt / 0.35);
      phiSum += phi[i];

      // --- threat activation: local stimulus + neighbour-to-neighbour jumps ---
      let stim = 0, dP = 1e9;
      if (probe.str > 0.01 && RG.probe) {
        const BA0 = sys.ballAt;
        const cx0 = BA0 ? BA0[i * 3] : probe.x;
        const cy0 = BA0 ? BA0[i * 3 + 1] : probe.y;
        const cz0 = BA0 ? BA0[i * 3 + 2] : probe.z;
        const dx = x - cx0, dy = y - cy0, dz = z - cz0;
        const d2 = dx * dx + dy * dy + dz * dz;
        dP = Math.sqrt(d2);
        stim = Math.exp(-d2 / (2 * SIG * SIG)) * probe.str;
        meas[i] = Math.max(meas[i], stim);
      }
      act[i] += (stim * 2.6 - act[i] * 1.0) * dt;
      const jump = Math.max(0, maxNbAct * 0.88 - act[i]);
      act[i] += jump * dt * 1.9 * RG.engage * Math.exp(-dP / 95);
      if (act[i] < 0) act[i] = 0; else if (act[i] > 1.4) act[i] = 1.4;
      meas[i] *= Math.exp(-dt / 1.15);
      if (refr[i] > 0) refr[i] = Math.max(0, refr[i] - dt);

      // --- commitment with hysteresis, a recruitment envelope and turnover ---
      const canCommit = RG.shell > 0.05;
      if (!cmt[i]) {
        if (canCommit && act[i] > 0.42 && dP < 115 && refr[i] <= 0) {
          cmt[i] = 1;
          fibSlot(slotSeq++, tmp);
          slot[i * 3] = tmp[0]; slot[i * 3 + 1] = tmp[1]; slot[i * 3 + 2] = tmp[2];
        }
      } else {
        const pTurn = 1 - Math.exp(-Math.min(CLAMP.lambdaDt, 0.055 * dt));
        if (!canCommit || act[i] < 0.22 || rnd() < pTurn) { cmt[i] = 0; refr[i] = 4.5; }
      }
      const enclNow = cmt[i] && dP < 1e8
        ? 1 - smoothstep(Math.max(5, sys.shellR * 0.85) * 0.35, Math.max(5, sys.shellR * 0.85), Math.abs(dP - sys.shellR))
        : 0;
      eng[i] += ((cmt[i] ? 1 : 0) - eng[i]) * Math.min(1, dt * (cmt[i] ? 3.0 : 1.4));
      def[i] = eng[i];
      if (cmt[i]) { committed++; if (enclNow > 0.5) onShell++; }

      // --- behaviour simplex: independent / collective / response ---
      // Alarm is a response of its own, not only a precursor to commitment: an
      // alerted agent breaks off what it was doing while the threat is loose.
      const alarm = RG.flee ? Math.min(0.88, act[i] * 1.25) : 0;
      let wR = Math.max(eng[i], alarm, wag[i] > 0.5 ? 1 : 0, tgt[i] >= 0 ? 0.42 : 0);
      let wC = 0.24 * smoothstep(0, 4, cnt) * (1 - wR);
      let wI = 1 - wR - wC;
      if (wI < 0) wI = 0;
      const wsum = wI + wC + wR;
      drift = Math.max(drift, Math.abs(wsum - 1));
      wI /= wsum; wC /= wsum; wR /= wsum;

      // --- desired heading ---
      const cs = spd[i] || 1;
      let hx = vx[i] / cs, hy = vy[i] / cs, hz = vz[i] / cs;
      let dxw = hx * wI, dyw = hy * wI, dzw = hz * wI;

      if (wC > 0 && cnt) {
        const al = Math.hypot(ux, uy, uz) || 1;
        const cl = Math.hypot(cxs / cnt - x, cys / cnt - y, czs / cnt - z) || 1;
        const sl = Math.hypot(sx, sy, sz) || 1;
        dxw += wC * (0.28 * ux / al + 0.20 * (cxs / cnt - x) / cl + 0.58 * sx / sl);
        dyw += wC * (0.28 * uy / al + 0.20 * (cys / cnt - y) / cl + 0.58 * sy / sl);
        dzw += wC * (0.28 * uz / al + 0.20 * (czs / cnt - z) / cl + 0.58 * sz / sl);
      }

      let dancing = false, onRun = false;
      if (wR > 0) {
        if (wag[i] > 0.5 && sys.danceOf[i]) {
          // chase a guide point 0.25 s ahead on the figure-of-eight
          const D = sys.danceOf[i];
          D.s = (D.s + dt / DANCE_PERIOD) % 1;
          danceGuide(D, (D.s + 0.25 / DANCE_PERIOD) % 1, gpt);
          const gx = gpt[0] - x, gy = gpt[1] - y, gz = gpt[2] - z;
          const gl = Math.hypot(gx, gy, gz) || 1;
          dxw += wR * gx / gl; dyw += wR * gy / gl; dzw += wR * gz / gl;
          dancing = true; onRun = gpt[3] > 0.5;
        } else if (cmt[i]) {
          // A slot inside the ball, not on its surface: the radial factor fills the
          // volume so the cluster reads as a packed mass instead of a hollow sphere.
          const rs2 = sys.shellR * rdisp[i] * (1 + 0.04 * Math.sin(sys.t * 0.9 + i));
          const BA = sys.ballAt;
          const bx = BA ? BA[i * 3] : probe.x;
          const by = BA ? BA[i * 3 + 1] : probe.y;
          const bz = BA ? BA[i * 3 + 2] : probe.z;
          const tx = bx + slot[i * 3] * rs2 - x;
          const ty = by + slot[i * 3 + 1] * rs2 - y;
          const tz = bz + slot[i * 3 + 2] * rs2 - z;
          const tl = Math.hypot(tx, ty, tz) || 1;
          dxw += wR * tx / tl; dyw += wR * ty / tl; dzw += wR * tz / tl;
        } else if (RG.flee && (stim > 0.02 || act[i] > 0.10)) {
          // Close in, the intruder is fled. Further out the same alarm turns the
          // agent to face it: vigilance, not flight.
          const fx = x - probe.x, fy = y - probe.y, fz = z - probe.z;
          const fl = Math.hypot(fx, fy, fz) || 1;
          const sgn = dP < SIG * 2.1 ? 1 : -0.55;
          dxw += wR * sgn * fx / fl; dyw += wR * sgn * fy / fl; dzw += wR * sgn * fz / fl;
        } else if (tgt[i] >= 0 && sites[tgt[i]]) {
          const st = sites[tgt[i]];
          const tx = st.x - x, ty = st.y - y, tz = st.z - z;
          const tl = Math.hypot(tx, ty, tz) || 1;
          dxw += wR * tx / tl; dyw += wR * ty / tl; dzw += wR * tz / tl;
        }
      }

      // weak ambient drift + inward containment
      field(x, y, z, sys.t, tmp);
      const fl2 = Math.hypot(tmp[0], tmp[1], tmp[2]) || 1;
      const amb = dancing ? 0 : cmt[i] ? 0.04 : 0.16;
      dxw += amb * tmp[0] / fl2; dyw += amb * tmp[1] / fl2; dzw += amb * tmp[2] / fl2;
      const rr = Math.hypot(x, y, z);
      if (HIVE) {
        if (!dancing) {   // cavity containment: the colony stays in the interior
          const bx = HIVE.hx * 0.88, by = HIVE.hy * 0.84, bz = HIVE.hz * 0.88;
          if (x > bx) dxw -= smoothstep(bx, HIVE.hx, x) * 1.7;
          else if (x < -bx) dxw += smoothstep(bx, HIVE.hx, -x) * 1.7;
          if (y > by) dyw -= smoothstep(by, HIVE.hy, y) * 1.9;
          else if (y < -by) dyw += smoothstep(by, HIVE.hy, -y) * 1.9;
          if (z > bz) dzw -= smoothstep(bz, HIVE.hz, z) * 1.7;
          else if (z < -bz) dzw += smoothstep(bz, HIVE.hz, -z) * 1.7;
        }
      } else if (rr > R * 0.86 && !dancing) {
        const k2 = smoothstep(R * 0.86, R * 1.05, rr) * 1.5;
        dxw -= k2 * x / rr; dyw -= k2 * y / rr; dzw -= k2 * z / rr;
      }

      let dl = Math.hypot(dxw, dyw, dzw);
      if (dl < 1e-5) { dxw = hx; dyw = hy; dzw = hz; dl = 1; }
      dxw /= dl; dyw /= dl; dzw /= dl;

      // --- rotate the heading toward the desired direction, rate-limited ---
      const turnMax = dancing ? CLAMP.turnMaxDancing : cmt[i] ? CLAMP.turnMaxCommitted : CLAMP.turnMax;
      let dot = hx * dxw + hy * dyw + hz * dzw;
      dot = dot > 1 ? 1 : dot < -1 ? -1 : dot;
      const ang = Math.acos(dot), maxA = turnMax * dt;
      if (ang > 1e-4) {
        const a2 = Math.min(ang, maxA), sA = Math.sin(ang);
        // slerp h -> d by a2
        const w1 = Math.sin(ang - a2) / sA, w2 = Math.sin(a2) / sA;
        hx = hx * w1 + dxw * w2; hy = hy * w1 + dyw * w2; hz = hz * w1 + dzw * w2;
        const hl = Math.hypot(hx, hy, hz) || 1; hx /= hl; hy /= hl; hz /= hl;
      }

      // --- OU angular velocity: persistence, not a per-frame jitter ---
      const tau = tauW[i];
      const sg = (dancing ? (onRun ? 0.75 : 0.3) : cmt[i] ? 2.2 + RG.compress * 2.6 : 2.0);
      const kdec = Math.exp(-dt / tau), noise = Math.sqrt(1 - kdec * kdec) * sg;
      oa[i] = oa[i] * kdec + gauss() * noise;
      ob[i] = ob[i] * kdec + gauss() * noise;
      if (oa[i] > CLAMP.omegaMax) oa[i] = CLAMP.omegaMax; else if (oa[i] < -CLAMP.omegaMax) oa[i] = -CLAMP.omegaMax;
      if (ob[i] > CLAMP.omegaMax) ob[i] = CLAMP.omegaMax; else if (ob[i] < -CLAMP.omegaMax) ob[i] = -CLAMP.omegaMax;
      // two perpendicular axes from the heading
      let axx = -hz, axy = 0, axz = hx;
      let axl = Math.hypot(axx, axy, axz);
      if (axl < 1e-4) { axx = 1; axy = 0; axz = 0; axl = 1; }
      axx /= axl; axy /= axl; axz /= axl;
      const bxx = hy * axz - hz * axy, bxy = hz * axx - hx * axz, bxz = hx * axy - hy * axx;
      hx += (axx * oa[i] + bxx * ob[i]) * dt;
      hy += (axy * oa[i] + bxy * ob[i]) * dt;
      hz += (axz * oa[i] + bxz * ob[i]) * dt;
      let hl2 = Math.hypot(hx, hy, hz) || 1; hx /= hl2; hy /= hl2; hz /= hl2;

      // --- elevation clamp; altitude preference suppressed under commitment ---
      const elMax = (cmt[i] || dancing) ? CLAMP.elMaxCommitted : CLAMP.elMax;
      const sMax = Math.sin(elMax);
      if (hy > sMax || hy < -sMax) {
        const want = hy > 0 ? sMax : -sMax;
        const horiz = Math.hypot(hx, hz) || 1e-4;
        const scale = Math.sqrt(Math.max(0, 1 - want * want)) / horiz;
        hx *= scale; hz *= scale; hy = want;
      }

      // --- speed: mean-reverting to v0_effective, clamped ---
      // INTENSIFY raises internal agitation, not translation: members of the
      // ball slow down and vibrate, which is what produces the heat
      // an incoming bee dashes; only one already on the shell slows to vibrate,
      // so convergence is quick and the compression stays where it belongs
      const v0ef = v0[i] * (1 - 0.50 * RG.compress * eng[i] * enclNow)
        * (cmt[i] && enclNow < 0.4 ? 1.55 : 1) * (dancing ? 1.35 : 1) * (1 + 0.40 * alarm);
      const kv = Math.min(1, dt / 0.45);
      let s2 = spd[i] + (v0ef - spd[i]) * kv + gauss() * 1.7 * Math.sqrt(dt);
      const lo = CLAMP.speedLo * v0[i], hi = CLAMP.speedHi * v0ef;
      if (dancing) { const floor = 30; if (s2 < floor) s2 = floor; }
      if (s2 < lo) s2 = lo; else if (s2 > hi) s2 = hi;
      spd[i] = s2;

      vx[i] = hx * s2; vy[i] = hy * s2; vz[i] = hz * s2;

      // --- integrate position: velocity only, no teleportation ---
      const dxp = vx[i] * dt, dyp = vy[i] * dt, dzp = vz[i] * dt;
      const disp = Math.hypot(dxp, dyp, dzp);
      if (disp > maxDisp) maxDisp = disp;
      px[i] += dxp; py[i] += dyp; pz[i] += dzp;

      // --- lumped thermal balance ---
      // Production requires the agent to be ON the envelope, not merely
      // committed to it: one still flying in produces nothing. Neighbours
      // insulate what it makes; isolation sheds it.
      let encl = 0;
      if (cmt[i] && dP < 1e8) {
        const tol = Math.max(5, sys.shellR * 0.85);
        encl = 1 - smoothstep(tol * 0.35, tol, Math.abs(dP - sys.shellR));
      }
      // Production and insulation are tuned so the mid arc actually crosses
      // HEAT_ON: a loose envelope has fewer neighbours per agent than a
      // compressed one, and if production scales linearly with that count the
      // whole rise stays sub-threshold until the critical band. The count term
      // is therefore softened — it modulates production, it does not gate it.
      // The bees surround FIRST and vibrate SECOND. Production is gated by the
      // measured closure of the envelope — the share of committed agents actually
      // on the shell — so no agent turns warm while the ball is still forming.
      const prod = 0.66 * RG.thermal * eng[i] * encl * sys.closure
        * (0.7 + 0.4 * Math.min(1.4, cnt / 12));
      // insulation comes from the ball, not from the local count: an agent on the
      // shell is jacketed by the mass behind it even where the shell is thin, so
      // the sparse side keeps its heat and the hot mass stays centred on the threat
      const loss = 0.60 * temp[i] * (1 + (cmt[i] ? 0.45 : 2.2) / (1 + cnt));
      temp[i] += (prod - loss) * dt;
      if (temp[i] < 0) temp[i] = 0; else if (temp[i] > 1.15) temp[i] = 1.15;
      tSum += temp[i]; if (temp[i] > tMax) tMax = temp[i];

      // --- measured direction field accumulation ---
      const gi = mi(px[i], py[i], pz[i]);
      accU[gi * 3] += hx; accU[gi * 3 + 1] += hy; accU[gi * 3 + 2] += hz;
      accN[gi] += 1;

      // --- assistance: dwell next to a dancer raises departure probability ---
      if (danceNear >= 0 && tgt[i] < 0 && !cmt[i]) {
        assist[i] += dt;
        if (assist[i] > 0.35) {
          const src = tgt[danceNear];
          const pGo = 1 - Math.exp(-Math.min(CLAMP.lambdaDt, 5.0 * dt));
          if (src >= 0 && rnd() < pGo) { tgt[i] = src; assist[i] = 0; }
        }
      } else assist[i] = Math.max(0, assist[i] - dt * 0.35);

      wag[i] = Math.max(0, wag[i] - dt * (sys.danceOf[i] ? 0 : 0.9));
      cool[i] = Math.max(0, cool[i] - dt);
    }

    sys.committed = committed;
    // closure: 0 while the swarm is still converging, 1 once the shell is manned.
    // Smoothed, then ramped — below 45% covered there is no vibration at all.
    const cov = committed > 6 ? onShell / committed : 0;
    sys.coverage += (cov - sys.coverage) * Math.min(1, dt / 0.32);
    sys.closure = smoothstep(0.32, 0.58, sys.coverage);
    sys.maxDisp = maxDisp;
    sys.simplexDrift = drift;
    sys.phiG += (phiSum / N - sys.phiG) * Math.min(1, dt / 0.9);
    sys.tempMean = tSum / N; sys.tempMax = tMax;

    // --- smooth the measured field (EMA) ---
    for (let c = 0; c < MN; c++) {
      const n2 = accN[c];
      let ex = 0, ey = 0, ez = 0, coh = 0;
      if (n2 > 0) {
        ex = accU[c * 3] / n2; ey = accU[c * 3 + 1] / n2; ez = accU[c * 3 + 2] / n2;
        coh = Math.hypot(ex, ey, ez);
        if (coh > 1e-4) { ex /= coh; ey /= coh; ez /= coh; }
      }
      const al = Math.min(1, dt / 0.5);
      mU[c * 3] += (ex - mU[c * 3]) * al;
      mU[c * 3 + 1] += (ey - mU[c * 3 + 1]) * al;
      mU[c * 3 + 2] += (ez - mU[c * 3 + 2]) * al;
      mC[c] += (coh - mC[c]) * al;
      const ml = Math.hypot(mU[c * 3], mU[c * 3 + 1], mU[c * 3 + 2]);
      if (ml > 1e-4) { mU[c * 3] /= ml; mU[c * 3 + 1] /= ml; mU[c * 3 + 2] /= ml; }
    }
  }

  sys.danceOf = new Array(N).fill(null);

  // --- ABC search + collective decision, on a slower cadence ---
  let abcAcc = 0;
  function abc(dt) {
    // employed bees probe a neighbourhood of their site; onlookers recruit;
    // scouts explore; LIMIT trials abandons.
    for (let s = sites.length - 1; s >= 0; s--) {
      const st = sites[s];
      st.pop = 0;
    }
    for (let i = 0; i < N; i++) if (tgt[i] >= 0 && sites[tgt[i]]) sites[tgt[i]].pop++;

    for (let s = sites.length - 1; s >= 0; s--) {
      const st = sites[s];
      // employed: try a neighbour solution
      const nx = st.x + (rnd() * 2 - 1) * 5, ny = st.y + (rnd() * 2 - 1) * 3.4, nz = st.z + (rnd() * 2 - 1) * 5;
      const q2 = resource(nx, ny, nz);
      if (q2 > st.q) { st.x = nx; st.y = ny; st.z = nz; st.q = q2; st.trials = 0; }
      else st.trials++;
      if (st.trials > LIMIT) {                     // abandonment
        sites.splice(s, 1);
        for (let i = 0; i < N; i++) {
          if (tgt[i] === s) tgt[i] = -1;
          else if (tgt[i] > s) tgt[i]--;
        }
        for (const D of dances) {
          if (D.site === s) D.dead = true;
          else if (D.site > s) D.site--;
        }
      }
    }

    // scouts
    let fitSum = 0;
    for (const st of sites) fitSum += st.q;
    for (let i = 0; i < N; i++) {
      if (role[i] !== 1 || tgt[i] >= 0 || cmt[i]) continue;
      const q = resource(px[i], py[i], pz[i]);
      if (q > 0.45 && sites.length < SITE_MAX) {
        let near = false;
        for (const st of sites) if (Math.hypot(st.x - px[i], st.y - py[i], st.z - pz[i]) < 24) near = true;
        if (!near) {
          sites.push({ x: px[i], y: py[i], z: pz[i], q, trials: 0, pop: 0 });
          tgt[i] = sites.length - 1;
        }
      }
    }

    // onlookers: fitness-proportional recruitment with cross-inhibition
    for (let i = 0; i < N; i++) {
      if (role[i] === 1 || cmt[i] || sites.length === 0) continue;
      if (tgt[i] >= 0) {
        const st = sites[tgt[i]];
        const other = N - st.pop;
        const lam = 0.02 + 0.05 * (other / N);      // cross-inhibition
        if (rnd() < 1 - Math.exp(-Math.min(CLAMP.lambdaDt, lam * dt))) tgt[i] = -1;
        continue;
      }
      if (rnd() > 0.02) continue;
      let r = rnd() * (fitSum || 1), k = 0;
      while (k < sites.length - 1 && r > sites[k].q) { r -= sites[k].q; k++; }
      const lam = 0.035 * sites[k].q;
      if (rnd() < 1 - Math.exp(-Math.min(CLAMP.lambdaDt, lam * dt))) tgt[i] = k;
    }

    // --- dance floor: rare, capped, cooldown-gated ---
    for (let d = dances.length - 1; d >= 0; d--) {
      const D = dances[d];
      D.ttl -= dt;
      if (D.ttl <= 0 || D.dead || !sites[D.site]) {
        sys.danceOf[D.i] = null; wag[D.i] = 0.9; cool[D.i] = COOLDOWN;
        dances.splice(d, 1);
      }
    }
    if (dances.length < FLOOR) {
      for (let i = 0; i < N; i++) {
        if (dances.length >= FLOOR) break;
        if (cmt[i] || sys.danceOf[i] || cool[i] > 0) continue;
        const k = tgt[i]; if (k < 0 || !sites[k]) continue;
        const st = sites[k];
        const dist = Math.hypot(st.x - px[i], st.y - py[i], st.z - pz[i]);
        if (dist > 26) continue;                    // announce on arrival
        if (rnd() > 1 - Math.exp(-Math.min(CLAMP.lambdaDt, 0.5 * dt))) continue;
        // message M = (r, theta, q)
        let ax = st.x - px[i], ay = st.y - py[i], az = st.z - pz[i];
        const al = Math.hypot(ax, ay, az) || 1;
        ax /= al; ay /= al; az /= al;
        // a perpendicular for the loop plane
        let bx = -az, by = 0, bz = ax;
        let bl = Math.hypot(bx, by, bz);
        if (bl < 1e-4) { bx = 1; by = 0; bz = 0; bl = 1; }
        bx /= bl; by /= bl; bz /= bl;
        const rNorm = Math.min(1, al / (R * 0.9));
        const D = {
          i, site: k, s: 0, ttl: 6.5 + rnd() * 3.5, dead: false,
          L: RUN_MIN + RUN_SPAN * rNorm, q: st.q, r: rNorm,
          ax, ay, az, bx, by, bz,
          cx: px[i], cy: py[i], cz: pz[i],
          thx: ax, thy: ay, thz: az
        };
        dances.push(D);
        sys.danceOf[i] = D;
        wag[i] = 1;
      }
    }
  }

  // ==== public step: fixed substeps, time-based trace sampling =============
  function step(dtIn) {
    let remain = Math.min(dtIn, SUBSTEP * MAX_SUBSTEPS);
    const pinned = sys.cycle ? sys.cycle(sys.t) : sys.regime;
    if (sys.anchorAt) sys.probeAnchor = sys.anchorAt(sys.t);
    if (sys.pointer > 0) sys.pointer = Math.max(0, sys.pointer - dtIn);
    const pointing = sys.pointer > 0;

    // Sustained exposure at the critical band neutralises the intruder. The ball
    // then has nothing left to hold and disperses, even with the cursor still
    // in the field; after a pause the field re-arms.
    if (sys.neutralFor > 0) {
      sys.neutralFor = Math.max(0, sys.neutralFor - dtIn);
      if (sys.neutralFor === 0) { sys.dose = 0; sys.neutralised = false; }
    } else {
      if (sys.tempMax > 0.82) sys.dose += dtIn / 1.6;
      else sys.dose = Math.max(0, sys.dose - dtIn / 5);
      if (sys.dose >= 1) { sys.neutralised = true; sys.neutralFor = 5; }
    }

    if (pinned) {
      probe.auto = 0;
      probe.on = pointing ? 1 : pinned.probe;
      if (!pointing) { probe.x = sys.probeAnchor[0]; probe.y = sys.probeAnchor[1]; probe.z = sys.probeAnchor[2]; }
    } else if (probe.auto || (sys.t - probe.lastInput > 5.5 && !pointing)) {
      probe.auto = 1;
      probe.on = (sys.t % 17) < 9.5 ? 1 : 0;
      // the target slows to a near halt as the ball closes: a Lissajous
      // stimulus cannot be enclosed
      const a = sys.autoPhase = (sys.autoPhase || 0) + dtIn * 0.21 * (1 - 0.94 * sys.dwell);
      if (HIVE) {
        const p = HIVE.autoPath(a);
        probe.x = p[0]; probe.y = p[1]; probe.z = p[2];
      } else {
        probe.x = Math.sin(a * 1.0) * R * 0.5;
        probe.y = Math.sin(a * 1.37 + 1.2) * R * 0.24;
        probe.z = Math.cos(a * 0.83) * R * 0.5;
      }
    } else {
      probe.on = pointing ? 1 : 0;
    }

    sys.dwell += probe.on ? dtIn / 1.25 : -dtIn / 1.5;
    if (sys.dwell < 0) sys.dwell = 0; else if (sys.dwell > 1) sys.dwell = 1;

    let RG = pointing ? arcRegime(sys.dwell)
      : pinned ? ((pinned.thermal === 0 && sys.dwell > 0.05) ? arcRegime(sys.dwell) : pinned)
        : (sys.dwell > 0.01 ? arcRegime(sys.dwell) : NEUTRAL);

    // ENVIRONMENTAL GATING. Nothing about the response changes; what changes is
    // whether the colony can answer at all. Outside: no defensive sequence.
    // At the aperture: local detection, never enclosure. Inside: the full arc.
    if (HIVE) {
      const g = HIVE.gate(probe.x, probe.y, probe.z);
      sys.hiveGate = g;
      if (g < 0.02) {
        probe.on = 0;
        RG = NEUTRAL;
        sys.dwell = Math.max(0, sys.dwell - dtIn / 1.6);
      } else if (g < 0.999) {
        const inner = Math.max(0, (g - 0.6) / 0.4);
        RG = {
          probe: RG.probe, flee: RG.flee, align: RG.align,
          engage: RG.engage * Math.min(1, g * 1.35),
          shell: RG.shell * inner, compress: RG.compress * inner, thermal: RG.thermal * inner
        };
      }
    }

    if (sys.neutralised) { probe.on = 0; sys.dwell = 0; RG = REGIMES.rest; }

    // Shell radius contracts with compression, but must also hold the population
    // that has committed to it: agents sit on a spherical shell, so the radius
    // needed grows as sqrt(n). A fixed radius left most of a large ball off the
    // shell, where it produces no heat, and the core temperature plateaued.
    const nOnShell = Math.max(12, sys.committed || 12);
    const fit = Math.sqrt(nOnShell / 150);
    sys.shellR = (18 - 14 * RG.compress) * Math.max(1, Math.min(1.15, fit)) * (sys.shellK ?? 1);
    probe.str += ((probe.on ? 1 : 0) - probe.str) * (1 - Math.exp(-dtIn / (probe.on ? 0.08 : 0.95)));
    sys.perturb = probe.str;

    while (remain > 1e-6) {
      const h = Math.min(SUBSTEP, remain);
      remain -= h;
      sys.t += h; sys.frame++;
      substep(h, RG);

      abcAcc += h;
      if (abcAcc >= 0.1) { abc(abcAcc); abcAcc = 0; }

      sampleAcc += h;
      if (sampleAcc >= SAMPLE_DT) {
        sampleAcc -= SAMPLE_DT;
        sys.head = (sys.head + 1) % TL;
        for (let i = 0; i < N; i++) {
          const o = (i * TL + sys.head) * 3;
          trail[o] = px[i]; trail[o + 1] = py[i]; trail[o + 2] = pz[i];
        }
      }
    }

    // population invariant: u + sum(x_k) = 1, and no dangling commitment labels
    let cSum = 0, bad = 0;
    for (let i = 0; i < N; i++) {
      const k = tgt[i];
      if (k >= 0) { if (k < sites.length) cSum++; else bad++; }
    }
    sys.popErr = Math.abs(((N - cSum - bad) + cSum) / N - 1);

    buildStreamline(slNext); slNext = (slNext + 1) % SL;
    buildStreamline(slNext); slNext = (slNext + 1) % SL;
  }

  return sys;
}

// ---- marching squares ------------------------------------------------------
function isolines(buf, gw, gh, level, segs) {
  segs.length = 0;
  const at = (i, j) => buf[j * gw + i];
  for (let j = 0; j < gh - 1; j++) {
    for (let i = 0; i < gw - 1; i++) {
      const a = at(i, j), b = at(i + 1, j), c = at(i + 1, j + 1), d = at(i, j + 1);
      const pts = [];
      if ((a < level) !== (b < level)) pts.push([i + (level - a) / (b - a), j]);
      if ((b < level) !== (c < level)) pts.push([i + 1, j + (level - b) / (c - b)]);
      if ((c < level) !== (d < level)) pts.push([i + 1 - (level - c) / (d - c), j + 1]);
      if ((d < level) !== (a < level)) pts.push([i, j + 1 - (level - d) / (a - d)]);
      if (pts.length === 2) segs.push(pts[0], pts[1]);
      else if (pts.length === 4) { segs.push(pts[0], pts[1]); segs.push(pts[2], pts[3]); }
    }
  }
  return segs;
}

return { TL, SAMPLE_DT, SUBSTEP, MAX_SUBSTEPS, ANGLES, SQ2, CLAMP, FCC_DIRS, RD_FACES, field, rk4, makeCam, project, unproject, REGIMES, arcRegime, T_AMBIENT, degC, createSystem, isolines };
})();

// ===== theme.js =====
__M["theme.js"] = (() => {
// THEME — the canvas half of the role layer, generated from material-theme.json
// (Material Theme Builder export, seed #007D76). Same role names as the
// CSS custom properties in the page, so a colour has ONE definition per mode.
const THEMES = {
  dark: {
    selected:   [50,75,73],
    stage:      [14,21,20],
    backing:    [22,29,28],
    outline:    [137,147,145],
    lit:        [221,228,226],
    ink:        [190,201,198],
    dim:        [63,73,71],
    tick:       [137,147,145],
    teal:       [129,213,205],
    critical:   [255,180,171],
    primary:    [129,213,205],
    health:     [176,204,200],
    warn:       [175,201,231],
    primaryInk: '#81D5CD',
    text1:      '#DDE4E2',
    text2:      '#BEC9C6',
    text3:      '#899391',
    textHi:     '#DDE4E2',
    border:     '#3F4947',
    ink2:       '#BEC9C6',
    ink3:       '#DDE4E2',
    telemetry:  '#5C8A85',   // primary 62% over surface — teal telemetry (owner)   // pure-gray data-viz neutral, low contrast (owner)
    telemetryHi:'#DDE4E2',
    barOn:      '#81D5CD',
    barOff:     '#3F4947',
    // the export defines no categorical data colours (extendedColors is empty), so
    // workload identity remains the one table authored outside Material.
    // OWNER 2026-09-01 v2: MAX-VARIATION categorical palette — blue 245, magenta 335,
    // lime 130, orange 50, yellow 95: hues far from teal structure, green-152 live,
    // amber-85 warn and red-25 error, and markedly different from each other
    workloads: {
      eric: [77,172,246], vision: [221,113,200], confRemote: [147,204,75],
      confCarlos: [245,139,75], workload: [229,201,94]
    }
  },
  light: {
    selected:   [204,232,228],
    stage:      [244,251,249],
    backing:    [232,240,238],
    outline:    [111,121,119],
    lit:        [22,29,28],
    ink:        [63,73,71],
    dim:        [141,158,154],   // geography on a LIGHT ground must darken, not lighten
    tick:       [96,107,105],
    teal:       [0,106,100],
    critical:   [186,26,26],
    primary:    [0,106,100],
    health:     [74,99,96],
    warn:       [72,97,122],
    primaryInk: '#006A64',
    text1:      '#161D1C',
    text2:      '#3F4947',
    text3:      '#6F7977',
    textHi:     '#161D1C',
    border:     '#BEC9C6',
    ink2:       '#3F4947',
    ink3:       '#161D1C',
    telemetry:  '#6FA49E',   // primary 55% over surface — teal telemetry (owner)   // pure-gray data-viz neutral, low contrast (owner)
    telemetryHi:'#161D1C',
    barOn:      '#006A64',
    barOff:     '#BEC9C6',
    // the export defines no categorical data colours (extendedColors is empty), so
    // workload identity remains the one table authored outside Material.
    // OWNER 2026-09-01 v2: MAX-VARIATION categorical palette — blue 245, magenta 335,
    // lime 130, orange 50, yellow 95: hues far from teal structure, green-152 live,
    // amber-85 warn and red-25 error, and markedly different from each other
    workloads: {
      eric: [0,104,178], vision: [150,37,133], confRemote: [81,130,0],
      confCarlos: [176,77,0], workload: [153,126,0]
    }
  }
};
let current = 'dark';    // standalone: the dark stage
const T = { ...THEMES.dark };
function setTheme(name) {
  if (!THEMES[name] || name === current) return false;
  current = name;
  Object.assign(T, THEMES[name]);
  return true;
}
function themeName() { return current; }
// helpers every renderer uses instead of writing a literal
const rgbaT = (role, a) => {
  const c = T[role];
  return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
};

return { THEMES, T, setTheme, themeName, rgbaT };
})();

// ===== hive.js =====
__M["hive.js"] = (() => {
// FIELD LANGUAGE — the hive as an ENVIRONMENTAL / DOMAIN layer.
//
// Three components only: a cavity, one aperture, a few comb planes. Deliberately
// kept apart from the other systems:
//   hive geometry   = physical context      (this file)
//   FCC / rhombic   = organisational structure  (swarm-core FCC_DIRS / RD_FACES)
//   thermal field   = emergent outcome      (treatments layerIsotherms)
//   agents / flow   = colony behaviour      (swarm-core)
// The hive is never coloured by temperature and never drawn from FCC geometry.

const {project} = __M["vendor/swarm-core.js"];

const S = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const o4 = new Float32Array(4), o4b = new Float32Array(4);

// Visual-only. Presence never touches the swarm mathematics — it is independent
// of STRUCTURE PRESENCE by design, so hive and lattice can be judged separately.
const HIVE_PRESENCE = {
  'None': { chamber: 0, entrance: 0, comb: 0, section: 0 },
  'Entrance only': { chamber: 0, entrance: 1, comb: 0, section: 0 },
  'Entrance + chamber': { chamber: 1, entrance: 1, comb: 0, section: 0 },
  'Chamber + sparse comb': { chamber: 1, entrance: 0.4, comb: 1, section: 0 },
  'Full contextual': { chamber: 1, entrance: 1, comb: 1, section: 1 }
};

function makeHive(o = {}) {
  // The cavity is deliberately small relative to the frame: it is the boundary
  // the colony lives inside, so it has to occupy a central portion of the
  // composition rather than run past the viewport on every side.
  const hx = o.hx ?? 92, hy = o.hy ?? 50, hz = o.hz ?? 82;
  // aperture low and off-axis on the -z wall: never centred, never symmetric
  const ent = { x: o.ex ?? 68, y: o.ey ?? -29, z: -hz, r: o.er ?? 14 };
  const combs = o.combs ?? [-30, 18, 64];      // parallel comb plates, fixed z

  const h = {
    hx, hy, hz, ent, combs,
    // camera hypothesis: inside, oblique, entrance toward a frame edge, world
    // continuing past the viewport
    view: { target: [-2, -22, 6], yaw: Math.PI + 0.44, pitch: 0.16, dist: 252, fov: 900 },
    anchors: {
      far: [ent.x, ent.y, -hz - 118],
      outside: [ent.x, ent.y, -hz - 46],
      mouth: [ent.x * 0.94, ent.y * 0.9, -hz + 10],
      inner: [ent.x * 0.6, ent.y * 0.62, -hz + 58],
      deep: [ent.x * 0.34, ent.y * 0.4, -hz + 82]
    },
    inside(x, y, z) { return Math.abs(x) < hx && Math.abs(y) < hy && Math.abs(z) < hz; },
    // ENVIRONMENTAL GATING. Outside the cavity the probe is not a threat the
    // colony can answer; the entrance neighbourhood registers as local detection
    // only; inside, the full defensive sequence is available.
    gate(x, y, z) {
      if (h.inside(x, y, z)) return 1;
      const dxy = Math.hypot(x - ent.x, y - ent.y);
      const out = -hz - z;
      if (out < 0 || out > 100 || dxy > ent.r * 2.9) return 0;
      return 0.62 * (1 - S(ent.r * 0.85, ent.r * 2.9, dxy)) * (1 - S(6, 94, out));
    },
    // the unattended intruder: approach, cross, wander, retreat
    autoPath(a) {
      const u = ((a * 0.16) % 1 + 1) % 1, A = h.anchors;
      const L = (p, q, w) => [p[0] + (q[0] - p[0]) * w, p[1] + (q[1] - p[1]) * w, p[2] + (q[2] - p[2]) * w];
      if (u < 0.20) return L(A.far, A.outside, u / 0.20);
      if (u < 0.32) return L(A.outside, A.mouth, (u - 0.20) / 0.12);
      if (u < 0.48) return L(A.mouth, A.inner, (u - 0.32) / 0.16);
      if (u < 0.70) return L(A.inner, A.deep, (u - 0.48) / 0.22);
      if (u < 0.82) return L(A.deep, A.mouth, (u - 0.70) / 0.12);
      return L(A.mouth, A.far, (u - 0.82) / 0.18);
    }
  };
  return h;
}

// ---- drawing helpers -------------------------------------------------------
const pt = (view, x, y, z, out) => project(view.cam, x, y, z, view.W, view.H, out);

function polyline(ctx, view, pts, close) {
  ctx.beginPath();
  for (let i = 0; i < pts.length; i++) {
    pt(view, pts[i][0], pts[i][1], pts[i][2], o4);
    i ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
  }
  if (close) ctx.closePath();
  ctx.stroke();
}
function segmented(ctx, view, A, B, n, duty, tickEvery) {
  for (let i = 0; i < n; i++) {
    const u0 = i / n, u1 = u0 + duty / n;
    pt(view, A[0] + (B[0] - A[0]) * u0, A[1] + (B[1] - A[1]) * u0, A[2] + (B[2] - A[2]) * u0, o4);
    const x0 = o4[0], y0 = o4[1];
    pt(view, A[0] + (B[0] - A[0]) * u1, A[1] + (B[1] - A[1]) * u1, A[2] + (B[2] - A[2]) * u1, o4b);
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(o4b[0], o4b[1]); ctx.stroke();
    if (tickEvery && i % tickEvery === 0) {
      const dx = o4b[0] - x0, dy = o4b[1] - y0, L = Math.hypot(dx, dy) || 1, t = 3.2;
      ctx.beginPath();
      ctx.moveTo(x0 - (-dy / L) * t, y0 - (dx / L) * t);
      ctx.lineTo(x0 + (-dy / L) * t, y0 + (dx / L) * t);
      ctx.stroke();
    }
  }
}
function reg(ctx, view, p, c) {
  pt(view, p[0], p[1], p[2], o4);
  ctx.beginPath();
  ctx.moveTo(o4[0] - c, o4[1]); ctx.lineTo(o4[0] + c, o4[1]);
  ctx.moveTo(o4[0], o4[1] - c); ctx.lineTo(o4[0], o4[1] + c);
  ctx.stroke();
}
function scr(view, pts) {
  const out = [];
  for (const p of pts) { pt(view, p[0], p[1], p[2], o4); out.push([o4[0], o4[1]]); }
  return out;
}
function fillPoly(ctx, sp, style) {
  ctx.beginPath();
  for (let i = 0; i < sp.length; i++) i ? ctx.lineTo(sp[i][0], sp[i][1]) : ctx.moveTo(sp[i][0], sp[i][1]);
  ctx.closePath(); ctx.fillStyle = style; ctx.fill();
}

// shared topology: the entrance wall, the recession edges, the floor
function topo(h) {
  const { hx, hy, hz } = h, back = -hz + 2 * hz * 0.6;
  return {
    F: [[-hx, -hy, -hz], [hx, -hy, -hz], [hx, hy, -hz], [-hx, hy, -hz]],
    R: [[-hx, -hy, back], [hx, -hy, back], [hx, hy, back], [-hx, hy, back]],
    floorZ: [-hz + 2 * hz * 0.30, -hz + 2 * hz * 0.62]
  };
}
function combQuad(h, z) {
  const x0 = -h.hx * 0.76, x1 = h.hx * 0.76, y0 = -h.hy * 0.88, y1 = h.hy * 0.56;
  return [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]];
}
// real comb geometry, used sparingly because it IS the physical architecture
function cells(h, z, cb) {
  const r = 8.6, dx = r * Math.sqrt(3), dy = r * 1.5;
  for (let row = 0; row < 3; row++) for (let col = 0; col < 5; col++)
    cb(-h.hx * 0.58 + col * dx + (row % 2 ? dx * 0.5 : 0), -h.hy * 0.74 + row * dy, r, row, col);
}
function hexPts(cx, cy, z, r) {
  const p = [];
  for (let k = 0; k < 6; k++) {
    const a = Math.PI / 6 + k * Math.PI / 3;
    p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r, z]);
  }
  return p;
}
const ringPts = (ent, n, k) => {
  const p = [];
  for (let i = 0; i < n; i++) {
    const a = 2 * Math.PI * i / n;
    p.push([ent.x + Math.cos(a) * ent.r * k, ent.y + Math.sin(a) * ent.r * k, ent.z]);
  }
  return p;
};

// ---- 1A engraved survey ----------------------------------------------------
function chamberI(ctx, view, h, P, pres) {
  const { F, R, floorZ } = topo(h);
  ctx.lineWidth = 0.6; ctx.strokeStyle = P.a('ink', 0.26);
  polyline(ctx, view, F, true);
  ctx.lineWidth = 0.5; ctx.strokeStyle = P.a('ink', 0.15);
  for (let i = 0; i < 4; i++) polyline(ctx, view, [F[i], R[i]], false);
  ctx.strokeStyle = P.a('graphite', 0.28);
  for (let k = 1; k <= 3; k++) {                       // section lines across the wall
    const y = -h.hy + 2 * h.hy * k / 4;
    polyline(ctx, view, [[-h.hx, y, -h.hz], [h.hx, y, -h.hz]], false);
  }
  for (let k = 1; k <= 3; k++) {
    const x = -h.hx + 2 * h.hx * k / 4;
    polyline(ctx, view, [[x, -h.hy, -h.hz], [x, h.hy, -h.hz]], false);
  }
  ctx.strokeStyle = P.a('graphite', 0.22);
  for (const z of floorZ) polyline(ctx, view, [[-h.hx, -h.hy, z], [h.hx, -h.hy, z]], false);
  if (pres.section) {                                  // survey stations along the sill
    ctx.strokeStyle = P.a('ink', 0.3); ctx.lineWidth = 0.5;
    for (let k = 0; k <= 16; k++) {
      const x = -h.hx + 2 * h.hx * k / 16, t = k % 4 ? 3 : 6;
      pt(view, x, -h.hy, -h.hz, o4);
      ctx.beginPath(); ctx.moveTo(o4[0], o4[1]); ctx.lineTo(o4[0], o4[1] - t); ctx.stroke();
    }
    polyline(ctx, view, [[-h.hx, h.hy * 0.1, -h.hz], [-h.hx, h.hy * 0.1, R[0][2]]], false);
  }
}
function entI(ctx, view, h, P, k) {
  const e = h.ent;
  fillPoly(ctx, scr(view, ringPts(e, 40, 1)), P.a('ink', 0.055 * k));
  ctx.lineWidth = 0.75; ctx.strokeStyle = P.a('ink', 0.5 * k);
  polyline(ctx, view, ringPts(e, 48, 1), true);
  ctx.lineWidth = 0.5; ctx.strokeStyle = P.a('ink', 0.2 * k);
  polyline(ctx, view, ringPts(e, 48, 1.34), true);
  ctx.strokeStyle = P.a('ink', 0.34 * k);               // measured entrance marks
  for (let i = 0; i < 12; i++) {
    const a = i * Math.PI / 6;
    polyline(ctx, view, [
      [e.x + Math.cos(a) * e.r * 1.06, e.y + Math.sin(a) * e.r * 1.06, e.z],
      [e.x + Math.cos(a) * e.r * 1.28, e.y + Math.sin(a) * e.r * 1.28, e.z]], false);
  }
  ctx.strokeStyle = P.a('graphite', 0.42 * k); ctx.lineWidth = 0.5;
  polyline(ctx, view, [[e.x - e.r * 1.8, e.y, e.z], [e.x + e.r * 1.8, e.y, e.z]], false);
  for (const s of [-1, 1]) polyline(ctx, view, [
    [e.x + s * e.r * 1.8, e.y - 4.5, e.z], [e.x + s * e.r * 1.8, e.y + 4.5, e.z]], false);
}
function combI(ctx, view, h, P) {
  ctx.lineWidth = 0.5;
  for (const z of h.combs) {
    ctx.strokeStyle = P.a('ink', 0.13);
    polyline(ctx, view, combQuad(h, z), true);
    ctx.strokeStyle = P.a('graphite', 0.3);
    cells(h, z, (cx, cy, r) => polyline(ctx, view, hexPts(cx, cy, z, r), true));
  }
}

// ---- 1B interval notation --------------------------------------------------
function chamberII(ctx, view, h, P, pres) {
  const { F, R, floorZ } = topo(h);
  ctx.lineWidth = 0.9; ctx.strokeStyle = P.a('ink', 0.3);
  for (let i = 0; i < 4; i++) segmented(ctx, view, F[i], F[(i + 1) % 4], 12, 0.42, 4);
  ctx.strokeStyle = P.a('ink', 0.2);
  for (let i = 0; i < 4; i++) segmented(ctx, view, F[i], R[i], 7, 0.36, 0);
  ctx.strokeStyle = P.a('graphite', 0.34);
  for (let k = 1; k <= 3; k++) {
    const y = -h.hy + 2 * h.hy * k / 4;
    segmented(ctx, view, [-h.hx, y, -h.hz], [h.hx, y, -h.hz], 16, 0.3, 0);
  }
  for (const z of floorZ) segmented(ctx, view, [-h.hx, -h.hy, z], [h.hx, -h.hy, z], 14, 0.28, 0);
  ctx.lineWidth = 0.8; ctx.strokeStyle = P.a('gold', 0.34);   // registration signs
  for (const p of F) reg(ctx, view, p, 3.4);
  for (const p of R) reg(ctx, view, p, 2.4);
  if (pres.section) {
    ctx.strokeStyle = P.a('ink', 0.3); ctx.lineWidth = 0.7;
    for (let k = 0; k <= 8; k++) {
      const x = -h.hx + 2 * h.hx * k / 8;
      pt(view, x, -h.hy, -h.hz, o4);
      ctx.beginPath(); ctx.moveTo(o4[0], o4[1]); ctx.lineTo(o4[0], o4[1] - (k % 2 ? 3 : 6)); ctx.stroke();
    }
  }
}
function entII(ctx, view, h, P, k) {
  const e = h.ent, n = 48;
  fillPoly(ctx, scr(view, ringPts(e, 40, 1)), P.a('ink', 0.05 * k));
  ctx.lineWidth = 1.0; ctx.strokeStyle = P.a('ink', 0.55 * k);
  const R1 = ringPts(e, n, 1);
  for (let s = 0; s < 16; s++) {                        // segmented boundary notation
    const a = s * 3, b = a + 2;
    ctx.beginPath();
    for (let i = a; i <= b; i++) {
      const p = R1[i % n]; pt(view, p[0], p[1], p[2], o4);
      i === a ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
    }
    ctx.stroke();
  }
  ctx.lineWidth = 0.8; ctx.strokeStyle = P.a('ink', 0.34 * k);
  for (let i = 0; i < 8; i++) {                          // interval marks
    const a = i * Math.PI / 4;
    polyline(ctx, view, [
      [e.x + Math.cos(a) * e.r * 1.12, e.y + Math.sin(a) * e.r * 1.12, e.z],
      [e.x + Math.cos(a) * e.r * 1.34, e.y + Math.sin(a) * e.r * 1.34, e.z]], false);
  }
  ctx.strokeStyle = P.a('gold', 0.42 * k); ctx.lineWidth = 0.8;
  for (const s of [[-1, -1], [1, -1], [1, 1], [-1, 1]])
    reg(ctx, view, [e.x + s[0] * e.r * 1.42, e.y + s[1] * e.r * 1.42, e.z], 3);
}
function combII(ctx, view, h, P) {
  ctx.lineWidth = 0.8;
  for (const z of h.combs) {
    ctx.strokeStyle = P.a('ink', 0.16);
    const q = combQuad(h, z);
    segmented(ctx, view, q[3], q[2], 14, 0.3, 0);
    ctx.strokeStyle = P.a('graphite', 0.4);
    cells(h, z, (cx, cy, r, row, col) => {              // sampled comb geometry
      if ((row + col) % 2) return;
      const p = hexPts(cx, cy, z, r);
      for (let s = 0; s < 6; s += 2) polyline(ctx, view, [p[s], p[s + 1]], false);
    });
  }
}

// ---- 1C coherence field ----------------------------------------------------
function chamberIII(ctx, view, h, P, pres) {
  const { F, R } = topo(h);
  // the quads run well past the cavity so their own edges never read as a
  // contour: what is drawn is a transition, not a boundary
  const wx = h.hx * 2.2, wyLo = -h.hy * 1.9, wyHi = h.hy * 1.05;
  const sp = scr(view, [[-wx, wyLo, -h.hz], [wx, wyLo, -h.hz], [wx, wyHi, -h.hz], [-wx, wyHi, -h.hz]]);
  let y0 = 1e9, y1 = -1e9;
  for (const p of sp) { y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); }
  const g = ctx.createLinearGradient(0, y1, 0, y0);     // density transition, no contour
  g.addColorStop(0, P.a('graphite', 0.15));
  g.addColorStop(0.5, P.a('graphite', 0.05));
  g.addColorStop(1, P.a('graphite', 0));
  fillPoly(ctx, sp, g);
  const fl = scr(view, [[-wx, -h.hy, -h.hz], [wx, -h.hy, -h.hz], [wx, -h.hy, R[1][2]], [-wx, -h.hy, R[0][2]]]);
  const g2 = ctx.createLinearGradient(0, y1 + 30, 0, y1 - 90);
  g2.addColorStop(0, P.a('graphite', 0.11));
  g2.addColorStop(1, P.a('graphite', 0));
  fillPoly(ctx, fl, g2);
  if (pres.section) {                                   // the faintest possible edge
    ctx.strokeStyle = P.a('graphite', 0.2); ctx.lineWidth = 0.5;
    polyline(ctx, view, [F[0], F[1]], false);
    polyline(ctx, view, [F[0], F[3]], false);
  }
}
function entIII(ctx, view, h, P, k) {
  const e = h.ent;
  pt(view, e.x, e.y, e.z, o4);
  const rp = Math.max(6, e.r * o4[3]);
  const g = ctx.createRadialGradient(o4[0], o4[1], 0, o4[0], o4[1], rp * 2.3);
  g.addColorStop(0, P.a('ink', 0.16 * k));
  g.addColorStop(0.42, P.a('ink', 0.07 * k));
  g.addColorStop(1, P.a('ink', 0));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(o4[0], o4[1], rp * 2.3, 0, 6.2832); ctx.fill();
  ctx.strokeStyle = P.a('ink', 0.3 * k); ctx.lineWidth = 0.6;
  const R1 = ringPts(e, 48, 1);
  ctx.beginPath();
  for (let i = 26; i <= 44; i++) {
    const p = R1[i % 48]; pt(view, p[0], p[1], p[2], o4b);
    i === 26 ? ctx.moveTo(o4b[0], o4b[1]) : ctx.lineTo(o4b[0], o4b[1]);
  }
  ctx.stroke();
}
function combIII(ctx, view, h, P) {
  for (const z of h.combs) {
    fillPoly(ctx, scr(view, combQuad(h, z)), P.a('graphite', 0.035));
    cells(h, z, (cx, cy, r, row, col) => {
      if ((row + col) % 3) return;
      fillPoly(ctx, scr(view, hexPts(cx, cy, z, r)), P.a('graphite', 0.055));
    });
  }
}

const BY_T = {
  I: { chamber: chamberI, ent: entI, comb: combI },
  II: { chamber: chamberII, ent: entII, comb: combII },
  III: { chamber: chamberIII, ent: entIII, comb: combIII }
};

// Same hive topology in all three columns, expressed through each treatment's
// own formal grammar. Drawn before the colony: it is context, not subject.
function drawHive(ctx, sim, view, P, pres) {
  const h = view.hive;
  if (!h || !pres) return;
  const g = BY_T[view.t] || BY_T.I;
  ctx.save();
  ctx.lineCap = 'butt'; ctx.setLineDash([]);
  if (pres.chamber) g.chamber(ctx, view, h, P, pres);
  if (pres.comb) g.comb(ctx, view, h, P);
  if (pres.entrance) g.ent(ctx, view, h, P, pres.entrance);
  ctx.restore();
}

return { HIVE_PRESENCE, makeHive, drawHive };
})();

// ===== geo-real.js =====
__M["geo-real.js"] = (() => {
// REAL GEOGRAPHY — Natural Earth 110m land (public domain), simplified to
// ~0.8° tolerance, specks under 4 deg² dropped. Outer rings only, [lon,lat].
// Generated from ne_110m_land.json; replaces the hand-authored coastline
// approximation so land silhouettes on the world are the real ones.
const POLYS = [[[-45.15,-78.05],[-43.92,-78.48],[-43.49,-79.09],[-43.33,-80.03],[-44.88,-80.34],[-46.51,-80.59],[-48.39,-80.83],[-50.48,-81.03],[-52.85,-80.97],[-54.16,-80.63],[-51.85,-79.95],[-50.99,-79.61],[-50.36,-79.18],[-49.91,-78.81],[-49.31,-78.46],[-48.66,-78.05],[-46.66,-77.83],[-45.15,-78.05]],[[-68.45,-70.96],[-68.51,-71.8],[-69.96,-72.31],[-71.08,-72.5],[-72.39,-72.48],[-71.9,-72.09],[-73.07,-72.23],[-74.19,-72.37],[-74.95,-72.07],[-73.92,-71.27],[-73.23,-71.15],[-72.07,-71.19],[-71.78,-70.68],[-71.74,-69.51],[-71.17,-69.04],[-70.25,-68.88],[-69.72,-69.25],[-69.06,-70.07],[-68.45,-70.96]],[[-58.61,-64.15],[-59.79,-64.21],[-60.61,-64.31],[-61.3,-64.54],[-62.02,-64.8],[-62.65,-65.48],[-62.12,-66.19],[-62.81,-66.43],[-63.75,-66.5],[-64.29,-66.84],[-64.88,-67.15],[-65.51,-67.58],[-65.31,-68.37],[-64.78,-68.68],[-63.96,-68.91],[-63.2,-69.23],[-62.79,-69.62],[-62.28,-70.38],[-61.81,-70.72],[-61.38,-72.01],[-61,-72.77],[-60.83,-73.7],[-61.38,-74.11],[-61.96,-74.44],[-63.3,-74.58],[-63.75,-74.93],[-64.35,-75.26],[-65.86,-75.64],[-67.19,-75.79],[-68.45,-76.01],[-69.8,-76.22],[-70.6,-76.63],[-72.21,-76.67],[-73.97,-76.63],[-75.56,-76.71],[-77.24,-76.71],[-75.4,-77.28],[-74.28,-77.56],[-73.66,-77.91],[-74.77,-78.22],[-76.5,-78.12],[-77.93,-78.38],[-78.02,-79.18],[-76.85,-79.51],[-75.36,-80.26],[-73.24,-80.42],[-71.44,-80.69],[-70.01,-81],[-68.19,-81.32],[-65.7,-81.47],[-63.26,-81.75],[-61.55,-82.04],[-59.69,-82.38],[-58.71,-82.85],[-58.22,-83.22],[-57.01,-82.87],[-55.36,-82.57],[-53.62,-82.26],[-51.54,-82],[-49.76,-81.73],[-47.27,-81.71],[-44.83,-81.85],[-42.81,-82.08],[-42.16,-81.65],[-40.77,-81.36],[-38.24,-81.34],[-36.27,-81.12],[-34.39,-80.91],[-32.31,-80.77],[-30.1,-80.59],[-28.55,-80.34],[-29.25,-79.99],[-29.69,-79.26],[-31.62,-79.3],[-33.68,-79.46],[-35.64,-79.46],[-35.78,-78.34],[-33.9,-77.89],[-32.21,-77.65],[-31,-77.36],[-29.78,-77.07],[-28.88,-76.67],[-27.51,-76.5],[-26.16,-76.36],[-23.93,-76.24],[-22.46,-76.11],[-21.22,-75.91],[-20.01,-75.67],[-18.91,-75.44],[-17.52,-75.13],[-16.64,-74.79],[-15.7,-74.5],[-16.47,-73.87],[-15.45,-73.15],[-14.41,-72.95],[-13.31,-72.72],[-12.29,-72.4],[-11.51,-72.01],[-11.02,-71.54],[-10.3,-71.27],[-9.1,-71.32],[-8.61,-71.66],[-7.42,-71.7],[-6.87,-70.93],[-5.79,-71.03],[-4.34,-71.46],[-3.05,-71.29],[-1.8,-71.17],[-0.66,-71.23],[-0.23,-71.64],[0.87,-71.3],[1.89,-71.13],[3.02,-70.99],[4.14,-70.85],[5.16,-70.62],[6.27,-70.46],[7.14,-70.25],[7.74,-69.89],[8.49,-70.15],[9.53,-70.01],[10.25,-70.48],[10.82,-70.83],[11.95,-70.64],[12.4,-70.25],[13.42,-69.97],[14.73,-70.03],[15.95,-70.03],[17.03,-69.91],[18.2,-69.87],[19.26,-69.89],[20.38,-70.01],[21.45,-70.07],[21.92,-70.4],[22.57,-70.7],[23.67,-70.52],[24.84,-70.48],[25.98,-70.48],[27.09,-70.46],[28.09,-70.32],[29.15,-70.21],[30.03,-69.93],[30.97,-69.76],[31.99,-69.66],[32.75,-69.38],[33.3,-68.84],[33.87,-68.5],[34.91,-68.66],[36.16,-69.25],[37.2,-69.17],[37.91,-69.52],[38.65,-69.78],[39.67,-69.54],[40.92,-68.93],[41.96,-68.6],[42.94,-68.46],[44.11,-68.27],[44.9,-68.05],[45.72,-67.82],[46.5,-67.6],[47.44,-67.72],[48.34,-67.37],[48.99,-67.09],[49.93,-67.11],[50.75,-66.88],[51.79,-66.25],[52.61,-66.05],[53.61,-65.9],[54.53,-65.82],[55.41,-65.88],[56.36,-65.97],[57.16,-66.25],[58.14,-67.01],[58.74,-67.29],[59.94,-67.41],[60.61,-67.68],[61.43,-67.95],[62.39,-68.01],[63.19,-67.82],[64.05,-67.41],[64.99,-67.62],[65.97,-67.74],[66.91,-67.86],[67.89,-67.93],[68.89,-67.93],[69.71,-68.97],[69.56,-69.68],[68.6,-69.93],[67.81,-70.31],[69.07,-70.68],[68.42,-71.44],[67.95,-71.85],[68.71,-72.17],[69.87,-72.26],[71.02,-72.09],[71.57,-71.7],[72.45,-71.01],[73.08,-70.72],[73.86,-69.87],[75.63,-69.74],[76.63,-69.62],[77.64,-69.46],[78.13,-69.07],[79.11,-68.33],[80.09,-68.07],[80.94,-67.88],[81.48,-67.54],[82.78,-67.21],[83.78,-67.31],[84.68,-67.21],[85.66,-67.09],[86.75,-67.15],[87.48,-66.88],[87.99,-66.21],[88.83,-66.95],[89.67,-67.15],[90.63,-67.23],[91.59,-67.11],[92.61,-67.19],[93.55,-67.21],[95.02,-67.17],[95.78,-67.39],[96.68,-67.25],[97.76,-67.25],[98.68,-67.11],[99.72,-67.25],[100.38,-66.92],[100.89,-66.58],[101.58,-66.31],[102.83,-65.56],[104.24,-65.97],[104.91,-66.33],[106.18,-66.93],[107.16,-66.95],[108.08,-66.95],[109.16,-66.84],[110.24,-66.7],[111.06,-66.43],[111.74,-66.13],[112.86,-66.09],[113.6,-65.88],[114.39,-66.07],[114.9,-66.39],[115.6,-66.7],[116.7,-66.66],[117.38,-66.92],[118.58,-67.17],[119.83,-67.27],[120.87,-67.19],[121.65,-66.88],[122.32,-66.56],[123.22,-66.48],[124.12,-66.62],[125.16,-66.72],[126.1,-66.56],[127,-66.56],[127.88,-66.66],[128.8,-66.76],[129.7,-66.58],[130.78,-66.43],[131.8,-66.39],[132.94,-66.39],[133.86,-66.29],[134.76,-66.21],[135.07,-65.31],[135.7,-65.58],[136.21,-66.45],[137.46,-66.95],[138.6,-66.9],[139.91,-66.88],[140.81,-66.82],[142.12,-66.82],[143.06,-66.8],[144.37,-66.84],[145.49,-66.92],[146.2,-67.23],[146.65,-67.9],[147.72,-68.13],[148.84,-68.39],[150.13,-68.56],[151.48,-68.72],[152.5,-68.87],[153.64,-68.89],[154.28,-68.56],[155.17,-68.84],[155.93,-69.15],[156.81,-69.38],[158.03,-69.48],[159.18,-69.6],[159.67,-69.99],[160.81,-70.23],[161.57,-70.58],[162.69,-70.74],[163.84,-70.72],[164.92,-70.78],[166.11,-70.76],[167.31,-70.83],[168.43,-70.97],[169.46,-71.21],[170.5,-71.4],[171.21,-71.7],[170.56,-72.44],[170.11,-72.89],[169.29,-73.66],[167.98,-73.81],[167.39,-74.17],[166.09,-74.38],[165.64,-74.77],[164.96,-75.15],[164.23,-75.46],[163.82,-75.87],[163.47,-76.69],[164.06,-77.46],[164.74,-78.18],[166.6,-78.32],[167,-78.75],[165.19,-78.91],[163.67,-79.12],[161.77,-79.16],[160.92,-79.73],[160.32,-80.57],[159.79,-80.95],[161.12,-81.28],[161.63,-81.69],[162.49,-82.06],[163.71,-82.4],[165.1,-82.71],[166.6,-83.02],[168.9,-83.34],[169.4,-83.83],[172.28,-84.04],[173.22,-84.41],[175.99,-84.16],[178.28,-84.47],[180,-84.71],[180,-90],[-180,-90],[-180,-84.71],[-179.06,-84.14],[-177.26,-84.45],[-176.52,-84.23],[-175.83,-84.12],[-174.38,-84.53],[-173.12,-84.12],[-169.95,-83.88],[-169,-84.12],[-167.02,-84.57],[-164.18,-84.83],[-161.93,-85.14],[-158.07,-85.37],[-155.19,-85.1],[-150.94,-85.3],[-148.53,-85.61],[-145.89,-85.32],[-143.11,-85.04],[-146.83,-84.53],[-150.06,-84.3],[-150.9,-83.9],[-153.59,-83.69],[-153.04,-82.83],[-152.86,-82.04],[-154.53,-81.77],[-155.29,-81.42],[-156.84,-81.1],[-154.41,-81.16],[-152.1,-81],[-150.65,-81.34],[-148.87,-81.04],[-147.22,-80.67],[-146.42,-80.34],[-148.06,-79.65],[-149.53,-79.36],[-151.59,-79.3],[-153.39,-79.16],[-155.33,-79.06],[-155.98,-78.69],[-157.27,-78.38],[-158.05,-78.03],[-158.37,-76.89],[-156.97,-77.3],[-155.33,-77.2],[-153.74,-77.07],[-152.92,-77.5],[-151.33,-77.4],[-150,-77.18],[-148.75,-76.91],[-147.61,-76.58],[-146.1,-76.48],[-146.5,-75.73],[-144.91,-75.2],[-144.32,-75.54],[-142.79,-75.34],[-141.64,-75.09],[-140.21,-75.07],[-138.86,-74.97],[-137.51,-74.73],[-136.43,-74.52],[-135.21,-74.3],[-134.43,-74.36],[-132.26,-74.3],[-130.93,-74.48],[-129.55,-74.46],[-128.24,-74.32],[-126.89,-74.42],[-125.4,-74.52],[-124.01,-74.48],[-122.56,-74.5],[-121.07,-74.52],[-119.7,-74.48],[-118.68,-74.19],[-117.47,-74.03],[-116.22,-74.24],[-115.02,-74.07],[-113.94,-73.71],[-113.3,-74.03],[-112.3,-74.71],[-111.26,-74.42],[-110.07,-74.79],[-108.71,-74.91],[-107.56,-75.18],[-106.15,-75.13],[-104.88,-74.95],[-103.37,-74.99],[-102.02,-75.13],[-100.65,-75.3],[-100.12,-74.87],[-100.76,-74.54],[-101.25,-74.19],[-102.55,-74.11],[-103.11,-73.73],[-103.68,-72.62],[-102.92,-72.75],[-101.61,-72.81],[-100.31,-72.75],[-99.14,-72.91],[-98.12,-73.21],[-96.34,-73.62],[-95.04,-73.48],[-93.67,-73.28],[-92.44,-73.17],[-91.42,-73.4],[-90.09,-73.32],[-89.23,-72.56],[-88.42,-73.01],[-87.27,-73.19],[-86.01,-73.09],[-85.19,-73.48],[-83.88,-73.52],[-82.67,-73.64],[-81.47,-73.85],[-80.69,-73.48],[-79.3,-73.52],[-77.93,-73.42],[-76.91,-73.64],[-76.22,-73.97],[-74.89,-73.87],[-73.85,-73.66],[-72.83,-73.4],[-71.62,-73.26],[-70.21,-73.15],[-68.94,-73.01],[-67.96,-72.79],[-67.37,-72.48],[-67.25,-71.64],[-67.92,-70.85],[-68.49,-70.11],[-68.45,-69.33],[-67.98,-68.95],[-67.58,-68.54],[-67.62,-67.72],[-67.25,-66.88],[-66.7,-66.58],[-66.06,-66.21],[-65.37,-65.9],[-64.57,-65.6],[-64.18,-65.17],[-63.63,-64.9],[-63,-64.64],[-62.04,-64.58],[-61.41,-64.27],[-60.71,-64.07],[-59.89,-63.96],[-59.16,-63.7],[-58.59,-63.39],[-57.81,-63.27],[-57.22,-63.53],[-58.61,-64.15]],[[-67.75,-53.85],[-66.45,-54.45],[-65.05,-54.7],[-65.5,-55.2],[-66.45,-55.25],[-66.96,-54.9],[-68.15,-55.61],[-69.23,-55.5],[-69.96,-55.2],[-71.01,-55.05],[-72.26,-54.5],[-73.29,-53.96],[-74.66,-52.84],[-73.84,-53.05],[-72.43,-53.72],[-71.11,-54.07],[-70.59,-53.62],[-70.27,-52.93],[-69.35,-52.52],[-68.63,-52.64],[-68.25,-53.1],[-67.75,-53.85]],[[145.4,-40.79],[146.36,-41.14],[147.69,-40.81],[148.36,-42.06],[147.91,-43.21],[146.87,-43.63],[146.05,-43.55],[145.43,-42.69],[144.72,-41.16],[145.4,-40.79]],[[173.02,-40.92],[173.96,-40.93],[174.25,-41.77],[173.88,-42.23],[173.22,-42.97],[172.71,-43.37],[173.08,-43.85],[171.45,-44.24],[171.19,-44.9],[170.62,-45.91],[169.83,-46.36],[168.41,-46.62],[167.76,-46.29],[166.68,-46.22],[167.05,-45.11],[168.3,-44.12],[168.95,-43.94],[169.67,-43.56],[170.52,-43.03],[171.13,-42.51],[171.57,-41.77],[172.1,-40.96],[172.8,-40.49]],[[174.61,-36.16],[175.34,-37.21],[175.81,-36.8],[175.96,-37.56],[176.76,-37.88],[178.01,-37.58],[178.27,-38.58],[177.97,-39.17],[176.94,-39.45],[176.51,-40.6],[176.01,-41.29],[175.24,-41.69],[174.65,-41.28],[175.23,-40.46],[174.9,-39.91],[173.82,-39.51],[174.57,-38.8],[174.74,-38.03],[174.29,-36.71],[173.84,-36.12],[173.05,-35.24],[172.64,-34.53],[173.55,-35.01],[174.33,-35.27],[174.61,-36.16]],[[50.06,-13.56],[50.22,-14.76],[50.38,-15.71],[49.86,-15.41],[49.86,-16.45],[49.5,-17.11],[49.44,-17.95],[49.04,-19.12],[48.55,-20.5],[47.93,-22.39],[47.55,-23.78],[47.1,-24.94],[46.28,-25.18],[45.41,-25.6],[44.83,-25.35],[44.04,-24.99],[43.76,-24.46],[43.7,-23.57],[43.35,-22.78],[43.25,-22.06],[43.43,-21.34],[43.9,-20.83],[44.37,-20.07],[44.23,-18.96],[44.04,-18.33],[43.96,-17.41],[44.31,-16.85],[44.94,-16.18],[45.87,-15.79],[46.88,-15.21],[47.71,-14.59],[48.01,-14.09],[48.85,-13.09],[49.19,-12.04],[49.81,-12.9],[50.06,-13.56]],[[143.56,-13.76],[143.92,-14.55],[144.56,-14.17],[145.37,-14.98],[145.49,-16.29],[145.89,-16.91],[146.16,-17.76],[146.39,-18.96],[147.47,-19.48],[148.18,-19.96],[148.85,-20.39],[149.29,-21.26],[149.68,-22.34],[150.48,-22.56],[150.9,-23.46],[151.61,-24.08],[152.07,-24.46],[152.86,-25.27],[153.14,-26.07],[153.09,-27.26],[153.57,-28.11],[153.51,-29],[153.07,-30.35],[152.89,-31.64],[152.45,-32.55],[151.71,-33.04],[151.34,-33.82],[151.01,-34.31],[150.71,-35.17],[150.33,-35.67],[150.08,-36.42],[149.95,-37.11],[149.42,-37.77],[148.3,-37.81],[147.38,-38.22],[146.92,-38.61],[146.32,-39.04],[145.49,-38.59],[145.03,-37.9],[143.61,-38.81],[142.75,-38.54],[141.61,-38.31],[140.64,-38.02],[139.99,-37.4],[139.81,-36.64],[139.08,-35.73],[138.12,-35.61],[138.45,-35.13],[138.21,-34.38],[137.72,-35.08],[136.83,-35.26],[137.35,-34.71],[137.89,-33.64],[137.81,-32.9],[137,-33.75],[136.37,-34.09],[135.99,-34.89],[135.21,-34.48],[134.61,-33.22],[134.09,-32.85],[132.99,-32.01],[131.33,-31.5],[129.54,-31.59],[128.24,-31.95],[127.1,-32.28],[126.15,-32.22],[125.09,-32.73],[124.22,-32.96],[123.66,-33.89],[122.81,-33.91],[121.3,-33.82],[120.58,-33.93],[119.3,-34.51],[118.51,-34.75],[117.3,-35.03],[115.56,-34.39],[115.05,-33.62],[115.71,-33.26],[115.8,-32.21],[115.16,-30.6],[115.04,-29.46],[114.64,-28.81],[114.17,-28.12],[114.05,-27.33],[113.48,-26.54],[113.44,-25.62],[114.23,-26.3],[113.72,-25],[113.39,-24.38],[113.71,-23.56],[113.74,-22.48],[114.15,-21.76],[114.23,-22.52],[114.65,-21.83],[115.46,-21.5],[115.95,-21.07],[116.71,-20.7],[118.23,-20.37],[118.99,-20.04],[119.81,-19.98],[120.86,-19.68],[121.4,-19.24],[122.24,-18.2],[122.31,-17.25],[123.01,-16.41],[123.43,-17.27],[123.82,-16.11],[124.38,-15.57],[124.93,-15.08],[125.67,-14.51],[126.14,-14.1],[127.07,-13.82],[127.8,-14.28],[128.36,-14.87],[129.62,-14.97],[129.89,-13.62],[130.18,-13.11],[130.62,-12.54],[131.22,-12.18],[132.58,-12.11],[131.82,-11.27],[133.02,-11.38],[133.55,-11.79],[134.39,-12.04],[135.3,-12.25],[135.88,-11.96],[136.95,-12.35],[136.69,-12.89],[135.96,-13.32],[135.78,-14.22],[135.43,-14.72],[136.3,-15.55],[137.07,-15.87],[137.58,-16.22],[138.3,-16.81],[139.11,-17.06],[140.22,-17.71],[140.88,-17.37],[141.27,-16.39],[141.7,-15.04],[141.64,-14.27],[141.65,-12.94],[141.93,-11.88],[142.14,-11.04],[142.87,-11.78],[143.16,-12.33],[143.52,-12.83],[143.56,-13.76]],[[108.62,-6.78],[110.54,-6.88],[112.61,-6.95],[112.98,-7.59],[114.48,-7.78],[115.71,-8.37],[114.56,-8.75],[113.46,-8.35],[112.56,-8.38],[111.52,-8.3],[110.59,-8.12],[109.43,-7.74],[108.69,-7.64],[106.45,-7.35],[105.37,-6.85],[106.05,-5.9],[107.27,-5.95],[108.07,-6.35],[108.62,-6.78]],[[134.14,-1.15],[134.42,-2.77],[135.46,-3.37],[136.29,-2.31],[137.44,-1.7],[138.33,-1.7],[139.18,-2.05],[139.93,-2.41],[141,-2.6],[142.74,-3.29],[144.58,-3.86],[145.27,-4.37],[145.83,-4.88],[147.65,-6.08],[146.97,-6.72],[147.19,-7.39],[148.08,-8.04],[148.73,-9.1],[149.27,-9.51],[150.04,-9.68],[150.8,-10.29],[150.03,-10.65],[148.92,-10.28],[147.91,-10.13],[147.14,-9.49],[146.57,-8.94],[146.05,-8.07],[144.74,-7.63],[143.9,-7.92],[143.29,-8.25],[143.41,-8.98],[142.63,-9.33],[141.03,-9.12],[140.14,-8.3],[139.13,-8.1],[137.61,-8.41],[138.04,-7.6],[138.67,-7.32],[138.41,-6.23],[137.93,-5.39],[135.99,-4.55],[135.16,-4.46],[133.66,-3.54],[132.98,-4.11],[132.75,-3.31],[131.99,-2.82],[133.07,-2.46],[133.7,-2.21],[132.23,-2.21],[131.84,-1.62],[130.94,-1.43],[130.52,-0.94],[131.87,-0.7],[132.38,-0.37],[133.99,-0.78]],[[125.24,1.42],[124.44,0.43],[123.69,0.24],[122.72,0.43],[121.06,0.38],[120.18,0.24],[120.04,-0.52],[120.94,-1.41],[121.48,-0.96],[123.34,-0.62],[122.82,-0.93],[122.39,-1.52],[121.51,-1.9],[122.45,-3.19],[123.17,-4.68],[122.63,-5.63],[122.72,-4.46],[121.74,-4.85],[120.9,-3.6],[120.97,-2.63],[120.31,-2.93],[120.39,-4.1],[120.43,-5.53],[119.37,-5.38],[119.65,-4.46],[119.5,-3.49],[118.77,-2.8],[119.18,-2.15],[119.32,-1.35],[119.83,0.15],[120.89,1.31],[121.67,1.01],[122.93,0.88],[124.08,0.92],[125.07,1.64]],[[105.82,-5.85],[104.71,-5.87],[103.87,-5.04],[102.58,-4.22],[102.16,-3.61],[101.4,-2.8],[100.9,-2.05],[100.14,-0.65],[99.26,0.18],[98.97,1.04],[98.6,1.82],[97.7,2.45],[97.18,3.31],[96.42,3.87],[95.38,4.97],[95.94,5.44],[97.48,5.25],[98.37,4.27],[99.14,3.59],[99.69,3.17],[100.64,2.1],[101.66,2.08],[102.5,1.4],[103.08,0.56],[103.84,0.1],[103.44,-0.71],[104.01,-1.06],[104.54,-1.78],[104.89,-2.34],[105.62,-2.43],[106.11,-3.06],[105.86,-4.31],[105.82,-5.85]],[[117.88,1.83],[119,0.9],[117.81,0.78],[117.48,0.1],[117.52,-0.8],[116.56,-1.49],[116.53,-2.48],[116.15,-4.01],[114.86,-4.11],[114.47,-3.5],[113.26,-3.12],[112.07,-3.48],[111.7,-2.99],[110.22,-2.93],[110.07,-1.59],[109.09,-0.46],[108.95,0.42],[109.07,1.34],[109.66,2.01],[110.4,1.66],[111.17,1.85],[111.37,2.7],[113,3.1],[113.71,3.89],[114.2,4.53],[115.45,5.45],[116.22,6.14],[116.73,6.92],[117.64,6.42],[118.35,5.71],[119.18,5.41],[118.44,4.97],[117.88,4.14],[117.31,3.23],[118.05,2.29]],[[126.38,8.41],[126.54,7.19],[126.2,6.27],[125.83,7.29],[125.36,6.79],[125.68,6.05],[124.22,6.16],[123.94,6.89],[123.61,7.83],[122.83,7.46],[122.09,6.9],[122.31,8.03],[122.94,8.32],[123.49,8.69],[123.84,8.24],[124.6,8.51],[125.47,8.99],[125.41,9.76],[126.22,9.29],[126.38,8.41]],[[81.22,6.2],[80.35,5.97],[79.87,6.76],[79.7,8.2],[80.15,9.82],[80.84,9.27],[81.3,8.56],[81.79,7.52],[81.64,6.48]],[[121.32,18.5],[121.94,18.22],[122.52,17.09],[122.25,16.26],[121.66,15.93],[121.51,15.12],[121.73,14.33],[122.7,14.34],[123.95,13.78],[124.18,13],[123.3,13.03],[122.93,13.55],[122.03,13.78],[121.13,13.64],[120.68,14.27],[120.07,14.97],[119.88,16.36],[120.39,17.6],[120.72,18.51]],[[-72.58,19.87],[-71.71,19.71],[-70.81,19.88],[-70.21,19.62],[-69.22,19.31],[-68.32,18.61],[-69.16,18.42],[-70.13,18.25],[-71,18.28],[-71.4,17.6],[-72.37,18.21],[-73.45,18.22],[-74.46,18.34],[-73.45,18.53],[-72.69,18.45],[-72.78,19.48],[-73.19,19.92]],[[-79.68,22.77],[-78.35,22.51],[-77.15,21.66],[-76.52,21.21],[-75.6,21.02],[-74.93,20.69],[-74.18,20.28],[-74.96,19.92],[-76.32,19.95],[-77.76,19.86],[-77.09,20.41],[-78.14,20.74],[-78.72,21.6],[-80.22,21.83],[-81.82,22.19],[-82.78,22.69],[-83.49,22.17],[-84.05,21.91],[-84.97,21.9],[-84.45,22.2],[-83.78,22.79],[-82.51,23.08],[-81.4,23.12],[-79.68,22.77]],[[140.98,37.14],[140.6,36.34],[140.25,35.14],[138.98,34.67],[137.22,34.61],[135.79,33.46],[135.12,33.85],[133.34,34.38],[132.16,33.9],[130.99,33.89],[132,33.15],[131.33,31.45],[130.69,31.03],[130.2,31.42],[130.45,32.32],[129.81,32.61],[129.41,33.3],[130.35,33.6],[130.88,34.23],[131.88,34.75],[132.62,35.43],[134.61,35.73],[135.68,35.53],[136.72,37.3],[137.39,36.83],[138.86,37.83],[139.43,38.22],[140.05,39.44],[139.88,40.56],[140.31,41.2],[141.37,41.38],[141.91,39.99],[141.88,39.18],[140.96,38.17],[140.98,37.14]],[[143.91,44.17],[144.61,43.96],[145.32,44.38],[145.54,43.26],[144.06,42.99],[143.18,42],[141.61,42.68],[141.07,41.58],[139.96,41.57],[139.82,42.56],[140.31,43.33],[141.38,43.39],[141.67,44.77],[141.97,45.55],[143.14,44.51],[143.91,44.17]],[[-56.13,50.69],[-56.8,49.81],[-56.14,50.15],[-55.47,49.94],[-54.94,49.31],[-53.48,49.25],[-53.79,48.52],[-53.09,48.69],[-52.65,47.54],[-53.07,46.66],[-54.18,46.81],[-53.96,47.63],[-55.4,46.88],[-56.25,47.63],[-57.33,47.57],[-59.27,47.6],[-58.8,48.25],[-58.39,49.13],[-57.36,50.72],[-56.74,51.29],[-55.87,51.63],[-56.13,50.69]],[[143.65,50.75],[144.65,48.98],[143.17,49.31],[142.56,47.86],[143.53,46.84],[142.75,46.74],[142.09,45.97],[141.91,46.81],[142.02,47.78],[141.9,48.86],[142.14,49.62],[142.18,50.95],[141.59,51.94],[141.68,53.3],[142.61,53.76],[142.21,54.23],[142.91,53.7],[143.26,52.74],[143.24,51.76],[143.65,50.75]],[[-6.79,52.26],[-8.56,51.67],[-9.98,51.82],[-9.17,52.86],[-9.69,53.88],[-8.33,54.66],[-7.57,55.13],[-6.73,55.17],[-5.66,54.55],[-6.2,53.87],[-6.03,53.15],[-6.79,52.26]],[[-3.01,58.64],[-4.07,57.55],[-3.06,57.69],[-1.96,57.68],[-2.22,56.87],[-3.12,55.97],[-2.09,55.91],[-1.11,54.62],[-0.43,54.46],[0.18,53.33],[1.68,52.74],[1.05,51.81],[1.45,51.29],[0.55,50.77],[-0.79,50.77],[-2.49,50.5],[-3.62,50.23],[-4.54,50.34],[-5.25,49.96],[-4.31,51.21],[-3.41,51.43],[-4.98,51.59],[-4.22,52.3],[-4.77,52.84],[-4.58,53.5],[-3.09,53.4],[-3.63,54.62],[-4.84,54.79],[-4.72,55.51],[-5.59,55.31],[-5.64,56.28],[-6.15,56.79],[-5.79,57.82],[-5.01,58.63],[-4.21,58.55],[-3.01,58.64]],[[-85.16,65.66],[-84.46,65.37],[-83.88,65.11],[-82.79,64.77],[-81.64,64.46],[-80.82,64.06],[-80.1,63.73],[-80.99,63.41],[-82.55,63.65],[-83.11,64.1],[-84.1,63.57],[-85.52,63.05],[-85.87,63.64],[-87.22,63.54],[-86.35,64.04],[-86.22,64.82],[-85.88,65.74],[-85.16,65.66]],[[-14.51,66.46],[-14.74,65.81],[-13.61,65.13],[-14.91,64.36],[-17.79,63.68],[-18.66,63.5],[-19.97,63.64],[-22.76,63.96],[-21.78,64.4],[-23.96,64.89],[-22.18,65.08],[-24.33,65.61],[-23.65,66.26],[-22.13,66.41],[-20.58,65.73],[-19.06,66.28],[-17.8,65.99],[-16.17,66.53],[-14.51,66.46]],[[-175.01,66.58],[-174.34,66.34],[-174.57,67.06],[-171.86,66.91],[-169.9,65.98],[-170.89,65.54],[-172.53,65.44],[-172.56,64.46],[-173.89,64.28],[-174.65,64.63],[-175.98,64.92],[-177.22,65.52],[-178.36,65.39],[-178.9,65.74],[-179.88,65.87],[-179.43,65.4],[-180,64.98],[-180,68.96],[-177.55,68.2],[-174.93,67.21]],[[-90.55,69.5],[-90.55,68.48],[-89.22,69.26],[-88.02,68.62],[-88.32,67.87],[-87.35,67.2],[-86.31,67.92],[-85.58,68.78],[-85.52,69.88],[-84.1,69.81],[-82.62,69.66],[-81.28,69.16],[-81.96,68.13],[-81.26,67.6],[-83.34,66.41],[-84.74,66.26],[-85.77,66.56],[-86.07,66.06],[-87.03,65.21],[-88.48,64.1],[-89.91,64.03],[-90.7,63.61],[-91.93,62.84],[-93.16,62.02],[-94.24,60.9],[-94.63,60.11],[-94.68,58.95],[-93.22,58.78],[-92.76,57.85],[-92.3,57.09],[-90.9,57.28],[-89.04,56.85],[-88.04,56.47],[-87.32,56],[-86.07,55.72],[-85.01,55.3],[-83.36,55.24],[-82.27,55.15],[-82.44,54.28],[-82.13,53.28],[-81.4,52.16],[-79.91,51.21],[-79.14,51.53],[-78.6,52.56],[-79.12,54.14],[-79.83,54.67],[-78.23,55.14],[-77.1,55.84],[-76.54,56.53],[-77.3,58.05],[-78.52,58.8],[-77.34,59.85],[-77.77,60.76],[-78.11,62.32],[-77.41,62.55],[-75.7,62.28],[-74.67,62.18],[-73.84,62.44],[-72.91,62.11],[-71.68,61.53],[-69.59,61.06],[-69.62,60.22],[-69.29,58.96],[-68.37,58.8],[-67.65,58.21],[-66.2,58.77],[-65.25,59.87],[-64.58,60.34],[-63.8,59.44],[-62.5,58.17],[-61.4,56.97],[-61.8,56.34],[-60.47,55.78],[-59.57,55.2],[-57.98,54.95],[-57.33,54.63],[-56.94,53.78],[-56.16,53.65],[-55.68,52.15],[-56.41,51.77],[-57.13,51.42],[-58.77,51.06],[-60.03,50.24],[-61.72,50.08],[-63.86,50.29],[-65.36,50.3],[-66.4,50.23],[-67.24,49.51],[-68.51,49.07],[-69.95,47.74],[-71.1,46.82],[-70.26,46.99],[-68.65,48.3],[-66.55,49.13],[-65.06,49.23],[-64.17,48.74],[-65.12,48.07],[-64.8,46.99],[-64.47,46.24],[-63.17,45.74],[-61.52,45.88],[-60.52,47.01],[-59.8,45.92],[-61.04,45.27],[-63.25,44.67],[-64.25,44.27],[-65.36,43.55],[-66.12,43.62],[-66.16,44.47],[-64.43,45.29],[-66.03,45.26],[-67.14,45.14],[-68.03,44.33],[-69.06,43.98],[-70.12,43.68],[-70.69,43.03],[-70.83,42.34],[-70.49,41.81],[-71.12,41.49],[-71.86,41.32],[-72.88,41.22],[-73.71,40.93],[-72.24,41.12],[-73.34,40.63],[-74.26,40.47],[-74.18,39.71],[-74.91,38.94],[-75.53,39.5],[-75.08,38.78],[-75.38,38.02],[-75.94,37.22],[-75.72,37.94],[-76.23,38.32],[-76.35,39.15],[-76.33,38.08],[-76.26,36.97],[-75.87,36.55],[-75.73,35.55],[-76.36,34.81],[-77.4,34.51],[-78.05,33.93],[-79.06,33.49],[-80.3,32.51],[-80.86,32.03],[-81.34,31.44],[-81.49,30.73],[-81.31,30.04],[-80.98,29.18],[-80.54,28.47],[-80.06,26.88],[-80.13,25.82],[-80.38,25.21],[-81.33,25.64],[-82.24,26.73],[-82.71,27.5],[-82.65,28.55],[-82.93,29.1],[-83.71,29.94],[-85.11,29.64],[-85.77,30.15],[-86.4,30.4],[-87.53,30.27],[-88.42,30.38],[-89.18,30.32],[-89.43,29.49],[-90.15,29.12],[-91.63,29.68],[-92.5,29.55],[-93.23,29.78],[-94.69,29.48],[-95.6,28.74],[-96.59,28.31],[-97.14,27.83],[-97.38,26.69],[-97.14,25.87],[-97.53,24.99],[-97.7,24.27],[-97.78,22.93],[-97.7,21.9],[-97.19,20.64],[-96.53,19.89],[-96.29,19.32],[-95.9,18.83],[-94.84,18.56],[-94.43,18.14],[-93.55,18.42],[-92.79,18.52],[-92.04,18.7],[-91.41,18.88],[-90.77,19.28],[-90.53,19.87],[-90.45,20.71],[-89.6,21.26],[-88.54,21.49],[-87.66,21.46],[-86.81,21.33],[-87.38,20.26],[-87.62,19.65],[-87.84,18.26],[-88.29,17.64],[-88.36,16.53],[-88.93,15.89],[-88.22,15.73],[-87.37,15.85],[-86.44,15.78],[-85.68,15.95],[-84.53,15.86],[-83.77,15.42],[-83.15,15],[-83.41,13.97],[-83.55,13.13],[-83.63,12.32],[-83.86,11.37],[-83.4,10.4],[-82.55,9.57],[-82.21,9],[-81.44,8.79],[-80.52,9.11],[-79.91,9.31],[-79.02,9.55],[-78.06,9.25],[-77.35,8.67],[-76.09,9.34],[-75.66,9.77],[-75.48,10.62],[-74.91,11.08],[-74.2,11.31],[-73.41,11.23],[-72.63,11.73],[-71.75,12.44],[-71.14,12.11],[-71.95,11.42],[-71.63,10.45],[-72.07,9.87],[-71.7,9.07],[-71.04,9.86],[-71.4,10.97],[-70.16,11.38],[-69.94,12.16],[-69.58,11.46],[-68.23,10.89],[-67.3,10.55],[-66.23,10.65],[-65.66,10.2],[-64.89,10.08],[-64.33,10.39],[-63.08,10.7],[-61.88,10.72],[-62.73,10.42],[-62.39,9.95],[-61.59,9.87],[-60.83,9.38],[-60.67,8.58],[-59.76,8.37],[-59.1,8],[-58.48,7.35],[-58.08,6.81],[-57.54,6.32],[-55.95,5.77],[-55.03,6.03],[-53.96,5.76],[-52.88,5.41],[-51.82,4.57],[-51.32,4.2],[-51.07,3.65],[-50.51,1.9],[-49.95,1.05],[-50.7,0.22],[-48.62,-0.24],[-48.58,-1.24],[-47.82,-0.58],[-46.57,-0.94],[-44.91,-1.55],[-44.42,-2.14],[-43.42,-2.38],[-41.47,-2.91],[-39.98,-2.87],[-38.5,-3.7],[-37.22,-4.82],[-36.45,-5.11],[-35.6,-5.15],[-34.9,-6.74],[-35.13,-9],[-35.64,-9.65],[-37.05,-11.04],[-37.68,-12.17],[-38.42,-13.04],[-38.95,-13.79],[-38.88,-15.67],[-39.16,-17.21],[-39.58,-18.26],[-39.76,-19.6],[-40.77,-20.9],[-40.94,-21.94],[-41.75,-22.37],[-41.99,-22.97],[-43.07,-22.97],[-44.65,-23.35],[-45.35,-23.8],[-46.47,-24.09],[-47.65,-24.89],[-48.5,-25.88],[-48.64,-26.62],[-48.66,-28.19],[-49.59,-29.22],[-50.7,-30.98],[-51.58,-31.78],[-52.26,-32.25],[-52.71,-33.2],[-53.37,-33.77],[-53.81,-34.4],[-54.94,-34.95],[-55.67,-34.75],[-57.14,-34.43],[-58.43,-33.91],[-57.23,-35.29],[-57.36,-35.98],[-56.74,-36.41],[-57.75,-38.18],[-59.23,-38.72],[-61.24,-38.93],[-62.34,-38.83],[-62.13,-39.42],[-62.33,-40.17],[-62.75,-41.03],[-63.77,-41.17],[-64.73,-40.8],[-64.98,-42.06],[-64.3,-42.36],[-63.76,-42.04],[-63.46,-42.56],[-64.38,-42.87],[-65.18,-43.5],[-65.33,-44.5],[-66.51,-45.04],[-67.29,-45.55],[-67.58,-46.3],[-66.6,-47.03],[-65.64,-47.24],[-65.99,-48.13],[-67.17,-48.7],[-67.82,-49.87],[-68.73,-50.26],[-69.14,-50.73],[-68.82,-51.77],[-68.15,-52.35],[-69.46,-52.29],[-70.85,-52.9],[-71.01,-53.83],[-72.56,-53.53],[-73.7,-52.84],[-74.95,-52.26],[-75.26,-51.63],[-74.98,-51.04],[-75.48,-50.38],[-75.61,-48.67],[-75.18,-47.71],[-74.13,-46.94],[-75.64,-46.65],[-74.69,-45.76],[-74.35,-44.1],[-73.24,-44.45],[-72.72,-42.38],[-73.39,-42.12],[-73.7,-43.37],[-74.02,-41.79],[-73.68,-39.94],[-73.22,-39.26],[-73.51,-38.28],[-73.59,-37.16],[-72.55,-35.51],[-71.86,-33.91],[-71.44,-32.42],[-71.67,-30.92],[-71.37,-30.1],[-71.49,-28.86],[-70.91,-27.64],[-70.72,-25.71],[-70.4,-23.63],[-70.09,-21.39],[-70.16,-19.76],[-70.37,-18.35],[-71.38,-17.77],[-73.44,-16.36],[-75.24,-15.27],[-76.01,-14.65],[-76.42,-13.82],[-77.11,-12.22],[-78.09,-10.38],[-79.04,-8.39],[-79.45,-7.93],[-79.76,-7.19],[-80.54,-6.54],[-81.25,-6.14],[-81.41,-4.74],[-81.1,-4.04],[-80.3,-3.4],[-79.77,-2.66],[-80.97,-2.25],[-80.93,-1.06],[-80.4,-0.28],[-80.02,0.36],[-79.54,0.98],[-78.86,1.38],[-78.66,2.27],[-77.93,2.7],[-77.51,3.33],[-77.13,3.85],[-77.31,4.67],[-77.53,5.58],[-77.48,6.69],[-77.88,7.22],[-78.43,8.05],[-78.62,8.72],[-79.56,8.93],[-80.16,8.33],[-80,7.55],[-80.89,7.22],[-81.52,7.71],[-82.13,8.18],[-82.82,8.29],[-83.51,8.45],[-83.91,9.29],[-84.65,9.62],[-85.34,9.83],[-85.79,10.44],[-86.06,11.4],[-86.53,11.81],[-87.17,12.46],[-87.67,12.91],[-88.48,13.16],[-89.26,13.46],[-90.1,13.74],[-91.23,13.93],[-92.23,14.54],[-93.36,15.62],[-93.88,15.94],[-94.69,16.2],[-96.05,15.75],[-97.26,15.92],[-98.01,16.11],[-98.95,16.57],[-99.7,16.71],[-100.83,17.17],[-101.67,17.65],[-102.48,17.98],[-103.5,18.29],[-103.92,18.75],[-104.99,19.32],[-105.49,19.95],[-105.5,20.82],[-105.27,21.42],[-105.69,22.27],[-106.03,22.77],[-106.91,23.77],[-107.92,24.55],[-108.4,25.17],[-109.26,25.58],[-109.29,26.44],[-110.39,27.16],[-110.64,27.86],[-111.76,28.47],[-112.23,28.95],[-112.81,30.02],[-113.16,30.79],[-113.87,31.57],[-114.78,31.8],[-114.77,30.91],[-114.67,30.16],[-113.59,29.06],[-113.14,28.41],[-112.76,27.78],[-112.24,27.17],[-111.62,26.66],[-111.28,25.73],[-110.71,24.83],[-110.17,24.27],[-109.77,23.81],[-109.41,23.36],[-109.85,22.82],[-110.29,23.43],[-110.95,24],[-111.67,24.48],[-112.15,25.47],[-112.78,26.32],[-113.46,26.77],[-114.47,27.14],[-115.06,27.72],[-114.2,28.12],[-114.93,29.28],[-115.52,29.56],[-115.89,30.18],[-116.26,30.84],[-116.72,31.64],[-117.13,32.54],[-117.94,33.62],[-118.52,34.03],[-119.44,34.35],[-120.37,34.45],[-120.74,35.16],[-121.71,36.16],[-122.55,37.55],[-122.95,38.11],[-123.73,38.95],[-123.87,39.77],[-124.4,40.31],[-124.18,41.14],[-124.21,42],[-124.53,42.77],[-124.14,43.71],[-123.9,45.52],[-124.08,46.86],[-124.4,47.72],[-124.57,48.38],[-123.12,48.04],[-122.59,47.1],[-122.5,48.18],[-122.84,49],[-124.91,49.98],[-125.62,50.42],[-127.44,50.83],[-127.99,51.72],[-129.13,52.76],[-129.31,53.56],[-130.51,54.29],[-131.09,55.18],[-131.97,55.5],[-132.25,56.37],[-133.54,57.18],[-134.08,58.12],[-135.04,58.19],[-136.63,58.21],[-137.8,58.5],[-139.87,59.54],[-140.83,59.73],[-142.57,60.08],[-143.96,60],[-145.93,60.46],[-147.11,60.88],[-148.22,60.67],[-148.02,59.98],[-149.73,59.71],[-150.61,59.37],[-151.72,59.16],[-151.41,60.73],[-150.35,61.03],[-151.9,60.73],[-152.58,60.06],[-154.02,59.35],[-153.29,58.86],[-154.23,58.15],[-155.31,57.73],[-156.31,57.42],[-158.12,56.46],[-159.6,55.57],[-161.22,55.36],[-162.24,55.02],[-163.07,54.69],[-164.79,54.4],[-163.85,55.04],[-162.87,55.35],[-161.8,55.9],[-160.56,56.01],[-160.07,56.42],[-158.68,57.02],[-157.72,57.57],[-157.55,58.33],[-157.04,58.92],[-158.19,58.62],[-159.06,58.42],[-159.71,58.93],[-161.35,58.67],[-162.05,59.27],[-162.52,59.99],[-163.82,59.8],[-164.66,60.27],[-165.35,60.51],[-166.12,61.5],[-165.73,62.08],[-164.92,62.63],[-164.56,63.15],[-163.75,63.22],[-163.07,63.06],[-162.26,63.54],[-161.53,63.46],[-160.77,63.77],[-161.52,64.4],[-160.78,64.79],[-162.45,64.56],[-163.55,64.56],[-164.96,64.45],[-166.43,64.69],[-166.84,65.09],[-168.11,65.67],[-166.71,66.09],[-164.47,66.58],[-163.65,66.58],[-161.68,66.12],[-162.49,66.74],[-163.72,67.12],[-164.43,67.62],[-165.39,68.04],[-166.76,68.36],[-166.2,68.88],[-164.43,68.92],[-163.17,69.37],[-161.91,70.33],[-160.93,70.45],[-159.04,70.89],[-158.12,70.82],[-156.58,71.36],[-155.07,71.15],[-154.34,70.7],[-152.21,70.83],[-150.74,70.43],[-149.72,70.53],[-147.61,70.21],[-145.69,70.12],[-144.92,69.99],[-143.59,70.15],[-142.07,69.85],[-140.99,69.71],[-139.12,69.47],[-137.55,68.99],[-136.5,68.9],[-135.63,69.32],[-134.41,69.63],[-132.93,69.51],[-131.43,69.94],[-129.79,70.19],[-129.11,69.78],[-128.36,70.01],[-127.45,70.38],[-125.76,69.48],[-124.42,70.16],[-124.29,69.4],[-123.06,69.56],[-121.47,69.8],[-119.94,69.38],[-117.6,69.01],[-116.23,68.84],[-115.25,68.91],[-113.9,68.4],[-115.3,67.9],[-113.5,67.69],[-110.8,67.81],[-109.95,67.98],[-108.88,67.38],[-107.79,67.89],[-108.81,68.31],[-108.17,68.65],[-106.95,68.7],[-106.15,68.8],[-105.34,68.56],[-104.34,68.02],[-103.22,68.1],[-101.45,67.65],[-99.9,67.81],[-98.44,67.78],[-97.67,68.58],[-96.12,68.24],[-96.13,67.29],[-95.49,68.09],[-94.68,68.06],[-94.23,69.07],[-95.3,69.69],[-96.47,70.09],[-96.39,71.19],[-95.21,71.92],[-93.89,71.76],[-92.88,71.32],[-91.52,70.19],[-92.41,69.7],[-90.55,69.5]],[[-114.17,73.12],[-114.67,72.65],[-112.44,72.96],[-111.05,72.45],[-109.92,72.96],[-109.01,72.63],[-108.19,71.65],[-107.69,72.07],[-108.4,73.09],[-107.52,73.24],[-106.52,73.08],[-105.4,72.67],[-104.77,71.7],[-104.46,70.99],[-102.79,70.5],[-100.98,70.02],[-102.73,69.5],[-102.09,69.12],[-104.24,68.91],[-105.96,69.18],[-107.12,69.12],[-109,68.78],[-111.97,68.6],[-113.31,68.54],[-113.85,69.01],[-115.22,69.28],[-116.11,69.17],[-117.34,69.96],[-115.13,70.24],[-113.72,70.19],[-112.42,70.37],[-114.35,70.6],[-116.49,70.52],[-117.9,70.54],[-118.43,70.91],[-116.11,71.31],[-117.66,71.3],[-119.4,71.56],[-118.56,72.31],[-117.87,72.71],[-115.19,73.31],[-114.17,73.12]],[[-86.56,73.16],[-85.77,72.53],[-84.85,73.34],[-82.32,73.75],[-80.6,72.72],[-80.75,72.06],[-78.77,72.35],[-77.82,72.75],[-75.61,72.24],[-74.23,71.77],[-72.24,71.56],[-71.2,70.92],[-68.79,70.53],[-67.91,70.12],[-66.97,69.19],[-68.81,68.72],[-66.45,68.07],[-64.86,67.85],[-63.42,66.93],[-61.85,66.86],[-62.16,66.16],[-63.92,65],[-65.15,65.43],[-66.72,66.39],[-68.02,66.26],[-67.09,65.11],[-65.73,64.65],[-64.67,63.39],[-65.01,62.67],[-66.28,62.95],[-68.78,63.75],[-67.37,62.88],[-66.33,62.28],[-68.88,62.33],[-71.02,62.91],[-72.24,63.4],[-73.38,64.19],[-74.83,64.68],[-77.71,64.23],[-78.56,64.57],[-77.9,65.31],[-76.02,65.33],[-73.96,65.45],[-73.94,66.31],[-72.65,67.28],[-73.31,68.07],[-74.84,68.55],[-76.87,68.89],[-76.23,69.15],[-77.29,69.77],[-78.17,69.83],[-78.96,70.17],[-79.49,69.87],[-81.31,69.74],[-84.94,69.97],[-87.06,70.26],[-88.68,70.41],[-89.51,70.76],[-88.47,71.22],[-89.89,71.22],[-90.21,72.24],[-89.44,73.13],[-88.41,73.54],[-85.83,73.8],[-86.56,73.16]],[[-100.36,73.84],[-99.16,73.63],[-97.38,73.76],[-98.05,72.99],[-96.54,72.56],[-96.72,71.66],[-98.36,71.27],[-99.32,71.36],[-100.01,71.74],[-102.5,72.51],[-100.44,72.71],[-101.54,73.36],[-100.36,73.84]],[[-93.2,72.77],[-94.27,72.02],[-95.41,72.06],[-96.03,72.94],[-95.5,73.86],[-94.5,74.13],[-92.42,74.1],[-90.51,73.86],[-92,72.97],[-93.2,72.77]],[[-120.46,71.4],[-123.09,70.9],[-123.62,71.34],[-125.93,71.87],[-124.81,73.02],[-123.94,73.68],[-124.92,74.29],[-121.54,74.45],[-120.11,74.24],[-117.56,74.19],[-116.58,73.9],[-115.51,73.48],[-116.77,73.22],[-119.22,72.52],[-120.46,71.82]],[[145.09,75.56],[144.3,74.82],[140.61,74.85],[138.96,74.61],[136.97,75.26],[137.51,75.95],[138.83,76.14],[141.47,76.09],[145.09,75.56]],[[-98.5,76.72],[-97.74,76.26],[-98.16,75],[-99.81,74.9],[-100.88,75.06],[-102.5,75.56],[-102.57,76.34],[-101.49,76.31],[-99.98,76.65],[-98.58,76.59]],[[-108.21,76.2],[-106.93,76.01],[-105.88,75.97],[-106.31,75.01],[-109.7,74.85],[-112.22,74.42],[-113.74,74.39],[-111.79,75.16],[-116.31,75.04],[-117.71,75.22],[-116.35,76.2],[-115.4,76.48],[-112.59,76.14],[-110.81,75.55],[-109.07,75.47],[-110.5,76.43],[-109.58,76.79],[-108.55,76.68],[-108.21,76.2]],[[57.54,70.72],[53.68,70.76],[51.6,71.47],[52.48,72.23],[54.43,73.63],[53.51,73.75],[55.9,74.63],[57.87,75.61],[61.17,76.25],[64.5,76.44],[66.21,76.81],[68.16,76.94],[68.85,76.54],[68.18,76.23],[64.64,75.74],[61.58,75.26],[58.48,74.31],[56.99,73.33],[55.42,72.37],[55.62,71.54],[57.54,70.72]],[[-94.68,77.1],[-93.57,76.78],[-91.61,76.78],[-90.74,76.45],[-89.82,75.85],[-89.19,75.61],[-87.84,75.57],[-86.38,75.48],[-84.79,75.7],[-82.75,75.78],[-81.13,75.71],[-80.06,75.34],[-80.46,74.66],[-81.95,74.44],[-83.23,74.56],[-86.1,74.41],[-88.15,74.39],[-89.76,74.52],[-92.42,74.84],[-92.77,75.39],[-93.89,76.32],[-95.96,76.44],[-97.12,76.75],[-94.68,77.1]],[[-116.2,77.65],[-116.34,76.88],[-117.11,76.53],[-118.04,76.48],[-119.9,76.05],[-121.5,75.9],[-122.85,76.12],[-121.16,76.86],[-119.1,77.51],[-117.57,77.5],[-116.2,77.65]],[[106.97,76.97],[108.15,76.72],[111.08,76.71],[113.33,76.22],[114.13,75.85],[112.78,75.03],[110.15,74.48],[109.4,74.18],[110.64,74.04],[112.12,73.79],[113.02,73.98],[113.53,73.34],[115.57,73.75],[118.78,73.59],[123.2,72.97],[123.26,73.74],[125.38,73.56],[126.98,73.57],[128.59,73.04],[129.05,72.4],[128.46,71.98],[129.72,71.19],[131.29,70.79],[132.25,71.84],[133.86,71.39],[135.56,71.66],[137.5,71.35],[138.23,71.63],[139.87,71.49],[139.15,72.42],[140.47,72.85],[149.5,72.2],[150.35,71.61],[152.97,70.84],[157.01,71.03],[159,70.87],[159.83,70.45],[159.71,69.72],[160.94,69.44],[162.28,69.64],[164.05,69.67],[165.94,69.47],[167.84,69.58],[169.58,68.69],[170.82,69.01],[170.01,69.65],[170.45,70.1],[173.64,69.82],[175.72,69.88],[178.6,69.4],[180,68.96],[180,64.98],[178.71,64.53],[177.41,64.61],[178.31,64.08],[178.91,63.25],[179.49,62.57],[177.36,62.52],[174.57,61.77],[173.68,61.65],[172.15,60.95],[170.7,60.34],[170.33,59.88],[168.9,60.57],[166.3,59.79],[165.84,60.16],[164.88,59.73],[163.54,59.87],[163.22,59.21],[162.02,58.24],[163.19,57.62],[163.06,56.16],[162.13,56.12],[161.7,55.29],[162.12,54.86],[160.37,54.34],[160.02,53.2],[158.53,52.96],[158.23,51.94],[156.79,51.01],[156.42,51.7],[155.99,53.16],[155.43,55.38],[155.91,56.77],[156.76,57.36],[158.36,58.06],[160.15,59.31],[161.87,60.34],[163.67,61.14],[164.47,62.55],[163.26,62.47],[162.66,61.64],[160.12,60.54],[159.3,61.77],[156.72,61.43],[154.22,59.76],[155.04,59.15],[152.81,58.88],[151.27,58.78],[149.78,59.66],[148.54,59.16],[145.49,59.34],[142.2,59.04],[138.96,57.09],[135.13,54.73],[136.7,54.6],[137.19,53.98],[138.16,53.76],[138.8,54.25],[139.9,54.19],[141.35,53.09],[141.38,52.24],[140.6,51.24],[140.51,50.05],[140.06,48.45],[138.55,47],[138.22,46.31],[136.86,45.14],[135.52,43.99],[134.87,43.4],[133.54,42.81],[132.28,43.28],[130.94,42.55],[130.4,42.28],[129.67,41.6],[129.19,40.66],[128.63,40.19],[127.97,40.03],[127.5,39.32],[128.35,38.61],[129.21,37.43],[129.46,36.78],[129.47,35.63],[129.09,35.08],[128.19,34.89],[127.39,34.48],[126.49,34.39],[126.56,35.68],[126.12,36.73],[126.86,36.89],[126.17,37.75],[125.28,37.67],[124.71,38.11],[125.22,38.67],[125.39,39.39],[124.74,39.66],[122.87,39.64],[122.13,39.17],[121.05,38.9],[121.59,39.36],[122.17,40.42],[121.64,40.95],[120.77,40.59],[119.64,39.9],[119.02,39.25],[118.04,39.2],[117.53,38.74],[118.06,38.06],[118.88,37.9],[119.7,37.16],[120.82,37.87],[121.71,37.48],[122.52,36.93],[121.1,36.65],[120.64,36.11],[119.66,35.61],[119.15,34.91],[120.23,34.36],[120.62,33.38],[121.23,32.46],[121.91,31.69],[121.26,30.68],[122.09,29.83],[121.94,29.02],[121.68,28.23],[120.4,27.05],[119.59,25.74],[118.66,24.55],[117.28,23.62],[115.89,22.78],[114.76,22.67],[114.15,22.22],[113.24,22.05],[111.84,21.55],[110.79,21.4],[110.44,20.34],[109.63,21.01],[108.52,21.72],[106.72,20.7],[105.88,19.75],[105.66,19.06],[106.43,18],[107.36,16.7],[108.27,16.08],[108.88,15.28],[109.34,13.43],[109.2,11.67],[108.37,11.01],[107.22,10.36],[106.41,9.53],[105.16,8.6],[104.8,9.24],[105.08,9.92],[104.33,10.49],[103.5,10.63],[103.09,11.15],[102.59,12.19],[101.69,12.65],[100.83,12.63],[100.98,13.41],[100.1,13.41],[100.02,12.31],[99.48,10.85],[99.15,9.96],[99.87,9.21],[100.28,8.3],[100.46,7.43],[101.02,6.86],[102.14,6.22],[102.96,5.52],[103.38,4.86],[103.33,3.73],[103.5,2.79],[104.25,1.63],[103.52,1.23],[102.57,1.97],[101.39,2.76],[100.7,3.94],[100.56,4.77],[100.2,5.31],[100.31,6.04],[99.69,6.85],[98.99,7.91],[98.5,8.38],[98.26,8.97],[98.55,9.93],[98.46,10.68],[98.76,11.44],[98.43,12.03],[98.51,13.12],[98.1,13.64],[97.78,14.84],[97.6,16.1],[97.16,16.93],[96.51,16.43],[95.37,15.71],[94.19,16.04],[94.53,17.28],[94.32,18.21],[93.54,19.37],[93.08,19.86],[92.37,20.67],[92.08,21.19],[91.83,22.18],[91.42,22.77],[90.5,22.81],[90.27,21.84],[89.42,21.97],[88.89,21.69],[86.98,21.5],[87.03,20.74],[86.5,20.15],[85.06,19.48],[83.94,18.3],[83.19,17.67],[82.19,17.02],[81.69,16.31],[80.79,15.95],[80.03,15.14],[80.23,13.84],[80.29,13.01],[79.86,12.06],[79.86,10.36],[78.89,9.55],[78.28,8.93],[77.94,8.25],[76.59,8.9],[76.13,10.3],[75.75,11.31],[75.4,11.78],[74.86,12.74],[74.62,13.99],[73.53,15.99],[73.12,17.93],[72.82,19.21],[72.82,20.42],[72.63,21.36],[71.18,20.76],[70.47,20.88],[69.16,22.09],[69.64,22.45],[68.18,23.69],[67.44,23.94],[67.15,24.66],[66.37,25.43],[64.53,25.24],[62.91,25.22],[61.5,25.08],[59.62,25.38],[58.53,25.61],[57.4,25.74],[56.97,26.97],[55.72,26.96],[54.72,26.48],[53.49,26.81],[52.48,27.58],[51.52,27.87],[50.85,28.81],[50.12,30.15],[48.94,30.32],[47.97,29.98],[48.42,28.55],[48.81,27.69],[49.47,27.11],[50.15,26.69],[50.24,25.61],[50.66,25],[51.01,26.01],[51.61,25.22],[51.39,24.63],[51.79,24.02],[52.58,24.18],[53.4,24.15],[54.69,24.8],[55.44,25.44],[56.07,26.06],[56.4,24.92],[56.85,24.24],[57.4,23.88],[58.14,23.75],[59.18,22.99],[59.81,22.53],[59.44,21.71],[58.86,21.11],[58.49,20.43],[57.83,20.24],[57.79,19.07],[56.61,18.57],[56.28,17.88],[55.27,17.63],[54.79,16.95],[53.57,16.71],[52.39,16.38],[52.17,15.6],[51.17,15.18],[49.57,14.71],[48.68,14],[47.35,13.59],[46.72,13.4],[45.88,13.35],[45.14,12.95],[44.49,12.72],[43.48,12.64],[43.22,13.22],[43.09,14.06],[42.89,14.8],[42.7,15.72],[42.65,16.77],[42.27,17.47],[41.75,17.83],[41.22,18.67],[40.94,19.49],[40.25,20.17],[39.14,21.29],[39.02,21.99],[38.49,23.69],[38.02,24.08],[37.15,24.86],[36.93,25.6],[36.25,26.57],[35.64,27.38],[35.13,28.06],[34.79,28.61],[34.96,29.36],[34.43,28.34],[33.92,27.65],[33.14,28.42],[32.42,29.85],[32.73,28.71],[33.35,27.7],[34.1,26.14],[34.47,25.6],[34.8,25.03],[35.69,23.93],[35.53,23.1],[36.69,22.2],[37.19,21.02],[37.11,19.81],[37.48,18.61],[38.41,18],[38.99,16.84],[39.27,15.92],[39.81,15.44],[41.18,14.49],[41.73,13.92],[42.28,13.34],[43.08,12.7],[43.29,11.97],[42.72,11.74],[43.47,11.28],[44.12,10.45],[45.56,10.7],[46.65,10.82],[47.53,11.13],[48.38,11.38],[49.27,11.43],[50.26,11.68],[50.73,12.02],[51.04,11.17],[50.83,10.28],[50.55,9.2],[50.07,8.08],[49.45,6.8],[48.59,5.34],[47.74,4.22],[46.56,2.86],[45.56,2.05],[44.07,1.05],[43.14,0.29],[42.04,-0.92],[41.59,-1.68],[40.88,-2.08],[40.26,-2.57],[40.12,-3.28],[39.6,-4.35],[38.74,-5.91],[39.44,-6.84],[39.19,-7.7],[39.54,-9.11],[39.95,-10.1],[40.48,-10.77],[40.44,-11.76],[40.56,-12.64],[40.6,-14.2],[40.48,-15.41],[40.09,-16.1],[39.45,-16.72],[38.54,-17.1],[37.41,-17.59],[36.28,-18.66],[35.2,-19.55],[34.7,-20.5],[35.18,-21.25],[35.39,-22.14],[35.53,-23.07],[35.46,-24.12],[34.22,-24.82],[33.01,-25.36],[32.57,-25.73],[32.92,-26.22],[32.58,-27.47],[32.46,-28.3],[31.52,-29.26],[30.9,-29.91],[30.06,-31.14],[28.93,-32.17],[28.22,-32.77],[27.46,-33.23],[26.42,-33.61],[25.78,-33.94],[24.68,-33.99],[23.59,-33.79],[22.57,-33.86],[21.54,-34.26],[20.69,-34.42],[20.07,-34.8],[19.19,-34.46],[18.42,-34],[18.25,-33.28],[17.93,-32.61],[18.22,-31.66],[17.57,-30.73],[17.06,-29.88],[16.35,-28.58],[15.6,-27.82],[15.21,-27.09],[14.99,-26.12],[14.74,-25.39],[14.41,-23.85],[14.39,-22.66],[13.87,-21.7],[13.35,-20.87],[12.83,-19.67],[12.61,-19.05],[11.79,-18.07],[11.73,-17.3],[11.78,-15.79],[12.12,-14.88],[12.5,-13.55],[13.31,-12.48],[13.74,-11.3],[13.39,-10.37],[13.12,-9.77],[12.88,-9.17],[13.24,-8.56],[12.93,-7.6],[12.73,-6.93],[12.23,-6.29],[11.92,-5.04],[11.09,-3.98],[10.07,-2.97],[9.41,-2.14],[8.8,-1.11],[9.05,-0.46],[9.29,0.27],[9.49,1.01],[9.65,2.28],[9.8,3.07],[9.4,3.73],[8.74,4.35],[7.46,4.41],[6.7,4.24],[5.9,4.26],[5.36,4.89],[5.03,5.61],[4.33,6.27],[2.69,6.26],[1.87,6.14],[1.06,5.93],[-0.51,5.34],[-1.06,5],[-1.96,4.71],[-2.86,4.99],[-4.01,5.18],[-5.83,4.99],[-6.53,4.71],[-7.52,4.34],[-9,4.83],[-9.91,5.59],[-10.77,6.14],[-11.44,6.79],[-12.43,7.26],[-12.95,7.8],[-13.25,8.9],[-13.69,9.49],[-14.33,10.02],[-14.69,10.66],[-15.13,11.04],[-15.66,11.46],[-16.31,11.81],[-16.68,12.38],[-16.84,13.15],[-17.13,14.37],[-17.63,14.73],[-16.7,15.62],[-16.55,16.67],[-16.15,18.11],[-16.26,19.1],[-16.28,20.09],[-17.06,21],[-16.97,21.89],[-16.26,22.68],[-15.98,23.72],[-15.43,24.36],[-14.82,25.1],[-14.44,26.25],[-13.77,26.62],[-13.14,27.64],[-12.62,28.04],[-11.69,28.15],[-10.9,28.83],[-9.56,29.93],[-9.81,31.18],[-9.43,32.04],[-8.66,33.24],[-7.65,33.7],[-6.91,34.11],[-6.24,35.15],[-5.93,35.76],[-4.59,35.33],[-3.64,35.4],[-2.6,35.18],[-1.21,35.71],[-0.13,35.89],[0.5,36.3],[1.47,36.61],[3.16,36.78],[4.82,36.87],[6.26,37.11],[7.33,37.12],[8.42,36.95],[9.51,37.35],[10.21,37.23],[11.03,37.09],[10.6,36.41],[10.94,35.7],[10.81,34.83],[10.15,34.33],[10.86,33.77],[11.49,33.14],[12.66,32.79],[13.92,32.71],[15.25,32.27],[15.71,31.38],[16.61,31.18],[18.02,30.76],[19.09,30.27],[20.05,30.99],[19.82,31.75],[20.13,32.24],[20.85,32.71],[21.54,32.84],[22.9,32.64],[23.61,32.19],[24.92,31.9],[26.5,31.59],[27.46,31.32],[28.45,31.03],[29.68,31.19],[30.98,31.56],[31.69,31.43],[32.99,31.02],[33.77,30.97],[34.56,31.55],[34.96,32.83],[35.48,33.91],[35.98,34.61],[35.91,35.41],[35.78,36.28],[34.71,36.8],[34.03,36.22],[32.51,36.11],[31.7,36.64],[30.62,36.68],[29.7,36.14],[28.73,36.68],[27.64,36.66],[27.05,37.65],[26.32,38.21],[26.8,38.99],[26.17,39.46],[27.28,40.42],[28.82,40.46],[29.24,41.22],[31.15,41.09],[32.35,41.74],[33.51,42.02],[35.17,42.04],[36.91,41.34],[38.35,40.95],[39.51,41.1],[40.37,41.01],[41.55,41.54],[41.45,42.65],[40.88,43.01],[39.96,43.44],[38.68,44.28],[37.54,44.66],[36.68,45.24],[37.4,45.4],[38.23,46.24],[37.67,46.64],[39.15,47.04],[38.22,47.1],[37.43,47.02],[36.76,46.7],[35.82,46.65],[34.96,46.27],[35.51,45.41],[36.53,45.47],[35.24,44.94],[33.88,44.36],[33.55,45.03],[32.45,45.33],[33.59,45.85],[31.74,46.33],[30.75,46.58],[30.38,46.03],[29.6,45.29],[29.14,44.82],[28.56,43.71],[28.04,43.29],[27.67,42.58],[28,42.01],[28.99,41.3],[27.62,41],[26.36,40.15],[26.06,40.82],[24.93,40.95],[23.71,40.69],[24.41,40.13],[23.34,39.96],[22.81,40.48],[22.85,39.66],[23.35,39.19],[23.53,38.51],[24.04,37.66],[23.12,37.92],[23.41,37.41],[23.15,36.42],[21.67,36.85],[21.3,37.65],[21.12,38.31],[20.73,38.77],[20.22,39.34],[19.96,39.92],[19.41,40.25],[19.4,41.41],[18.88,42.28],[17.51,42.85],[16.93,43.21],[16.02,43.51],[15.17,44.24],[14.9,45.08],[14.26,45.23],[13.68,45.48],[12.33,45.38],[12.26,44.6],[12.59,44.09],[13.53,43.59],[14.03,42.76],[15.14,41.96],[16.17,41.74],[16.79,41.18],[17.52,40.88],[18.38,40.36],[16.87,40.44],[16.45,39.8],[17.17,39.42],[16.64,38.84],[16.1,37.99],[15.89,38.75],[15.72,39.54],[15.41,40.05],[14.7,40.6],[14.06,40.79],[13.63,41.19],[12.89,41.25],[12.11,41.7],[11.19,42.36],[10.51,42.93],[10.2,43.92],[8.89,44.37],[7.85,43.77],[6.53,43.13],[4.56,43.4],[3.1,43.08],[3.04,41.89],[2.09,41.23],[0.81,41.01],[0.11,40.12],[-0.28,39.31],[0.11,38.74],[-0.47,38.29],[-0.68,37.64],[-1.44,37.44],[-2.15,36.67],[-3.42,36.66],[-4.37,36.68],[-5,36.32],[-5.87,36.03],[-6.52,36.94],[-7.45,37.1],[-8.38,36.98],[-8.75,37.65],[-9.29,38.36],[-9.45,39.39],[-8.98,40.16],[-8.77,40.76],[-8.99,41.54],[-8.98,42.59],[-9.39,43.03],[-7.98,43.75],[-6.75,43.57],[-5.41,43.57],[-4.35,43.4],[-3.52,43.46],[-1.9,43.42],[-1.38,44.02],[-1.19,46.01],[-2.23,47.06],[-2.96,47.57],[-4.49,47.96],[-4.59,48.68],[-3.3,48.9],[-1.62,48.64],[-1.93,49.78],[-0.99,49.35],[1.34,50.13],[1.64,50.95],[2.51,51.15],[3.32,51.35],[4.71,53.09],[6.07,53.51],[6.91,53.48],[7.94,53.75],[8.8,54.02],[8.53,54.96],[8.12,55.52],[8.09,56.54],[8.54,57.11],[9.42,57.17],[10.58,57.73],[10.25,56.89],[10.91,56.46],[10.37,56.19],[9.65,55.47],[9.94,54.6],[10.95,54.36],[11.96,54.2],[12.52,54.47],[13.65,54.08],[14.8,54.05],[16.36,54.51],[17.62,54.85],[18.62,54.68],[19.66,54.43],[21.27,55.19],[21.06,56.03],[21.58,57.41],[22.52,57.75],[23.32,57.01],[24.12,57.03],[24.31,57.79],[23.43,58.61],[24.6,59.47],[25.86,59.61],[26.95,59.45],[27.98,59.48],[29.12,60.03],[28.07,60.5],[26.26,60.42],[24.5,60.06],[22.87,59.85],[22.29,60.39],[21.32,60.72],[21.54,61.71],[21.06,62.61],[21.54,63.19],[22.44,63.82],[24.73,64.9],[25.4,65.11],[23.9,66.01],[22.18,65.72],[21.21,65.03],[19.78,63.61],[17.85,62.75],[17.12,61.34],[17.83,60.64],[18.79,60.08],[17.87,58.95],[16.83,58.72],[16.45,57.04],[15.88,56.1],[14.67,56.2],[14.1,55.41],[12.94,55.36],[12.63,56.31],[11.79,57.44],[11.03,58.86],[10.36,59.47],[8.38,58.31],[7.05,58.08],[5.67,58.59],[5.31,59.66],[4.99,61.97],[5.91,62.61],[8.55,63.45],[10.53,64.49],[12.36,65.88],[14.76,67.81],[16.44,68.56],[19.18,69.82],[21.38,70.26],[23.02,70.2],[24.55,71.03],[26.37,70.99],[28.17,71.19],[31.29,70.45],[30.01,70.19],[31.1,69.56],[32.13,69.91],[33.78,69.3],[36.51,69.06],[40.29,67.93],[41.06,67.46],[40.02,66.27],[38.38,66],[33.92,66.76],[33.18,66.63],[34.81,65.9],[34.94,64.41],[36.23,64.11],[37.01,63.85],[36.52,64.78],[37.18,65.14],[39.59,64.52],[40.44,64.76],[39.76,65.5],[42.09,66.48],[43.02,66.42],[43.95,66.07],[44.53,66.76],[43.7,67.35],[44.19,67.95],[43.45,68.57],[46.25,68.25],[46.82,67.69],[45.56,67.57],[46.35,66.67],[47.89,66.88],[48.14,67.52],[50.23,68],[53.72,68.86],[54.47,68.81],[53.49,68.2],[54.73,68.1],[55.44,68.44],[57.32,68.47],[58.8,68.88],[59.94,68.28],[61.08,68.94],[60.03,69.52],[60.55,69.85],[63.5,69.55],[64.89,69.23],[68.51,68.09],[69.18,68.62],[68.16,69.14],[66.93,69.45],[67.26,69.93],[66.72,70.71],[68.54,71.93],[69.2,72.84],[69.94,73.04],[72.59,72.78],[71.85,71.41],[72.47,71.09],[72.79,70.39],[72.56,69.02],[73.67,68.41],[73.24,67.74],[71.28,66.32],[72.42,66.17],[73.92,66.79],[75.05,67.76],[74.47,68.33],[74.94,68.99],[73.84,69.07],[74.4,70.63],[73.1,71.45],[74.89,72.12],[74.66,72.83],[75.68,72.3],[75.29,71.34],[76.36,71.15],[75.9,71.87],[77.58,72.27],[79.65,72.32],[81.5,71.75],[80.61,72.58],[80.51,73.65],[82.25,73.85],[84.66,73.81],[86.82,73.94],[86.01,74.46],[87.17,75.12],[88.32,75.14],[90.26,75.64],[92.9,75.77],[95.86,76.14],[96.68,75.92],[98.92,76.45],[100.76,76.43],[101.99,77.29],[104.35,77.7],[106.07,77.37],[104.71,77.13],[106.97,76.97]],[[18.25,79.7],[21.54,78.96],[19.03,78.56],[18.47,77.83],[17.59,77.64],[17.12,76.81],[15.91,76.77],[13.76,77.38],[14.67,77.74],[13.17,78.02],[11.22,78.87],[10.44,79.65],[13.17,80.01],[13.72,79.66],[15.14,79.67],[16.99,80.05],[18.25,79.7]],[[25.45,80.41],[27.41,80.06],[25.92,79.52],[23.02,79.4],[20.08,79.57],[18.46,79.86],[17.37,80.32],[20.46,80.6],[21.91,80.36],[22.92,80.66],[25.45,80.41]],[[99.94,78.88],[97.76,78.76],[94.97,79.04],[93.31,79.43],[92.55,80.14],[91.18,80.34],[93.78,81.02],[95.94,81.25],[97.88,80.75],[100.19,79.78],[99.94,78.88]],[[-87.02,79.66],[-85.81,79.34],[-87.19,79.04],[-89.04,78.29],[-90.8,78.22],[-92.88,78.34],[-93.95,78.75],[-93.15,79.38],[-94.97,79.37],[-96.08,79.71],[-96.71,80.16],[-96.02,80.6],[-95.32,80.91],[-94.3,80.98],[-92.41,81.26],[-91.13,80.72],[-89.45,80.51],[-87.81,80.32],[-87.02,79.66]],[[-68.5,83.11],[-65.83,83.03],[-63.68,82.9],[-61.85,82.63],[-64.33,81.93],[-66.75,81.73],[-67.66,81.5],[-65.48,81.51],[-67.84,80.9],[-69.47,80.62],[-71.18,79.8],[-73.24,79.63],[-73.88,79.43],[-76.91,79.32],[-75.53,79.2],[-76.22,79.02],[-75.39,78.53],[-76.34,78.18],[-77.89,77.9],[-78.36,77.51],[-79.76,77.21],[-77.91,77.02],[-80.56,76.18],[-83.17,76.45],[-86.11,76.3],[-87.6,76.42],[-89.49,76.47],[-87.77,77.18],[-88.26,77.9],[-84.98,77.54],[-86.34,78.18],[-87.96,78.37],[-87.15,78.76],[-85.38,79],[-86.51,79.74],[-86.93,80.25],[-84.2,80.21],[-83.41,80.1],[-81.85,80.46],[-84.1,80.58],[-87.6,80.52],[-89.37,80.86],[-90.2,81.26],[-91.37,81.55],[-90.1,82.08],[-88.93,82.12],[-86.97,82.28],[-85.5,82.65],[-84.26,82.6],[-83.18,82.32],[-82.42,82.86],[-81.1,83.02],[-79.31,83.13],[-76.25,83.17],[-72.83,83.23],[-70.67,83.17],[-68.5,83.11]],[[-27.1,83.52],[-20.85,82.73],[-22.69,82.34],[-26.52,82.3],[-31.9,82.2],[-27.86,82.13],[-24.84,81.79],[-22.9,82.09],[-22.07,81.73],[-23.17,81.15],[-20.62,81.52],[-15.77,81.91],[-12.77,81.72],[-12.21,81.29],[-16.29,80.58],[-20.05,80.18],[-17.73,80.13],[-18.9,79.4],[-19.7,78.75],[-19.67,77.64],[-18.47,76.99],[-20.04,76.94],[-21.68,76.63],[-19.83,76.1],[-19.6,75.25],[-20.67,75.16],[-19.37,74.3],[-21.59,74.22],[-20.43,73.82],[-22.17,73.31],[-23.57,73.31],[-22.31,72.63],[-24.28,72.6],[-23.44,72.08],[-22.13,71.47],[-21.75,70.66],[-23.54,70.47],[-24.31,70.86],[-25.54,71.43],[-25.2,70.75],[-26.36,70.23],[-23.73,70.18],[-22.35,70.13],[-25.03,69.26],[-27.75,68.47],[-30.67,68.13],[-31.78,68.12],[-32.81,67.74],[-34.2,66.68],[-36.35,65.98],[-38.38,65.69],[-39.81,65.46],[-40.67,64.84],[-41.19,63.48],[-42.82,62.68],[-42.42,61.9],[-42.87,61.07],[-43.38,60.1],[-44.79,60.04],[-46.26,60.85],[-48.26,60.86],[-49.23,61.41],[-49.9,62.38],[-51.63,63.63],[-52.14,64.28],[-52.28,65.18],[-53.66,66.1],[-53.3,66.84],[-53.97,67.19],[-52.98,68.36],[-51.48,68.73],[-51.08,69.15],[-50.87,69.93],[-52.01,69.57],[-53.46,69.28],[-54.68,69.61],[-54.36,70.82],[-53.43,70.84],[-51.39,70.57],[-53.11,71.2],[-54,71.55],[-55,71.41],[-55.83,71.65],[-54.72,72.59],[-55.33,72.96],[-56.12,73.65],[-57.32,74.71],[-58.6,75.1],[-61.27,76.1],[-63.39,76.18],[-66.06,76.13],[-68.5,76.06],[-69.66,76.38],[-71.4,77.01],[-68.78,77.32],[-66.76,77.38],[-71.04,77.64],[-73.3,78.04],[-69.37,78.91],[-65.71,79.39],[-68.02,80.12],[-67.15,80.52],[-63.69,81.21],[-62.23,81.32],[-62.65,81.77],[-60.28,82.03],[-57.21,82.19],[-54.13,82.2],[-53.04,81.89],[-50.39,82.44],[-48,82.06],[-46.6,81.99],[-44.52,81.66],[-46.9,82.2],[-43.41,83.23],[-39.9,83.18],[-38.62,83.55],[-35.09,83.65],[-27.1,83.52]]];
// bounding boxes for fast point-in-land tests
const BBOX = POLYS.map(p => {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const [x, y] of p) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
  return [x0, y0, x1, y1];
});

return { POLYS, BBOX };
})();

// ===== geo-land.js =====
__M["geo-land.js"] = (() => {
// GEO — shared geography for two DIFFERENT views.
//
// Coarse hand-authored coastline polygons (lon/lat), used twice:
//   * the flat Operations Map strokes the rings directly (map-view.js)
//   * the Swarm world samples them into a faint point stipple, present only as
//     spatial anchoring behind the capacity field (never as cartography)
//
// v2 note: the stipple is deliberately sparse and low-contrast. Geography is
// subordinate in Swarm; the capacity field is the subject.
//
// IMPORTANT: land points go through the SAME eased projection as the region
// anchors (easeLon/easeLat below), so geography and markers can never
// disagree. The easing widens the mid-Atlantic view slightly and relaxes the
// poles; it is monotonic and continuous at the antimeridian.

const RAD = Math.PI / 180;
const LON0 = -41;           // mid-Atlantic view centre
const LATK = 0.72;

function easeLonDelta(dl) {
  // dl in degrees, relative to LON0, in (-180, 180]
  return dl + 0.2 * dl * (1 - Math.abs(dl) / 180);   // x1.2 near centre, x1 at back
}
function toSphere(latDeg, lonDeg, R) {
  let dl = lonDeg - LON0;
  while (dl > 180) dl -= 360;
  while (dl <= -180) dl += 360;
  const L = easeLonDelta(dl) * RAD;
  const ph = latDeg * LATK * RAD;
  return [Math.cos(ph) * Math.sin(L) * R, Math.sin(ph) * R, -Math.cos(ph) * Math.cos(L) * R];
}

// (lon, lat) vertex rings — REAL geography (Natural Earth 110m via
// geo-real.js); the hand-authored approximation is retired.
const POLYS = __M["geo-real.js"].POLYS;
const {BBOX} = __M["geo-real.js"];

function inPoly(lon, lat, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
    if ((yi > lat) !== (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function isLand(lon, lat) {
  for (let k = 0; k < POLYS.length; k++) {
    const b = BBOX[k];
    if (lon < b[0] || lon > b[2] || lat < b[1] || lat > b[3]) continue;
    if (inPoly(lon, lat, POLYS[k])) return true;
  }
  return false;
}

// INVERSE of the eased mapping: an eased-sphere unit vector back to true
// lat/lon. Needed by the zoom LOD, which has to know WHICH piece of real
// geography the camera is looking at before it can sample more points there.
// easeLonDelta is monotonic, so the longitude term inverts by bisection.
function fromSphereUnit(u) {
  const ph = Math.asin(Math.max(-1, Math.min(1, u[1])));
  const lat = ph / (LATK * RAD);
  const easedDl = Math.atan2(u[0], -u[2]) / RAD;         // degrees, eased
  let lo = -180, hi = 180;
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (easeLonDelta(mid) < easedDl) lo = mid; else hi = mid;
  }
  let lon = LON0 + (lo + hi) / 2;
  while (lon > 180) lon -= 360;
  while (lon <= -180) lon += 360;
  return [lat, lon];
}

// ZOOM LOD: the same stipple rule, sampled only inside a spherical cap around
// the point the camera is looking at, so a close view can carry MANY MORE POINTS
// without paying for them over the whole globe. Sampling is uniform-in-area
// inside the cap and low-discrepancy in azimuth — same texture, more of it.
function buildLandStippleCap(R, n, seed, latC, lonC, capDeg) {
  const pts = [];
  const GOLD = 2.399963229728653;
  let s = (seed >>> 0) || 1;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  // cap centre and an orthonormal frame around it, in TRUE geographic space
  const la = latC * RAD, lo = lonC * RAD;
  const c = [Math.cos(la) * Math.cos(lo), Math.sin(la), Math.cos(la) * Math.sin(lo)];
  let e1 = [-Math.sin(lo), 0, Math.cos(lo)];
  const e2 = [
    c[1] * e1[2] - c[2] * e1[1],
    c[2] * e1[0] - c[0] * e1[2],
    c[0] * e1[1] - c[1] * e1[0]
  ];
  const cosCap = Math.cos(capDeg * RAD);
  for (let k = 0; k < n; k++) {
    const ct = 1 - (1 - cosCap) * (k + 0.5) / n;         // uniform in cap area
    const st = Math.sqrt(Math.max(0, 1 - ct * ct));
    const ph2 = GOLD * k;
    const cf = Math.cos(ph2) * st, sf = Math.sin(ph2) * st;
    const dx = c[0] * ct + e1[0] * cf + e2[0] * sf;
    const dy = c[1] * ct + e1[1] * cf + e2[1] * sf;
    const dz = c[2] * ct + e1[2] * cf + e2[2] * sf;
    const lat = Math.asin(Math.max(-1, Math.min(1, dy))) / RAD;
    let lon = Math.atan2(dz, dx) / RAD;
    if (lon > 180) lon -= 360;
    if (!isLand(lon, lat)) continue;
    const p = toSphere(lat, lon, R);
    pts.push({ p, u: [p[0] / R, p[1] / R, p[2] / R], j: rnd() });
  }
  return pts;
}

// stipple: fibonacci sphere in TRUE lat/lon space, kept where land, projected
// through the eased mapping — density is uniform on the real globe
function buildLandStipple(R, n = 9200, seed = 77) {
  const pts = [];
  const GOLD = 2.399963229728653;
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  for (let k = 0; k < n; k++) {
    const z = 1 - 2 * (k + 0.5) / n;
    const lat = Math.asin(z) / RAD;
    let lon = ((GOLD * k) / RAD) % 360;
    if (lon > 180) lon -= 360;
    if (!isLand(lon, lat)) continue;
    const p = toSphere(lat, lon, R);
    pts.push({ p, u: [p[0] / R, p[1] / R, p[2] / R], j: rnd() });   // j: per-point shimmer phase
  }
  return pts;
}

return { POLYS, LON0, easeLonDelta, toSphere, isLand, fromSphereUnit, buildLandStippleCap, buildLandStipple };
})();

// ===== world-scene.js =====
__M["world-scene.js"] = (() => {
// WORLD SCENE — one persistent spherical operational world, three lenses.
//
// The world is drawn ONCE per frame from one camera; the lens weights
// (mapK / nodesK / swarmK, eased in the driver) only redistribute emphasis:
//   MAP        geography + nodes + traffic dominate, capacity recedes to ambience
//   NODE STATS same world, node marks and telemetry gain emphasis
//   SWARM      geography recedes to the v2 whisper, capacity behaviour dominates
//
// Geography comes from the source's real geo data (geo-land.js): a dense
// fibonacci stipple of actual land, never hand-drawn coastline strokes. Every
// third stipple point is the v2 "faint anchoring" layer and is always present;
// the other two thirds fade in with the Map lens, so Map reads as a fuller
// geographic world and Swarm as the approved faint one — the SAME points, so
// the transition is a change of reading, not of world.
//
// Capacity rendering (trails, hexagons, capped chroma, engaged fill) is the
// session board language over the untouched v2 behaviour. No new metrics.

const {project, isolines} = __M["vendor/swarm-core.js"];
const {T, rgbaT, themeName} = __M["theme.js"];
const {toSphere, POLYS} = __M["geo-land.js"];

const o4 = new Float32Array(4), o4b = new Float32Array(4), o4c = new Float32Array(4);

const HEAT_ON = 0.16;
// v4 colour grammar: teal is STRUCTURAL (selected node, control, YOU); engaged
// capacity takes ONE controlled WARM accent — a narrow gold band that never
// travels toward orange-red, so coordination can never read as thermal danger.
const STOPS = [[0.16, 148, 126, 86], [0.40, 178, 148, 90], [0.70, 205, 167, 95], [1, 222, 180, 100]];
function heatRGB(T) {
  if (!(T >= HEAT_ON)) return null;
  for (let i = 1; i < STOPS.length; i++) {
    const a = STOPS[i - 1], b = STOPS[i];
    if (T <= b[0] || i === STOPS.length - 1) {
      const u = Math.max(0, Math.min(1, (T - a[0]) / (b[0] - a[0])));
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  return null;
}
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const INK = a => rgbaT('ink', a);
const LIT = a => rgbaT('lit', a);
const TEAL = a => rgbaT('primary', a);   // legacy name; reads the primary role
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
// Geometry and TYPE do not want the same factor: marks need a nudge to stay
// visible on a large panel, but the type is already sized like the DOM chrome
// around it and blows up fast. Two gentle factors, both tightly capped.
let UIK = 1, FK = 1, SK = 1;
function setUiScale(k) {
  UIK = Math.max(1, Math.min(1.55, k));
  FK = Math.max(1, Math.min(1.22, 1 + (k - 1) * 0.28));
  SK = Math.max(1, Math.min(1.2, 1 + (UIK - 1) * 0.35));   // geography stipple
}
const fpx = px => (px * FK).toFixed(1) + 'px ui-monospace, Menlo, monospace';
const fpxw = (px, w) => w + ' ' + (px * FK).toFixed(1) + 'px ui-monospace, Menlo, monospace';
const ACC = a => rgbaT('primary', a);    // selection accent = primary role
const WRM = a => rgbaT('teal', a);   // the engagement accent, as type

function camFwd(cam) {
  const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  return [sy * cp, sp, cy * cp];
}
const dn = (cam, d, R) => Math.max(0, Math.min(1, (cam.dist + R * 0.9 - d) / (R * 1.8)));

function hexPath(ctx, x, y, r, a0) {
  ctx.beginPath();
  for (let k = 0; k < 6; k++) {
    const a = a0 + k * Math.PI / 3;
    const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
    k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
  }
  ctx.closePath();
}

// ---- the sphere itself: volume, limb, computational graticule ----------------
// Built from the SAME eased projection as land and regions, so all layers of
// the world agree. The graticule belongs to the Map reading and fades with it.
function buildGraticule(SR) {
  const lines = [];
  for (const lat of [-60, -30, 0, 30, 60]) {
    const pts = [];
    for (let lon = -180; lon <= 180; lon += 4) pts.push(toSphere(lat, lon, SR * 1.001));
    lines.push(pts);
  }
  for (let lon = -180; lon < 180; lon += 30) {
    const pts = [];
    for (let lat = -80; lat <= 80; lat += 4) pts.push(toSphere(lat, lon, SR * 1.001));
    lines.push(pts);
  }
  return lines;
}

// ---- landmass as CONTINUOUS SURFACE ------------------------------------------
// The stipple alone leaves the world reading as scattered marks; filled
// silhouettes with a hairline coast give the sphere a real geographic surface
// that stays legible at every zoom scale, and it is the layer that makes local
// focus useful. Subtle by construction: a hair above the ocean, never a fill
// that competes with capacity.
let RINGS = null;
function rings(SR) {
  if (RINGS && RINGS.SR === SR) return RINGS.r;
  const out = [];
  for (const ring of POLYS) {
    if (ring.length < 4) continue;
    const pts = [];
    for (const [lon, lat] of ring) {
      const p = toSphere(lat, lon, SR);
      const l = Math.hypot(p[0], p[1], p[2]) || 1;
      pts.push([p[0], p[1], p[2], p[0] / l, p[1] / l, p[2] / l]);
    }
    out.push(pts);
  }
  RINGS = { SR, r: out };
  return out;
}
function drawLandFill(ctx, cam, W, H, SR, mapK, zoom) {
  const f = camFwd(cam);
  const rs = rings(SR);
  // v3: MAP is an operational reference layer, so the land actually reads —
  // a filled silhouette a clear step above the ocean plus a legible hairline
  // coast. Swarm never gets here (it is weighted out by mapK in the driver), so
  // raising the contrast cannot make the capacity view noisier.
  const zk = Math.min(1, Math.max(0, (zoom - 1.6) / 1.4));
  const fillA = (0.60 + 0.34 * mapK) + 0.28 * zk;
  ctx.fillStyle = rgbaT('backing', Math.min(0.97, fillA));
  ctx.strokeStyle = rgbaT('outline', 0.18 + 0.28 * mapK + 0.24 * zk);
  ctx.lineWidth = Math.min(1.5, 0.75 + 0.16 * zoom);
  for (const pts of rs) {
    // a ring entirely on the far side is skipped; one that straddles the limb
    // has its far vertices slid onto the terminator, so the outline stays closed
    let front = 0;
    for (const q of pts) if (-(q[3] * f[0] + q[4] * f[1] + q[5] * f[2]) > 0) front++;
    if (!front) continue;
    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) {
      const q = pts[i];
      const d = q[3] * f[0] + q[4] * f[1] + q[5] * f[2];
      let x = q[0], y = q[1], z = q[2];
      if (d > 0) {                          // behind the limb: project onto it
        let ux = q[3] - f[0] * d, uy = q[4] - f[1] * d, uz = q[5] - f[2] * d;
        const l = Math.hypot(ux, uy, uz) || 1;
        x = ux / l * SR; y = uy / l * SR; z = uz / l * SR;
      }
      project(cam, x, y, z, W, H, o4);
      i ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
    }
    ctx.closePath();
    ctx.fill();
    if (mapK > 0.02 || zoom > 1.4) ctx.stroke();
  }
}

// ---- one label layer, one collision registry ---------------------------------
// Labels are ANNOTATIONS: they live outside the capacity they describe, joined
// back to it by a short leader. Every label in the frame competes in one
// registry, so nothing can overlap anything else, and the passes run in
// priority order — cohorts first, then region names, then places, then node
// ids — so when the frame gets busy the least important labels simply do not
// get a slot. Keep-out discs cover the active cohorts, so no label can ever
// land on top of moving hexagons.
let LBL = [], KEEP = [], BANDS = [];
function keepOutRect(x, y, w, h) { BANDS.push([x, y, w, h]); }
function beginLabels(ctx) {
  LBL.length = 0; KEEP.length = 0; BANDS.length = 0;
  // one baseline for every pass, so the box that was collision-tested is the
  // box that gets painted: each label draws at y + h/2
  if (ctx) ctx.textBaseline = 'middle';
}
function keepOut(x, y, r) { KEEP.push([x, y, r]); }
// UI chrome is not a label: panels and control rails are the one thing a fixed-
// offset label is allowed to dodge, by flipping to its other side.
function clearOfBands(x, y, w, h) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  return x >= 6 && x + w <= W_LAST - 8;
}
let W_LAST = 1600;
function setLabelWidth(w) { W_LAST = w; }
// With fixed-offset labels, occasional overlap is accepted — but the text-clearing
// backing must NOT be: destination-out would erase whatever type is already
// underneath. So a label that lands on an existing label draws WITHOUT its
// backing; the two simply cross, and neither is destroyed.
function hitsLabel(x, y, w, h) {
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    if (x < r[0] + r[2] && x + w > r[0] && y < r[1] + r[3] && y + h > r[1]) return true;
  }
  return false;
}
function free(x, y, w, h) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    // minimum external clearance between any two placed information objects
    if (x < r[0] + r[2] + 6 && x + w + 6 > r[0] && y < r[1] + r[3] + 5 && y + h + 5 > r[1]) return false;
  }
  for (let i = 0; i < KEEP.length; i++) {
    const k = KEEP[i];
    // exact circle-vs-rectangle test with external clearance, so a marker can
    // never sit inside any part of a label box — including the far end of a
    // wide card, which the old centre-distance approximation let through
    const px2 = Math.max(x, Math.min(k[0], x + w));
    const py2 = Math.max(y, Math.min(k[1], y + h));
    if (Math.hypot(k[0] - px2, k[1] - py2) < k[2] + 4) return false;
  }
  return true;
}
// Same test WITHOUT the marker keep-out discs: for a node id, sitting close to a
// neighbouring node dot is proximity, not a collision — and being pushed off its
// own node's centre line for that is worse than the near miss. Only real
// information objects (other labels, page controls) can displace it.
function freeOfLabels(x, y, w, h, sx, sy) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    // generous HORIZONTAL clearance so two ids on nearly the same line can never
    // read as one run of text; no vertical padding, so ids one line apart may
    // both stay on their own node's centre line
    if (x < r[0] + r[2] + 8 && x + w + 8 > r[0] && y < r[1] + r[3] && y + h > r[1]) return false;
  }
  // other nodes' markers are respected (a label must not sit on another node's
  // dot); the label's OWN marker is not, since the gap already clears it
  for (let i = 0; i < KEEP.length; i++) {
    const k = KEEP[i];
    if (sx !== undefined && Math.hypot(k[0] - sx, k[1] - sy) < 3) continue;
    const px2 = Math.max(x, Math.min(k[0], x + w));
    const py2 = Math.max(y, Math.min(k[1], y + h));
    if (Math.hypot(k[0] - px2, k[1] - py2) < k[2] + 1) return false;
  }
  return true;
}
// candidate slots ring the anchor at growing radii; the first free one wins,
// and null means "no room — do not draw this label at all"
const SLOTS = [-0.30, 0.30, -0.95, 0.95, -1.75, 1.75, 2.55, -2.55, Math.PI];
function placeLabel(ax, ay, w, h, rad, W, H, must, near) {
  // near = a label that must read as ONE UNIT with its mark (node ids): the
  // candidate rings hug the anchor instead of ringing it at annotation distance
  const RINGS2 = near
    ? [rad + 7 * FK, rad + 15 * FK, rad + 28 * FK, rad + 46 * FK]
    : [rad + 16 * FK, rad + 40 * FK, rad + 68 * FK, rad + 104 * FK];
  for (const R of RINGS2) {
    for (const a of SLOTS) {
      const px = ax + Math.cos(a) * R, py = ay + Math.sin(a) * R * 0.62;
      const left = px < ax;
      const x = left ? px - w : px, y = py - h / 2;
      if (x < 6 || x + w > W - 8 || y < 20 || y + h > H - 8) continue;
      if (!free(x, y, w, h)) continue;
      LBL.push([x, y, w, h]);
      return [x, y, left, px, py];
    }
  }
  // v3: an IMPORTANT label is never solved by hiding it. When every candidate
  // slot is taken, park it just outside the anchor on whichever side has room
  // and clamp it into the panel. Only region-level labels ask for this.
  if (!must) return null;
  // park on the roomier side first, then the other, walking vertically in
  // whole-box steps; only if the whole panel is exhausted does it overlap
  const sides = ax > W * 0.55 ? [true, false] : [false, true];
  const y0 = ay - h / 2;
  for (const left of sides) {
    const x0 = Math.max(6, Math.min(W - 8 - w,
      left ? ax - rad - 14 * FK - w : ax + rad + 14 * FK));
    for (const dir of [1, -1]) {
      for (let s = 0; s < 12; s++) {
        const y = y0 + dir * s * (h + 8);
        if (y < 20 || y + h > H - 8) break;
        if (!free(x0, y, w, h)) continue;
        LBL.push([x0, y, w, h]);
        return [x0, y, left, left ? x0 + w : x0, y + h / 2];
      }
    }
  }
  const leftF = sides[0];
  const xF = Math.max(6, Math.min(W - 8 - w, leftF ? ax - rad - 14 * FK - w : ax + rad + 14 * FK));
  const yF = Math.max(20, Math.min(H - 8 - h, y0));
  LBL.push([xF, yF, w, h]);
  return [xF, yF, leftF, leftF ? xF + w : xF, yF + h / 2];
}
// NOT a card: the backing ERASES the canvas noise behind the text
// (destination-out), so the actual stage — the panel's own ground — shows
// through, exactly. Nothing frames it: no border, no radius, no shadow, no
// tint. Its only job is to clear visual noise behind the type; against the
// stage it is invisible as a rectangle.
function clearBox(ctx, x, y, w, h, a) {
  ctx.save();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.globalAlpha = Math.min(1, a * 1.7);
  ctx.fillStyle = '#000';
  ctx.fillRect(x, y, w, h);
  ctx.restore();
}
// the anchor a regional leader line starts FROM: a small technical tick target —
// a hair ring with a centre dot — sitting on the real thing being described
function anchorMark(ctx, x, y, alpha) {
  ctx.strokeStyle = INK(0.55 * alpha);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath(); ctx.arc(x, y, 4.5 * UIK, 0.6, 0.6 + 4.4); ctx.stroke();
  ctx.fillStyle = INK(0.7 * alpha);
  ctx.beginPath(); ctx.arc(x, y, 1.1 * UIK, 0, 6.2832); ctx.fill();
}
function leader(ctx, ax, ay, lx, ly, alpha) {
  ctx.strokeStyle = INK(0.26 * alpha);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath();
  ctx.moveTo(ax, ay); ctx.lineTo(lx, ly);
  ctx.stroke();
}

// ---- place names: real settlements near each region -------------------------
// They appear only at LOCAL scale, and they are what makes a close-up an
// operational view instead of a magnified dot. Real coordinates, no invention.
const PLACES = {
  ohio: [['Columbus', 39.96, -83.00], ['Dublin', 40.10, -83.11], ['Delaware', 40.30, -83.07],
         ['Newark', 40.06, -82.40], ['Lancaster', 39.71, -82.60], ['Springfield', 39.92, -83.81],
         ['Marysville', 40.24, -83.37], ['Circleville', 39.60, -82.95], ['Grove City', 39.88, -83.09]],
  frankfurt: [['Frankfurt', 50.11, 8.68], ['Offenbach', 50.10, 8.77], ['Hanau', 50.13, 8.92],
              ['Darmstadt', 49.87, 8.65], ['Mainz', 49.99, 8.25], ['Wiesbaden', 50.08, 8.24]],
  dublin: [['Dublin', 53.35, -6.26], ['Swords', 53.46, -6.22], ['Bray', 53.20, -6.11],
           ['Malahide', 53.45, -6.15], ['Tallaght', 53.29, -6.37]],
  london: [['London', 51.51, -0.13], ['Croydon', 51.37, -0.10], ['Watford', 51.66, -0.40],
           ['Bromley', 51.41, 0.01], ['Ilford', 51.56, 0.07]]
};
function drawPlaces(ctx, cam, W, H, SR, focusId, localA) {
  if (localA < 0.03 || !focusId || !PLACES[focusId]) return;
  const f = camFwd(cam);
  ctx.font = fpx(10);
  ctx.textAlign = 'left';
  for (const [name, lat, lon] of PLACES[focusId]) {
    const p = toSphere(lat, lon, SR);
    const l = Math.hypot(p[0], p[1], p[2]) || 1;
    if (-(p[0] / l * f[0] + p[1] / l * f[1] + p[2] / l * f[2]) < 0.05) continue;
    project(cam, p[0], p[1], p[2], W, H, o4);
    const wT = ctx.measureText(name).width;
    const slot = placeLabel(o4[0], o4[1], wT, 11 * FK, 4 * FK, W, H);
    if (!slot) continue;
    ctx.fillStyle = INK(0.30 * localA);
    ctx.beginPath(); ctx.arc(o4[0], o4[1], 1.6, 0, 6.2832); ctx.fill();
    ctx.fillStyle = INK(0.52 * localA);
    ctx.fillText(name, slot[0], slot[1] + 5.5 * FK);
  }
}

// ---- cohort reservation --------------------------------------------------------
// Regional cards no longer live inside the globe (they moved to the side rails),
// but each active cohort still RESERVES its footprint in the collision registry,
// so node ids and other labels can never sit on moving engaged capacity. A small
// anchor tick marks the cohort's live centroid — the "you are looking at it"
// point the side label describes.
function drawCohortLabels(ctx, cam, W, H, regions, info, swarmK, SR, detail, ballAt) {
  if (swarmK < 0.15) return;
  const f = camFwd(cam);
  for (const r of regions) {
    if (r.activityLevel < 0.12) continue;
    const nfo0 = info && info[r.id];
    if (nfo0 && nfo0.used <= 0) continue;
    const P = r.centroid || ((ballAt && ballAt.id === r.id) ? ballAt.p : r.p);
    const pl = Math.hypot(P[0], P[1], P[2]) || 1;
    const facing = -(P[0] * f[0] + P[1] * f[1] + P[2] * f[2]) / pl;
    if (facing < 0.12) continue;
    project(cam, P[0], P[1], P[2], W, H, o4);
    const span = (ballAt && ballAt.r) || r.ballR || 6;
    const rad = span * o4[3] + 8;
    keepOut(o4[0], o4[1], rad);
    const a = Math.min(1, (facing - 0.12) / 0.3) * swarmK;
    anchorMark(ctx, o4[0], o4[1], a * 0.8);
  }
}

function drawSphereBase(ctx, cam, W, H, SR, grat, mapK) {
  const q = SR / cam.dist;
  if (q >= 0.98) return;
  const Rs = SR * cam.fov / (cam.dist * Math.sqrt(1 - q * q));
  const cx = W * 0.5, cy = H * 0.5;   // no gradient fill: the stipple carries the volume
  ctx.strokeStyle = INK(0.15);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath(); ctx.arc(cx, cy, Rs, 0, 6.2832); ctx.stroke();
}

// ---- geography: one stipple, two readings ------------------------------------
// i%3===0 points are the permanent v2 faint layer; the rest arrive with mapK.
// Every point is a SMALL HEXAGON — the world's grid speaks the same cell
// language as the capacity glyphs. Stamped from a supersampled sprite so a
// hundred-thousand-point frame stays cheap.
let HEXS = null, HEXR = 0;
let HEXT = null;
function hexSprite(r) {
  if (HEXS && HEXR === r && HEXT === themeName()) return HEXS;
  const s = Math.max(12, Math.ceil((r + 1) * 8));
  const c = document.createElement('canvas'); c.width = c.height = s;
  const x = c.getContext('2d');
  x.fillStyle = rgbaT('ink', 1);
  x.beginPath();
  const R = s / 2 - 1;
  for (let k = 0; k < 6; k++) {
    const a = -Math.PI / 2 + k * Math.PI / 3;
    const X = s / 2 + Math.cos(a) * R, Y = s / 2 + Math.sin(a) * R;
    k ? x.lineTo(X, Y) : x.moveTo(X, Y);
  }
  x.closePath(); x.fill();
  HEXT = themeName(); HEXS = c; HEXR = r;
  return c;
}
// GEOGRAPHIC LOD — MORE POINTS, not bigger or brighter ones. The base stipple is
// a fixed point set on the sphere, so zooming magnifies the gaps between its
// points and the continents thin out. The fix is to SAMPLE MORE GEOGRAPHY where
// the camera is looking (the driver builds a denser cap-restricted stipple per
// zoom and hands it in as `lod`) and draw it with exactly the same dot rule as
// the base layer. Nothing else changes: same size, same alpha, same texture.
function drawLand(ctx, cam, W, H, land, t, k, mapK, zoom = 1, lod = null) {
  const f = camFwd(cam);
  // dot size barely grows with zoom (the LOD adds POINTS, not bulk): at GLOBAL
  // it is exactly the original 1.6, and it never passes 1.15× that, so the
  // texture keeps gaps between dots instead of flooding into a solid mass
  const rBase = (1.25 + 0.35 * mapK) * Math.min(1.15, 1 + 0.12 * (zoom - 1)) * SK;
  const spr = hexSprite(rBase);
  const ga = ctx.globalAlpha;
  let drawn = 0;
  const paint = (arr, thirds, aMul, onlyThirds) => {
    for (let i = 0; i < arr.length; i++) {
      const q = arr[i];
      const base = !thirds || i % 3 === 0;
      if (!base && (mapK < 0.02 || onlyThirds)) continue;
      const facing = -(q.u[0] * f[0] + q.u[1] * f[1] + q.u[2] * f[2]);
      if (q.node || facing < 0.02) continue;   // node points draw highlighted, not twice
      // NO LIMB SHADING. This used to ramp alpha over the outer 0.34 of the
      // hemisphere and square it, so geography darkened toward the silhouette and
      // the globe read as if it were lit from the centre — a shaded rim that is not
      // part of the visual language. Density alone carries the curvature now: the
      // alpha is flat, and only the last sliver before the terminator fades, just
      // enough that points do not pop in and out as the world turns.
      const vis = Math.min(1, (facing - 0.02) / 0.05);
      const shim = 0.9 + 0.1 * Math.sin(t * 0.55 + q.j * 6.28);
      const a = (base ? (0.30 + 0.22 * mapK) : 0.34 * mapK) * aMul;
      ctx.globalAlpha = Math.min(1, vis * a * shim * k) * ga;
      project(cam, q.p[0], q.p[1], q.p[2], W, H, o4);
      if (o4[0] < -12 || o4[0] > W + 12 || o4[1] < -12 || o4[1] > H + 12) continue;
      const d = (base ? rBase : rBase * 0.82) * 2;
      ctx.drawImage(spr, o4[0] - d / 2, o4[1] - d / 2, d, d);
      drawn++;
    }
  };
  // with a LOD patch in hand the base layer only needs to carry the geography
  // OUTSIDE it, so it drops to its every-third sampling and gets out of the way
  const hasLod = !!(lod && lod.length);
  paint(land, true, hasLod ? 0.55 : 1, hasLod);
  if (hasLod) paint(lod, false, 0.7);
  ctx.globalAlpha = ga;
  // review hook: the LOD numbers behind this frame's geography
  if (typeof window !== 'undefined') window.__geoDbg = { drawn, lod: lod ? lod.length : 0, rBase, mapK, k };
}

// ---- capacity trails: short local wakes (v2 rule, board rendering) -----------
function drawTrails(ctx, cam, sim, W, H, eng, chroma) {
  const TL = sim.TL, head = sim.head;
  for (let i = 0; i < sim.N; i++) {
    const e = eng[i];
    if (chroma[i] > 0.5) continue;               // assembled: no wake
    if (e < 0.22 && i % 3) continue;
    const n = Math.round(7 + e * 3);
    const hc = heatRGB(chroma[i]);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = dn(cam, o4[2], sim.R);
    if (dl < 0.05) continue;
    const sw = Math.max(0.15, Math.min(1, sim.spd[i] / (sim.SPD * 2.2)));
    let hx = 0, hy = 0;
    for (let a = n - 1; a >= 0; a--) {
      const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
      project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
      if (a < n - 1) {
        const u = 1 - a / n, t2 = u * u;
        ctx.lineWidth = 0.6 * (0.35 + 1.15 * t2) * (0.55 + dl * 0.85);
        const aa = Math.min(1, 0.20 * (0.55 + e * 1.05) * 2.4 * t2 * sw * (0.35 + dl * 0.65));
        ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.0)) : INK(aa);
        ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
      }
      hx = o4[0]; hy = o4[1];
    }
  }
}

// ---- capacity agents: hexagons, available vs engaged --------------------------
// PARTICLE RENDERING — lifted from capacity-scene.js so the marks in this UI are
// the marks of the original scene: one size and one opacity for every agent (no
// depth cueing), the glyph oriented along its own heading, stroke plus fill, and
// the five-stop response ramp that runs through amber into red. Trails are the
// original's tapered histories with their cross ticks.
const TAN_HALF = Math.tan(70.529 * Math.PI / 360);
const SC_STOPS = [[0.2, 148, 126, 86], [0.45, 178, 148, 90], [0.68, 200, 164, 94], [0.85, 212, 172, 96], [1, 222, 180, 100]];
function sceneHeat(T) {
  if (!(T >= 0.2)) return null;
  for (let i = 1; i < SC_STOPS.length; i++) {
    const a = SC_STOPS[i - 1], b = SC_STOPS[i];
    if (T <= b[0]) {
      const u = (T - a[0]) / (b[0] - a[0]);
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  const l = SC_STOPS[SC_STOPS.length - 1];
  return [l[1], l[2], l[3]];
}
const GLYPHS = {
  Triangle: { kind: 'tri', scale: 1 },
  Dash: { kind: 'dash', scale: 1 },
  Circle: { kind: 'dot', scale: 1.15 },
  Diamond: { kind: 'dia', scale: 0.9 },
  Hexagon: { kind: 'hex', scale: 1 },
  'Circle filled': { kind: 'dot', scale: 1.15, fill: true },
  'Diamond filled': { kind: 'dia', scale: 0.9, fill: true }
};
function prim(ctx, kind, x, y, hx, hy, sz, fill) {
  const px_ = -hy, py_ = hx;
  if (kind === 'dash') {
    const L = sz * 1.35;
    ctx.beginPath();
    ctx.moveTo(x - hx * L, y - hy * L); ctx.lineTo(x + hx * L, y + hy * L);
    ctx.stroke(); return;
  }
  ctx.beginPath();
  if (kind === 'dot') {
    ctx.arc(x, y, sz * 0.5, 0, 6.2832);
  } else if (kind === 'dia') {
    const a = sz * 1.15, b = a / Math.SQRT2;
    ctx.moveTo(x + hx * a, y + hy * a);
    ctx.lineTo(x + px_ * b, y + py_ * b);
    ctx.lineTo(x - hx * a, y - hy * a);
    ctx.lineTo(x - px_ * b, y - py_ * b);
    ctx.closePath();
  } else if (kind === 'hex') {
    const r = sz * 0.82, a0 = Math.atan2(hy, hx);
    for (let k = 0; k < 6; k++) {
      const a = a0 + k * Math.PI / 3;
      const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
      k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
  } else {
    const Hh = sz * 1.25, b = TAN_HALF * Hh;
    ctx.moveTo(x + hx * Hh * 0.66, y + hy * Hh * 0.66);
    ctx.lineTo(x - hx * Hh * 0.34 + px_ * b, y - hy * Hh * 0.34 + py_ * b);
    ctx.lineTo(x - hx * Hh * 0.34 - px_ * b, y - hy * Hh * 0.34 - py_ * b);
    ctx.closePath();
  }
  if (fill) ctx.fill(); else ctx.stroke();
}

let TB = null, TGW = 0, TGH = 0;
const SEGS = [];
function drawIsotherms(ctx, cam, sim, W, H) {
  if (sim.tempMax < 0.06) return;
  const cell = 7 * UIK;
  const gw = Math.max(8, Math.round(W / cell)), gh = Math.max(6, Math.round(H / cell));
  if (TGW !== gw || TGH !== gh) { TGW = gw; TGH = gh; TB = new Float32Array(gw * gh); }
  TB.fill(0);
  for (let i = 0; i < sim.N; i++) {
    if (sim.temp[i] < 0.02) continue;
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const x0 = Math.round(o4[0] / W * gw), y0 = Math.round(o4[1] / H * gh);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = x0 + dx, y = y0 + dy;
      if (x < 0 || y < 0 || x >= gw || y >= gh) continue;
      const v = sim.temp[i] * Math.exp(-(dx * dx + dy * dy) / 1.5);
      if (v > TB[y * gw + x]) TB[y * gw + x] = v;
    }
  }
  const kx = W / gw, ky = H / gh, n = 5;
  const stroke = () => {
    ctx.beginPath();
    for (let s = 0; s < SEGS.length; s += 2) {
      ctx.moveTo(SEGS[s][0] * kx, SEGS[s][1] * ky);
      ctx.lineTo(SEGS[s + 1][0] * kx, SEGS[s + 1][1] * ky);
    }
    ctx.stroke();
  };
  for (let l = 0; l < n; l++) {
    const lv = 0.2 + (sim.tempMax - 0.2) * ((l + 0.6) / n);
    if (lv <= 0.2) continue;
    const c = sceneHeat(lv); if (!c) continue;
    isolines(TB, gw, gh, lv, SEGS);
    if (!SEGS.length) continue;
    const crit = lv > 0.82;
    ctx.strokeStyle = rgba(c, crit ? 0.95 : 0.5 + (l / n) * 0.32);
    ctx.lineWidth = (crit ? 1.1 : 0.55) * UIK;
    stroke();
    if (crit) {
      ctx.setLineDash([2 * UIK, 3 * UIK]); ctx.lineWidth = 0.5 * UIK;
      stroke();
      ctx.setLineDash([]);
    }
  }
}

// the original's tapered histories, with the cross ticks
function drawHistories(ctx, cam, sim, W, H, cfg) {
  const c = cfg || {};
  const TL = sim.TL, head = sim.head;
  const n = Math.max(3, Math.min(TL, Math.round(c.n ?? 15)));
  const stride = Math.max(1, Math.round(c.stride ?? 4));
  const w = (c.w ?? 0.55) * UIK;
  const alpha = c.alpha ?? 0.2;
  const tick = 7;
  for (let i = 0; i < sim.N; i += stride) {
    const hc = sceneHeat(sim.temp[i]);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - o4[2]) / (sim.R * 1.8)));
    if (dl < 0.04) continue;
    const av = alpha * (0.3 + dl * 0.7);
    if (c.taper) {
      const sw = Math.max(0.12, Math.min(1, sim.spd[i] / (sim.SPD * 2.4)));
      let hx = 0, hy = 0;
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        if (a < n - 1) {
          const u = 1 - a / n, t2 = u * u;
          ctx.lineWidth = w * (0.35 + 1.05 * t2) * (0.55 + dl * 0.85);
          const aa = Math.min(1, av * 2.6 * t2 * sw);
          ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.5)) : INK(aa);
          ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
        }
        hx = o4[0]; hy = o4[1];
      }
    } else {
      ctx.beginPath();
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        a === n - 1 ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
      }
      ctx.lineWidth = w * (0.55 + dl * 0.85);
      ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 1.6)) : INK(av);
      ctx.stroke();
    }
    if (c.ticks === false) continue;
    ctx.lineWidth = 0.6 * UIK;
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 2.2)) : INK(alpha * (0.3 + dl * 0.7));
    for (let a = n - 2; a >= 1; a -= tick) {
      const oA = (i * TL + ((head - a - 1 + TL * 2) % TL)) * 3;
      const oB = (i * TL + ((head - a + 1 + TL * 2) % TL)) * 3;
      project(cam, sim.trail[oA], sim.trail[oA + 1], sim.trail[oA + 2], W, H, o4);
      project(cam, sim.trail[oB], sim.trail[oB + 1], sim.trail[oB + 2], W, H, o4b);
      const mx = (o4[0] + o4b[0]) / 2, my = (o4[1] + o4b[1]) / 2;
      const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
      const tk = 1.9 * UIK * (1 - a / n * 0.55);
      ctx.beginPath();
      ctx.moveTo(mx + dy / L * tk, my - dx / L * tk);
      ctx.lineTo(mx - dy / L * tk, my + dx / L * tk);
      ctx.stroke();
    }
  }
}

let ORD = null, SD = null, SX = null, SY = null, ROT = null, SHX = null, SHY = null;
// the separation hash is reused across frames: at 4K the grid is ~74k cells,
// and reallocating it every frame would cost more than the relaxation itself
let HEAD = null, NEXT = null, HCOLS = 0, HROWS = 0;
function drawAgents(ctx, cam, sim, W, H, eng, chroma, scale = 1, ambient = 1, avoid, glyph = 'Hexagon', lift = null, ink = null) {
  const N = sim.N;
  if (!SD || SD.length !== N) {
    SD = new Float32Array(N); SX = new Float32Array(N); SY = new Float32Array(N);
    ROT = new Float32Array(N); ORD = Array.from({ length: N }, (_, i) => i);
  }
  if (!SHX || SHX.length !== N) { SHX = new Float32Array(N); SHY = new Float32Array(N); }
  const sx = SX, sy = SY, rot = ROT;
  for (let i = 0; i < N; i++) {
    // RADIAL LIFT, applied at DRAW time only: an engaged particle is shown
    // standing a little way up its workload's filament, along the local normal,
    // while the physics keeps running on the shell — so the plume reads as
    // emerging from the sphere without the lift ever fighting the docking.
    let px = sim.px[i], py = sim.py[i], pz = sim.pz[i];
    if (lift && lift[i]) {
      const L0 = Math.hypot(px, py, pz) || 1;
      const kk = (L0 + lift[i]) / L0;
      px *= kk; py *= kk; pz *= kk;
    }
    project(cam, px, py, pz, W, H, o4);
    project(cam, px + sim.vx[i] * 0.3, py + sim.vy[i] * 0.3, pz + sim.vz[i] * 0.3, W, H, o4b);
    sx[i] = o4[0]; sy[i] = o4[1]; SD[i] = o4[2];
    const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
    SHX[i] = dx / L; SHY[i] = dy / L;
    rot[i] = Math.atan2(dy, dx);
  }
  ORD.sort((a, b) => SD[b] - SD[a]);

  // ---- NO OVERLAP OF ANY MARK ----------------------------------------------
  // Enforced in SCREEN space, where the constraint actually lives: the glyph is
  // a fixed pixel size while the world scales with the viewport and the zoom.
  // A spatial hash finds every pair closer than one glyph and relaxes them
  // apart; node marks are hard obstacles applied last, so nothing can be pushed
  // back onto one. The guard matters: if the visible hemisphere cannot hold N
  // glyphs at this spacing the solver would saturate and flatten the whole
  // field into a uniform lattice, so on a panel that small only the node discs
  // are applied and the field keeps its natural distribution.
  {
    const D = ((2.8 + 1.0) * scale * UIK) * 2 + 1.6 * UIK;
    const Rw = sim.R * cam.fov / cam.dist;              // world radius, on screen
    const roomy = Math.PI * Rw * Rw > N * 0.866 * D * D * 1.85;
    if (roomy) {
      const cell = D, cols = Math.max(1, Math.ceil(W / cell) + 2), rows = Math.max(1, Math.ceil(H / cell) + 2);
      if (!HEAD || HCOLS !== cols || HROWS !== rows) { HEAD = new Int32Array(cols * rows); HCOLS = cols; HROWS = rows; }
      if (!NEXT || NEXT.length !== N) NEXT = new Int32Array(N);
      const head = HEAD, next = NEXT;
      const cellOf = i => {
        const cx = Math.min(cols - 1, Math.max(0, Math.floor(sx[i] / cell) + 1));
        const cy = Math.min(rows - 1, Math.max(0, Math.floor(sy[i] / cell) + 1));
        return cy * cols + cx;
      };
      for (let pass = 0; pass < 4; pass++) {
        head.fill(-1);
        for (let i = 0; i < N; i++) { const k = cellOf(i); next[i] = head[k]; head[k] = i; }
        for (let i = 0; i < N; i++) {
          const cx = Math.min(cols - 1, Math.max(0, Math.floor(sx[i] / cell) + 1));
          const cy = Math.min(rows - 1, Math.max(0, Math.floor(sy[i] / cell) + 1));
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const nx2 = cx + ox, ny2 = cy + oy;
            if (nx2 < 0 || nx2 >= cols || ny2 < 0 || ny2 >= rows) continue;
            for (let j = head[ny2 * cols + nx2]; j !== -1; j = next[j]) {
              if (j <= i) continue;
              let dx = sx[j] - sx[i], dy = sy[j] - sy[i];
              const d2 = dx * dx + dy * dy;
              if (d2 >= D * D) continue;
              let d = Math.sqrt(d2);
              if (d < 1e-4) { dx = 1; dy = 0; d = 1; }
              const push = (D - d) * 0.5;
              dx /= d; dy /= d;
              sx[i] -= dx * push; sy[i] -= dy * push;
              sx[j] += dx * push; sy[j] += dy * push;
            }
          }
        }
      }
    }
    if (avoid) for (let i = 0; i < N; i++) {
      for (let k = 0; k < avoid.length; k++) {
        const A = avoid[k];
        let dx = sx[i] - A[0], dy = sy[i] - A[1];
        let d = Math.hypot(dx, dy);
        const R = A[2] + D * 0.5;
        if (d >= R) continue;
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        sx[i] = A[0] + dx / d * R; sy[i] = A[1] + dy / d * R;
      }
    }
  }

  const fw = camFwd(cam);
  const gl = GLYPHS[glyph] || GLYPHS.Hexagon;
  for (let q = 0; q < N; q++) {
    const i = ORD[q];
    const dl = dn(cam, SD[i], sim.R);
    if (dl <= 0.01) continue;
    const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
    if (-(sim.px[i] * fw[0] + sim.py[i] * fw[1] + sim.pz[i] * fw[2]) / pl < 0.02) continue;
    // the original's treatment: no depth cueing — every mark reads at one size
    // and one opacity, and only the response colour separates them
    const al = sim.meas[i];
    const hc = sceneHeat(chroma[i]);
    const engd = !!hc;
    const s = (engd ? (3.2 + (al > 0.08 ? 0.9 : 0)) : 3.2 * 0.62) * scale * UIK;
    const a = engd ? (0.78 + (al > 0.08 ? Math.min(0.22, al * 0.9) : 0)) : 0.26;
    // INK OVERRIDE: free capacity normally takes the theme's ink, which assumes a
    // surface ground. A caller drawing the swarm on a coloured ground (the sign-in
    // world, on primary) hands in its own foreground instead. Engaged particles
    // are unaffected — their colour is the response reading, not a foreground.
    const IK = ink ? (aa => rgba(ink, aa)) : INK;
    ctx.strokeStyle = engd ? rgba(hc, Math.min(1, a * 1.55)) : IK(a * ambient);
    ctx.lineWidth = (engd && al > 0.08 ? 1.05 : 0.7) * UIK;
    ctx.fillStyle = engd ? rgba(hc, Math.min(1, a * 1.35)) : IK(a * 0.9 * ambient);
    prim(ctx, gl.kind, sx[i], sy[i], SHX[i], SHY[i], s * (gl.scale || 1), !!gl.fill);
  }
}

// ---- engagement field: the zone reads as a unit -------------------------------
// Two spherical isolines around an active region delimit where capacity is
// coordinating — the board's isoline language (isoline = scalar), drawn, not
// simulated: the v2 behaviour underneath is untouched and nothing converges.
function drawEngagementField(ctx, cam, W, H, regions, levels, swarmK, SR, t) {
  if (swarmK < 0.05) return;
  const f = camFwd(cam);
  let idx = 0;
  for (const r of regions) {
    const lv = levels[r.id] || 0;
    idx++;
    if (lv < 0.06) continue;
    const u = r.u;
    let e1 = [u[1], -u[0], 0];
    let L = Math.hypot(e1[0], e1[1], e1[2]);
    if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
    e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
    const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
    const breathe = 1 + 0.02 * Math.sin(t * 0.7 + idx * 2.1);
    const thO = (0.24 + 0.18 * lv) * breathe;
    const hc = heatRGB(0.45 + 0.3 * lv) || [210, 126, 38];
    // [angular radius, alpha, dash, width] — a soft glow pass under each line
    const rings = [
      [thO, 0.12 + 0.10 * lv, [], 6],
      [thO, 0.30 + 0.45 * lv, [], 1.3],
      [thO * 0.55, 0.16 + 0.22 * lv, [3, 5], 1]
    ];
    for (const [th, ra, dash, lw] of rings) {
      const ct = Math.cos(th), st = Math.sin(th);
      ctx.setLineDash(dash);
      ctx.lineWidth = lw;
      ctx.strokeStyle = rgba(hc, Math.min(1, ra * swarmK));
      ctx.beginPath();
      let pen = false;
      for (let s2 = 0; s2 <= 72; s2++) {
        const ph = s2 / 72 * 6.2832;
        const px = (u[0] * ct + (e1[0] * Math.cos(ph) + e2[0] * Math.sin(ph)) * st) * SR * 1.003;
        const py = (u[1] * ct + (e1[1] * Math.cos(ph) + e2[1] * Math.sin(ph)) * st) * SR * 1.003;
        const pz = (u[2] * ct + (e1[2] * Math.cos(ph) + e2[2] * Math.sin(ph)) * st) * SR * 1.003;
        const pl = Math.hypot(px, py, pz) || 1;
        if (-(px * f[0] + py * f[1] + pz * f[2]) / pl < 0.03) { pen = false; continue; }
        project(cam, px, py, pz, W, H, o4);
        pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
        pen = true;
      }
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }
}

// ---- region marks: one glyph across all lenses --------------------------------
// The crosshair tick is the region in EVERY lens (same world, same mark); the
// Map lens adds a quiet label, the zoom adds node counts (semantic zoom), and
// the thin arc prints the region's existing activityLevel. No boxes.
function drawRegionMarks(ctx, cam, W, H, regions, levels, mapK, swarmK, dist, ballAt, scale) {
  const f = camFwd(cam);
  const zoomA = clamp01((252 - dist) / 30);          // REGIONAL reading arrives as you approach
  for (const r of regions) {
    const lv = levels[r.id] || 0;
    const P = (ballAt && ballAt.id === r.id) ? ballAt.p : r.p;
    const l = Math.hypot(P[0], P[1], P[2]) || 1;
    const facing = -(P[0] * f[0] + P[1] * f[1] + P[2] * f[2]) / l;
    if (facing < 0.12) continue;
    const vis = Math.min(1, (facing - 0.12) / 0.3);
    project(cam, P[0], P[1], P[2], W, H, o4);
    const x = o4[0], y = o4[1];
    const a = vis * (0.30 + 0.50 * lv) * Math.max(0.85 * mapK + 0.35, swarmK);
    // REGIONAL / CONTROL ANCHOR — the region's operational reference point, NOT
    // one of the compute nodes and never counted as one: a target ring with a
    // centre and four short outward ticks, in the control teal. One clear step
    // above a compute-node marker, identical in Map and Swarm. No glow.
    const rr2 = 6.5 * UIK;
    ctx.strokeStyle = TEAL(Math.min(1, a * 0.95));
    ctx.lineWidth = 1 * UIK;
    ctx.beginPath(); ctx.arc(x, y, rr2, 0, 6.2832); ctx.stroke();
    ctx.fillStyle = TEAL(Math.min(1, a));
    ctx.beginPath(); ctx.arc(x, y, 1.6 * UIK, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = TEAL(Math.min(1, a * 0.6));
    ctx.beginPath();
    ctx.moveTo(x - rr2 - 3.5 * UIK, y); ctx.lineTo(x - rr2 - 1 * UIK, y);
    ctx.moveTo(x + rr2 + 1 * UIK, y); ctx.lineTo(x + rr2 + 3.5 * UIK, y);
    ctx.moveTo(x, y - rr2 - 3.5 * UIK); ctx.lineTo(x, y - rr2 - 1 * UIK);
    ctx.moveTo(x, y + rr2 + 1 * UIK); ctx.lineTo(x, y + rr2 + 3.5 * UIK);
    ctx.stroke();
    keepOut(x, y, rr2 + 4 * UIK);
    // the SIDE RAIL names regions now; on the globe only the control-plane id
    // remains, close to its anchor, at REGIONAL scale and beyond
    if (r.ctrl && mapK > 0.04 && scale !== 'GLOBAL') {
      const alpha = vis * (0.6 + 0.3 * lv) * mapK;
      ctx.font = fpx(9);
      ctx.textAlign = 'left';
      const wT = ctx.measureText(r.ctrl).width;
      const slot = placeLabel(x, y, wT, 11 * FK, rr2 + 5 * UIK, W, H, false, true);
      if (slot) {
        ctx.fillStyle = TEAL(Math.min(1, alpha * 0.75));
        ctx.fillText(r.ctrl, slot[0], slot[1] + 5.5 * FK);
      }
    }
  }
}

// ---- node marks: actual infrastructure on the world ---------------------------
// Nodes are real compute; each region's nodes sit in a small deterministic ring
// on its tangent plane. Teal is infrastructure's colour (never capacity's).
// Node ids appear only at LOCAL zoom or under the Node-stats lens — semantic
// zoom, not clutter.
function buildNodeMarks(regions, nodesByRegion, SR, land) {
  const marks = [];
  for (const r of regions) {
    const ids = nodesByRegion[r.id] || [];
    if (!ids.length) continue;
    const u = r.u;
    let e1 = [u[1] * 1 - u[2] * 0, u[2] * 0 - u[0] * 1, u[0] * 0 - u[1] * 0]; // u × ŷ
    let L = Math.hypot(e1[0], e1[1], e1[2]);
    if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
    e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
    const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
    ids.forEach((id, k) => {
      const ang = 0.9 + k * 6.2832 / ids.length;
      const rr = 4.4;
      const p = [
        u[0] * SR + (e1[0] * Math.cos(ang) + e2[0] * Math.sin(ang)) * rr,
        u[1] * SR + (e1[1] * Math.cos(ang) + e2[1] * Math.sin(ang)) * rr,
        u[2] * SR + (e1[2] * Math.cos(ang) + e2[2] * Math.sin(ang)) * rr
      ];
      const pl = Math.hypot(p[0], p[1], p[2]) || 1;
      let un = [p[0] / pl, p[1] / pl, p[2] / pl];
      let pp = [un[0] * SR * 1.004, un[1] * SR * 1.004, un[2] * SR * 1.004];
      if (land && land.length) {
        // the node is one of the map's own points, highlighted — never an extra dot
        let best = -1, bd = -2;
        for (let q = 0; q < land.length; q++) {
          if (land[q].node) continue;
          const d = land[q].u[0] * un[0] + land[q].u[1] * un[1] + land[q].u[2] * un[2];
          if (d > bd) { bd = d; best = q; }
        }
        if (best >= 0) {
          land[best].node = true;
          un = land[best].u;
          pp = [un[0] * SR * 1.004, un[1] * SR * 1.004, un[2] * SR * 1.004];
        }
      }
      marks.push({ id, rid: r.id, p: pp, u: un, rc: r.u });
    });
  }
  return marks;
}

const NODE_SIDE = new Map();
function drawNodeMarks(ctx, cam, W, H, marks, levels, mapK, nodesK, dist, t, scale, focusId, zz, hw, idsAtGlobal, accent, flagId) {
  const f = camFwd(cam);
  const localA = clamp01((215 - dist) / 18);        // LOCAL reading: hardware detail
  const lensA = Math.max(mapK * 0.95, nodesK);
  if (lensA < 0.02) return;
  // the globe's projected centre: which side of it a node sits on decides which
  // side its label takes, so the whole set reads outward from one origin
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  // NODE MARKERS: a node is a small PRECISE mark — a fine ring with a solid core,
  // unmistakably not a capacity hexagon — and its id now attaches through the SAME
  // spatial grammar Swarm uses for workloads: one true sphere-normal stem out of
  // the surface, with the id horizontal at its outer end. Shared geometry, not
  // shared styling: the stem here is a restrained infrastructure line, never a
  // workload radial. Colour semantics unchanged — idle infrastructure is quiet
  // neutral; only a SERVING node takes the flow's colour.
  const list = [...marks].sort((a2, b2) =>
    ((levels[b2.rid] || 0) - (levels[a2.rid] || 0)) || (a2.id < b2.id ? -1 : 1));
  for (const m of list) {
    const facing = -(m.u[0] * f[0] + m.u[1] * f[1] + m.u[2] * f[2]);
    if (facing < 0.1) continue;
    const vis = Math.min(1, (facing - 0.1) / 0.3);
    const busy = (levels[m.rid] || 0) > 0.001;
    project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
    const bx = o4[0], by = o4[1];
    const a = vis * lensA;
    // NODE MARKER — concentric and precise, NO GLOW: one hairline ring and a
    // solid core, nothing radiating. A SERVING node takes the colour of the flow
    // that reaches it — the same workload colour its token traffic carries — so
    // node and route read as one identity; idle infrastructure stays neutral.
    // SELECTED NODE: the mark itself grows, so the node reads as the subject at
    // any scale; the tangent ring around it carries the rest (owner 2026-09-11).
    const flagged = !!flagId && m.id === flagId;
    const sz = (2.4 + nodesK * 0.5) * UIK * (flagged ? 1.95 : 1);
    const acc = busy && accent ? accent[m.id] : null;
    const FLOW = al => acc
      ? `rgba(${acc[0] | 0},${acc[1] | 0},${acc[2] | 0},${Math.min(1, al).toFixed(3)})`
      : TEAL(Math.min(1, al));
    ctx.strokeStyle = busy ? FLOW(a * 0.72) : INK(Math.min(1, a * 0.62));
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.arc(bx, by, sz * 1.25, 0, 6.2832); ctx.stroke();
    ctx.fillStyle = busy ? FLOW(a * 0.95) : LIT(Math.min(1, a * 0.62));
    ctx.beginPath(); ctx.arc(bx, by, sz * 0.46, 0, 6.2832); ctx.fill();

    // SEMANTIC ZOOM. On the geographic Map the node id is part of the global
    // reading, so ids are allowed at GLOBAL and the collision registry simply
    // drops the ones with no room; hardware metadata still waits for LOCAL. In
    // Swarm the global reading is capacity, so ids wait for REGIONAL.
    if (scale === 'GLOBAL' && !idsAtGlobal && nodesK < 0.3) continue;
    if (scale === 'LOCAL' && focusId && m.rid !== focusId) continue;
    const front = Math.max(0, Math.min(1, (facing - 0.36) / 0.22));
    const idA = Math.max(nodesK, mapK * 0.9, localA) * vis * front;
    if (idA > 0.10) {
      // HARDWARE IS CONTEXTUAL, NOT AMBIENT. The left rail is the home for node
      // detail, so the world shows hardware only when the view is actually about
      // one place: LOCAL scale with a region focused (or that node selected).
      // Otherwise every visible node carried two lines of metadata and the map
      // read as a diagnostic overlay instead of an operational view.
      const hwAllowed = localA > 0.25 && (focusId ? m.rid === focusId : false);
      let hwTxt = (hwAllowed && hw && hw[m.id]) ? hw[m.id] : null;
      ctx.textAlign = 'left';
      ctx.font = busy ? fpxw(10.5, 600) : fpx(10.5);
      const idW = ctx.measureText(m.id).width;
      let wT = idW;
      if (hwTxt) { ctx.font = fpx(8.5); wT = Math.max(wT, ctx.measureText(hwTxt).width); }
      let hT = (hwTxt ? 22 : 11) * FK;
      const GAP = sz * 0.8 + 7 * UIK;
      // NODE ID PLACEMENT — ONE FIXED RULE, no search, no sliding, no stepping:
      // the label hangs at the OUTER END of the node's stem, on the side away from
      // the globe centre, horizontal in screen space. Two labels may occasionally
      // overlap; that is accepted, because a label that wanders away from its node
      // to avoid a neighbour is worse than a momentary collision. The only
      // corrections are the viewport edges.
      const idOff = 5.5 * FK;
      // ONE SPHERE-NORMAL STEM, from the marker outward along this node's own
      // normal — normalize(P − C), which for a surface point is simply P/|P| — at a
      // FIXED WORLD length, shorter than the workload stem (SR*0.07 against
      // SR*0.11). No screen-length compensation: it foreshortens with the globe,
      // which is what makes it read as genuinely perpendicular to the surface.
      const nr = Math.hypot(m.p[0], m.p[1], m.p[2]) || 1;
      const nu = [m.p[0] / nr, m.p[1] / nr, m.p[2] / nr];
      const stemL = nr * 0.07;
      project(cam, m.p[0] + nu[0] * stemL, m.p[1] + nu[1] * stemL, m.p[2] + nu[2] * stemL, W, H, o4c);
      const ex = o4c[0], ey = o4c[1];
      {
        // starts clear of the marker ring, fades outward, thinner and quieter than
        // both the workload stem and the token traffic
        const dxs = ex - bx, dys = ey - by, dls = Math.hypot(dxs, dys);
        if (dls > sz * 1.9) {
          const k0 = (sz * 1.6) / dls;
          const sx0 = bx + dxs * k0, sy0 = by + dys * k0;
          const sa = Math.min(1, idA) * 0.55;
          const gr = ctx.createLinearGradient(sx0, sy0, ex, ey);
          if (busy) { gr.addColorStop(0, FLOW(sa * 0.8)); gr.addColorStop(1, FLOW(sa * 0.42)); }
          else { gr.addColorStop(0, INK(sa * 0.62)); gr.addColorStop(1, INK(sa * 0.3)); }
          ctx.strokeStyle = gr;
          ctx.lineWidth = 0.7 * UIK;
          ctx.beginPath(); ctx.moveTo(sx0, sy0); ctx.lineTo(ex, ey); ctx.stroke();
          // END DOT: the stem terminates in a small point and the id sits right
          // beside it, so point + text read as one lockup belonging to this node.
          // Smaller and quieter than the workload stem's dot.
          ctx.fillStyle = busy ? FLOW(Math.min(1, idA) * 0.8) : LIT(Math.min(1, idA) * 0.62);
          ctx.beginPath(); ctx.arc(ex, ey, 1.5 * UIK, 0, 6.2832); ctx.fill();
        }
      }
      const prevSide = NODE_SIDE.get(m.id);
      let side = (ex - gcx) > 4 * UIK ? 1 : (ex - gcx) < -4 * UIK ? -1 : (prevSide || 1);
      NODE_SIDE.set(m.id, side);
      let lx = side > 0 ? ex + GAP : ex - GAP - wT;
      if (lx < 6) lx = ex + GAP;
      else if (lx + wT > W - 8) lx = ex - GAP - wT;
      // KEEP-OUT BANDS OUTRANK A NODE ID, but a node id is never dropped — it was
      // flickering in and out as the globe turned. So: try the node's own side,
      // flip once, then step the box just above or below its own stem end. Only
      // if every one of those is still inside a reserved area does it fall back
      // to its own side, which is the readable failure.
      const bandFree = (x, y) => clearOfBands(x - 3, y, wT + 6, hT);
      let ly = ey - idOff;
      if (!bandFree(lx, ly)) {
        const alt = lx > ex ? ex - GAP - wT : ex + GAP;
        const step = hT + 6 * FK;
        if (alt >= 6 && alt + wT <= W - 8 && bandFree(alt, ly)) lx = alt;
        else if (bandFree(lx, ly - step)) ly -= step;
        else if (bandFree(lx, ly + step)) ly += step;
      }
      const slot = [lx, Math.max(20, Math.min(H - 8 - hT, ly))];
      if (slot) {
        const [lx, ly] = slot;
        if (typeof window !== 'undefined' && window.__lblDbgOn) {
          (window.__lblDbg = window.__lblDbg || {})[m.id] =
            { bx: +bx.toFixed(1), by: +by.toFixed(1), lx: +lx.toFixed(1), ly: +ly.toFixed(1), side, hw: !!hwTxt, hT: +hT.toFixed(1), idBase: +(ly + (hwTxt ? 9.6 : hT / 2 + 3.7) * FK).toFixed(1) };
        }
        const clean = !hitsLabel(lx - 3, ly, wT + 6, hT);
        LBL.push([lx, ly, wT, hT]);
        if (clean) clearBox(ctx, lx - 3, ly, wT + 6, hT, Math.min(1, idA));
        ctx.textBaseline = 'middle';
        ctx.font = busy ? fpxw(10.5, 600) : fpx(10.5);
        ctx.fillStyle = LIT(Math.min(1, idA * 0.88));
        ctx.fillText(m.id, lx, ly + idOff);
        if (hwTxt) {
          ctx.font = fpx(8.5);
          ctx.fillStyle = INK(Math.min(1, idA * 0.7) * Math.min(1, localA));
          ctx.fillText(hwTxt, lx, ly + idOff + 11 * FK);
        }
        ctx.textBaseline = 'alphabetic';
      }
    }
  }
}

// ---- WORKLOAD COHORT LABELS ------------------------------------------------------
// P2: the SAME simple rule the node ids use. The label sits at ONE fixed offset
// from the cohort's PERSISTENT SEMANTIC ANCHOR (a direction derived once from the
// infrastructure its slots live on — see the driver's assign()), on the outward
// side of the globe centre, primary line on the anchor's horizontal axis. No
// candidate search, no hysteresis bookkeeping, no dropping: nothing here consults
// where the particles happen to be this frame, so the label cannot chase them,
// and occasional overlap is accepted in exchange for absolute stability.
function drawWorkloadCohorts(ctx, cam, W, H, sim, cohorts, swarmK, SR, camKey, structs, stemK = 1, labelK = 1) {
  if (!cohorts || !cohorts.length || swarmK < 0.15) return;
  // The stem is DRAWN, not faded: its length runs 0 -> full, so it extends along
  // the surface normal as the lens resolves. The label follows a beat later,
  // sliding the last few px outward from the stem's end into place.
  const sk = Math.max(0, Math.min(1, stemK));
  const lk = Math.max(0, Math.min(1, labelK));
  if (sk < 0.02) return;
  const f = camFwd(cam);
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  ctx.textAlign = 'left';
  for (const co of cohorts) {
    const st = structs && structs[co.id];
    const u = (st && st.u) || co.anchor;
    if (!u) continue;
    const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
    if (facing < 0.1) continue;
    const a = Math.min(1, (facing - 0.1) / 0.25) * swarmK;
    const la = a * lk;
    const P = (st && st.p) || [u[0] * SR, u[1] * SR, u[2] * SR];
    project(cam, P[0], P[1], P[2], W, H, o4);
    const ax = o4[0], ay = o4[1];
    // ONE SPHERE-NORMAL STEM per workload: from the anchor on the surface
    // straight OUT along that point's own normal (centre → surface → out), a
    // CONSTANT WORLD LENGTH. It used to be held at a constant screen length by
    // dividing by px-per-world-unit, which made the stem grow enormously toward
    // the camera near the disc centre and swing as the globe turned — it read as
    // an animated radial ray. A fixed world length foreshortens honestly instead:
    // a short perpendicular nub near the centre, a tall one at the limb, always
    // plainly perpendicular to the surface. It exists only to carry the label.
    const stemL = SR * 0.11 * sk;
    project(cam, P[0] + u[0] * stemL, P[1] + u[1] * stemL, P[2] + u[2] * stemL, W, H, o4);
    const ex = o4[0], ey = o4[1];
    // the cohort's footprint comes from its ALLOCATION, never from particle
    // positions, so the label's clearance does not breathe either
    const rad = Math.min(74, 16 + co.slots * 7) * (o4[3] / (cam.fov / cam.dist));
    keepOut(ax, ay, Math.max(14, rad));
    let name = co.name;
    if (name.length > 22) name = name.slice(0, 21).trimEnd() + '…';
    // IDENTIFICATION ONLY: the globe label answers "which cloud is this?" and
    // nothing else. Slot counts and percentages live in the Active Workloads
    // panel. The label hangs at the OUTER END of the stem, horizontal in screen
    // space — the text never rotates with the stem and never follows curvature.
    ctx.font = fpxw(10.5, 600);
    const bw = ctx.measureText(name).width + 10 * FK;
    const bh = 14 * FK;
    // the label sits RIGHT NEXT TO the stem's end dot — that adjacency is what
    // ties the name to its stem, so the gap stays small even when the stem
    // foreshortens near the disc centre (occasional overlap is accepted)
    const GAP = (8 + 10 * (1 - lk)) * UIK;
    let lx = (ex - gcx) >= 0 ? ex + GAP : ex - GAP - bw;
    W_LAST = W;
    if (!clearOfBands(lx, ey - 7 * FK, bw, bh)) {
      const alt = lx > ex ? ex - GAP - bw : ex + GAP;
      if (clearOfBands(alt, ey - 7 * FK, bw, bh)) lx = alt;
    }
    if (lx < 6) lx = ex + GAP;
    else if (lx + bw > W - 8) lx = ex - GAP - bw;
    const ly = Math.max(20, Math.min(H - 8 - bh, ey - 7 * FK));
    const clean = !hitsLabel(lx, ly, bw, bh);
    LBL.push([lx, ly, bw, bh]);
    if (clean && lk > 0.02) clearBox(ctx, lx, ly, bw, bh, la);
    // THE STEM: one line, anchor → outer end, in the workload's colour, fading
    // outward so the anchor end reads as the attachment point.
    const gr = ctx.createLinearGradient(ax, ay, ex, ey);
    gr.addColorStop(0, rgba(co.color, Math.min(1, 0.45 * a)));
    gr.addColorStop(1, rgba(co.color, Math.min(1, 0.38 * a)));
    ctx.strokeStyle = gr;
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ex, ey); ctx.stroke();
    // THE STEM'S END DOT: the stem terminates in a small filled point in the
    // workload's colour, and the name sits immediately beside it — point and
    // text read as one lockup, which is what binds the label to its stem and so
    // to the anchor and cloud below it.
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.95 * a));
    ctx.beginPath(); ctx.arc(ex, ey, 2 * UIK, 0, 6.2832); ctx.fill();
    // WORKLOAD ANCHOR — small, restrained, workload-coloured: a thin ring with a
    // core and a very slow, very small breath. Not a Map compute node.
    const t2 = (sim && sim.t) || 0;
    const pul = 0.5 + 0.5 * Math.sin(t2 * 0.8 + (co.slots + name.length) * 0.7);
    const rr = 4.4 * UIK;
    ctx.strokeStyle = rgba(co.color, Math.min(1, 0.55 * a));
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.arc(ax, ay, rr * (1 + 0.06 * pul), 0, 6.2832); ctx.stroke();
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.85 * a));
    ctx.beginPath(); ctx.arc(ax, ay, 1.7 * UIK, 0, 6.2832); ctx.fill();
    ctx.textBaseline = 'middle';
    ctx.font = fpxw(10.5, 600);
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.9 * la));
    ctx.fillText(name, lx + 5 * FK, ly + bh / 2);
    ctx.textBaseline = 'alphabetic';
  }
}

// ---- PER-PARTICLE SPHERE NORMALS -------------------------------------------------
// The same geometry as the workload stem, one order of magnitude quieter: every
// ENGAGED particle gets a very short line along its own sphere normal
// (normalize(p − C)), in its workload's colour at low alpha. It is not a
// scaffold and carries no label — it just states that active capacity stands
// off the surface, and it makes a cohort read as one body of upright marks
// rather than loose dots. Fixed WORLD length, so it foreshortens honestly with
// rotation and never swings.
const _ps = new Float32Array(4), _pe = new Float32Array(4), _pc = new Float32Array(4);
function drawParticleStems(ctx, cam, sim, W, H, alloc, swarmK, SR) {
  if (!alloc || swarmK < 0.12) return;
  const f = camFwd(cam);
  const wlc = sim.wlc;
  // WHY THIS LOOKED LIKE NOTHING. A sphere-normal line foreshortens to a POINT
  // where the surface faces the camera and stands at full length at the limb — so
  // culling by `facing` threw away the only marks that could ever read as upright,
  // and everything that survived was drawn end-on. Two corrections: keep the limb
  // (cull only what is genuinely behind the horizon), and give every stem a minimum
  // SCREEN length so a foreshortened one still registers as a short tick instead
  // of vanishing. Alpha is not multiplied by swarmK here — the caller already sets
  // it as globalAlpha, and doing it twice squared the fade.
  const LE = SR * 0.042, LF = SR * 0.03;
  const MINPX = 2.2 * UIK;
  for (let i = 0; i < sim.N; i++) {
    const eng = !!alloc[i];
    const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
    const l = Math.hypot(x, y, z) || 1;
    const nx = x / l, ny = y / l, nz = z / l;
    const facing = -(nx * f[0] + ny * f[1] + nz * f[2]);
    if (facing < 0.02) continue;
    const L = eng ? LE : LF;
    project(cam, x, y, z, W, H, _ps);
    project(cam, x + nx * L, y + ny * L, z + nz * L, W, H, _pe);
    let dx = _pe[0] - _ps[0], dy = _pe[1] - _ps[1];
    const len = Math.hypot(dx, dy);
    if (!isFinite(len)) continue;
    if (len < MINPX) {
      if (len < 0.25) {
        // dead-on: no honest screen direction, so take the projected radius from
        // the disc centre — that is where "outward" points there
        project(cam, 0, 0, 0, W, H, _pc);
        dx = _ps[0] - _pc[0]; dy = _ps[1] - _pc[1];
        const rl = Math.hypot(dx, dy) || 1;
        dx = dx / rl * MINPX; dy = dy / rl * MINPX;
      } else { dx *= MINPX / len; dy *= MINPX / len; }
    }
    const o = i * 3;
    const c = (eng && wlc && wlc[o] >= 0) ? [wlc[o], wlc[o + 1], wlc[o + 2]] : [159, 176, 170];
    // brightest at the limb, where the stem is longest and reads most clearly
    const av = (eng ? 0.5 : 0.26) * (0.55 + 0.45 * (1 - Math.min(1, facing)));
    ctx.lineWidth = (eng ? 1 : 0.8) * UIK;
    const gr = ctx.createLinearGradient(_ps[0], _ps[1], _ps[0] + dx, _ps[1] + dy);
    gr.addColorStop(0, rgba(c, av));
    gr.addColorStop(0.6, rgba(c, av * 0.6));
    gr.addColorStop(1, rgba(c, av * 0.14));
    ctx.strokeStyle = gr;
    ctx.beginPath(); ctx.moveTo(_ps[0], _ps[1]); ctx.lineTo(_ps[0] + dx, _ps[1] + dy); ctx.stroke();
  }
}

// ---- YOU: a small 3D golf-flag on the world -------------------------------------
// A spatial OBJECT, not floating text: a thin radial pole out of the surface and
// a small pennant built in WORLD space, so both foreshorten and travel as the
// globe turns. The pole is the SAME FIXED WORLD LENGTH as a compute node's stem
// (SR*0.07), so YOU stands at the same height as the infrastructure around it and
// foreshortens by the same rule; the pennant and base are proportional to it. The
// pole follows the local surface normal; the pennant reaches along u×f, so its
// plane partially faces the camera and stays readable from any rotation.
// Structural teal, no glow, no pin, no waving.
const _yp = new Float32Array(4), _yq = new Float32Array(4), _yr = new Float32Array(4), _ys = new Float32Array(4);
function drawYou(ctx, cam, W, H, u, SR, zz, alpha, ctxInfo) {
  if (alpha < 0.03) return;
  const f = camFwd(cam);
  const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
  if (facing < 0.08) return;
  const vis = Math.min(1, (facing - 0.08) / 0.3) * alpha;
  // TRUE PERSPECTIVE, NO CHEATING: the pole is radial to the sphere, like every
  // node stem, so it foreshortens honestly — head-on it collapses to a point and
  // the flag is read from the base disc (a full circle in that view) and the
  // enlarged node mark instead. An earlier version leaned the pole toward the
  // camera to keep it visible; it looked forced and is gone (owner 2026-09-11).
  // pennant tangent: u × f, unit — in the screen plane, so the flag reads
  let wx = u[1] * f[2] - u[2] * f[1], wy = u[2] * f[0] - u[0] * f[2], wz = u[0] * f[1] - u[1] * f[0];
  const wl = Math.hypot(wx, wy, wz) || 1;
  wx /= wl; wy /= wl; wz /= wl;
  project(cam, u[0] * SR, u[1] * SR, u[2] * SR, W, H, _yp);                       // base
  project(cam, u[0] * SR + wx, u[1] * SR + wy, u[2] * SR + wz, W, H, _yq);        // tangent probe
  const pxw = Math.max(0.5, Math.hypot(_yq[0] - _yp[0], _yq[1] - _yp[1]));
  const L = SR * 0.07;                            // pole: same height as a node stem
  const FL = L * 0.42;                            // pennant reach, proportional
  const footH = SR + L * 0.72, tipH = SR + L * 0.90;
  project(cam, u[0] * (SR + L), u[1] * (SR + L), u[2] * (SR + L), W, H, _yq);     // pole top
  project(cam, u[0] * footH, u[1] * footH, u[2] * footH, W, H, _yr);              // flag foot
  project(cam, u[0] * tipH + wx * FL, u[1] * tipH + wy * FL, u[2] * tipH + wz * FL, W, H, _ys); // flag tip
  // CIRCULAR BASE: a real disc lying in the local tangent plane, so it
  // foreshortens into an ellipse with the surface and the flag reads as planted
  // rather than pasted on. Its basis is orthogonalised against u, so the leaning
  // pole never tips the disc out of the tangent plane.
  const wdu = wx * u[0] + wy * u[1] + wz * u[2];
  let twx = wx - u[0] * wdu, twy = wy - u[1] * wdu, twz = wz - u[2] * wdu;
  const twl = Math.hypot(twx, twy, twz) || 1; twx /= twl; twy /= twl; twz /= twl;
  let vx = u[1] * twz - u[2] * twy, vy = u[2] * twx - u[0] * twz, vz = u[0] * twy - u[1] * twx;
  const vln = Math.hypot(vx, vy, vz) || 1; vx /= vln; vy /= vln; vz /= vln;
  const BR = L * 0.31;
  ctx.beginPath();
  for (let i = 0; i <= 22; i++) {
    const th = (i / 22) * 6.2832, cs = Math.cos(th) * BR, sn = Math.sin(th) * BR;
    project(cam, u[0] * SR + twx * cs + vx * sn, u[1] * SR + twy * cs + vy * sn, u[2] * SR + twz * cs + vz * sn, W, H, _yr);
    if (i === 0) ctx.moveTo(_yr[0], _yr[1]); else ctx.lineTo(_yr[0], _yr[1]);
  }
  ctx.closePath();
  ctx.fillStyle = rgbaT('stage', (0.72 * vis).toFixed(3));
  ctx.fill();
  ctx.strokeStyle = TEAL(Math.min(1, 0.55 * vis));
  ctx.lineWidth = 0.9 * UIK;
  ctx.stroke();
  project(cam, u[0] * footH, u[1] * footH, u[2] * footH, W, H, _yr);              // flag foot (restore)
  // base tick on the surface
  ctx.fillStyle = TEAL(Math.min(1, 0.5 * vis));
  ctx.beginPath(); ctx.arc(_yp[0], _yp[1], 1.1 * UIK, 0, 6.2832); ctx.fill();
  // pole
  ctx.strokeStyle = TEAL(Math.min(1, 0.9 * vis));
  ctx.lineWidth = 1 * UIK;
  ctx.beginPath(); ctx.moveTo(_yp[0], _yp[1]); ctx.lineTo(_yq[0], _yq[1]); ctx.stroke();
  // pennant: a filled world-space triangle — restrained, no halo
  ctx.beginPath();
  ctx.moveTo(_yq[0], _yq[1]); ctx.lineTo(_ys[0], _ys[1]); ctx.lineTo(_yr[0], _yr[1]);
  ctx.closePath();
  ctx.fillStyle = TEAL(Math.min(1, 0.82 * vis));
  ctx.fill();
  // the physical object is reserved FIRST: nothing may sit on the flag
  {
    const x0 = Math.min(_yp[0], _yq[0], _ys[0]) - 6;
    const x1 = Math.max(_yp[0], _yq[0], _ys[0]) + 6;
    const y0 = Math.min(_yp[1], _yq[1], _ys[1]) - 6;
    const y1 = Math.max(_yp[1], _yq[1], _ys[1]) + 6;
    keepOutRect(x0, y0, x1 - x0, y1 - y0);
  }
  // YOU LABEL — ONE LOCKED HORIZONTAL LOCKUP: "YOU · OHIO · US-EAST-2", set on a
  // single line so nothing about it can fragment or stack. The node count is not
  // part of the lockup (the capacity panel owns quantities); the control plane is
  // optional tertiary metadata on a quiet second line once there is room. In
  // SWARM, where the region prints its own spatial reference, the flag prints the
  // word YOU alone.
  const C = ctxInfo || {};
  const combined = !!C.combined && !!C.region;
  ctx.textAlign = 'left';
  ctx.font = fpxw(11, 600);
  const wYou = ctx.measureText('YOU').width;
  let wRgn = 0, wSub = 0, wCtrl = 0;
  const ctrl = (combined && C.ctrl && (zz || 0) > 0.25) ? C.ctrl : null;
  if (combined) {
    ctx.font = fpx(11);
    wRgn = ctx.measureText(' · ' + C.region).width;
    if (ctrl) { ctx.font = fpx(8.5); wCtrl = ctx.measureText(ctrl).width; }
  }
  const PX = 5 * FK, PY = 4 * FK;
  const bw = Math.max(wYou + wRgn, wSub, wCtrl) + PX * 2;
  const bh = combined
    ? PY * 2 + (12 + (ctrl ? 3 + 8 : 0)) * FK
    : 15 * FK;
  // ATTACHED TO THE FLAG, NOT FLOATING BESIDE IT: the lockup hangs off the POLE
  // TOP — the same grammar as the node stems and the workload stems, where the
  // outer end of the 3D line carries a point and the horizontal text sits
  // immediately beside it. So the lockup rises and foreshortens with the flag.
  const mx = _yq[0], my = _yq[1];
  // SAME SIDE RULE AS THE NODES: flag on the left half of the globe, lockup goes
  // LEFT of it; right half, right of it. Fixed clearance, and the YOU line
  // aligned to the flag's mid height so the two read as one unit.
  project(cam, 0, 0, 0, W, H, o4b);
  const gcxY = o4b[0];
  const GAPY = 8 * UIK;
  const sideY = (mx - gcxY) >= 0 ? 1 : -1;
  const idOffY = combined ? PY + 6 * FK : bh * 0.5;
  const tryBox = dy => {
    const x = sideY > 0 ? mx + GAPY : mx - GAPY - bw;
    const y = my - idOffY + dy;
    if (x < 6 || x + bw > W - 8 || y < 20 || y + bh > H - 8) return null;
    return free(x, y, bw, bh) ? [x, y] : null;
  };
  let slot = tryBox(0) || tryBox(bh + 5 * FK) || tryBox(-(bh + 5 * FK));
  if (!slot) {
    // YOU is the highest-priority label on the stage: it is never dropped —
    // it parks on its own side and is clamped into the panel.
    const x = Math.max(6, Math.min(W - 8 - bw, sideY > 0 ? mx + GAPY : mx - GAPY - bw));
    slot = [x, Math.max(20, Math.min(H - 8 - bh, my - idOffY))];
  }
  LBL.push([slot[0], slot[1], bw, bh]);
  // YOU OUTRANKS EVERY OTHER LABEL: its lockup is reserved as a keep-out band, not
  // just a label box, so node ids, region names and workload names can never be
  // drawn over the flag or its text.
  keepOutRect(slot[0] - 2 * UIK, slot[1] - 2 * UIK, bw + 4 * UIK, bh + 4 * UIK);
  if (slot) {
    const [lx, ly] = slot;
    clearBox(ctx, lx, ly, bw, bh, vis);
    const y1 = combined ? ly + PY + 6 * FK : ly + bh * 0.5;
    ctx.font = fpxw(11, 600);
    ctx.fillStyle = TEAL(Math.min(1, 0.96 * vis));   // inverted (owner 2026-09-01): YOU carries the accent
    ctx.fillText('YOU', lx + PX, y1);
    if (combined) {
      ctx.font = fpx(11);
      ctx.fillStyle = LIT(Math.min(1, 0.9 * vis));    // …and the location is neutral
      ctx.fillText(' · ' + C.region, lx + PX + wYou, y1);
      if (ctrl) {
        ctx.font = fpx(8.5);
        ctx.fillStyle = INK(0.4 * vis);
        ctx.fillText(ctrl, lx + PX, ly + PY + (12 + 3 + 6) * FK);
      }
    }
  }
}

// ---- FLAGGED NODE: YOU's flag, planted on one compute node ----------------------
// Owner 2026-09-11. The SAME object as drawYou (radial pole at node-stem height,
// world-space pennant, tangent-plane base disc) in the structural primary role, so
// the two read as one grammar; what differs is the lockup, which carries what the
// node card cannot: the workloads this node serves and their tok/s.
// SELECTED NODE — THE SAME RING RESOURCE AS YOU (owner 2026-09-11, replacing the
// pole-and-pennant flag): a real circle lying in the node's local tangent plane,
// at the same world radius as YOU's base disc, so it foreshortens into an ellipse
// with the surface and reads as drawn ON the world. No pole, so nothing has to be
// propped up when the node faces the camera dead-on — that is the view where a
// ring is at its LARGEST, a full circle. Its basis comes from u alone, never from
// the camera, so the ellipse cannot wobble as the world turns.
const _np = new Float32Array(4), _nq = new Float32Array(4), _nr = new Float32Array(4);
function drawNodeRing(ctx, cam, W, H, u, SR, alpha, info) {
  if (alpha < 0.03 || !info) return;
  const f = camFwd(cam);
  const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
  if (facing < 0.08) return;
  const vis = Math.min(1, (facing - 0.08) / 0.3) * alpha;
  let e1 = [u[1], -u[0], 0];                       // u × ẑ — degenerate only at the poles
  let el = Math.hypot(e1[0], e1[1], e1[2]);
  if (el < 1e-3) { e1 = [1, 0, 0]; el = 1; }
  e1 = [e1[0] / el, e1[1] / el, e1[2] / el];
  const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
  const R = SR * 0.022;                            // = YOU's base disc radius
  let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  let exL = null, exR = null;
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const th = (i / 40) * 6.2832, cs = Math.cos(th) * R, sn = Math.sin(th) * R;
    project(cam,
      u[0] * SR + e1[0] * cs + e2[0] * sn,
      u[1] * SR + e1[1] * cs + e2[1] * sn,
      u[2] * SR + e1[2] * cs + e2[2] * sn, W, H, _nr);
    if (i === 0) ctx.moveTo(_nr[0], _nr[1]); else ctx.lineTo(_nr[0], _nr[1]);
    if (_nr[0] < minX) { minX = _nr[0]; exL = [_nr[0], _nr[1]]; }
    if (_nr[0] > maxX) { maxX = _nr[0]; exR = [_nr[0], _nr[1]]; }
    if (_nr[1] < minY) minY = _nr[1];
    if (_nr[1] > maxY) maxY = _nr[1];
  }
  ctx.closePath();
  ctx.fillStyle = rgbaT('stage', (0.5 * vis).toFixed(3));
  ctx.fill();
  ctx.strokeStyle = TEAL(Math.min(1, 0.7 * vis));  // primary role
  ctx.lineWidth = 1.1 * UIK;
  ctx.stroke();
  project(cam, u[0] * SR, u[1] * SR, u[2] * SR, W, H, _np);
  ctx.fillStyle = TEAL(Math.min(1, 0.5 * vis));
  ctx.beginPath(); ctx.arc(_np[0], _np[1], 1.1 * UIK, 0, 6.2832); ctx.fill();
  keepOutRect(minX - 4, minY - 4, (maxX - minX) + 8, (maxY - minY) + 8);
  // LOCKUP — node id and region on the YOU lines, then one row per workload this
  // node serves: name in the workload's own colour, tok/s right-aligned. Every
  // figure is handed in by the caller from the live traffic state; nothing about
  // quantity is computed here.
  const rows = info.rows || [];
  ctx.textAlign = 'left';
  ctx.font = fpxw(11, 600);
  const wId = ctx.measureText(info.id || '').width;
  ctx.font = fpx(11);
  const wRgn = info.region ? ctx.measureText(' · ' + info.region).width : 0;
  let wRow = 0;
  for (const r of rows) {
    ctx.font = fpx(9.5);
    const a2 = ctx.measureText(r.name).width;
    ctx.font = fpxw(9.5, 600);
    wRow = Math.max(wRow, a2 + 10 * FK + ctx.measureText(r.tok).width);
  }
  const PX = 5 * FK, PY = 4 * FK;
  const bw = Math.max(wId + wRgn, wRow) + PX * 2;
  const bh = PY * 2 + (12 + rows.length * 11) * FK;
  // HUNG OFF THE RING, not off the node: the lockup sits just outside the ring's
  // screen-space edge, on the side away from the globe centre — the same outward
  // rule the node ids follow.
  project(cam, 0, 0, 0, W, H, _nq);
  const side = (_np[0] - _nq[0]) >= 0 ? 1 : -1;
  const anchor = side > 0 ? (exR || [maxX, _np[1]]) : (exL || [minX, _np[1]]);
  const ax = anchor[0], ay = anchor[1];
  const GAP = 8 * UIK;
  const tryBox = ddy => {
    const x = side > 0 ? ax + GAP : ax - GAP - bw;
    const y = ay - bh * 0.5 + ddy;
    if (x < 6 || x + bw > W - 8 || y < 20 || y + bh > H - 8) return null;
    return free(x, y, bw, bh) ? [x, y] : null;
  };
  let slot = tryBox(0) || tryBox(bh + 5 * FK) || tryBox(-(bh + 5 * FK));
  if (!slot) {
    // a selected node the operator asked for is never dropped: it parks on its
    // own side, clamped into the stage
    const x = Math.max(6, Math.min(W - 8 - bw, side > 0 ? ax + GAP : ax - GAP - bw));
    slot = [x, Math.max(20, Math.min(H - 8 - bh, ay - bh * 0.5))];
  }
  LBL.push([slot[0], slot[1], bw, bh]);
  keepOutRect(slot[0] - 2 * UIK, slot[1] - 2 * UIK, bw + 4 * UIK, bh + 4 * UIK);
  const [lx, ly] = slot;
  clearBox(ctx, lx, ly, bw, bh, vis);
  const y1 = ly + PY + 6 * FK;
  ctx.font = fpxw(11, 600);
  ctx.fillStyle = TEAL(Math.min(1, 0.96 * vis));
  ctx.fillText(info.id || '', lx + PX, y1);
  if (info.region) {
    ctx.font = fpx(11);
    ctx.fillStyle = LIT(Math.min(1, 0.9 * vis));
    ctx.fillText(' · ' + info.region, lx + PX + wId, y1);
  }
  let ry = y1 + 12 * FK;
  for (const r of rows) {
    const c = r.rgb;
    ctx.font = fpx(9.5);
    ctx.fillStyle = c
      ? `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${Math.min(1, 0.95 * vis).toFixed(3)})`
      : LIT(Math.min(1, 0.8 * vis));
    ctx.fillText(r.name, lx + PX, ry);
    ctx.font = fpxw(9.5, 600);
    ctx.textAlign = 'right';
    ctx.fillStyle = LIT(Math.min(1, 0.85 * vis));
    ctx.fillText(r.tok, lx + bw - PX, ry);
    ctx.textAlign = 'left';
    ry += 11 * FK;
  }
}

// ---- REGIONAL REFERENCES (SWARM) -------------------------------------------------
// P2: text only, and placed by the SAME simple rule as every other label. The
// region name sits at ONE fixed offset from its own anchor, on the outward side
// of the globe centre, primary line on the anchor's horizontal axis. No candidate
// search, no hysteresis, no leader line, no marker: Swarm's regional reference is
// a quiet spatial context label, and only real compute nodes carry node marks.
function drawSideRegionLabels(ctx, cam, W, H, regions, nodesByRegion, lensA, info, camKey) {
  // Region names are spatial CONTEXT, not entities. The caller fades them as the
  // scales descend — full at GLOBAL, much quieter at REGIONAL, gone at LOCAL —
  // because once node ids are readable the region name is the least useful text on
  // the stage and must not sit at the same weight as node identity.
  if (lensA < 0.04) return;
  const f = camFwd(cam);
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  ctx.textAlign = 'left';
  // stable order: the same regions resolve in the same sequence every frame
  const list = [...regions].sort((p, q) => (p.id < q.id ? -1 : 1));
  for (const r of list) {
    const ids = nodesByRegion[r.id] || [];
    if (!ids.length) continue;
    const facing = -(r.u[0] * f[0] + r.u[1] * f[1] + r.u[2] * f[2]);
    if (facing < 0.08) continue;
    const a = Math.min(1, (facing - 0.08) / 0.22) * lensA;
    project(cam, r.p[0], r.p[1], r.p[2], W, H, o4);
    const ax = o4[0], ay = o4[1];
    const nfo = info && info[r.id];
    const name = (nfo && nfo.name) || r.id.toUpperCase();
    const sub = ids.length + ' nodes';
    ctx.font = fpxw(13, 600);
    const w1 = ctx.measureText(name).width;
    ctx.font = fpx(9.5);
    const w2 = ctx.measureText(sub).width;
    const bw = Math.max(w1, w2) + 8 * FK;
    const bh = 26 * FK;
    const GAP = 16 * UIK;
    let lx = (ax - gcx) >= 0 ? ax + GAP : ax - GAP - bw;
    W_LAST = W;
    if (!clearOfBands(lx, ay - 8 * FK, bw, bh)) {
      const alt = lx === ax + GAP ? ax - GAP - bw : ax + GAP;
      if (clearOfBands(alt, ay - 8 * FK, bw, bh)) lx = alt;
    }
    if (lx < 6) lx = ax + GAP;
    else if (lx + bw > W - 8) lx = ax - GAP - bw;
    const ly = ay - 8 * FK;
    if (ly < 20 || ly + bh > H - 8) continue;
    const clean = !hitsLabel(lx, ly, bw, bh);
    LBL.push([lx, ly, bw, bh]);
    if (clean) clearBox(ctx, lx, ly, bw, bh, a);
    ctx.textBaseline = 'middle';
    ctx.font = fpxw(13, 600);
    ctx.fillStyle = LIT(Math.min(1, 0.9 * a));
    ctx.fillText(name, lx + 4 * FK, ay);
    ctx.font = fpx(9.5);
    ctx.fillStyle = INK(0.5 * a);
    ctx.fillText(sub, lx + 4 * FK, ay + 14 * FK);
    ctx.textBaseline = 'alphabetic';
  }
}


return { HEAT_ON, heatRGB, setUiScale, buildGraticule, drawLandFill, keepOutRect, beginLabels, keepOut, setLabelWidth, placeLabel, drawPlaces, drawCohortLabels, drawSphereBase, drawLand, drawTrails, sceneHeat, GLYPHS, drawIsotherms, drawHistories, drawAgents, drawRegionMarks, buildNodeMarks, drawNodeMarks, drawWorkloadCohorts, drawParticleStems, drawYou, drawNodeRing, drawSideRegionLabels };
})();

// ===== capacity-field.js =====
__M["capacity-field.js"] = (() => {
// CAPACITY FIELD — the Swarm view's adapter over the untouched engine.
//
// WHAT CHANGED IN v2, AND WHY
//
// v1 expressed regional demand by letting the engine COMMIT agents to a
// probe: the engine's commitment machinery pulls committed agents onto slot
// vectors around one anchor. Reshaping those slots spread the mass out, but
// the underlying force was still "collect capacity at a place", so higher
// demand always tended toward a denser, brighter patch — the orange blob.
//
// v2 removes that force entirely. The engine runs permanently in its RESTING
// regime (probe 0, shell 0, engage 0, compress 0, thermal 0), so there is no
// attractor anywhere in the system and commitment never fires. Nothing can
// clump, structurally.
//
// Engagement is instead a BEHAVIOURAL treatment applied to velocities after
// the engine has stepped:
//
//   1. SHARED FLOW TENDENCY — engaged capacity near a region blends its
//      heading toward a common tangential circulation of that region, so many
//      independent wanderers become one legible sweep. Position is never a
//      target; capacity coordinates while continuing to travel.
//   2. REDUCED WANDER — the engine's OU angular noise is low-passed in
//      proportion to engagement, so engaged paths straighten and trails align.
//   3. MOTION SYNCHRONISATION — engaged capacity in a region shares one slow
//      speed phase, so the region breathes together.
//   4. CHROMA — a capped secondary cue only. Colour never carries the reading
//      on its own, and it never saturates.
//
// Regions hold PERSISTENT, INDEPENDENT levels: several regions can sit at
// different activity at the same time. There is no lifecycle, no acts, no
// story — the field is always running and the levels are just where they are.
//
// SIMULATION VALUES ARE PROTOTYPE-ONLY: activityLevel / engagement /
// capacityParticipation / coherence describe this simulation. They are not
// Civarro product metrics and are not mapped to GPU %, tok/s or request rate.
//
// vendor/swarm-core.js is byte-identical to the supplied prototype.
//
// DEVIATION FROM v2 (owner direction, 2026-08-25): ORBITAL ASSEMBLY.
// Engaged capacity may temporarily assemble into a loose orbital formation
// around the regional centre. Each agent targets its OWN ring radius (a band,
// never the centre point), so the formation stays porous and individually
// resolvable; the density relief and crowd escape stay active underneath and
// keep it from ever collapsing into a mass. When activity falls, engagement
// decays and the formation dissolves back into the ambient field.

const core = __M["vendor/swarm-core.js"];
const {makeHive} = __M["hive.js"];

const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;

// Engagement falloff around a region, in radians of arc on the world. The
// field GROWS with activity: at moderate activity it stays tight enough that
// two active regions read separately, and at higher demand it reaches further
// out, so more distant capacity genuinely joins in rather than the same
// capacity merely getting brighter.
//
// Tightened in the final pass for regional legibility: in a one-region state
// the coordinated portion should visibly BELONG to that region, with the rest
// of the sphere carrying on independently. Tightening the cone changes only
// who participates — there is still no attractor, so nothing densifies.
// v2 refinement pass: TIGHTER still. Frankfurt active must read as a
// Frankfurt-area phenomenon, so the cone that decides who participates is
// roughly half the previous solid angle. Nothing else changes: no attractor,
// no densification — only membership narrows.
// Refinement: recruit MORE nearby capacity (a wider intake) while the assembled
// body itself gets SMALLER and fully packed — concentration comes from filling a
// tighter footprint, never from bigger glyphs.
const angIn = lv => 0.15 + 0.095 * lv;
const angOut = lv => 0.35 + 0.26 * lv;

function makeField(opts = {}) {
  const SR = opts.SR ?? 58;
  const HIVE = makeHive();                        // containment math only, never drawn
  const sim = core.createSystem({ n: opts.n ?? 520, hive: HIVE, worldR: 70, speed: 0.34 });
  // v3 — THE TWO KNOBS, SEPARATED.
  //
  // In v2 one number did two jobs: the arc position decided BOTH how strongly
  // capacity adheres to the formation and how small that formation is. Pushing
  // the arc up to get a real formation therefore always produced a critical
  // mass, and pulling it down to open the formation up dissolved the formation
  // entirely. So the two are now separate:
  //
  //   sim.dwell (below)  how strongly engaged capacity holds the formation
  //   sim.shellK (here)  how BIG that formation is
  //
  // Adherence stays high, so the cohort is unmistakably one coordinated body;
  // the envelope is more than twice v2's radius, so the same population occupies
  // roughly six times the area and every mark stays individually resolvable.
  // compact by direction (Swarm pass): the cohort reads as ONE contained,
  // efficient formation — most of the group near the coordinated core, only a
  // minority at the rim. Still porous (compression stays low, so no solid mass,
  // no vibration, no heat), but the envelope is clearly smaller than before.
  sim.shellK = 0.50;                              // envelope scale
  sim.PATCH.length = 0; sim.sites.length = 0;     // ABC / resource sites off
  sim.probe.auto = 0;
  const N = sim.N;
  const SPD0 = sim.SPD * 0.5;

  // deterministic per-agent character
  let s = 20260825 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };

  const eng = new Float32Array(N);                // engagement, 0..1
  const chroma = new Float32Array(N);             // secondary colour cue, 0..~0.7
  const bias = new Float32Array(N);               // participation propensity
  const tauE = new Float32Array(N);               // engagement time constant
  const prevH = new Float32Array(N * 3);          // last frame's heading (wander low-pass)
  const turn = new Float32Array(N);               // measured heading change rate, rad/s
  const home = new Int8Array(N).fill(-1);
  const slotOf = new Int16Array(N).fill(-1);      // formation station, -1 = none
  const slotReg = new Int8Array(N).fill(-1);
  const arr = new Uint8Array(N);                  // 1 = docked at its station
  const lift = new Float32Array(N);               // radial height off the shell
  let EMERGE = null;                              // lens-transition origins
  const ctr = new Float32Array(N * 3);            // the particle's OWN cohort centre
  const hasCtr = new Uint8Array(N);
  // DIRECT PLACEMENT of engaged capacity (see placeEngaged below): its own polar
  // address inside its workload's cloud, plus a per-particle motion phase.
  const pcoh = new Int16Array(N).fill(-1);
  const prho = new Float32Array(N);
  const pphi = new Float32Array(N);
  const pphs = new Float32Array(N);
  const ppx = new Float32Array(N), ppy = new Float32Array(N), ppz = new Float32Array(N);
  const asmT = new Float32Array(N);               // recruitment countdown, s
  const curve = new Float32Array(N);              // own approach curvature bias
  const hold = new Float32Array(N);               // time spent in transit
  const saz = new Float32Array(N);                // slot azimuth on the patch
  const srad = new Float32Array(N);               // radial fraction, RMIN..1
  const swirl = new Float32Array(N);              // per-agent flow-band phase
  const occ = new Int16Array(64);                 // equal-area occupancy cells
  const ocx = new Float32Array(64), ocy = new Float32Array(64), ocz = new Float32Array(64);
  const cell = new Int8Array(N);
  for (let i = 0; i < N; i++) {
    bias[i] = 0.40 + rnd() * 0.85;                // some capacity stays independent even in a busy region
    tauE[i] = 1.1 + rnd() * 1.5;
    swirl[i] = rnd() * 6.283;
  }

  const REG = (opts.regions || []).map(r => ({
    id: r.id, u: r.u.slice(), p: r.p.slice(),
    activityLevel: 0, target: 0, phase: rnd() * 6.283,
    flowSign: r.flowSign ?? 1,
    coherence: 0, participation: 0, spread: 0,
    rotPhase: rnd() * 6.283, e1: null, e2: null, ballR: 0, docked: 0
  }));
  for (const r of REG) {
    let e1 = [r.u[1], -r.u[0], 0];
    let L2 = Math.hypot(e1[0], e1[1], e1[2]);
    if (L2 < 1e-3) { e1 = [1, 0, 0]; L2 = 1; }
    r.e1 = [e1[0] / L2, e1[1] / L2, e1[2] / L2];
    r.e2 = [r.u[1] * r.e1[2] - r.u[2] * r.e1[1], r.u[2] * r.e1[0] - r.u[0] * r.e1[2], r.u[0] * r.e1[1] - r.u[1] * r.e1[0]];
  }
  // FORMATION — the original swarm's own mechanics, re-aimed at the coordinated
  // region instead of the cursor. Each committed agent keeps a persistent SLOT:
  // an azimuth on the region's tangent plane plus a radial fraction in
  // [RMIN, 1] of the ball radius. The cube-root distribution fills the annulus
  // evenly instead of crowding the rim, and RMIN leaves a hollow core, so the
  // body forms AROUND the node and never touches it. The ball grows with the
  // population it holds (√n, as in the original) and turns as one via rotPhase.
  const RMIN = 0.22;                               // a FILLED disc with a small core — never a ring
  const CAP = 42;                                  // members per cohort
  // The original sized its ball with a √n law for a 3D volume. Here the body is
  // an annulus ON the surface, so the radius follows the AREA the population
  // needs at the glyph pitch, with the hollow core discounted:
  //   n·0.866·pitch² = π·R²·(1 − RMIN²)
  function ballRadius(n) {
    const need = Math.max(1, n) * 0.866;
    return F.stationPitch * 1.22 * Math.max(1.6, Math.sqrt(need / (Math.PI * (1 - RMIN * RMIN))));
  }

  const RIX = Object.fromEntries(REG.map((r, i) => [r.id, i]));

  function toSurface() {
    for (let i = 0; i < N; i++) {
      const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
      const L = Math.hypot(x, y, z) || 1, k = SR / L;
      sim.px[i] = x * k; sim.py[i] = y * k; sim.pz[i] = z * k;
      const nx = x / L, ny = y / L, nz = z / L;
      const rad = sim.vx[i] * nx + sim.vy[i] * ny + sim.vz[i] * nz;
      sim.vx[i] -= rad * nx; sim.vy[i] -= rad * ny; sim.vz[i] -= rad * nz;
    }
  }

  // ===== CAPACITY OWNERSHIP MODEL ==========================================
  // NETWORK -> REGION -> NODE -> SLOT -> PARTICLES -> FREE/ENGAGED.
  //
  // Ownership comes BEFORE state. Every slot has a permanent node and region;
  // every particle inherits that ownership from its slot and never leaves it.
  // Position, proximity, movement, density and animation cannot change it.
  // Only the SLOT's allocation decides FREE vs ENGAGED, and it decides for all
  // five of its particles at once.
  //
  // PROTOTYPE FIXTURE — a stand-in for backend slot ownership, not a claim
  // about production capacity: 59 slots over 10 nodes.
  const PER_SLOT = 5;
  const NODE_SLOTS = [
    { region: 'ohio', node: 'ohio-node-01', slots: 6 },
    { region: 'ohio', node: 'ohio-node-02', slots: 6 },
    { region: 'ohio', node: 'ohio-node-03', slots: 6 },
    { region: 'ohio', node: 'ohio-node-04', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-01', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-02', slots: 6 },
    { region: 'frankfurt', node: 'frankfurt-node-03', slots: 6 },
    { region: 'dublin', node: 'dublin-node-01', slots: 6 },
    { region: 'dublin', node: 'dublin-node-02', slots: 6 },
    { region: 'dublin', node: 'dublin-node-03', slots: 5 }
  ];
  // the slot table, and the particle ids each slot permanently owns
  const SLOTS = [];
  const ownerOf = new Int16Array(N).fill(-1);       // region index, immutable
  const slotOfParticle = new Int16Array(N).fill(-1);
  {
    let pid = 0;
    for (const nd of NODE_SLOTS) {
      const rk = RIX[nd.region];
      for (let s = 0; s < nd.slots; s++) {
        const ids = [];
        for (let k = 0; k < PER_SLOT && pid < N; k++, pid++) {
          ids.push(pid);
          ownerOf[pid] = rk;
          slotOfParticle[pid] = SLOTS.length;
        }
        SLOTS.push({ id: SLOTS.length, node: nd.node, region: nd.region, rk, ids, used: 0 });
      }
    }
  }
  let ballAt = null;                                // per-agent ball centre
  const slotsTotal = SLOTS.length;
  const alloc = new Uint8Array(N);                  // 1 = ENGAGED
  const usedBy = {};
  for (const r of REG) usedBy[r.id] = 0;
  let allocKey = '';
  let slotsUsed = 0;

  // the engine assigns a solid-angle slot on commitment; because membership is
  // declared here, the direction is handed out here too — indexed by the
  // particle's rank within its own region's engaged set, so each cohort fills
  // its ball evenly and the same identities always take the same places
  const GOLD = Math.PI * (3 - Math.sqrt(5));
  const _sl = new Float32Array(3);
  function fibSlot(k, n, out) {
    const z = 1 - 2 * (k + 0.5) / Math.max(1, n);
    const r = Math.sqrt(Math.max(0, 1 - z * z));
    const a = k * GOLD;
    out[0] = Math.cos(a) * r; out[1] = z; out[2] = Math.sin(a) * r;
  }

  // FREE/ENGAGED is set at SLOT level. A region's used slots can only come from
  // the slots that region already owns.
  function applyUsed(perRegion) {
    alloc.fill(0);
    lift.fill(0);
    hasCtr.fill(0);
    pcoh.fill(-1);
    slotsUsed = 0;
    for (const r of REG) {
      const own = SLOTS.filter(s => s.region === r.id);
      const want = Math.max(0, Math.min(own.length, Math.round(perRegion[r.id] || 0)));
      usedBy[r.id] = want;
      slotsUsed += want;
      let rank = 0;
      for (let k = 0; k < own.length; k++) {
        const s = own[k];
        s.used = k < want ? 1 : 0;
        if (!s.used) continue;
        for (const i of s.ids) alloc[i] = 1;
      }
      const total = want * PER_SLOT;
      for (let k = 0; k < own.length; k++) {
        const s = own[k];
        if (!s.used) continue;
        for (const i of s.ids) {
          fibSlot(rank++, total, _sl);
          sim.slot[i * 3] = _sl[0]; sim.slot[i * 3 + 1] = _sl[1]; sim.slot[i * 3 + 2] = _sl[2];
        }
      }
    }
  }

  // ADDRESSED ALLOCATION. applyUsed() above takes a count per region and marks
  // that region's first N slots; a review fixture instead names the exact slots
  // it engages, by their permanent address [nodeId, indexWithinNode]. Same
  // ownership model, same per-slot particles, no counts inferred — the fixture
  // decides which nodes participate.
  function applyUsedAddresses(list) {
    const byAddr = {};
    const perNode = {};
    for (const s of SLOTS) {
      const k = (perNode[s.node] = (perNode[s.node] ?? -1) + 1);
      byAddr[s.node + '#' + k] = s;
    }
    alloc.fill(0);
    lift.fill(0);
    hasCtr.fill(0);
    pcoh.fill(-1);
    slotsUsed = 0;
    for (const r of REG) usedBy[r.id] = 0;
    for (const s of SLOTS) s.used = 0;
    for (const [node, idx] of list) {
      const s = byAddr[node + '#' + idx];
      if (!s || s.used) continue;
      s.used = 1;
      slotsUsed++;
      usedBy[s.region] = (usedBy[s.region] || 0) + 1;
      for (const i of s.ids) alloc[i] = 1;
    }
    // formation slots, per region, over that region's engaged particles
    for (const r of REG) {
      const own = SLOTS.filter(s => s.region === r.id && s.used);
      const total = own.length * PER_SLOT;
      let rank = 0;
      for (const s of own) for (const i of s.ids) {
        fibSlot(rank++, total, _sl);
        sim.slot[i * 3] = _sl[0]; sim.slot[i * 3 + 1] = _sl[1]; sim.slot[i * 3 + 2] = _sl[2];
      }
    }
  }

  // ---- ONE COHORT PER WORKLOAD FOOTPRINT ---------------------------------------
  // OWNERSHIP IS AUTHORITATIVE. A slot permanently belongs to a node and a
  // region; its five particles inherit that ownership and nothing here may move
  // them out of it. An earlier build tallied a workload's regions, picked a HOME
  // region and gathered ALL of its capacity there so each workload would have
  // exactly one cloud. That contradicted the model: capacity allocated on a
  // Frankfurt node was drawn in Ohio.
  // So a workload is split into FOOTPRINTS — one per region it actually holds
  // capacity in — and each footprint is stationed in ITS OWN region. VISION PRO
  // with a slot on sev-2 (Ohio) and one on gpu-1 (Frankfurt) therefore shows
  // capacity in both places. It remains ONE workload record with ONE colour and
  // ONE label: the label anchors on the PRIMARY footprint (most particles; ties
  // resolve by lowest region index, so the choice is deterministic), and the
  // other footprints are recognised by the shared workload colour.
  let COHORTS = [];
  function setCohortStations(groups) {
    const byReg = new Map();
    for (const g of groups || []) {
      const mine = [];
      const tally = new Map();
      for (const i of g.parts || []) {
        if (!alloc[i]) continue;
        const k = ownerOf[i];
        if (k < 0) continue;
        mine.push(i);
        tally.set(k, (tally.get(k) || 0) + 1);
      }
      if (!mine.length) continue;
      let home = -1, hv = -1;
      for (const [k, n] of tally) if (n > hv || (n === hv && k < home)) { hv = n; home = k; }
      mine.sort((a, b2) => a - b2);
      if (!byReg.has(home)) byReg.set(home, []);
      byReg.get(home).push({ id: g.id, parts: mine });
    }
    const centres = {};
    COHORTS = [];
    for (const [k, list] of byReg) {
      const r = REG[k];
      const G = list.length;
      const ballR = ballRadius(list.reduce((n, g) => n + g.parts.length, 0));
      // the region's own tangent frame: sub-cohorts separate ALONG the surface,
      // never radially — engaged capacity is projected onto the sphere, so a
      // radial split would collapse into the same screen area
      let e1x = -r.u[2], e1y = 0, e1z = r.u[0];
      let e1l = Math.hypot(e1x, e1y, e1z);
      if (e1l < 1e-4) { e1x = 1; e1y = 0; e1z = 0; e1l = 1; }
      e1x /= e1l; e1y /= e1l; e1z /= e1l;
      const e2x = r.u[1] * e1z - r.u[2] * e1y;
      const e2y = r.u[2] * e1x - r.u[0] * e1z;
      const e2z = r.u[0] * e1y - r.u[1] * e1x;
      const SEP = G === 1 ? 0 : 0.8;             // sector centre, in ball radii
      for (let gi = 0; gi < G; gi++) {
        const g = list[gi];
        const thg = (gi / G) * 6.2832 + 0.4;
        const bx = Math.cos(thg) * e1x + Math.sin(thg) * e2x;
        const by = Math.cos(thg) * e1y + Math.sin(thg) * e2y;
        const bz = Math.cos(thg) * e1z + Math.sin(thg) * e2z;
        const M = g.parts.length;
        // ONE COMPACT CLOUD per workload, around its own anchor: a fibonacci fill
        // of a small tangential patch, so every particle still holds a DISTINCT
        // station (which is what stops the engine's spacing forces from scattering
        // a cohort) while the group reads as ONE cloud. No branches, no spokes, no
        // scaffold: the only structure is the single sphere-normal stem the
        // renderer raises from the anchor to carry the label.
        // CLOUD RADIUS — owner 2026-09-11: 1.05 / 0.52 still read as too separated
        // in Capacity, both between particles and from the node they belong to.
        // Tightened to ~2/3, and the inner ring pulled closer to the anchor, so a
        // cohort sits ON its node instead of orbiting wide of it. Particles still
        // resolve individually — the ring band and the golden-angle spacing are
        // unchanged, only the radius shrinks.
        const SPR = G === 1 ? 0.68 : 0.34;       // cloud radius, in ball radii
        const RC = ballR * SPR;                  // cloud radius, world units
        for (let j = 0; j < M; j++) {
          const i = g.parts[j];
          // sqrt keeps the fill area-even (no dense core); the 0.4 floor pushes the
          // innermost ring off the anchor so nothing piles up on the marker
          const fr = 0.3 + 0.7 * Math.sqrt((j + 0.5) / M);
          const rho = SPR * fr;
          const ph = j * GOLD;
          const cx2 = Math.cos(ph) * rho, sy2 = Math.sin(ph) * rho;
          let dx = bx * SEP + e1x * cx2 + e2x * sy2 + r.u[0] * 0.05;
          let dy = by * SEP + e1y * cx2 + e2y * sy2 + r.u[1] * 0.05;
          let dz = bz * SEP + e1z * cx2 + e2z * sy2 + r.u[2] * 0.05;
          const dl = Math.hypot(dx, dy, dz) || 1;
          const cap = Math.min(1, dl);
          sim.slot[i * 3] = dx / dl * cap;
          sim.slot[i * 3 + 1] = dy / dl * cap;
          sim.slot[i * 3 + 2] = dz / dl * cap;
          lift[i] = 0;
          hasCtr[i] = 1;
          // its polar address inside its OWN cloud, and its own motion phase
          pcoh[i] = COHORTS.length;
          prho[i] = RC * fr;
          pphi[i] = ph;
          pphs[i] = (j * 2.399963) % 6.2832;
        }
        // THE WORKLOAD ANCHOR: one point on the sphere. The renderer raises a
        // single stem from it along THIS point's own normal.
        const axw = r.u[0] * SR + bx * ballR * SEP;
        const ayw = r.u[1] * SR + by * ballR * SEP;
        const azw = r.u[2] * SR + bz * ballR * SEP;
        const al2 = Math.hypot(axw, ayw, azw) || 1;
        const co = {
          id: g.id, reg: k, n: M,
          c: [axw / al2 * SR, ayw / al2 * SR, azw / al2 * SR],
          // the cloud's own tangent frame at the anchor, for direct placement
          t1: null, t2: null, rc: RC
        };
        {
          const nx = axw / al2, ny = ayw / al2, nz = azw / al2;
          let ax2 = -nz, ay2 = 0, az2 = nx;
          let al3 = Math.hypot(ax2, ay2, az2);
          if (al3 < 1e-4) { ax2 = 1; ay2 = 0; az2 = 0; al3 = 1; }
          co.t1 = [ax2 / al3, ay2 / al3, az2 / al3];
          co.t2 = [ny * co.t1[2] - nz * co.t1[1], nz * co.t1[0] - nx * co.t1[2], nx * co.t1[1] - ny * co.t1[0]];
        }
        for (const i of g.parts) {
          ctr[i * 3] = axw / al2; ctr[i * 3 + 1] = ayw / al2; ctr[i * 3 + 2] = azw / al2;
        }
        COHORTS.push(co);
        const cl = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
        const prev = centres[g.id];
        // PRIMARY FOOTPRINT for the label: most particles wins; a tie goes to the
        // lowest region index, so the anchor never depends on iteration luck
        if (!prev || M > prev.n || (M === prev.n && k < prev.k)) {
          centres[g.id] = { n: M, k, u: [co.c[0] / cl, co.c[1] / cl, co.c[2] / cl] };
        }
      }
    }
    const out = {};
    for (const id in centres) out[id] = centres[id].u;
    return out;
  }
  // live structures in world space, read AFTER this frame's body rotation. One
  // entry per workload id: its PRIMARY footprint (most particles, ties to the
  // lowest region index) — the label anchors there, the other footprints keep
  // their own clouds where their capacity actually lives.
  function cohortStructures() {
    const out = {};
    for (const co of COHORTS) {
      const l = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
      const u = [co.c[0] / l, co.c[1] / l, co.c[2] / l];
      const s = { u, p: co.c, n: co.n, reg: co.reg };
      const prev = out[co.id];
      if (!prev) { out[co.id] = s; s.all = [s]; continue; }
      const all = prev.all;
      all.push(s);
      if (co.n > prev.n || (co.n === prev.n && co.reg < prev.reg)) {
        out[co.id] = s; s.all = all;          // the primary, still carrying the set
      }
    }
    return out;
  }

  // ---- DIRECT PLACEMENT OF ENGAGED CAPACITY ------------------------------------
  // THE REASON NOTHING BEFORE THIS WORKED. swarm-core owns the positions of every
  // committed particle and organises them around ONE anchor for the whole engine
  // (sim.probeAnchor = the dominant region's point). Every previous attempt only
  // set station vectors and velocity nudges, which the engine consumes as hints
  // inside its own single ball — so the clouds kept sliding off their anchors and
  // interleaving, no matter what the stations said.
  // So engaged capacity is no longer asked: it is PLACED. Each particle sits at
  // its own polar address inside its workload's cloud, around that workload's own
  // anchor, and the only motion is a small deterministic wobble of its angle,
  // radius and height. Free capacity is untouched — the engine still owns all 245.
  function placeEngaged(t) {
    let unplaced = 0;
    for (let i = 0; i < N; i++) {
      const ci = pcoh[i];
      if (!alloc[i]) continue;
      if (ci < 0 || ci >= COHORTS.length) { unplaced++; continue; }
      const co = COHORTS[ci];
      const ph = pphs[i];
      // ORBIT. Each particle circles its own workload anchor — the angle advances
      // continuously at its own rate, so the cloud is in permanent local motion
      // instead of merely trembling — while its radius breathes on a different
      // period. Coordinated (all one way) but never in lockstep.
      const om = 0.34 + 0.22 * ((i * 0.618034) % 1);          // rad/s, per particle
      const phi = pphi[i] + t * om + 0.18 * Math.sin(t * 1.1 + ph);
      const rr = prho[i] * (1 + 0.24 * Math.sin(t * 0.85 + ph * 1.7) + 0.08 * Math.sin(t * 2.3 + ph));
      const hi = co.rc * 0.05 * (0.5 + 0.5 * Math.sin(t * 0.8 + ph * 0.9));
      const cs = Math.cos(phi) * rr, sn = Math.sin(phi) * rr;
      let x = co.c[0] + co.t1[0] * cs + co.t2[0] * sn;
      let y = co.c[1] + co.t1[1] * cs + co.t2[1] * sn;
      let z = co.c[2] + co.t1[2] * cs + co.t2[2] * sn;
      const l = Math.hypot(x, y, z) || 1;
      const k2 = (SR + hi) / l;
      x *= k2; y *= k2; z *= k2;
      // velocity from the actual displacement, so glyph headings and wakes stay honest
      sim.vx[i] = (x - (ppx[i] || x)) * 60;
      sim.vy[i] = (y - (ppy[i] || y)) * 60;
      sim.vz[i] = (z - (ppz[i] || z)) * 60;
      ppx[i] = x; ppy[i] = y; ppz[i] = z;
      sim.px[i] = x; sim.py[i] = y; sim.pz[i] = z;
    }
    if (typeof window !== 'undefined') {
      // how far each engaged particle sits from its OWN cohort centre: the number
      // that says whether any colour has been stranded away from its anchor
      let far = 0, maxArc = 0;
      for (let i = 0; i < N; i++) {
        const ci = pcoh[i];
        if (ci < 0 || !alloc[i] || ci >= COHORTS.length) continue;
        const co = COHORTS[ci];
        const l = Math.hypot(co.c[0], co.c[1], co.c[2]) || 1;
        const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
        const cd = (co.c[0] * sim.px[i] + co.c[1] * sim.py[i] + co.c[2] * sim.pz[i]) / (l * pl);
        const arc = Math.acos(Math.max(-1, Math.min(1, cd))) * 57.2958;
        if (arc > maxArc) maxArc = arc;
        if (arc > 12) far++;
      }
      let eng = 0; for (let i = 0; i < N; i++) if (alloc[i]) eng++;
      window.__engDbg = { unplaced, cohorts: COHORTS.length, engaged: eng, strayOver12deg: far, maxArcDeg: +maxArc.toFixed(1) };
    }
  }

  const F = {
    sim, SR, eng, chroma, home, regions: REG,
    alloc, PER_SLOT, lift,
    get slots() {
      const engaged = slotsUsed * PER_SLOT;
      const tot = slotsTotal * PER_SLOT;
      return {
        total: slotsTotal, used: slotsUsed, free: slotsTotal - slotsUsed,
        particlesTotal: tot, particlesEngaged: engaged, particlesFree: tot - engaged,
        usedPct: slotsTotal ? Math.round(slotsUsed / slotsTotal * 100) : 0,
        freePct: slotsTotal ? Math.round((slotsTotal - slotsUsed) / slotsTotal * 100) : 0
      };
    },
    // the slot table, read-only, for consumers that must map a slot's OWN
    // particles to something outside the model (e.g. workload identity)
    slotTable() { return SLOTS.map(s => ({ id: s.id, node: s.node, region: s.region, used: s.used, ids: s.ids })); },
    setCohortStations, cohortStructures,
    emergeOrigins() {
      if (!EMERGE) EMERGE = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        const o = i * 3;
        let u = null;
        if (alloc[i] && hasCtr[i]) u = [ctr[o], ctr[o + 1], ctr[o + 2]];
        else { const k = ownerOf[i]; if (k >= 0) u = REG[k].u; }
        if (u) { EMERGE[o] = u[0]; EMERGE[o + 1] = u[1]; EMERGE[o + 2] = u[2]; }
        else { EMERGE[o] = 0; EMERGE[o + 1] = 0; EMERGE[o + 2] = 0; }
      }
      return EMERGE;
    },
    // ownership: permanent, and independent of any fixture
    ownership() {
      const out = { network: { slots: slotsTotal, particles: slotsTotal * PER_SLOT, nodes: NODE_SLOTS.length }, regions: {} };
      for (const r of REG) {
        const own = SLOTS.filter(s => s.region === r.id);
        if (!own.length) continue;
        out.regions[r.id] = {
          nodes: new Set(own.map(s => s.node)).size,
          slots: own.length,
          particles: own.length * PER_SLOT,
          usedSlots: usedBy[r.id],
          freeSlots: own.length - usedBy[r.id],
          engagedParticles: usedBy[r.id] * PER_SLOT,
          freeParticles: (own.length - usedBy[r.id]) * PER_SLOT
        };
      }
      return out;
    },
    audit() {
      const byRegion = {};
      for (const r of REG) byRegion[r.id] = 0;
      for (let i = 0; i < N; i++) if (alloc[i] && ownerOf[i] >= 0) byRegion[REG[ownerOf[i]].id]++;
      let a = 0, c = 0, hot = 0;
      for (let i = 0; i < N; i++) {
        if (alloc[i]) a++;
        if (sim.cmt[i]) c++;
        if (chroma[i] > 0) hot++;
      }
      return { N, allocated: a, committed: c, coloured: hot, byRegion, expected: slotsUsed * PER_SLOT };
    },
    // perRegion: { regionId: usedSlots }. Only the regions whose count changed
    // are recomputed, so no region loses capacity because another gained it.
    // perRegion: { regionId: usedSlots } — the quantitative source of truth
    setSlots(_total, perRegion) {
      const key = REG.map(r => r.id + '=' + (perRegion[r.id] || 0)).join(',');
      if (key !== allocKey) { allocKey = key; applyUsed(perRegion); }
    },
    usedByRegion() { return { ...usedBy }; },
    // engage exactly these slot addresses ([nodeId, indexWithinNode] pairs)
    setUsedSlotAddresses(list) {
      const key = 'addr:' + list.map(a => a.join('#')).join(',');
      if (key !== allocKey) { allocKey = key; applyUsedAddresses(list); }
    },
    occupancyPeak: 0,
    tune: { flow: 1.7, wander: 0.55, sync: 0.18, chroma: 1.0, orbit: 1.0 },
    stationPitch: 3.3,
    // called from the render loop: the pitch that keeps a constant screen gap
    setStationPitch(v) {
      const w = Math.max(0.18, Math.min(7, v));
      if (Math.abs(w - this.stationPitch) / this.stationPitch > 0.05) this.stationPitch = w;
    },
    fixture: 'BASELINE',

    // ---- persistent state: set a region's activity, leave the others alone ----
    setLevel(id, v) { const k = RIX[id]; if (k !== undefined) REG[k].target = clamp01(v); },
    setLevels(map) { for (const r of REG) r.target = clamp01(map[r.id] ?? 0); },
    level(id) { const k = RIX[id]; return k === undefined ? 0 : REG[k].activityLevel; },

    update(dt) {
      // USE THE ENGINE'S OWN RESPONSE ARC. swarm-core already carries the
      // approved animation — hysteretic commitment, the converge → enclose →
      // peak walk, volumetric slots inside a contracting ball, incoming agents
      // dashing and settling members vibrating. Earlier revisions switched all
      // of that off and re-implemented a station grid by hand; this drives the
      // engine instead. The only change is WHERE it points: the anchor is the
      // coordinated region's own surface point, not the cursor.
      {
        let dom = null;
        for (const r of REG) if (!dom || r.activityLevel > dom.activityLevel) dom = r;
        const lvDom = dom ? dom.activityLevel : 0;
        if (dom && lvDom > 0.06) {
          sim.probeAnchor = [dom.p[0], dom.p[1], dom.p[2]];
          // v3 — A REGIME OF OUR OWN, NOT A POINT ON THE ARC.
          //
          // The engine's arc moves four things together: adherence to the
          // formation (shell), contraction (compress), heat (thermal) and global
          // alignment (align). v2 rode that arc, so the only way to get a real
          // formation was to accept the contraction, the vibration and the heat
          // that come with it — which is exactly the overload reading. The terms
          // are independent inputs to the model, so they are now set
          // independently:
          //
          //   shell    HIGH   the cohort genuinely holds one formation
          //   compress LOW    no contraction, no slowdown, no shell vibration
          //   thermal  ~0     nothing heats, so nothing can read as failure
          //   align    LOW    free capacity stays evenly distributed instead of
          //                   flocking into streams and knots of its own
          //
          // thermal sits a hair above zero on purpose: swarm-core substitutes its
          // own arc for any pinned regime whose thermal is exactly 0, and this
          // regime has to survive as written.
          const q = Math.min(1, lvDom);
          sim.regime = {
            probe: 1, flee: 0,
            engage: 0.78 + 0.22 * q,
            shell: 0.72 + 0.28 * q,
            compress: 0.06 + 0.06 * q,
            thermal: 0.0001,
            align: 0.20 + 0.12 * q
          };
          sim.dwell = q;                       // demand, for the engine's own use
        } else {
          sim.regime = core.REGIMES.rest;
          sim.dwell = 0;
        }
        sim.probe.auto = 0; sim.probe.lastInput = sim.t;
        sim.pointer = 0;
        sim.dose = 0; sim.neutralised = false; sim.neutralFor = 0;
      }

      {
        if (!ballAt) ballAt = new Float32Array(N * 3);
        for (let i = 0; i < N; i++) {
          const k = ownerOf[i];
          const p = k >= 0 ? REG[k].p : null;
          if (p) { ballAt[i * 3] = p[0]; ballAt[i * 3 + 1] = p[1]; ballAt[i * 3 + 2] = p[2]; }
          else { ballAt[i * 3] = sim.probe.x; ballAt[i * 3 + 1] = sim.probe.y; ballAt[i * 3 + 2] = sim.probe.z; }
        }
        sim.ballAt = ballAt;
      }
      // ---- ONE TURNING BODY --------------------------------------------------
      // Shared direction was the part the old build could not show: agents docked
      // at fixed stations and vibrated, so the cohort read as a cluster holding
      // still (or, at higher demand, as a mass contracting). The stations
      // themselves now rotate slowly about the region's own axis, so every
      // engaged mark travels the same way at the same time and the formation
      // reads as ONE coordinated body in motion. Rotating the stations costs
      // nothing in density: the formation keeps its shape and its spacing exactly.
      // ---- FIXED FORMATION, LIVING PARTICLES ---------------------------------
      // The stations used to revolve slowly around each region's axis, which read
      // as the workloads themselves drifting across the world: anchors, clouds and
      // labels all travelled. Semantic structure must not move, so that rotation
      // is off. Life comes from the engine's own local wander and coordination
      // inside each cloud, not from moving the structure.
      const BODY_TURN = 0;
      for (let k = 0; BODY_TURN && k < REG.length; k++) {
        const r = REG[k];
        const qr = Math.min(1, r.activityLevel);
        if (qr < 0.05) continue;
        // slow coherent drift of the whole body — legible shared motion, and far
        // below anything that could read as an orbit or a spiral
        const th = (0.07 + 0.09 * qr) * dt * (r.flowSign >= 0 ? 1 : -1);
        const c = Math.cos(th), sn = Math.sin(th), u = r.u, om = 1 - c;
        for (let i = 0; i < N; i++) {
          if (!alloc[i] || ownerOf[i] !== k) continue;
          const o = i * 3;
          const x = sim.slot[o], y = sim.slot[o + 1], z = sim.slot[o + 2];
          const du = u[0] * x + u[1] * y + u[2] * z;
          sim.slot[o] = x * c + (u[1] * z - u[2] * y) * sn + u[0] * du * om;
          sim.slot[o + 1] = y * c + (u[2] * x - u[0] * z) * sn + u[1] * du * om;
          sim.slot[o + 2] = z * c + (u[0] * y - u[1] * x) * sn + u[2] * du * om;
        }
        // the cohort structures turn with the same body, so the drawn spokes and
        // the stations their particles hold stay locked together
        for (const co of COHORTS) {
          if (co.reg !== k) continue;
          const rot = v => {
            const x2 = v[0], y2 = v[1], z2 = v[2];
            const d2 = u[0] * x2 + u[1] * y2 + u[2] * z2;
            v[0] = x2 * c + (u[1] * z2 - u[2] * y2) * sn + u[0] * d2 * om;
            v[1] = y2 * c + (u[2] * x2 - u[0] * z2) * sn + u[1] * d2 * om;
            v[2] = z2 * c + (u[0] * y2 - u[1] * x2) * sn + u[2] * d2 * om;
          };
          rot(co.c);
        }
      }
      sim.step(dt);
      // ONE MEMBERSHIP. The engine recruits by proximity and hysteresis, which
      // produced a second, different population from the allocation: free marks
      // inside the response and engaged marks outside it. Its commitment array
      // is now the allocation, so the same identities that render ENGAGED are
      // the identities the response animates.
      for (let i = 0; i < N; i++) {
        sim.cmt[i] = alloc[i];
        if (alloc[i]) { if (sim.act[i] < 0.5) sim.act[i] = 0.5; }
        else { sim.eng[i] = 0; sim.act[i] = 0; }
      }
      toSurface();
      // engaged capacity is placed directly, after the engine has run: its clouds
      // belong to their workload anchors, not to the engine's single ball
      placeEngaged(sim.t || 0);

      for (const r of REG) {
        r.activityLevel += (r.target - r.activityLevel) * Math.min(1, dt / 1.5);
        r.phase += dt * (0.5 + 0.55 * r.activityLevel);
        r.rotPhase += dt * (0.05 + 0.04 * r.activityLevel);   // the composition's own slow turn
        r._cohSum = 0; r._cohN = 0; r._part = 0; r._spread = 0;
        r.docked = 0;
      }
      for (let i2 = 0; i2 < N; i2++) if (slotReg[i2] >= 0) REG[slotReg[i2]].docked++;
      for (const r of REG) r.ballR = ballRadius(r.docked);

      // the ACTUAL centre of each engaged cohort, on the surface — the cohort
      // card anchors here, so its leader always ends on the visible group
      for (const r of REG) { r._cx = 0; r._cy = 0; r._cz = 0; r._cn = 0; }
      for (let i = 0; i < N; i++) {
        if (!alloc[i]) continue;
        const k2 = ownerOf[i]; if (k2 < 0) continue;
        const g2 = REG[k2];
        g2._cx += sim.px[i]; g2._cy += sim.py[i]; g2._cz += sim.pz[i]; g2._cn++;
      }
      for (const r of REG) {
        if (!r._cn) { r.centroid = null; continue; }
        const l2 = Math.hypot(r._cx, r._cy, r._cz) || 1;
        r.centroid = [r._cx / l2 * SR, r._cy / l2 * SR, r._cz / l2 * SR];
      }

      // ---- v3 COORDINATION TREATMENT ------------------------------------------
      // Coordination has to be legible with the colour taken away. After the
      // engine has stepped, engaged capacity (1) blends its heading toward its
      // OWN region's shared circulation, (2) low-passes that heading so paths
      // straighten, and (3) shares one slow regional speed phase so the cohort
      // breathes together. All three act on VELOCITY. None of them is a position
      // target, so none of them can accumulate capacity anywhere.
      for (const r of REG) r._sync = Math.sin(r.phase * 0.8);
      for (let i = 0; i < N; i++) {
        if (!alloc[i]) continue;
        const k = ownerOf[i]; if (k < 0) continue;
        const r = REG[k];
        const e = Math.min(1, sim.eng[i]);
        if (e < 0.02) continue;
        const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
        const qx = sim.px[i] / pl, qy = sim.py[i] / pl, qz = sim.pz[i] / pl;
        // MEMBERSHIP IS LOCAL, AND IT IS THE WORKLOAD'S. An engaged particle
        // belongs WITH its own cohort: its home is its workload anchor (not the
        // region centre), and one that strays past its cohort envelope steers
        // back along the great circle at raised speed instead of wandering. That
        // is what keeps every colour wrapped around the anchor that names it.
        const cosd = qx * r.u[0] + qy * r.u[1] + qz * r.u[2];
        const dArc = Math.acos(Math.max(-1, Math.min(1, cosd))) * SR;
        if (dArc > sim.shellR * 1.12) {
          let gx = r.u[0] - qx * cosd, gy = r.u[1] - qy * cosd, gz = r.u[2] - qz * cosd;
          const gl = Math.hypot(gx, gy, gz) || 1e-6;
          gx /= gl; gy /= gl; gz /= gl;
          const wf = 1 - Math.exp(-dt * 4.5);
          const spd0 = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
          let mx2 = sim.vx[i] / spd0 * (1 - wf) + gx * wf;
          let my2 = sim.vy[i] / spd0 * (1 - wf) + gy * wf;
          let mz2 = sim.vz[i] / spd0 * (1 - wf) + gz * wf;
          const ml2 = Math.hypot(mx2, my2, mz2) || 1;
          const sp2 = spd0 * (1 + 0.55 * Math.min(1, dArc / sim.shellR - 1.12));
          sim.vx[i] = mx2 / ml2 * sp2; sim.vy[i] = my2 / ml2 * sp2; sim.vz[i] = mz2 / ml2 * sp2;
          continue;
        }
        // ITS OWN ANCHOR, NOT THE REGION'S CENTRE. A soft, continuous pull toward
        // the particle's WORKLOAD anchor once it drifts past that cohort's own
        // envelope: it acts on velocity only, never as a hard position target, so
        // the cloud stays wrapped around the anchor that names it while all the
        // organic motion below still runs.
        if (hasCtr[i]) {
          const cxh = ctr[i * 3], cyh = ctr[i * 3 + 1], czh = ctr[i * 3 + 2];
          const cd = qx * cxh + qy * cyh + qz * czh;
          const aArc = Math.acos(Math.max(-1, Math.min(1, cd))) * SR;
          const env = Math.max(3, sim.shellR * 0.42);
          if (aArc > env) {
            let gx = cxh - qx * cd, gy = cyh - qy * cd, gz = czh - qz * cd;
            const gl = Math.hypot(gx, gy, gz) || 1e-6;
            gx /= gl; gy /= gl; gz /= gl;
            const wf = (1 - Math.exp(-dt * 2.2)) * Math.min(1, (aArc - env) / env);
            const spd0 = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
            let mx2 = sim.vx[i] / spd0 * (1 - wf) + gx * wf;
            let my2 = sim.vy[i] / spd0 * (1 - wf) + gy * wf;
            let mz2 = sim.vz[i] / spd0 * (1 - wf) + gz * wf;
            const ml2 = Math.hypot(mx2, my2, mz2) || 1;
            sim.vx[i] = mx2 / ml2 * spd0; sim.vy[i] = my2 / ml2 * spd0; sim.vz[i] = mz2 / ml2 * spd0;
          }
        }
        let tx = r.u[1] * qz - r.u[2] * qy;
        let ty = r.u[2] * qx - r.u[0] * qz;
        let tz = r.u[0] * qy - r.u[1] * qx;
        const tl = Math.hypot(tx, ty, tz);
        if (tl < 1e-4) continue;
        const sgn = r.flowSign >= 0 ? 1 / tl : -1 / tl;
        tx *= sgn; ty *= sgn; tz *= sgn;
        const spd = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1e-6;
        // deliberately modest: a stronger blend would cancel the engine's own
        // convergence and the cohort would never gather at all
        const w = Math.min(0.14, 0.08 * F.tune.flow * e);
        let nx = sim.vx[i] / spd * (1 - w) + tx * w;
        let ny = sim.vy[i] / spd * (1 - w) + ty * w;
        let nz = sim.vz[i] / spd * (1 - w) + tz * w;
        const h3 = i * 3;
        const hx = prevH[h3], hy = prevH[h3 + 1], hz = prevH[h3 + 2];
        if (hx || hy || hz) {
          // a strong heading low-pass: this is what makes engaged paths visibly
          // straighter than free ones, and it is measurable (turnEngaged < turnResting)
          const lp = Math.min(0.52, 0.95 * e * F.tune.wander);
          nx = nx * (1 - lp) + hx * lp; ny = ny * (1 - lp) + hy * lp; nz = nz * (1 - lp) + hz * lp;
        }
        const nl = Math.hypot(nx, ny, nz) || 1;
        const sp = spd * (1 + 0.09 * e * r._sync);
        sim.vx[i] = nx / nl * sp; sim.vy[i] = ny / nl * sp; sim.vz[i] = nz / nl * sp;
      }
      // heading change rate, measured for EVERY agent off the final velocity, so
      // the engaged / resting comparison in the diagnostics is a fair one: the
      // whole claim of the treatment is that engaged paths turn LESS.
      for (let i = 0; i < N; i++) {
        const h3 = i * 3;
        const vl = Math.hypot(sim.vx[i], sim.vy[i], sim.vz[i]) || 1;
        const nxh = sim.vx[i] / vl, nyh = sim.vy[i] / vl, nzh = sim.vz[i] / vl;
        const px2 = prevH[h3], py2 = prevH[h3 + 1], pz2 = prevH[h3 + 2];
        if (px2 || py2 || pz2) {
          const dot = Math.max(-1, Math.min(1, px2 * nxh + py2 * nyh + pz2 * nzh));
          turn[i] += (Math.acos(dot) / Math.max(1e-3, dt) - turn[i]) * Math.min(1, dt / 0.4);
        }
        prevH[h3] = nxh; prevH[h3 + 1] = nyh; prevH[h3 + 2] = nzh;
      }

      const kE = dt;
      const kS = Math.min(1, dt / 0.45);
      const kC = Math.min(1, dt / 0.7);

      // mean crowding of the resting field, used to keep coordination from
      // becoming accumulation (see the relief term below)
      let nbSum0 = 0;
      for (let i = 0; i < N; i++) nbSum0 += sim.nb[i];
      const nbMean = nbSum0 / N || 1;

      // OCCUPANCY: how many agents share each of 64 equal-area cells of the
      // world. This is the honest knot detector. Local neighbour counts cannot
      // tell a coherent STREAM from a KNOT — riding side by side raises both —
      // but a stream crosses many cells while a knot fills one.
      occ.fill(0); ocx.fill(0); ocy.fill(0); ocz.fill(0);
      for (let i = 0; i < N; i++) {
        const zb = Math.min(7, ((sim.py[i] / SR + 1) * 4) | 0);          // equal-area in z
        const ab = Math.min(7, (((Math.atan2(sim.pz[i], sim.px[i]) / Math.PI + 1) * 4) | 0));
        const c = zb * 8 + ab;
        cell[i] = c; occ[c]++;
        ocx[c] += sim.px[i]; ocy[c] += sim.py[i]; ocz[c] += sim.pz[i];
      }
      let oMax = 0;
      for (let k = 0; k < 64; k++) {
        if (occ[k] > oMax) oMax = occ[k];
        if (occ[k]) { ocx[k] /= occ[k]; ocy[k] /= occ[k]; ocz[k] /= occ[k]; }
      }
      F.occupancyPeak += (oMax - F.occupancyPeak) * Math.min(1, dt / 0.5);
      const expect = N / 64;

      // Engagement and colour are READ from the engine: sim.eng is its own
      // hysteretic commitment and sim.temp its response heat, so an orange mark
      // is a committed member of the ball — exactly the original's reading.
      // COLOUR IS TEMPERATURE, exactly as in the original scene: the response's
      // own thermal field is what the glyphs and the isotherms both read, so the
      // ball carries a real amber-to-red gradient instead of one flat orange.
      // No membership test of mine sits in between — temp only rises inside the
      // envelope, which is precisely why the original looks the way it does.
      // Colour follows ALLOCATION, gated by identity: an engaged particle keeps
      // its response colour wherever it goes, and a free particle never takes
      // one however close it drifts to an active region. Within the engaged set
      // the engine's own thermal gradient still reads.
      for (let i = 0; i < N; i++) {
        eng[i] = sim.eng[i];
        // v3: ENGAGED is ONE controlled engagement accent, not a thermal ramp.
        // The value still breathes a little so the cohort has internal life, but
        // it can never travel to the alarm end of any scale.
        chroma[i] = alloc[i] ? (0.40 + 0.15 * Math.min(1, sim.eng[i])) * F.tune.chroma : 0;
      }
      {
        // attribute committed capacity to the region the ball is centred on
        let dom = null;
        for (const r of REG) if (!dom || r.activityLevel > dom.activityLevel) dom = r;
        for (const r of REG) { r._part = 0; r._cohN = 0; r._cohSum = 0; r._spread = 0; }
        if (dom) {
          dom._part = sim.committed || 0;
          dom._cohN = 1;
          dom._cohSum = sim.closure || 0;
          dom._spread = sim.coverage || 0;
        }
      }

      for (const r of REG) {
        r.coherence = r._cohN ? r._cohSum / r._cohN : 0;
        r.participation = r._part / N;
        r.spread = r._cohN ? r._spread / r._cohN : 0;
      }
    },

    // review instrumentation: the motor's own state, so a dead response can be
    // told apart from a loose one
    motor() {
      return {
        dwell: +sim.dwell.toFixed(3),
        gate: sim.hiveGate == null ? null : +sim.hiveGate.toFixed(3),
        probeOn: sim.probe.on,
        perturb: +sim.perturb.toFixed(3),
        shellR: +sim.shellR.toFixed(2),
        committed: sim.committed,
        neutralised: sim.neutralised,
        tempMax: +sim.tempMax.toFixed(3),
        cmt: (() => { let n = 0; for (let i = 0; i < N; i++) if (sim.cmt[i]) n++; return n; })(),
        engMean: (() => { let s2 = 0, n = 0; for (let i = 0; i < N; i++) if (alloc[i]) { s2 += sim.eng[i]; n++; } return n ? +(s2 / n).toFixed(3) : 0; })()
      };
    },

    // review instrumentation: the actual geometry of each cohort, so the
    // formation can be judged by measurement instead of by eye
    geometry() {
      const out = {};
      for (let k = 0; k < REG.length; k++) {
        const r = REG[k];
        const ds = [];
        for (let i = 0; i < N; i++) {
          if (!alloc[i] || ownerOf[i] !== k) continue;
          const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
          const dot = (sim.px[i] * r.u[0] + sim.py[i] * r.u[1] + sim.pz[i] * r.u[2]) / pl;
          ds.push(Math.acos(Math.max(-1, Math.min(1, dot))) * SR);   // arc distance
        }
        if (!ds.length) continue;
        ds.sort((x, y) => x - y);
        out[r.id] = {
          n: ds.length,
          median: +ds[ds.length >> 1].toFixed(1),
          p90: +ds[Math.min(ds.length - 1, Math.floor(ds.length * 0.9))].toFixed(1),
          max: +ds[ds.length - 1].toFixed(1),
          shellR: +sim.shellR.toFixed(1)
        };
      }
      return out;
    },

    // prototype diagnostics only — never product metrics
    state() {
      let engaged = 0, cSum = 0, cMax = 0, nbSum = 0, nbN = 0, nbBase = 0, nbBaseN = 0;
      let phiE = 0, phiB = 0, tE = 0, tB = 0, nbAll = 0;
      // the knot detector: mean of the densest few neighbourhoods in the field.
      // A knot spikes this; a coherent stream barely moves it.
      const TOPK = 8, top = new Float32Array(TOPK);
      for (let i = 0; i < N; i++) {
        nbAll += sim.nb[i];
        const v = sim.nb[i];
        if (v > top[TOPK - 1]) {
          let k = TOPK - 1;
          while (k > 0 && top[k - 1] < v) { top[k] = top[k - 1]; k--; }
          top[k] = v;
        }
        if (eng[i] > 0.3) { engaged++; nbSum += v; phiE += sim.phi[i]; tE += turn[i]; nbN++; }
        else { nbBase += v; phiB += sim.phi[i]; tB += turn[i]; nbBaseN++; }
        cSum += chroma[i]; if (chroma[i] > cMax) cMax = chroma[i];
      }
      let peak = 0;
      for (let k = 0; k < TOPK; k++) peak += top[k];
      peak /= TOPK;
      return {
        fixture: F.fixture,
        N,
        engaged,
        capacityParticipation: engaged / N,
        chromaMean: cSum / N,
        chromaMax: cMax,
        crowding: nbN ? nbSum / nbN : 0,          // mean neighbours of engaged capacity
        crowdingBase: nbBaseN ? nbBase / nbBaseN : 0,
        crowdingAll: nbAll / N,                   // whole-field density, the stable comparator
        crowdingPeak: peak,                       // densest neighbourhoods (streams raise this too)
        occupancyPeak: F.occupancyPeak,           // fullest equal-area cell — the knot detector
        // measured witnesses that coordination lives in MOTION, not in colour:
        // heading change rate should fall for engaged capacity (steadier paths)
        turnEngaged: nbN ? tE / nbN : 0,
        turnResting: nbBaseN ? tB / nbBaseN : 0,
        // the engine's own local order parameter, for reference: the resting
        // field is already locally flocked, so this is NOT the discriminator
        phiEngaged: nbN ? phiE / nbN : 0,
        phiResting: nbBaseN ? phiB / nbBaseN : 0,
        t: +sim.t.toFixed(2),
        regions: REG.map(r => ({
          id: r.id,
          activityLevel: +r.activityLevel.toFixed(3),
          coherence: +r.coherence.toFixed(3),
          spread: +r.spread.toFixed(3),
          participation: +r.participation.toFixed(3)
        }))
      };
    }
  };

  for (let i = 0; i < 150; i++) F.update(1 / 60);   // settle the resting field
  return F;
}

return { makeField };
})();

// ===== traffic-overlay.js =====
__M["traffic-overlay.js"] = (() => {
// OPERATIONS — TRAFFIC OVERLAY (v3).
//
// Network/request traffic is a SEPARATE visual system from capacity:
//   capacity = population / field (the swarm on the world)
//   traffic  = events moving through the field (pulses on routes)
//
// This layer knows nothing about the swarm engine. It draws great-circle routes
// between points on the world and small pulses moving along them. Pulses stay
// deliberately unlike agents: tiny filled dots with a short fading tail — never
// triangles, never trails from the field.
//
// v3 adds exactly two things.
//
//   WORKLOAD IDENTITY. A route carries its workload's colour — the same colour
//   the right-hand legend prints beside that workload's name. Capacity state is
//   never coloured this way: FREE is neutral and ENGAGED is one accent, decided
//   elsewhere. Traffic is the only place categorical colour is allowed, because
//   "which workload" is the only question colour answers here.
//
//   SEMANTIC ZOOM. A route has a kind. 'inter' routes are the major regional
//   traffic and read at GLOBAL; from REGIONAL on they fade back unless they
//   touch the region you are looking at. 'local' routes join a region to its own
//   nodes and appear only once you are REGIONAL or LOCAL on that region, where
//   there is finally room to see discrete pulses entering and leaving a node.
//
// Restraint is a rule, not a preference: dashes stay thin, routes only exist
// while they carry traffic, and nothing glows.

const {project} = __M["vendor/swarm-core.js"];

const o4 = new Float32Array(4);
const o4b = new Float32Array(4);

function norm3(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }

// slerp between two unit vectors, with an altitude bump so arcs read as routes
// OVER the world rather than chords through it
function arcPoint(ua, ub, t, SR, lift, out) {
  let dot = ua[0] * ub[0] + ua[1] * ub[1] + ua[2] * ub[2];
  dot = Math.max(-1, Math.min(1, dot));
  const om = Math.acos(dot), so = Math.sin(om) || 1e-6;
  const w1 = Math.sin((1 - t) * om) / so, w2 = Math.sin(t * om) / so;
  const r = SR * (1 + lift * Math.sin(Math.PI * t));
  out[0] = (ua[0] * w1 + ub[0] * w2) * r;
  out[1] = (ua[1] * w1 + ub[1] * w2) * r;
  out[2] = (ua[2] * w1 + ub[2] * w2) * r;
  return out;
}

function makeTraffic(SR) {
  const routes = [];   // {ua, ub, on, want, kind, rids, color, lift}
  const pulses = [];   // {r, t, speed, dir}
  const p3 = new Float32Array(3), q3 = new Float32Array(3);

  // how much of a route belongs in the current reading. A workload route is
  // network-level information, so it speaks at GLOBAL; descending gives the
  // frame to the region you are on without silencing the others entirely.
  function weight(r, scale, focus) {
    if (r.kind === 'local') {
      if (scale === 'GLOBAL' || !focus || r.rids[0] !== focus) return 0;
      return scale === 'LOCAL' ? 1 : 0.62;
    }
    if (scale === 'GLOBAL') return 1;
    if (!focus) return 0.85;
    return r.rids.indexOf(focus) >= 0 ? 1 : 0.34;
  }

  // P1-T — TRAFFIC EMPHASIS BY SEMANTIC ZOOM, not a linear scale-up. Each reading
  // gets its own treatment of the same routes:
  //   GLOBAL   the network question: is activity happening, and whose? Routes
  //            read clearly, pulses are larger and fewer details compete, and a
  //            small aggregated activity ring sits on each SERVING node — so
  //            traffic never has to be discovered by zooming in.
  //   REGIONAL the destination question: the last stretch of each route resolves
  //            and a workload-coloured tick marks the node being served.
  //   LOCAL    the event question: discrete pulses with longer tails arriving at
  //            individual nodes, plus a brief arrival mark as each one lands.
  // Only nodes carrying active workload capacity have routes at all, so no idle
  // node can ever show traffic.
  const EMPH = {
    GLOBAL:   { line: 0.62, w: 1.15, dash: [2.4, 5], head: 1.5, tail: 2, tailA: 0.34, tailR: 0.85, ring: 1, tick: 0, arrive: 0 },
    REGIONAL: { line: 0.58, w: 1.05, dash: [2.2, 4.5], head: 1.7, tail: 3, tailA: 0.36, tailR: 0.95, ring: 0.45, tick: 1, arrive: 0.5 },
    LOCAL:    { line: 0.5, w: 1, dash: [2, 4], head: 1.9, tail: 4, tailA: 0.4, tailR: 1.05, ring: 0.2, tick: 1, arrive: 1 }
  };

  const T = {
    routes, pulses, t: 0,
    addRoute(a, b, o = {}) {
      const r = {
        ua: norm3(a), ub: norm3(b), on: 0, want: 0,
        kind: o.kind || 'inter',
        rids: o.rids || [],
        node: o.node || null,
        color: o.color || [255, 161, 0],
        lift: o.lift ?? 0.14
      };
      routes.push(r);
      return r;
    },
    spawn(route, dir = 1, speed = 0.45, color = null) {
      pulses.push({ r: route, t: dir > 0 ? 0 : 1, speed, dir, color });
    },
    update(dt) {
      T.t += dt;
      for (const r of routes) r.on += (r.want - r.on) * Math.min(1, dt / 0.8);
      for (let i = pulses.length - 1; i >= 0; i--) {
        const p = pulses[i];
        p.t += p.speed * p.dir * dt;
        if (p.t > 1.04 || p.t < -0.04) pulses.splice(i, 1);
      }
    },
    // camera-facing test so routes and pulses hide behind the world
    draw(ctx, cam, W, H, opts = {}) {
      const scale = opts.scale || 'GLOBAL';
      const focus = opts.focus || null;
      const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
      const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
      const fx = sy * cp, fy = sp, fz = cy * cp;
      const facing = (x, y, z) => {
        const l = Math.hypot(x, y, z) || 1;
        return -(x * fx + y * fy + z * fz) / l;
      };
      const paint = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
      const E = EMPH[scale] || EMPH.GLOBAL;
      // FLOWS: the route is a RESOLUTION CHAIN, not a pipe. The full path sits faint
      // under a progressive stroke that resolves origin -> model checkpoint -> node,
      // with holds at the handoffs; no throughput particles are drawn at all.
      const FLOWS = !!opts.flows;
      // 1 = whole route, 0 = fully retracted into its target node
      const drawK = opts.draw == null ? 1 : Math.max(0, Math.min(1, opts.draw));
      if (drawK <= 0.004) return;
      const t0 = 1 - drawK;
      // routes: faint dotted arcs in the workload's colour, only while carrying
      for (const r of routes) {
        const k = weight(r, scale, focus);
        const on = r.on * k;
        if (on < 0.03) continue;
        ctx.setLineDash([]);
        ctx.lineWidth = r.kind === 'local' ? 0.8 : E.w;
        ctx.beginPath();
        let pen = false;
        const steps = r.kind === 'local' ? 14 : 40;
        for (let s = 0; s <= steps; s++) {
          arcPoint(r.ua, r.ub, t0 + (1 - t0) * (s / steps), SR, r.lift, p3);
          if (facing(p3[0], p3[1], p3[2]) < 0.02) { pen = false; continue; }
          project(cam, p3[0], p3[1], p3[2], W, H, o4);
          pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
          pen = true;
        }
        ctx.strokeStyle = paint(r.color, (FLOWS ? 0.3 : 1) * E.line * on);
        ctx.stroke();
        ctx.setLineDash([]);
        // REGIONAL/LOCAL: the final stretch resolves into a solid approach, and
        // a small tick names the node actually being served
        if (E.tick && r.kind !== 'local') {
          ctx.beginPath();
          let pen2 = false;
          for (let s = 0; s <= 8; s++) {
            arcPoint(r.ua, r.ub, Math.max(t0, 0.86) + (1 - Math.max(t0, 0.86)) * (s / 8), SR, r.lift, p3);
            if (facing(p3[0], p3[1], p3[2]) < 0.02) { pen2 = false; continue; }
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            pen2 ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
            pen2 = true;
          }
          ctx.lineWidth = E.w;
          ctx.strokeStyle = paint(r.color, Math.min(1, 0.85 * on));
          ctx.stroke();
          if (facing(r.ub[0], r.ub[1], r.ub[2]) > 0.02) {
            project(cam, r.ub[0] * SR, r.ub[1] * SR, r.ub[2] * SR, W, H, o4);
            ctx.fillStyle = paint(r.color, Math.min(1, 0.9 * on));
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 1.8, 0, 6.2832); ctx.fill();
          }
        }
        // GLOBAL: an aggregated activity ring on the serving node — the presence
        // of workload traffic, readable without descending a scale
        if (E.ring > 0.02 && r.kind !== 'local' && facing(r.ub[0], r.ub[1], r.ub[2]) > 0.02) {
          project(cam, r.ub[0] * SR, r.ub[1] * SR, r.ub[2] * SR, W, H, o4);
          // one ring per workload served by this node, offset in phase, so a
          // shared node shows every identity using it without a second line
          const wls = (r.workloads && r.workloads.length) ? r.workloads : [{ color: r.color }];
          for (let k = 0; k < wls.length; k++) {
            const ph = (T.t * 0.55 + k / wls.length) % 1;
            ctx.strokeStyle = paint(wls[k].color, Math.min(1, (0.5 - 0.42 * ph) * on * E.ring));
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 2.5 + ph * 5, 0, 6.2832); ctx.stroke();
          }
        }
      }
      if (FLOWS) {
        // phase per route, staggered so the ambient reading breathes instead of
        // marching in step; the selected reading (opts.flowLabels) names the stages
        const seg = (a, b, x) => Math.max(0, Math.min(1, (x - a) / (b - a)));
        const ease = x => 1 - Math.pow(1 - x, 3);
        const pt = (r, t, out) => { arcPoint(r.ua, r.ub, t, SR, r.lift, out); return facing(out[0], out[1], out[2]) > 0.02; };
        const lab = opts.flowLabels;
        const font = opts.font || '500 11px "Source Sans 3", sans-serif';
        let idx = 0;
        for (const r of routes) {
          const k = weight(r, scale, focus); const on = r.on * k; idx++;
          if (on < 0.03) continue;
          const ph0 = ((T.t * 0.22) + idx * 0.19) % 1;
          // SELECTED: resolve once, then stay EXECUTING. The cycle only re-runs when the
          // route itself is rebuilt (scope / fixture change), i.e. when product state moves.
          if (lab && r._flowT0 == null) r._flowT0 = T.t;
          if (!lab) r._flowT0 = null;
          const ph = lab ? Math.min(0.9, (T.t - r._flowT0) * 0.3) : ph0;
          // 0-.32 resolve to the model checkpoint · hold · .42-.78 hand off to the node · hold
          const p = ph < 0.32 ? 0.5 * ease(seg(0, 0.32, ph)) : ph < 0.42 ? 0.5 : ph < 0.78 ? 0.5 + 0.5 * ease(seg(0.42, 0.78, ph)) : 1;
          const A = lab ? 1 : 0.55;
          // progressive stroke: the path exists only as far as it has resolved
          ctx.beginPath(); let pen = false;
          for (let s = 0; s <= 40; s++) { const t = p * s / 40; if (!pt(r, t, p3)) { pen = false; continue; } project(cam, p3[0], p3[1], p3[2], W, H, o4); pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]); pen = true; }
          ctx.lineWidth = E.w + 0.4; ctx.strokeStyle = paint(r.color, 0.9 * on * A); ctx.stroke();
          // ORIGIN: the control plane routing this workload — a hollow square, the
          // structural mark, never a node disc
          if (pt(r, 0, p3)) { project(cam, p3[0], p3[1], p3[2], W, H, o4); ctx.lineWidth = 1; ctx.strokeStyle = paint(r.color, 0.7 * on * A); ctx.strokeRect(o4[0] - 3, o4[1] - 3, 6, 6);
            // LOGICAL -> PHYSICAL HANDOFF: a dashed drop from the orchestration band down to
            // the origin of the geographic arc. The band itself names workload, control
            // plane and model; the globe only receives the resolved execution.
            ctx.setLineDash([3, 4]); ctx.lineWidth = 1; ctx.strokeStyle = paint(r.color, (lab ? 0.6 : 0.22) * on);
            ctx.beginPath(); ctx.moveTo(o4[0], o4[1] - 4); ctx.lineTo(o4[0], Math.min(o4[1] - 4, 112)); ctx.stroke(); ctx.setLineDash([]);
            if (lab && opts.workloadOf) { ctx.font = font; ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.8 * on); ctx.textAlign = 'right'; ctx.fillText(opts.ctrlOf ? (opts.ctrlOf(r) || '') : '', o4[0] - 10, o4[1] + 5); } }
          // MODEL checkpoint: a LOGICAL stage, not a place. Drawn as a tick across the
          // route with a hairline leader to its annotation, lifted off the arc — never
          // a disc, so it cannot read as a node or a location.
          if (false && p >= 0.5 && pt(r, 0.5, p3)) {
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            const grow = ph < 0.42 ? ease(seg(0.32, 0.42, ph)) : 1;
            // tangent of the arc at the checkpoint -> a short tick perpendicular to it
            pt(r, 0.52, q3); project(cam, q3[0], q3[1], q3[2], W, H, o4b);
            let tx = o4b[0] - o4[0], ty = o4b[1] - o4[1]; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
            const nx = -ty, ny = tx, L = 4 + 3 * grow;
            ctx.lineWidth = 1.4; ctx.strokeStyle = paint(r.color, 0.95 * on * A);
            ctx.beginPath(); ctx.moveTo(o4[0] - nx * L, o4[1] - ny * L); ctx.lineTo(o4[0] + nx * L, o4[1] + ny * L); ctx.stroke();
            if (lab && opts.modelOf) {
              // leader lifts the annotation off the globe surface: the model is read as
              // a decision on the route, not a point under it
              const lx = o4[0] + nx * 26, ly = o4[1] + ny * 26 - 14;
              ctx.lineWidth = 0.8; ctx.strokeStyle = paint(r.color, 0.55 * on);
              ctx.beginPath(); ctx.moveTo(o4[0] + nx * L, o4[1] + ny * L); ctx.lineTo(lx, ly); ctx.stroke();
              ctx.font = font; ctx.textAlign = 'left';
              ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.6 * on); ctx.fillText('MODEL', lx + 4, ly - 7);
              ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.95 * on); ctx.fillText(opts.modelOf(r) || '', lx + 4, ly + 6);
            }
          }
          // SERVING NODE: the chain completes; a landing ring holds while it executes
          if (p >= 1 && pt(r, 1, p3)) {
            project(cam, p3[0], p3[1], p3[2], W, H, o4);
            // EXECUTING: after landing the ring settles to a steady mark and holds
            const land = ease(seg(0.78, 0.9, ph));
            ctx.lineWidth = 1.2; ctx.strokeStyle = paint(r.color, (0.95 - 0.35 * land) * on * A);
            ctx.beginPath(); ctx.arc(o4[0], o4[1], 3 + 3 * land, 0, 6.2832); ctx.stroke();
            if (lab) { ctx.font = font; ctx.textAlign = 'left'; ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.6 * on); ctx.fillText(land >= 1 ? 'EXECUTING' : 'HANDOFF', o4[0] + 9, o4[1] + 1); ctx.fillStyle = paint(opts.ink || [230, 230, 230], 0.95 * on); ctx.fillText((r.node || '') + (opts.regionOf ? ' · ' + (opts.regionOf(r) || '') : ''), o4[0] + 9, o4[1] + 14); }
          }
        }
        return;   // no throughput particles in Flows
      }
      // pulses: a bright head and a short fading tail, in the route's colour
      for (const p of pulses) {
        const k = weight(p.r, scale, focus);
        if (k < 0.2) continue;
        const tp = Math.max(0, Math.min(1, p.t));
        if (tp < 1 - drawK) continue;
        arcPoint(p.r.ua, p.r.ub, tp, SR, p.r.lift, p3);
        if (facing(p3[0], p3[1], p3[2]) < 0.02) continue;
        project(cam, p3[0], p3[1], p3[2], W, H, o4);
        const hx = o4[0], hy = o4[1];
        for (let g = 1; g <= E.tail; g++) {
          const tg = Math.max(0, Math.min(1, p.t - p.dir * g * 0.022));
          arcPoint(p.r.ua, p.r.ub, tg, SR, p.r.lift, q3);
          if (facing(q3[0], q3[1], q3[2]) < 0.02) continue;
          project(cam, q3[0], q3[1], q3[2], W, H, o4);
          ctx.fillStyle = paint(p.color || p.r.color, E.tailA * k * (1 - g / (E.tail + 0.4)));
          ctx.beginPath(); ctx.arc(o4[0], o4[1], E.tailR, 0, 6.2832); ctx.fill();
        }
        ctx.fillStyle = paint(p.color || p.r.color, Math.min(1, 0.98 * k));
        ctx.beginPath(); ctx.arc(hx, hy, p.r.kind === 'local' ? 1.4 : E.head, 0, 6.2832); ctx.fill();
        // LOCAL: the pulse LANDS — a brief mark as it reaches the node
        if (E.arrive > 0.02 && t0 > 0.9) {
          const f2 = (t0 - 0.9) / 0.1;
          ctx.strokeStyle = paint(p.color || p.r.color, Math.min(1, (1 - f2) * 0.7 * k * E.arrive));
          ctx.lineWidth = 0.8;
          ctx.beginPath(); ctx.arc(hx, hy, 2 + f2 * 4, 0, 6.2832); ctx.stroke();
        }
      }
    }
  };
  return T;
}

return { makeTraffic };
})();

// ===== scene-orig.js =====
__M["scene-orig.js"] = (() => {
// QUIET SCENE — planar comb, colony, one red event point, one instrument that
// rides the cursor.
//
// Reading order: the comb plane, the colony inside it, the pinned event, the
// instrument. No frames, no rings around the swarm, no grids, no persistent
// diagnostics. The only chroma is the event point and the thermal arc.

const {project, degC, isolines} = __M["vendor/swarm-core.js"];
const {rgbaT} = __M["theme.js"];

const o4 = new Float32Array(4), o4b = new Float32Array(4);
const FONT = "px 'Share Tech Mono', ui-monospace, monospace";
const TAN_HALF = Math.tan(35.2644 * Math.PI / 180);

const HEAT_ON = 0.2;
// v3: ONE controlled engagement accent instead of the thermal ramp. Engaged
// capacity is coordinated capacity, not a thermal event, so the scale stays in
// a single hue and never reaches amber or red. Red is reserved for failure.
const STOPS = [[0.2, 106, 150, 136], [0.45, 96, 196, 165], [0.68, 84, 219, 179], [0.85, 111, 231, 194], [1, 150, 243, 214]];
function heatRGB(T) {
  if (!(T >= HEAT_ON)) return null;
  for (let i = 1; i < STOPS.length; i++) {
    const a = STOPS[i - 1], b = STOPS[i];
    if (T <= b[0] || i === STOPS.length - 1) {
      const u = Math.max(0, Math.min(1, (T - a[0]) / (b[0] - a[0])));
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  return null;
}
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const INK = a => rgbaT('ink', a);
const DIM = a => rgbaT('dim', a);
const RED = a => rgbaT('critical', a);
const LIT = a => rgbaT('lit', a);   // white = the measurement event
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// The cursor IS the intruder, so its readout reports the intruder's own
// condition — what the colony is doing to it — not the colony's perception.
// The colony's state stays where it belongs, in the scene label.
function intruderState(sim, ev) {
  if (ev && ev.dead > 0) return 'COMPLETE';
  if (sim.tempMax > HEAT_ON) return 'ACTIVE';
  if (sim.committed > 8) return 'COORDINATED';
  if (sim.pin) return 'COMMITTED';
  if (sim.perturb > 0.15) return 'REGISTERED';
  return 'SIGNAL';
}

// The arc is a latched phase machine, not a set of instantaneous thresholds:
// each step holds long enough to be read, the sequence only ever advances while
// the intruder lives, and RELEASE stays latched until the field is cold again.
const PHASES = ['DISTRIBUTED', 'SIGNAL', 'COMMIT', 'COORDINATE',
  'ACTIVE', 'PEAK', 'RELEASE'];
function sceneState(sim, ev) {
  const e = ev || {};
  if (e.phase == null) { e.phase = 0; e.phaseAt = -9; }
  const now = sim.t, held = now - e.phaseAt;
  const go = p => { if (p !== e.phase) { e.phase = p; e.phaseAt = now; } return PHASES[p]; };

  if (e.dead > 0) return go(6);                       // burning out
  if (e.phase === 6) {                                // latched until cold and gone
    if (!sim.pin && sim.tempMax < 0.05) return go(sim.perturb > 0.15 ? 1 : 0);
    return PHASES[6];
  }
  if (sim.pin) {
    let want = 2;
    if (sim.committed > 8) want = 3;
    if (sim.tempMax > HEAT_ON) want = 4;
    if (sim.tempMax > 0.82) want = 5;
    if (want <= e.phase) return PHASES[e.phase];
    // minimum dwell, so convergence is never skipped past on the way to heat
    if (e.phase >= 2 && held < 0.9 && want < 5) return PHASES[e.phase];
    return go(want);
  }
  if (e.phase >= 2 && sim.tempMax > 0.05) return go(6);   // pin lifted while warm
  return go(sim.perturb > 0.15 ? 1 : 0);
}

// ------------------------------------------------------------ planar comb
// The comb is FLAT: a plane facing the viewer, laid out in screen space, so it
// never turns with the camera and never reads as an object in perspective.
// An irregular mass with a ragged edge and a few detached cells.
function buildLattice(W, H, o = {}) {
  const R = o.r ?? Math.max(44, Math.min(104, 68 * (W / 1240)));
  const dx = R * Math.sqrt(3), dy = R * 1.5;
  const cx = W * 0.5, cy = H * 0.5;
  const cols = Math.ceil(W / dx) + 3, rows = Math.ceil(H / dy) + 3;
  let s = 991137 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const cells = [];
  // Flat: the lattice covers the central zone the colony occupies.
  // Curved: the same lattice is read as a spherical shell seen from inside —
  // arc length maps through sin(), so cells crowd and foreshorten toward the rim
  // and the surface recedes past the frame. It sits BEHIND the colony and stays
  // open toward the viewer: a world that continues, not a container.
  const Rs = Math.max(W, H) * 0.40, lim = o.curve ? 3.4 : 1.04;
  for (let r = -rows * 2; r <= rows * 2; r++) for (let c = -cols * 2; c <= cols * 2; c++) {
    const fx = c * dx + (Math.abs(r) & 1 ? dx * 0.5 : 0), fy = r * dy;
    const rad = Math.hypot(fx / (W * 0.30), fy / (H * 0.42));
    if (rad > lim) continue;
    rnd();
    let x = cx + fx, y = cy + fy, cr = R;
    if (o.curve) {
      const d0 = Math.hypot(fx, fy * 1.14);
      const th = Math.min(1.42, d0 / Rs);
      const k = d0 > 0.001 ? (Rs * Math.sin(th)) / d0 : 1;
      x = cx + fx * k; y = cy + fy * k * 0.92;
      cr = R * Math.max(0.30, Math.cos(th));
      if (th > 1.40) continue;
    }
    cells.push({ x, y, r: cr, amp: 0, chg: 0, rate: 0.6 + rnd() * 1.5, occ: 0, fore: o.curve ? Math.cos(Math.min(1.42, Math.hypot(fx, fy * 1.14) / Rs)) : 1 });
  }
  return { R, W, H, cells, active: 0, curve: !!o.curve };
}

function updateLattice(lat, sim, dt, allow, cam, W, H, cur) {
  const R2 = lat.R * lat.R, thr = Math.max(0.34, (sim.phiG || 0.4) + 0.1);
  for (const c of lat.cells) c.occ = 0;
  // The cursor reveals the comb as it passes: proximity charges a cell, and the
  // charge decays behind it at each cell's own rate, so the trace is a fading
  // wake rather than a highlight.
  if (cur) {
    const rr = lat.R * 2.3, rr2 = rr * rr;
    for (const c of lat.cells) {
      const dx = c.x - cur[0], dy = c.y - cur[1], d2 = dx * dx + dy * dy;
      if (d2 < rr2) c.rev = Math.min(1.7, (c.rev || 0) + dt * 2.3 * (1 - Math.sqrt(d2) / rr));
    }
  }
  // long, uneven fade: the wake stays on screen for seconds and thins out
  for (const c of lat.cells) c.rev = Math.max(0, (c.rev || 0) - dt / (7.5 * c.rate));
  if (cam) {
    for (let i = 0; i < sim.N; i++) {
      const coh = sim.phi[i] - thr;
      project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
      for (const c of lat.cells) {
        const ddx = o4[0] - c.x, ddy = o4[1] - c.y;
        if (ddx * ddx + ddy * ddy < R2) {
          // any agent crossing a cell wakes it, well below the cursor; a
          // coordinated one also charges it toward crystallisation
          c.pas = Math.min(0.9, (c.pas || 0) + dt * 2.2);
          if (coh > 0) c.occ += coh * 2.4;
          break;
        }
      }
    }
  }
  for (const c of lat.cells) c.pas = Math.max(0, (c.pas || 0) - dt / 2.0);
  let live = 0;
  for (const c of lat.cells) {
    const on = allow && c.occ > 1.2;
    c.chg += on ? dt / 1.3 : -dt / (0.9 * c.rate);
    if (c.chg > 1.25) c.chg = 1.25; else if (c.chg < 0) c.chg = 0;
    c.amp = smooth(0.05, 0.95, Math.max(c.chg, c.rev || 0, (c.pas || 0) * 0.62));
    if (c.amp > 0.02) live++;
  }
  lat.active = live;
}

function comb(ctx, lat, k) {
  if (lat.sphere) return combSphere(ctx, lat, k);
  // The cell is a plane, not an outline: a very faint fill, no stroke, so the
  // comb registers as area the colony has claimed rather than as drawn geometry.
  for (const c of lat.cells) {
    if (c.amp <= 0.02) continue;                 // invisible until revealed
    ctx.fillStyle = INK(c.amp * 0.05 * k);
    ctx.beginPath();
    for (let s = 0; s < 6; s++) {
      const a = Math.PI / 6 + s * Math.PI / 3;
      const X = c.x + Math.cos(a) * c.r * 0.965, Y = c.y + Math.sin(a) * c.r * 0.965;
      s ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
    ctx.fill();
    if (c.amp > 0.42) {
      ctx.strokeStyle = INK((c.amp - 0.42) * 0.34 * c.vis * k);
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }
}

// ------------------------------------------------------------------- behaviour
// Pathlines exactly as treatment I draws them in v1: every fourth agent, the
// whole history shortened to its recent third and softened: history should
// register as recent movement, not as a web of long strokes.
function histories(ctx, cam, sim, W, H, cfg) {
  const c = cfg || {};
  const TL = sim.TL, head = sim.head;
  const n = Math.max(3, Math.min(TL, Math.round(c.n ?? 15)));
  const stride = Math.max(1, Math.round(c.stride ?? 4));
  const w = c.w ?? 0.55, alpha = c.alpha ?? 0.2;
  const ticks = c.ticks !== false, tick = 7, tickA = alpha;
  const depth = c.depth !== false;
  for (let i = 0; i < sim.N; i += stride) {
    const hc = hcOf(sim, i);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - o4[2]) / (sim.R * 1.8)));
    if (dl < 0.04) continue;
    const av = depth ? alpha * (0.3 + dl * 0.7) : alpha;
    if (c.taper) {
      const sw = c.speedK ? Math.max(0.12, Math.min(1, sim.spd[i] / (sim.SPD * 2.4))) : 1;
      let hx = 0, hy = 0;
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        if (a < n - 1) {
          const u = 1 - a / n;                       // 0 at the tail, 1 at the head
          const t2 = u * u;
          ctx.lineWidth = w * (0.35 + 1.05 * t2) * (depth ? 0.55 + dl * 0.85 : 1);
          const aa = Math.min(1, av * 2.6 * t2 * sw);
          ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.5)) : INK(aa);
          ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
        }
        hx = o4[0]; hy = o4[1];
      }
    } else {
      ctx.beginPath();
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        a === n - 1 ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
      }
      ctx.lineWidth = depth ? w * (0.55 + dl * 0.85) : w;
      ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 1.6)) : INK(av);
      ctx.stroke();
    }
    if (!ticks) continue;
    ctx.lineWidth = 0.6;
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 2.2)) : INK(tickA * (depth ? 0.3 + dl * 0.7 : 1));
    for (let a = n - 2; a >= 1; a -= tick) {
      const oA = (i * TL + ((head - a - 1 + TL * 2) % TL)) * 3;
      const oB = (i * TL + ((head - a + 1 + TL * 2) % TL)) * 3;
      project(cam, sim.trail[oA], sim.trail[oA + 1], sim.trail[oA + 2], W, H, o4);
      project(cam, sim.trail[oB], sim.trail[oB + 1], sim.trail[oB + 2], W, H, o4b);
      const mx = (o4[0] + o4b[0]) / 2, my = (o4[1] + o4b[1]) / 2;
      const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
      const tk = 1.9 * (1 - a / n * 0.55);
      ctx.beginPath();
      ctx.moveTo(mx + dy / L * tk, my - dx / L * tk);
      ctx.lineTo(mx - dy / L * tk, my + dx / L * tk);
      ctx.stroke();
    }
  }
}

// Glyphs exactly as treatment I draws them in v1: an open 70.529-degree
// triangle built in screen space from the projected heading, drawn back to
// front, size 3.1 px scaled by depth.
let SX, SY, SD, SHX, SHY, ORD;
// Primitive set, as in v1: the shape is a control, the semantics are not.
function prim(ctx, kind, x, y, hx, hy, sz, fill) {
  const px_ = -hy, py_ = hx;
  if (kind === 'dash') {
    const L = sz * 1.35;
    ctx.beginPath();
    ctx.moveTo(x - hx * L, y - hy * L); ctx.lineTo(x + hx * L, y + hy * L);
    ctx.stroke(); return;
  }
  ctx.beginPath();
  if (kind === 'dot') {
    ctx.arc(x, y, sz * 0.5, 0, 6.2832);
  } else if (kind === 'dia') {
    const a = sz * 1.15, b = a / Math.SQRT2;
    ctx.moveTo(x + hx * a, y + hy * a);
    ctx.lineTo(x + px_ * b, y + py_ * b);
    ctx.lineTo(x - hx * a, y - hy * a);
    ctx.lineTo(x - px_ * b, y - py_ * b);
    ctx.closePath();
  } else if (kind === 'hex') {
    const r = sz * 0.82, a0 = Math.atan2(hy, hx);
    for (let k = 0; k < 6; k++) {
      const a = a0 + k * Math.PI / 3;
      const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
      k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
  } else {                                   // 'tri' — apex 70.529 degrees
    const Hh = sz * 1.25, b = TAN_HALF * Hh;
    ctx.moveTo(x + hx * Hh * 0.66, y + hy * Hh * 0.66);
    ctx.lineTo(x - hx * Hh * 0.34 + px_ * b, y - hy * Hh * 0.34 + py_ * b);
    ctx.lineTo(x - hx * Hh * 0.34 - px_ * b, y - hy * Hh * 0.34 - py_ * b);
    ctx.closePath();
  }
  if (fill) ctx.fill(); else ctx.stroke();
}

function agents(ctx, cam, sim, W, H, gl, gk = 1) {
  const N = sim.N;
  if (!SX || SX.length !== N) {
    SX = new Float32Array(N); SY = new Float32Array(N); SD = new Float32Array(N);
    SHX = new Float32Array(N); SHY = new Float32Array(N);
    ORD = Array.from({ length: N }, (_, i) => i);
  }
  for (let i = 0; i < N; i++) {
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    project(cam, sim.px[i] + sim.vx[i] * 0.3, sim.py[i] + sim.vy[i] * 0.3, sim.pz[i] + sim.vz[i] * 0.3, W, H, o4b);
    SX[i] = o4[0]; SY[i] = o4[1]; SD[i] = o4[2];
    const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
    SHX[i] = dx / L; SHY[i] = dy / L;
  }
  ORD.sort((a, b) => SD[b] - SD[a]);
  // FAR SIDE. The globe is not opaque, so without this every particle behind it
  // read as if it were in front. A particle's own surface normal against the
  // camera direction says which hemisphere it is on: the near side draws at full
  // strength, the limb crosses over smoothly, the far side stays faint enough to
  // read as "behind".
  const _cy = Math.cos(cam.yaw), _sy = Math.sin(cam.yaw);
  const _cp = Math.cos(cam.pitch), _sp = Math.sin(cam.pitch);
  const ffx = _sy * _cp, ffy = _sp, ffz = _cy * _cp;
  for (let k = 0; k < N; k++) {
    const i = ORD[k];
    const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
    const facing = -((sim.px[i] / pl) * ffx + (sim.py[i] / pl) * ffy + (sim.pz[i] / pl) * ffz);
    // the rim of the visible hemisphere used to fall to 16% and the free capacity
    // there read as dust; the floor is lifted so quiet still means legible
    const side = 0.44 + 0.56 * Math.max(0, Math.min(1, (facing + 0.06) / 0.22));
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - SD[i]) / (sim.R * 1.8)));
    if (dl <= 0.01) continue;
    // no depth cueing: every agent reads at one size and one opacity
    const al = sim.meas[i];                     // alerted by the intruder
    const s = (3.2 + (al > 0.08 ? 0.9 : 0)) * gk;
    const a = (0.78 + (al > 0.08 ? Math.min(0.22, al * 0.9) : 0)) * side;
    const hc = hcOf(sim, i);
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, a * 1.55)) : INK(a);
    ctx.lineWidth = al > 0.08 ? 1.05 : 0.9;
    if (hc) ctx.fillStyle = rgba(hc, Math.min(1, a * 1.35)); else ctx.fillStyle = INK(a * 0.9);
    // an ENGAGED mark is FILLED in the warm accent (and a touch larger): the
    // cohort reads instantly, while free capacity keeps the quiet outline
    prim(ctx, (gl && gl.kind) || 'tri', SX[i], SY[i], SHX[i], SHY[i], s * ((gl && gl.scale) || 1) * (hc ? 1.12 : 1), !!(gl && gl.fill) || !!hc);
  }
}

// ------------------------------------------------------ event point + instrument
// A filament burning out: a surge, a few hard irregular flickers with real dark
// gaps between them, then a dim ember that fades. Keyframed, so it is the same
// death every time and never reads as a smooth pulse.
const BURNOUT = [
  [0.00, 1.75], [0.05, 0.04], [0.09, 1.35], [0.15, 0.06],
  [0.24, 1.05], [0.28, 0.03], [0.50, 0.80], [0.54, 0.02],
  [0.86, 0.50], [0.89, 0.02], [1.10, 0.26], [1.16, 0.02],
  [1.34, 0.14], [1.44, 0.02], [1.60, 0.00]
];
function burnout(t) {
  for (let i = BURNOUT.length - 1; i >= 0; i--) if (t >= BURNOUT[i][0]) {
    const v = BURNOUT[i][1];
    // the ember steps decay inside their own segment; the flashes stay hard
    const nx = BURNOUT[i + 1];
    if (v < 0.3 && nx) return v * (1 - (t - BURNOUT[i][0]) / (nx[0] - BURNOUT[i][0]) * 0.8);
    return v;
  }
  return 0;
}

function eventPoint(ctx, cam, sim, W, H, ev) {
  const a = ev.on;
  if (a < 0.02) return null;
  // ALWAYS the pin. The probe is not a position of record: swarm-core can
  // re-arm its own moving stimulus, and drawing that made the dead intruder walk.
  const C = sim.pin || ev.lastC;
  if (!C) return null;
  ev.lastC = C.slice ? C.slice() : C;
  project(cam, C[0], C[1], C[2], W, H, o4);
  const px = o4[0], py = o4[1];
  let k = 1;
  if (ev.dead > 0) k = burnout(ev.deadT);
  if (k < 0.02) {
    // spent: the filament is out, and what is left is the carcass — a hollow
    // grey point with an outline. It does not vanish with the light.
    if (ev.dead <= 0) return [px, py];
    ctx.fillStyle = INK(0.12 * a);
    ctx.beginPath(); ctx.arc(px, py, 3.1, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = INK(0.5 * a); ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.arc(px, py, 3.1, 0, 6.2832); ctx.stroke();
    ctx.strokeStyle = INK(0.22 * a);
    ctx.beginPath(); ctx.arc(px, py, 5.4, 0, 6.2832); ctx.stroke();
    return [px, py];
  }
  const flare = Math.max(0, k - 1);                        // over-bright surge
  ctx.fillStyle = RED(Math.min(1, 0.9 * a * k));
  ctx.beginPath(); ctx.arc(px, py, 3.1 + flare * 2.6, 0, 6.2832); ctx.fill();
  ctx.strokeStyle = RED(Math.min(1, 0.5 * a * k)); ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.arc(px, py, 5.4 + flare * 4.2, 0, 6.2832); ctx.stroke();
  return [px, py];
}

// The instrument rides the cursor. At rest it is present but says nothing:
// a ring, a quiet disc, and the invitation. It only carries a reading once an
// event exists, and then a leader ties it back to the pinned point.
function instrument(ctx, sim, W, H, ev, cur, anchor, view_ = {}) {
  // Before the pointer has ever moved there is no cursor: park the resting
  // instrument in clear space on the right shoulder rather than at the centre
  // of the format, where it would sit on the densest part of the colony.
  let gx = cur ? cur[0] : W * 0.80, gy = cur ? cur[1] : H * 0.30;
  const on = ev.on, base = 1;
  const gr = 15 * (view_.cursorK ?? 1);
  const kk = view_.cursorK ?? 1;

  // The instrument never sits on the event: it would cover the ball it reports.
  // When the cursor is on the pinned point, the ring moves out to a shoulder
  // and the leader carries the connection.
  if (anchor) {
    const dx0 = gx - anchor[0], dy0 = gy - anchor[1], L0 = Math.hypot(dx0, dy0), MIN = 112;
    if (L0 < MIN) {
      const ux = L0 > 1 ? dx0 / L0 : 0.94, uy = L0 > 1 ? dy0 / L0 : -0.34;
      gx = Math.max(gr + 10, Math.min(W - gr - 10, anchor[0] + ux * MIN));
      gy = Math.max(gr + 10, Math.min(H - gr - 10, anchor[1] + uy * MIN));
    }
  }

  if (anchor) {                              // the leader, drawn behind the ring
    ctx.strokeStyle = INK(0.28 * on); ctx.lineWidth = 0.6;
    const dx = anchor[0] - gx, dy = anchor[1] - gy, L = Math.hypot(dx, dy) || 1;
    if (L > gr + 14) {
      ctx.beginPath();
      ctx.moveTo(gx + dx / L * (gr + 5), gy + dy / L * (gr + 5));
      ctx.lineTo(anchor[0] - dx / L * 7, anchor[1] - dy / L * 7);
      ctx.stroke();
    }
  }

  // Detected: while the colony has registered the prowling cursor but no
  // intrusion is pinned, the instrument pulses — a halo leaving the ring.
  const det = (!sim.pin && ev.dead <= 0) ? Math.max(0, Math.min(1, (sim.perturb || 0) * 1.6)) : 0;
  if (det > 0.04) {
    const ph = (sim.t * 1.15) % 1;
    ctx.strokeStyle = LIT(0.62 * det * (1 - ph)); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(gx, gy, gr + 2 + ph * 15, 0, 6.2832); ctx.stroke();
  }
  // detection takes the brightest step the palette has: white is the
  // measurement event, so the instrument goes white the moment it is registered
  ctx.strokeStyle = det > 0.04 ? LIT((0.55 + det * 0.45) * base) : DIM(0.6 * base);
  ctx.lineWidth = det > 0.04 ? 1.1 : 0.7;
  ctx.beginPath(); ctx.arc(gx, gy, gr, 0, 6.2832); ctx.stroke();

  const T = sim.tempMax, heat = on > 0.05 ? heatRGB(T) : null;
  if (heat) {
    ctx.strokeStyle = rgba(heat, 0.95 * on); ctx.lineWidth = 1.7;
    const frac = Math.max(0, Math.min(1, (T - HEAT_ON) / (1 - HEAT_ON)));
    ctx.beginPath(); ctx.arc(gx, gy, gr, -Math.PI / 2, -Math.PI / 2 + frac * 6.2832); ctx.stroke();
  }

  const agit = Math.max(0, Math.min(1, sim.agit || 0)) * on;
  ctx.fillStyle = det > 0.04 ? LIT(0.42 + det * 0.4) : INK(0.34 + agit * 0.4);
  const rr = 5.6 + agit * 2.8 * (0.6 + 0.4 * Math.abs(Math.sin(sim.t * 8.6)));
  ctx.beginPath(); ctx.arc(gx, gy, rr, 0, 6.2832); ctx.fill();

  const left = gx > W - 260;
  const tx = left ? gx - gr - 12 : gx + gr + 12;
  ctx.textAlign = left ? 'right' : 'left';
  ctx.font = (10.5 * kk) + FONT;
  const st = intruderState(sim, ev);
  if (on < 0.05) {
    // the label reports the intruder's condition at every stage
    ctx.fillStyle = det > 0.04 ? LIT(0.95) : DIM(st === 'SIGNAL' ? 0.6 : 0.95);
    ctx.fillText(st, tx, gy + 1);
  } else {
    ctx.fillStyle = DIM(1 * on);
    ctx.fillText(st, tx, gy - 8);
    ctx.font = (12 * kk) + FONT;
    ctx.fillStyle = INK(0.92 * on);
    ctx.fillText('C\u2090 ' + Math.max(0, Math.min(1, T / 1.15)).toFixed(2) + '   AT WORKLOAD', tx, gy + 5);
    ctx.font = (10 * kk) + FONT;
    ctx.fillStyle = DIM(0.85 * on);
    ctx.fillText('N\u2090 ' + sim.committed + '   \u03a6 ' + (sim.phiG || 0).toFixed(2)
      + '   RESPONSE ' + Math.round(Math.max(0, Math.min(1, sim.dose || 0)) * 100) + '%', tx, gy + 19);
  }
  ctx.textAlign = 'left';
}

// Isotherms exactly as treatment I draws them in v1: five continuous levels
// scaled to the current maximum, hairline, and the critical one doubled with a
// dashed companion. Temperature is sampled with max, never a sum.
let TB, TGW, TGH;
const SEGS = [];
function isotherms(ctx, cam, sim, W, H) {
  if (sim.tempMax < 0.06) return;
  const cell = 7;
  const gw = Math.max(8, Math.round(W / cell)), gh = Math.max(6, Math.round(H / cell));
  if (TGW !== gw || TGH !== gh) { TGW = gw; TGH = gh; TB = new Float32Array(gw * gh); }
  TB.fill(0);
  for (let i = 0; i < sim.N; i++) {
    if (sim.temp[i] < 0.02) continue;
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const x0 = Math.round(o4[0] / W * gw), y0 = Math.round(o4[1] / H * gh);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = x0 + dx, y = y0 + dy;
      if (x < 0 || y < 0 || x >= gw || y >= gh) continue;
      const v = sim.temp[i] * Math.exp(-(dx * dx + dy * dy) / 1.5);
      if (v > TB[y * gw + x]) TB[y * gw + x] = v;
    }
  }
  const kx = W / gw, ky = H / gh, n = 5;
  const stroke = () => {
    ctx.beginPath();
    for (let s = 0; s < SEGS.length; s += 2) {
      ctx.moveTo(SEGS[s][0] * kx, SEGS[s][1] * ky);
      ctx.lineTo(SEGS[s + 1][0] * kx, SEGS[s + 1][1] * ky);
    }
    ctx.stroke();
  };
  for (let l = 0; l < n; l++) {
    const lv = HEAT_ON + (sim.tempMax - HEAT_ON) * ((l + 0.6) / n);
    if (lv <= HEAT_ON) continue;
    const c = heatRGB(lv); if (!c) continue;
    isolines(TB, gw, gh, lv, SEGS);
    if (!SEGS.length) continue;
    const crit = lv > 0.82;
    ctx.strokeStyle = rgba(c, crit ? 0.95 : 0.5 + (l / n) * 0.32);
    ctx.lineWidth = crit ? 1.1 : 0.55;
    stroke();
    if (crit) {
      ctx.setLineDash([2, 3]); ctx.lineWidth = 0.5;
      stroke();
      ctx.setLineDash([]);
    }
  }
}

function scaleBar(ctx, W, H) {
  const L = Math.min(240, W * 0.16), x = W / 2 - L / 2, y = H - Math.max(70, Math.min(124, H * 0.2));
  ctx.strokeStyle = DIM(0.5); ctx.lineWidth = 0.7;
  ctx.beginPath();
  ctx.moveTo(x, y); ctx.lineTo(x + L, y);
  for (let i = 0; i <= 4; i++) {
    const tx = x + L * i / 4;
    ctx.moveTo(tx, y); ctx.lineTo(tx, y - (i % 2 ? 3.5 : 6));
  }
  ctx.stroke();
}

// Each phase carries its own animated signature, so the step is legible from
// the drawing alone. All hairline grey except the critical band, which is the
// one place chroma is allowed.
function phaseCues(ctx, cam, sim, W, H, ev, cursor) {
  if (!ev) return;
  const ph = ev.phase || 0, held = sim.t - (ev.phaseAt ?? 0);
  let px = 0, py = 0, sc = 1;
  if (sim.pin) {
    project(cam, sim.pin[0], sim.pin[1], sim.pin[2], W, H, o4);
    px = o4[0]; py = o4[1]; sc = cam.fov / o4[2];
  }
  const shell = Math.max(8, sim.shellR) * sc;

  // 1 · DETECTED — alarm spreading outward from the prowling intruder
  if (ph === 1 && cursor) {
    for (let q = 0; q < 2; q++) {
      const u = ((sim.t / 1.6) + q * 0.5) % 1;
      ctx.strokeStyle = INK(0.26 * (1 - u) * (1 - u));
      ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.arc(cursor[0], cursor[1], 16 + u * 150, 0, 6.2832); ctx.stroke();
    }
  }
  // 2 · LOCKED — one dashed ring snapping inward onto the point
  if (ph === 2 && sim.pin) {
    const u = Math.min(1, held / 0.6);
    ctx.strokeStyle = INK(0.44 * (1 - u * 0.55)); ctx.lineWidth = 0.8;
    ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.arc(px, py, 156 - 126 * u * u, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]);
    if (u > 0.75) {
      ctx.strokeStyle = INK(0.5 * (u - 0.75) / 0.25);
      for (let q = 0; q < 4; q++) {
        const a = q * Math.PI / 2;
        ctx.beginPath();
        ctx.moveTo(px + Math.cos(a) * 15, py + Math.sin(a) * 15);
        ctx.lineTo(px + Math.cos(a) * 22, py + Math.sin(a) * 22);
        ctx.stroke();
      }
    }
  }
  // 3 · CONVERGENCE — approach vectors on the agents still flying in
  if (ph === 3 && sim.pin) {
    ctx.lineWidth = 0.6;
    for (let i = 0; i < sim.N; i++) {
      if (sim.def[i] < 0.3) continue;
      project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4b);
      const dx = px - o4b[0], dy = py - o4b[1], L = Math.hypot(dx, dy) || 1;
      if (L < shell * 1.3) continue;                 // arrived: no vector
      const u = Math.min(1, (L - shell) / 130);
      const len = Math.min(17, L * 0.24);
      ctx.strokeStyle = INK(0.36 * u);
      ctx.beginPath();
      ctx.moveTo(o4b[0], o4b[1]);
      ctx.lineTo(o4b[0] + dx / L * len, o4b[1] + dy / L * len);
      ctx.stroke();
    }
  }
  // 5 · CRITICAL BAND — the lethal threshold breathes, dashed, in motion
  if (ph === 5 && sim.pin) {
    const b = 0.5 + 0.5 * Math.sin(sim.t * 4.4);
    ctx.strokeStyle = RED(0.26 + 0.3 * b); ctx.lineWidth = 0.9;
    ctx.setLineDash([2.5, 3.5]); ctx.lineDashOffset = -sim.t * 16;
    ctx.beginPath(); ctx.arc(px, py, shell * 1.55, 0, 6.2832); ctx.stroke();
    ctx.setLineDash([]); ctx.lineDashOffset = 0;
  }
  // 6 · RELEASE — one ring expanding away from the spent event
  if (ph === 6 && ev.lastC) {
    const u = held / 1.8;
    if (u < 1) {
      ctx.strokeStyle = INK(0.3 * (1 - u)); ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.arc(ev.lastC[0], ev.lastC[1], 12 + u * 180, 0, 6.2832); ctx.stroke();
    }
  }
}

// PER-PARTICLE COLOUR — workload identity first, generic engaged accent second.
// sim.wlc is an Int16Array of rgb triples (-1 = no workload assignment), written
// by the driver from the fixture's own workload table. When a particle carries a
// workload it takes that workload's exact colour — the same one the Active
// Workloads legend and the Map traffic print — so several cohorts read as
// several workloads instead of one undifferentiated engaged state.
function hcOf(sim, i) {
  const c = sim.wlc;
  if (c) {
    const o = i * 3;
    if (c[o] >= 0 && sim.temp[i] > 0.01) return [c[o], c[o + 1], c[o + 2]];
  }
  return heatRGB(sim.temp[i]);
}

function drawScene(ctx, W, H, sim, view, lat, hive, ev) {
  const cam = view.cam;
  if (!view.keepCanvas) ctx.clearRect(0, 0, W, H);
  const k = view.combK ?? view.hiveK ?? 1;
  if (lat && k > 0) comb(ctx, lat, k);
  phaseCues(ctx, cam, sim, W, H, ev, view.cursor);
  // the intruder is drawn UNDER the colony, so the defensive ball covers it
  const anchor = eventPoint(ctx, cam, sim, W, H, ev);
  if (view.trails !== false) histories(ctx, cam, sim, W, H, view.trailCfg);
  if (view.isotherms !== false) isotherms(ctx, cam, sim, W, H);   // v3: off in Operations
  agents(ctx, cam, sim, W, H, view.glyph, view.glyphK ?? 1);
  if (!view.hideInstrument) instrument(ctx, sim, W, H, ev, view.cursor, anchor, view);
}


// ---------------------------------------------------------------- THE WORLD
// The hive is a world: comb cells tile the surface of a sphere the colony lives
// on. Cells are only revealed by proximity, exactly as on the flat lattice, and
// the whole surface turns with the camera because every cell is a world point.
const WORLD_R = 58;

function buildSphereLattice(o = {}) {
  const n = o.n ?? 150, R = o.R ?? WORLD_R;
  const rc = R * Math.sqrt(Math.PI / n) * 1.06;    // cell radius that tiles the sphere
  const cells = [];
  let s = 991137 >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  const GOLD = 2.399963229728653;
  for (let k = 0; k < n; k++) {
    const z = 1 - 2 * (k + 0.5) / n, r = Math.sqrt(Math.max(0, 1 - z * z)), a = GOLD * k;
    const u = [r * Math.cos(a), z, r * Math.sin(a)];
    // a tangent basis, so the hexagon lies flat on the surface
    let tx = -u[2], ty = 0, tz = u[0];
    let tl = Math.hypot(tx, ty, tz);
    if (tl < 1e-4) { tx = 1; ty = 0; tz = 0; tl = 1; }
    tx /= tl; ty /= tl; tz /= tl;
    const bx = u[1] * tz - u[2] * ty, by = u[2] * tx - u[0] * tz, bz = u[0] * ty - u[1] * tx;
    cells.push({
      u, t: [tx, ty, tz], b: [bx, by, bz], rc,
      x: u[0] * R, y: u[1] * R, z: u[2] * R,
      amp: 0, chg: 0, rev: 0, rate: 0.6 + rnd() * 1.5, occ: 0,
      sx: 0, sy: 0, ss: 1, vis: 0
    });
  }
  // direction lookup: nearest cell per (azimuth, elevation) bucket, so an agent
  // finds its cell in constant time instead of scanning the whole surface
  const LA = 64, LE = 32, lut = new Int16Array(LA * LE);
  for (let ia = 0; ia < LA; ia++) for (let ie = 0; ie < LE; ie++) {
    const az = (ia + 0.5) / LA * Math.PI * 2, el = Math.acos(1 - 2 * (ie + 0.5) / LE);
    const dx = Math.sin(el) * Math.cos(az), dy = Math.cos(el), dz = Math.sin(el) * Math.sin(az);
    let bi = 0, bd = -2;
    for (let k = 0; k < cells.length; k++) {
      const u = cells[k].u, d = u[0] * dx + u[1] * dy + u[2] * dz;
      if (d > bd) { bd = d; bi = k; }
    }
    lut[ia * LE + ie] = bi;
  }
  return { sphere: true, R, rc, cells, active: 0, lut, LA, LE };
}

const _o = new Float32Array(4);
function updateSphereLattice(lat, sim, dt, allow, cam, W, H, cur, project) {
  const thr = Math.max(0.34, (sim.phiG || 0.4) + 0.1);
  lat.prj = (x, y, z, o) => project(cam, x, y, z, W, H, o);
  // camera forward, to cull the far side of the world
  const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  const fx = sy * cp, fy = sp, fz = cy * cp;
  for (const c of lat.cells) {
    c.occ = 0;
    const facing = -(c.u[0] * fx + c.u[1] * fy + c.u[2] * fz);
    c.vis = facing > 0.06 ? Math.min(1, (facing - 0.06) / 0.28) : 0;
    if (!c.vis) { c.rev = Math.max(0, c.rev - dt / (1.9 * c.rate)); c.amp = 0; continue; }
    const gw = lat.grow ?? 1;
    project(cam, c.x * gw, c.y * gw, c.z * gw, W, H, _o);
    c.sx = _o[0]; c.sy = _o[1]; c.ss = _o[3];
  }
  // the cursor reveals the surface it passes over
  if (cur) {
    for (const c of lat.cells) {
      if (!c.vis) continue;
      const rr = c.rc * c.ss * 1.9, d = Math.hypot(c.sx - cur[0], c.sy - cur[1]);
      if (d < rr) c.rev = Math.min(1.7, c.rev + dt * 2.6 * (1 - d / rr));
    }
  }
  // and so does traffic: agents crossing a cell wake it a third as strongly
  for (let i = 0; i < sim.N; i++) {
    const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
    const L = Math.hypot(x, y, z) || 1;
    const el = Math.acos(Math.max(-1, Math.min(1, y / L)));
    let az = Math.atan2(z / L, x / L); if (az < 0) az += Math.PI * 2;
    const ia = Math.min(lat.LA - 1, (az / (Math.PI * 2) * lat.LA) | 0);
    const ie = Math.min(lat.LE - 1, ((1 - Math.cos(el)) / 2 * lat.LE) | 0);
    const c = lat.cells[lat.lut[ia * lat.LE + ie]];
    if (!c.vis) continue;
    c.occ += 1; c.rev = Math.min(0.50, c.rev + dt * 0.85);
  }
  let live = 0;
  for (const c of lat.cells) {
    if (!c.vis) continue;
    c.rev = Math.max(0, c.rev - dt / (2.2 * c.rate));
    const on = allow && c.occ > 2 && (sim.phiG || 0) > thr;
    c.chg += on ? dt / 1.3 : -dt / (0.9 * c.rate);
    if (c.chg > 1.25) c.chg = 1.25; else if (c.chg < 0) c.chg = 0;
    const v = Math.max(c.chg, c.rev);
    c.amp = v <= 0.20 ? 0 : Math.min(1, (v - 0.20) / 0.62);
    if (c.amp > 0.02) live++;
  }
  lat.active = live;
}

function combSphere(ctx, lat, k) {
  for (const c of lat.cells) {
    if (c.amp <= 0.02 || !c.vis) continue;
    ctx.fillStyle = INK(c.amp * 0.15 * c.vis * k);
    // the hexagon is built in the cell's own tangent plane and projected, so it
    // foreshortens toward the limb like a face on a globe
    const gw = lat.grow ?? 1;
    const r = c.rc * 0.94 * gw, u = c.u, t = c.t, b = c.b, R = lat.R * gw;
    ctx.beginPath();
    for (let s = 0; s < 6; s++) {
      const a = Math.PI / 6 + s * Math.PI / 3;
      const ct = Math.cos(a) * r, cb = Math.sin(a) * r;
      const X = u[0] * R + t[0] * ct + b[0] * cb;
      const Y = u[1] * R + t[1] * ct + b[1] * cb;
      const Z = u[2] * R + t[2] * ct + b[2] * cb;
      lat.prj(X, Y, Z, _o);
      s ? ctx.lineTo(_o[0], _o[1]) : ctx.moveTo(_o[0], _o[1]);
    }
    ctx.closePath();
    ctx.fill();
    if (c.amp > 0.42) {
      ctx.strokeStyle = INK((c.amp - 0.42) * 0.34 * c.vis * k);
      ctx.lineWidth = 0.6;
      ctx.stroke();
    }
  }
}

return { heatRGB, intruderState, sceneState, buildLattice, updateLattice, drawScene, WORLD_R, buildSphereLattice, updateSphereLattice };
})();

// ===== lens-driver.js =====
__M["lens-driver.js"] = (() => {
// LENS DRIVER — one persistent spherical operational world, three lenses.
//
// SEMANTIC CONTRACT
//   MAP        where resources are and where activity is occurring
//   NODE STATS how those resources are performing (same world, telemetry forward)
//   SWARM      how distributed capacity is behaving collectively
//   ORCHESTRATION is a different screen; nothing here draws routing
//
// One world, one camera, one orientation, one zoom — lens switches ease
// emphasis weights (mapK/nodesK/swarmK) and never touch camera state.
// Capacity behaviour is the untouched v2 model (capacity-field.js verbatim).
//
// Camera: drag rotates (inertia); the wheel is a REAL magnifying zoom across
// three named operational scales — GLOBAL (world + regions), REGIONAL (region +
// participating capacity), LOCAL (settlements, node ids, node detail) — and
// Fit All returns to the wide overview. v2 fixes the earlier camera, whose fov
// tracked distance and so held the world at a constant screen size: zooming
// changed only foreshortening. Now zoom magnifies, and focusing a region turns
// the world to face it and descends the scales in one eased move.
// Traffic is geographic operational context: present in Map, a whisper in
// Swarm — short teal pulses, never capacity, never Orchestration's routes.

const core = __M["vendor/swarm-core.js"];
const {T, setTheme, themeName, rgbaT} = __M["theme.js"];
const {makeField} = __M["capacity-field.js"];
const {buildLandStipple, buildLandStippleCap, fromSphereUnit, toSphere} = __M["geo-land.js"];
const {buildGraticule, buildNodeMarks, drawSphereBase, drawLand, drawAgents, drawRegionMarks, drawNodeMarks, drawSideRegionLabels, drawYou, drawPlaces, drawCohortLabels, drawWorkloadCohorts, drawParticleStems, beginLabels, keepOut, keepOutRect, setUiScale, drawHistories, drawIsotherms} = __M["world-scene.js"];
const {makeTraffic} = __M["traffic-overlay.js"];
const sceneOrig = __M["scene-orig.js"];
// the original's glyph table, verbatim
const GLYPHS = {
  Triangle: { kind: 'tri', scale: 1 },
  Dash: { kind: 'dash', scale: 1 },
  Circle: { kind: 'dot', scale: 1.15 },
  Diamond: { kind: 'dia', scale: 0.9 },
  Hexagon: { kind: 'hex', scale: 1 },
  'Circle filled': { kind: 'dot', scale: 1.15, fill: true },
  'Diamond filled': { kind: 'dia', scale: 0.9, fill: true }
};

const SR = 58;
const RDEF = [
  // Infrastructure groups are FIXED data: exactly these nodes, these names.
  // ctrl is the control-plane location co-sited with the group where one exists —
  // a location, never a compute node, never part of any node count. London is
  // ONLY a control plane: no compute nodes exist there and none are invented.
  { id: 'ohio', name: 'OHIO · US-EAST-2', ctrl: 'control-use2-1', code: 'use2', label: 'us-ohio · you', lat: 40.0, lon: -83.0, nodes: 4, mo: [17, -20], flowSign: 1 },
  { id: 'dublin', name: 'EU-WEST-1A', code: 'euw1', label: 'eu-west-1a', lat: 53.3, lon: -6.3, nodes: 3, mo: [-17, -20], flowSign: 1 },
  { id: 'london', name: 'LONDON · EU-WEST-2', ctrl: 'control-euw2-1', code: 'ukl', label: 'uk-london', lat: 51.5, lon: -0.1, nodes: 0, mo: [-16, 22], flowSign: 1 },
  { id: 'frankfurt', name: 'FRANKFURT · EU-CENTRAL-1', ctrl: 'control-euc1-1', code: 'euc1', label: 'de-frankfurt', lat: 50.1, lon: 8.7, nodes: 3, mo: [17, 20], flowSign: 1 }
];
const FIXTURES = {
  'BASELINE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0 },
  'OHIO ACTIVE': { ohio: 0.62, dublin: 0, london: 0, frankfurt: 0 },
  'FRANKFURT ACTIVE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0.66 },
  'MULTI-REGION ACTIVE': { ohio: 0.40, dublin: 0.55, london: 0, frankfurt: 0.78 },
  'HIGHER DEMAND': { ohio: 0.60, dublin: 0.80, london: 0.30, frankfurt: 0.95 },
  'RETURN TO BASELINE': { ohio: 0, dublin: 0, london: 0, frankfurt: 0 }
};
const NODES_BY_REGION = {
  ohio: ['amd-0', 'sev-0', 'sev-1', 'sev-2'],
  dublin: ['sev-3', 'sev-4', 'sev-5'],
  frankfurt: ['gpu-1', 'gpu-2', 'sev-6']
};
const NODE_COUNTS = { ohio: 4, dublin: 3, frankfurt: 3, london: 0 };
// PROTOTYPE DATA — the model each node currently serves, as the node cards state it.
// This is a SNAPSHOT OF THE CURRENT RESOLVED STATE, not a permanent workload->model
// binding: the product routes per request.
const NODE_MODEL = {
  'amd-0': 'Qwen2.5 3B', 'gpu-1': 'Qwen2.5 7B', 'gpu-2': 'Qwen2.5 7B',
  'sev-0': 'Qwen2.5 3B', 'sev-1': 'Qwen2.5 3B', 'sev-2': 'Qwen2.5 3B', 'sev-3': 'Qwen2.5 3B',
  'sev-4': 'Qwen2.5 3B', 'sev-5': 'Qwen2.5 3B', 'sev-6': 'Qwen2.5 3B'
};
// place + infrastructure region, so the world and the panels can name a region
// unambiguously without inventing a new label
const REGION_DISPLAY = {
  ohio: ['Ohio', 'us-east-2'], frankfurt: ['Frankfurt', 'eu-central-1'],
  dublin: ['Dublin', 'eu-west-1a'], london: ['London', 'eu-west-2']
};
const SHORT2REG = {};
for (const rid in NODES_BY_REGION) for (const id of NODES_BY_REGION[rid]) SHORT2REG[id] = rid;
// secondary node detail, shown only where zoom allows — never invented beyond this
const NODE_HW = {
  'amd-0': 'AMD Radeon Pro V520 8GB',
  'gpu-1': 'NVIDIA L4 24GB',
  'gpu-2': 'NVIDIA L4 24GB',
  'sev-0': 'CPU · AMD EPYC / SEV-SNP',
  'sev-1': 'CPU · AMD EPYC / SEV-SNP',
  'sev-2': 'CPU · AMD EPYC / SEV-SNP',
  'sev-3': 'CPU · AMD EPYC / SEV-SNP',
  'sev-4': 'CPU · AMD EPYC / SEV-SNP',
  'sev-5': 'CPU · AMD EPYC / SEV-SNP',
  'sev-6': 'CPU · AMD EPYC / SEV-SNP'
};

// ---- WORKLOAD IDENTITY -----------------------------------------------------------
// SWARM IS WORKLOAD-ORIENTED. Workloads organise engaged capacity; regions only
// locate it. So the workload is the visual identity and it owns a colour that is
// the SAME in three places: the Active Workloads legend, the engaged capacity
// cohort on the globe, and the Map traffic. Free capacity is never coloured.
// The palette is small and categorical — blue, violet, green, cyan, magenta —
// with every reserved meaning avoided: no amber (structural / selection / YOU),
// no red (failure only), no neutral (free capacity). Amber took the primary role
// from teal, so the amber that used to sit in this palette moved to cyan.
const WL_COLORS = new Proxy({}, { get: (_, k) => T.workloads[k] });
const hexOf = c => '#' + c.map(v => Math.max(0, Math.min(255, v | 0)).toString(16).padStart(2, '0')).join('');
// The fixture's OWN workload entries, in fixture order: name + allocated slots,
// nothing else. Region is deliberately absent — the fixture does not declare
// workload -> region routing, so none is fabricated here. Slots are consumed in
// this order from the network's used slots, and each workload's capacity is
// simply wherever those slots physically live.
// ===== REVIEW FIXTURE ============================================================
// The review state, stated ONCE, explicitly, and isolated from all rendering.
//
// CANONICAL / SOURCE-BASED review values: 59 slots, 10 nodes, 10 used, 49 free
// (17% / 83%), the workload names and their slot counts.
// PROTOTYPE FIXTURE values (review stand-ins, NOT measured product data): the
// distribution of the 59 slots across individual nodes, the workload -> node
// assignments in `at`, the tok/s figures below, and the 1 slot = 5 particles
// visual scale — which makes 295 particles: 50 engaged, 245 free.
//
// Every engaged slot names its owner — node, region and workload — so ownership
// can never fall out of array order, animation or randomness. `ERIC 3` and
// `ERIC` stay separate records.
// `at` is [nodeId, slotIndexWithinThatNode]: the slot's permanent address in the
// capacity model's own ownership table (NETWORK -> REGION -> NODE -> SLOT).
// MAP TRAFFIC IS QUANTITATIVE: one moving traffic particle stands for a fixed
// number of tokens, so density is a reading of throughput rather than decoration.
// One global scale for every workload — no per-workload visual cheating — and a
// fixed visual persistence window, which is a rendering choice, not a metric.
const TOKEN_PARTICLE_SCALE = 50;      // tokens per traffic particle
// ---- LIVE TRAFFIC STATE ------------------------------------------------------
// SIMULATED live telemetry, NOT backend data. The fixture's tok/s figures are the
// NOMINAL BASE RATES; this layer varies each workload gently around its own base
// and publishes ONE state that the rail readings, the per-node route rates and
// the token-particle emission all read from. Nothing here animates text on its
// own — the numbers move because the traffic state moved, and the particles
// thicken and thin from the very same numbers.
// Replacing the simulation with real telemetry means feeding measured tok/s into
// setLive() and deleting the wave; every consumer below is unchanged.
const TRAFFIC_VARIATION = 0.10;   // ±10% around base
const TRAFFIC_RETARGET = 1.4;     // seconds between new targets
const TRAFFIC_SETTLE = 0.24;      // time constant of the approach (~0.7s to settle)
const trafficState = {
  base: {}, split: {}, live: {}, target: {}, totalTokPerSec: 0, workloads: {},
  _step: -1, _ready: false,
  // deterministic, smooth, and out of phase per workload: three low-frequency
  // components on mutually unrelated periods. No Math.random anywhere, so a
  // reload reproduces the same traffic behaviour for review.
  _wave(seed, t) {
    return 0.55 * Math.sin(t * 0.21 + seed * 1.7)
         + 0.30 * Math.sin(t * 0.37 + seed * 4.1)
         + 0.15 * Math.sin(t * 0.13 + seed * 2.6);
  },
  init(fixture) {
    this.base = {}; this.split = {}; this.live = {}; this.target = {}; this.workloads = {};
    const T = fixture.throughput || {};
    let i = 0;
    for (const wid in T) {
      const per = T[wid];
      let sum = 0;
      for (const nd in per) sum += per[nd];
      if (sum <= 0) continue;
      this.base[wid] = sum;
      this.split[wid] = {};
      for (const nd in per) this.split[wid][nd] = per[nd] / sum;   // fixture proportions, preserved
      this.live[wid] = sum;
      this.target[wid] = sum;
      this.workloads[wid] = { tokPerSec: sum, seed: ++i };
    }
    this._step = -1; this._ready = true;
    this._sum();
  },
  _sum() {
    let t = 0;
    for (const wid in this.live) { this.workloads[wid].tokPerSec = this.live[wid]; t += this.live[wid]; }
    this.totalTokPerSec = t;    // ALWAYS derived, never animated on its own
  },
  update(t, dt) {
    if (!this._ready) return;
    const step = Math.floor(t / TRAFFIC_RETARGET);
    if (step !== this._step) {
      this._step = step;
      const ts = step * TRAFFIC_RETARGET;
      for (const wid in this.base)
        this.target[wid] = this.base[wid] * (1 + TRAFFIC_VARIATION * this._wave(this.workloads[wid].seed, ts));
    }
    const k = 1 - Math.exp(-Math.max(0, dt) / TRAFFIC_SETTLE);
    for (const wid in this.base) this.live[wid] += (this.target[wid] - this.live[wid]) * k;
    this._sum();
  },
  // the per-node reading: the workload is the parent signal, its nodes keep the
  // fixture's own distribution ratios
  nodeRate(wid, node) {
    const s = this.split[wid];
    return s && s[node] ? this.live[wid] * s[node] : 0;
  }
};
const TRAFFIC_VISIBLE_WINDOW = 2;     // seconds a particle stays on its route
// PRODUCT vs DEV. false = the Civarro product interface: no fixture picker, no
// simulation controls, no model telemetry, no experimental instrument strip. The
// diagnostic code all survives behind this flag, so development keeps its tools
// without the product carrying them. Default MUST stay false.
const DEV_MODE = false;

const REVIEW_FIXTURE = {
  // CANONICAL SWARM REVIEW STATE — the single source of truth for slots, used,
  // free, workload names, slot counts, display percentages and the engaged
  // particle counts derived from them (1 slot = 5 particles).
  //   59 slots / 10 nodes · 10 used (17%) / 49 free
  //   295 capacity particles · 50 engaged / 245 free
  totals: { slots: 59, nodes: 10, used: 10, free: 49, perSlot: 5 },
  // the capacity model's ownership table names its nodes internally; these are
  // the SAME ten compute nodes the product shows. Stated here explicitly so no
  // rendering path has to infer it: 4 in Ohio, 3 in Frankfurt, 3 in EU-West.
  nodeIds: {
    'ohio-node-01': 'amd-0', 'ohio-node-02': 'sev-0', 'ohio-node-03': 'sev-1', 'ohio-node-04': 'sev-2',
    'frankfurt-node-01': 'gpu-1', 'frankfurt-node-02': 'gpu-2', 'frankfurt-node-03': 'sev-6',
    'dublin-node-01': 'sev-3', 'dublin-node-02': 'sev-4', 'dublin-node-03': 'sev-5'
  },
  // where a request enters the network: the control plane this screen is signed
  // into. It is a location, never a compute node, and never counted as one.
  source: { region: 'ohio', ctrl: 'control-use2-1' },
  // PROTOTYPE FIXTURE VALUES — tok/s per (workload, serving node). The source
  // snapshot carries no throughput figures, so these are review-fixture numbers
  // stated here explicitly and nowhere else; they are not product metrics and not
  // measured rates. A workload's total is DISTRIBUTED across its own nodes (never
  // repeated per route), so the sum below is the workload's total throughput.
  //   ERIC 3        250 tok/s      VISION PRO    250 tok/s
  //   CONF REMOTE   300 tok/s      CONF CARLOS   500 tok/s
  //   WORKLOAD      150 tok/s      ERIC (0 slots) idle, no route
  throughput: {
    'eric-1':        { 'amd-0': 100, 'sev-0': 100, 'sev-1': 50 },
    'vision-1':      { 'sev-2': 125, 'gpu-1': 125 },
    'conf-remote-1': { 'gpu-2': 150, 'sev-6': 150 },
    'workload-1':    { 'sev-3': 75, 'sev-4': 75 },
    'conf-carlos-1': { 'sev-5': 500 },
    'eric-2':        {}
  },
  // ACTIVE NODE COVERAGE: the 10 engaged slots take exactly one slot on each of
  // the ten compute nodes, so every node participates in active traffic and none
  // reads as disconnected. Per region that is Ohio 4, Frankfurt 3, EU-West 3 —
  // 10 used, 49 free. `ERIC 3` and `ERIC` are two distinct workload records; the
  // second holds 0 slots and therefore no capacity, no particles and no route.
  workloads: [
    { id: 'eric-1', name: 'ERIC 3', c: 'eric', slots: 3, pct: 5,
      at: [['ohio-node-01', 0], ['ohio-node-02', 0], ['ohio-node-03', 0]] },
    { id: 'vision-1', name: 'VISION PRO', c: 'vision', slots: 2, pct: 3,
      at: [['ohio-node-04', 0], ['frankfurt-node-01', 0]] },
    { id: 'conf-remote-1', name: 'CONFIDENTIAL COMPUTE FROM A REMOTE LOCATION', c: 'confRemote', slots: 2, pct: 3,
      at: [['frankfurt-node-02', 0], ['frankfurt-node-03', 0]] },
    { id: 'workload-1', name: 'WORKLOAD', c: 'workload', slots: 2, pct: 3,
      at: [['dublin-node-01', 0], ['dublin-node-02', 0]] },
    { id: 'conf-carlos-1', name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 1, pct: 2,
      at: [['dublin-node-03', 0]] },
    { id: 'eric-2', name: 'ERIC', c: 'eric', slots: 0, pct: 0, at: [] }
  ]
};

const WL_BY_FIXTURE = {
  'BASELINE': [],
  'OHIO ACTIVE': [
    { name: 'ERIC', c: 'eric', slots: 5 },
    { name: 'VISION PRO', c: 'vision', slots: 3 }],
  'FRANKFURT ACTIVE': [
    { name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 5 },
    { name: 'WORKLOAD', c: 'workload', slots: 3 }],
  // the review fixture: 59 slots / 10 used, partitioned exactly as the canonical
  // fixture states it — 3, 2, 2, 2, 1, 0. `ERIC 3` and `ERIC` stay separate.
  'MULTI-REGION ACTIVE': REVIEW_FIXTURE.workloads,
  'HIGHER DEMAND': [
    { name: 'ERIC', c: 'eric', slots: 9 },
    { name: 'VISION PRO', c: 'vision', slots: 8 },
    { name: 'CONFIDENTIAL COMPUTE FROM A REMOTE LOCATION', c: 'confRemote', slots: 8 },
    { name: 'CONFIDENTIAL COMPUTE CARLOS NOW', c: 'confCarlos', slots: 6 },
    { name: 'WORKLOAD', c: 'workload', slots: 3 }],
  'RETURN TO BASELINE': []
};
const TEAL = a => rgbaT('primary', a);   // legacy name; reads the primary role
const PR = () => (window.__ops3 && window.__ops3.props) || {};

const o4 = new Float32Array(4), o4c = new Float32Array(4), o4d = new Float32Array(4);
function boot(canvas0) {
  let canvas = canvas0;
  const $ = s => document.querySelector(s);
  const REGIONS = RDEF.map(r => {
    const p = toSphere(r.lat, r.lon, SR);
    const L = Math.hypot(p[0], p[1], p[2]);
    return { ...r, p, u: [p[0] / L, p[1] / L, p[2] / L] };
  });
  const REG = Object.fromEntries(REGIONS.map(r => [r.id, r]));
  const F = makeField({ n: 295, SR, regions: REGIONS });
  // CANONICAL REVIEW STATE: 59 slots over 10 nodes, 10 used / 49 free (17%),
  // 295 capacity particles / 50 engaged / 245 free. The engaged SLOT ADDRESSES
  // come from REVIEW_FIXTURE.workloads[].at and from nothing else.
  const SLOTS_TOTAL = 59;
  // PROTOTYPE DIAGNOSTIC FIXTURES ONLY — count-based demand states used to watch
  // capacity behaviour. They are NOT the canonical review state and must not
  // supply it: 'MULTI-REGION ACTIVE' is deliberately absent here, because that
  // fixture is driven by explicit slot addresses (see setFixture). Ohio owns 24
  // slots, Frankfurt 18, Dublin 17 (59), so every count below stays inside what
  // each region actually owns.
  const SLOTS_USED = {
    'BASELINE': {},
    'OHIO ACTIVE': { ohio: 8 },
    'FRANKFURT ACTIVE': { frankfurt: 8 },
    'HIGHER DEMAND': { frankfurt: 14, ohio: 12, dublin: 8 },
    'RETURN TO BASELINE': {}
  };
  F.setSlots(SLOTS_TOTAL, SLOTS_USED['BASELINE']);
  // one stipple, two readings: dense for Map, every-third for Swarm's whisper
  const land = buildLandStipple(SR * 1.002, 110000, 77);
  // GEOGRAPHIC LOD: as you zoom in, sample MORE real geography inside the patch
  // you are looking at, instead of stretching the same points apart. Rebuilt only
  // when the tier or the looked-at patch actually changes, and never more than
  // ~3x a second, so dragging stays smooth.
  let landLod = null, landLodKey = '', landLodAt = 0;
  function ensureLandLod(now) {
    const zl = Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6));
    if (zl < 0.18) { landLod = null; landLodKey = ''; return; }
    const capDeg = zl < 0.45 ? 60 : zl < 0.72 ? 34 : 20;
    const nPts = zl < 0.45 ? 50000 : zl < 0.72 ? 40000 : 34000;
    const f5 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
    const [lat, lon] = fromSphereUnit([-f5[0], -f5[1], -f5[2]]);
    const q = capDeg * 0.16;
    const key = capDeg + '|' + Math.round(lat / q) + '|' + Math.round(lon / q);
    if (key === landLodKey) return;
    if (now - landLodAt < 320) return;
    landLodKey = key; landLodAt = now;
    landLod = buildLandStippleCap(SR * 1.002, nPts, 91, lat, lon, capDeg);
  }
  const grat = buildGraticule(SR);
  const ALL_NODE_MARKS = buildNodeMarks(REGIONS, NODES_BY_REGION, SR, land);
  let nodeMarks = ALL_NODE_MARKS;
  const traffic = makeTraffic(SR);
  // ===== P1 — MAP WORKLOAD ROUTING ===============================================
  // ONE routing model, derived from REVIEW_FIXTURE and nothing else. The old
  // generic region-to-region arcs recoloured by "the region's dominant workload"
  // are gone: they collapsed several concurrent workloads into one line and threw
  // workload identity away.
  //
  //   CONTROL / REQUEST ORIGIN  (control-use2-1, the Ohio control plane)
  //             ↓
  //   WORKLOAD  (identity + persistent colour)
  //             ↓
  //   TARGET COMPUTE NODE(S)  (the nodes its slots actually sit on)
  //
  // One route per (workload, target node), so a workload may own several routes,
  // two workloads may reach the same node in their own colours, and the route
  // COUNT is a reading of the fixture — never a composition choice. Free capacity
  // generates nothing. Route topology is rebuilt only when the fixture changes.
  // ONE GEOMETRIC ROUTE PER TARGET NODE. A route is infrastructure geometry —
  // control plane -> compute node — so two workloads on one node share one line
  // and never draw parallel duplicates. The line stays neutral; workload identity
  // is carried by the moving pulses, one stream per workload on that node.
  let activeRoutes = [];
  // node -> a trace of the workload colour it serves (highest tok/s wins, so the
  // answer is deterministic). Used ONLY for the node's hairline activity ring.
  let nodeAccent = {};

  // ===== OPERATIONS SCOPE — ONE DERIVED FILTERED STATE ============================
  // The shell's filter chips (Location / Workload / Hardware / search) resolve ONE
  // set of visible nodes and workloads and publish it on `civarro:scope`. Every
  // region of the world reads THAT, and nothing filters on its own:
  //   engaged slot addresses -> capacity field -> cohorts -> routes, particles,
  //   node accents, capacity readings, workload legend
  //   scoped throughput      -> traffic rail rows, total, target count
  //   scoped node marks      -> node marks and region labels on the globe
  // SCOPE = null means unfiltered; the fixture is then used verbatim.
  // A node's region and hardware live in the shell's tables; this side only
  // consumes the resolved ids, so the two never disagree about a predicate.
  let SCOPE = null, scopeKey = 'all', NBR = NODES_BY_REGION;
  const ND2ID = REVIEW_FIXTURE.nodeIds;    // 'ohio-node-01' -> 'amd-0'
  const nodeOn = id => !SCOPE || SCOPE.nodes.has(id);
  const wlOn = id => !SCOPE || SCOPE.wl.has(id);
  // A WORKLOAD KEEPS EVERY SURVIVING PHYSICAL FOOTPRINT. Location narrows which of
  // its footprints are visible, never which region it "belongs" to; no workload is
  // ever given a home region here.
  function scopedWorkloads() {
    if (!SCOPE) return REVIEW_FIXTURE.workloads;
    const out = [];
    for (const w of REVIEW_FIXTURE.workloads) {
      if (!wlOn(w.id)) continue;
      const had = (w.at || []).length;
      const at = (w.at || []).filter(a => nodeOn(ND2ID[a[0]]));
      if (had && !at.length) continue;      // no footprint survives the filter
      out.push(Object.assign({}, w, { at: at, slots: at.length,
        pct: Math.round(at.length / SLOTS_TOTAL * 100) }));
    }
    return out;
  }
  function scopedThroughput() {
    const T0 = REVIEW_FIXTURE.throughput || {};
    if (!SCOPE) return T0;
    const out = {};
    for (const wid in T0) {
      if (!wlOn(wid)) continue;
      const per = {};
      for (const nd in T0[wid]) if (nodeOn(nd)) per[nd] = T0[wid][nd];
      if (Object.keys(per).length) out[wid] = per;
    }
    return out;
  }
  function applyScope() {
    nodeMarks = SCOPE ? ALL_NODE_MARKS.filter(m => nodeOn(m.id)) : ALL_NODE_MARKS;
    if (SCOPE) {
      NBR = {};
      for (const rid in NODES_BY_REGION) NBR[rid] = NODES_BY_REGION[rid].filter(nodeOn);
    } else NBR = NODES_BY_REGION;
    if (F.fixture === 'MULTI-REGION ACTIVE' && F.setUsedSlotAddresses) {
      const addrs = [];
      for (const w of scopedWorkloads()) for (const a of (w.at || [])) addrs.push(a);
      F.setUsedSlotAddresses(addrs);
    }
    asgKey = '';                 // cohorts re-derive from the new engaged set
    buildRoutes();               // routes + pulses of removed nodes are dropped
    const wb = $('[data-m-wl]'); if (wb) delete wb.dataset.k;
    flowKey = '';
    if (view !== 'swarm') { fillTrafficRail(); updateTrafficNumbers(); }
    fillFlowPanel();
  }
  window.addEventListener('civarro:scope', ev => {
    const d = ev.detail || {}, r = d.resolved, sc = d.scope || {};
    if (!r) return;
    const on = d.filtered !== undefined ? !!d.filtered
      : !!((sc.region || []).length || (sc.workload || []).length ||
           (sc.more || []).length || (sc.q || '').trim());
    // IDEMPOTENT. The shell re-renders its scope block on template re-renders and
    // re-publishes the same resolved sets; rebuilding routes on an unchanged scope
    // would drop every pulse in flight and the traffic would visibly restart.
    const key = on ? (r.nodes || []).join(',') + '/' + (r.wl || []).map(w => w.id).join(',') : 'all';
    if (key === scopeKey) return;
    scopeKey = key;
    SCOPE = on ? { nodes: new Set(r.nodes || []),
                   wl: new Set((r.wl || []).map(w => w.id)) } : null;
    applyScope();
  });

  // INCREMENTAL. A route is dropped only when its node stops carrying engaged
  // capacity, and a surviving route keeps its identity — so its pulses stay in
  // flight and the traffic does not blink out and refill on every filter change,
  // theme swap or reassignment.
  // ---- FLOWS ---------------------------------------------------------------------
  // The spatial summary of the CURRENT RESOLVED STATE, not Orchestration: for each
  // workload in scope, the origin now routing it, the model its nodes currently
  // serve, and where that compute physically is. Every value is read from the
  // prototype's own tables — no requirement set, no eligible set, no policy or trust
  // outcome, because the prototype workloads hold no such values.
  const opLens = () => (document.documentElement.dataset.opLens || 'map');
  let flowKey = '', flowRows = -1;
  function fillFlowPanel() {
    const box = $('[data-flow-wl]');
    if (!box) return;
    const key = F.fixture + '|' + scopeKey;
    if (flowKey === key && (flowRows === 0 || box.querySelector('[data-driver-rows] > *'))) return;
    flowKey = key;
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    const list = scopedWorkloads().filter(w => (w.at || []).length);
    const nodes = new Set(), regions = new Set();
    for (const w of list) for (const a of w.at) {
      const id = ND2ID[a[0]]; if (!id) continue;
      nodes.add(id); if (SHORT2REG[id]) regions.add(SHORT2REG[id]);
    }
    set('[data-flow-src]', REVIEW_FIXTURE.source.ctrl);
    // FLOWS reads the SAME scope the header facet publishes: one workload in scope is
    // the selected flow; several are the ambient reading. Every value below is derived
    // from the fixture's own tables (NODE_MODEL, SHORT2REG) — nothing is invented.
    const allModels = new Set(), allRegs = new Set(), allIds = new Set();
    for (const w of list) for (const a of w.at) {
      const i = ND2ID[a[0]]; if (!i) continue;
      allIds.add(i); if (NODE_MODEL[i]) allModels.add(NODE_MODEL[i]); if (SHORT2REG[i]) allRegs.add(SHORT2REG[i]);
    }
    set('[data-flow-sel]', list.length === 1 ? list[0].name : (list.length ? 'All workloads · ' + list.length : 'No workload in scope'));
    set('[data-flow-model]', [...allModels].join(' + ') || '—');
    set('[data-flow-region]', [...allRegs].map(r => (REGION_DISPLAY[r] || [r])[0] + ' · ' + ((REGION_DISPLAY[r] || ['', r])[1])).join(' + ') || '—');
    set('[data-flow-node]', [...allIds].join(', ') || '—');
    set('[data-flow-n]', String(list.length));
    set('[data-flow-nodes]', String(nodes.size));
    set('[data-flow-regions]', String(regions.size));
    const slot = rowSlot(box);
    for (const w of list) {
      const ids = w.at.map(a => ND2ID[a[0]]).filter(Boolean);
      const models = [...new Set(ids.map(i => NODE_MODEL[i]).filter(Boolean))];
      const regs = [...new Set(ids.map(i => SHORT2REG[i]).filter(Boolean))];
      const color = WL_COLORS[w.c] || [159, 176, 170];
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-width:0;';
      const head = document.createElement('span');
      head.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;align-self:stretch;min-width:0;';
      const dot = document.createElement('i');
      dot.dataset.wlc = w.c || '';
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(color) + ';';
      const nm = document.createElement('span');
      nm.setAttribute('data-wl-label', '');
      nm.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 1 auto;min-width:0;color:' + T.text1 + ';';
      nm.textContent = w.name;
      head.appendChild(dot); head.appendChild(nm);
      // the resolution chain, in the order it resolves
      const chain = document.createElement('span');
      chain.style.cssText = 'font-family:var(--md-sys-typescale-label-medium-font);font-weight:var(--md-sys-typescale-label-medium-weight);font-size:var(--md-sys-typescale-label-medium-size);line-height:var(--md-sys-typescale-label-medium-line-height);letter-spacing:var(--md-sys-typescale-label-medium-tracking);color:' + T.text2 + ';align-self:stretch;';
      chain.textContent = models.join(' + ') + ' → ' + ids.join(', ') + ' → '
        + regs.map(r => (REGION_DISPLAY[r] || [r])[0] + ' · ' + ((REGION_DISPLAY[r] || ['', r])[1])).join(' + ');
      row.appendChild(head); row.appendChild(chain);
      slot.appendChild(row);
    }
    if (!list.length) {
      const d0 = document.createElement('div');
      d0.style.cssText = 'color:' + T.text2 + ';font-family:var(--md-sys-typescale-body-medium-font);font-size:var(--md-sys-typescale-body-medium-size);line-height:var(--md-sys-typescale-body-medium-line-height);';
      d0.textContent = 'no workload resolves inside the current filters';
      slot.appendChild(d0);
    }
    flowRows = list.length;
    fillFlowBand(list);
  }
  // LOGICAL BAND. Every fixture workload with a footprint is listed; the ones outside
  // the current scope are subordinate (0.28). Fan-in to the one evidenced control
  // plane, fan-out to the models its nodes serve. Straight connectors: logical, not
  // geographic. Label roles: label-medium caps for stages, label-large for entities.
  function fillFlowBand(list) {
    const band = $('[data-flow-band]'); if (!band) return;
    const inScope = new Set(list.map(w => w.id));
    const all = REVIEW_FIXTURE.workloads.filter(w => (w.at || []).length);
    const LM = 'font-family:var(--md-sys-typescale-label-medium-font);font-weight:var(--md-sys-typescale-label-medium-weight);font-size:var(--md-sys-typescale-label-medium-size);line-height:var(--md-sys-typescale-label-medium-line-height);letter-spacing:var(--md-sys-typescale-label-medium-tracking);text-transform:uppercase;color:' + T.text2 + ';';
    const LL = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;color:' + T.text1 + ';';
    const modelNodes = {};
    for (const w of all) for (const a of w.at) { const i = ND2ID[a[0]], m = i && NODE_MODEL[i]; if (m) (modelNodes[m] = modelNodes[m] || new Set()).add(i); }
    const models = Object.keys(modelNodes);
    const wlModels = w => new Set(w.at.map(a => NODE_MODEL[ND2ID[a[0]]]).filter(Boolean));
    band.innerHTML = '<svg data-flow-lines style="position:absolute;inset:0;width:100%;height:100%;" fill="none"></svg>'
      + '<div style="position:absolute;left:28%;top:0;display:flex;flex-direction:column;gap:1px;"><span style="' + LM + '">Workload</span>'
      + all.map(w => '<span data-fb-wl="' + w.id + '" style="' + LL + 'display:flex;align-items:center;gap:8px;opacity:' + (inScope.has(w.id) ? 1 : 0.28) + ';"><i style="width:6px;height:6px;border-radius:50%;background:' + hexOf(WL_COLORS[w.c] || [159,176,170]) + ';"></i>' + w.name + '</span>').join('') + '</div>'
      + '<div data-fb-ctrl style="position:absolute;left:50%;top:0;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:2px;"><span style="' + LM + '">Control plane</span><i data-fb-ctrl-mark style="width:8px;height:8px;border:1.5px solid ' + T.text1 + ';margin-top:10px;"></i><span style="' + LL + '">' + REVIEW_FIXTURE.source.ctrl + '</span><span style="' + LM + 'text-transform:none;">routing · ' + (REGION_DISPLAY[REVIEW_FIXTURE.source.region] || [''])[0] + '</span></div>'
      + '<div style="position:absolute;left:62%;top:0;display:flex;flex-direction:column;gap:6px;"><span style="' + LM + '">Model</span>'
      + models.map(m => '<span data-fb-model="' + m + '" style="' + LL + 'border-top:1px solid ' + T.text2 + ';padding-top:3px;">' + m + ' <span style="color:' + T.text2 + ';">· ' + modelNodes[m].size + (modelNodes[m].size === 1 ? ' node' : ' nodes') + '</span></span>').join('') + '</div>';
    // connectors after layout: row right edge -> control mark -> model left edge.
    // The band is filled while still hidden (the lens applies before the rail
    // motion shows it), so the measurement waits until it has real geometry.
    let tries = 0;
    const wire = () => {
      const svg = band.querySelector('[data-flow-lines]'); if (!svg) return;
      const B = band.getBoundingClientRect();
      if ((!B.width || getComputedStyle(band).display === 'none') && tries++ < 40) { setTimeout(wire, 150); return; }
      const ck = band.querySelector('[data-fb-ctrl-mark]').getBoundingClientRect();
      const cx = ck.left + ck.width / 2 - B.left, cy = ck.top + ck.height / 2 - B.top;
      let d = '';
      for (const w of all) {
        const el = band.querySelector('[data-fb-wl="' + w.id + '"]'); if (!el) continue;
        const r = el.getBoundingClientRect(), x0 = r.right - B.left + 8, y0 = r.top + r.height / 2 - B.top;
        const col = hexOf(WL_COLORS[w.c] || [159,176,170]), a = inScope.has(w.id) ? 0.85 : 0.2;
        d += '<path d="M' + x0 + ' ' + y0 + ' C ' + (x0 + (cx - x0) * 0.6) + ' ' + y0 + ', ' + (cx - 30) + ' ' + cy + ', ' + (cx - 6) + ' ' + cy + '" stroke="' + col + '" stroke-opacity="' + a + '" stroke-width="1.2"/>';
        for (const m of wlModels(w)) {
          const me = band.querySelector('[data-fb-model="' + m + '"]'); if (!me) continue;
          const mr = me.getBoundingClientRect(), x1 = mr.left - B.left - 8, y1 = mr.top - B.top + 2;
          d += '<path d="M' + (cx + 6) + ' ' + cy + ' C ' + (cx + 40) + ' ' + cy + ', ' + (x1 - 40) + ' ' + y1 + ', ' + x1 + ' ' + y1 + '" stroke="' + col + '" stroke-opacity="' + (a * 0.8) + '" stroke-width="1.2"/>';
        }
      }
      svg.innerHTML = d;
    };
    requestAnimationFrame(wire);
  }
  // SCOPED CAPACITY. Read off the field's OWN slot table so a filtered reading is
  // the model's arithmetic, never an invented per-node figure.
  function scopedSlots() {
    const s = F.slots;
    if (!SCOPE || !F.slotTable) {
      return { total: s.total, used: s.used, free: s.free, usedPct: s.usedPct,
               nodes: F.ownership().network.nodes };
    }
    let total = 0, used = 0;
    for (const r of F.slotTable()) {
      const id = ND2ID[r.node];
      if (!id || !nodeOn(id)) continue;
      total++; if (r.used) used++;
    }
    return { total: total, used: used, free: total - used,
             usedPct: total ? Math.round(used / total * 100) : 0, nodes: SCOPE.nodes.size };
  }
  function buildRoutes() {
    const src = REG[REVIEW_FIXTURE.source.region];
    // the unique set of compute nodes carrying engaged workload capacity, and
    // which workloads each one serves — derived from the fixture, nothing else
    const byNode = new Map();
    if (src) for (const co of assign().cohorts) {
      for (const id of co.nodes || []) {
        if (!nodeMarks.some(n => n.id === id)) continue;   // never invent a destination
        const e = byNode.get(id) || { node: id, workloads: [] };
        if (!e.workloads.some(w => w.id === co.id)) e.workloads.push(co);
        byNode.set(id, e);
      }
    }
    for (let i = activeRoutes.length - 1; i >= 0; i--) {
      const r = activeRoutes[i];
      if (byNode.has(r.target)) continue;
      for (let j = traffic.pulses.length - 1; j >= 0; j--)
        if (traffic.pulses[j].r === r) traffic.pulses.splice(j, 1);
      const k = traffic.routes.indexOf(r);
      if (k >= 0) traffic.routes.splice(k, 1);
      activeRoutes.splice(i, 1);
    }
    for (const [id, e] of byNode) {
      const m = nodeMarks.find(n => n.id === id);
      let r = activeRoutes.find(x => x.target === id);
      if (!r) {
        r = traffic.addRoute(src.p, m.p, {
          rids: [REVIEW_FIXTURE.source.region, m.rid], node: id, lift: 0.022
        });
        r.color = [140, 156, 150];             // replaced below by its dominant workload
        r.sourceControlId = REVIEW_FIXTURE.source.ctrl;
        r.target = id; r.targetRegion = m.rid;
        r.streams = [];
        activeRoutes.push(r);
      }
      r.workloads = e.workloads;               // the identities sharing this path
      // one quantitative stream per workload on this node: tok/s -> particles/s.
      // An existing stream keeps its emission budget, so continuity survives.
      const prev = r.streams || [];
      r.streams = e.workloads.map(co => {
        // seeded from the fixture, then refreshed from the live state every frame
        const tps = ((REVIEW_FIXTURE.throughput[co.id] || {})[id]) || 0;
        const s = prev.find(p => p.co && p.co.id === co.id);
        if (s) { s.co = co; s.tokPerSec = tps; s.rate = tps / TOKEN_PARTICLE_SCALE; return s; }
        return { co, node: id, tokPerSec: tps, rate: tps / TOKEN_PARTICLE_SCALE, budget: 0, emitted: 0 };
      });
    }
    nodeAccent = {};
    for (const r of activeRoutes) {
      let best = null, bv = -1;
      for (const s of r.streams) if (s.tokPerSec > bv) { bv = s.tokPerSec; best = s.co; }
      if (best && best.color) { nodeAccent[r.target] = best.color; r.color = best.color; }
    }
  }
  // FLATTER PRODUCT LENS. Screen size of the globe is set by R0 and compensated in
  // cam.fov (fov = zoom * R0 * dist / SR), so pulling the camera back changes only
  // the PERSPECTIVE: at dist ≈ 4×SR the sphere bulged like a fisheye shot, pushing
  // Ohio and Europe apart and wrapping the limb. At ≈ 21×SR the projection is
  // effectively orthographic — the limb and the continents read like a true globe
  // plate, and the transatlantic band sits flat and horizontal, the way an
  // operations interface should read rather than a cinematic globe render.
  // THE WORLD SCALES WITH THE STAGE. Projection is s = fov / dist with a constant
  // fov, so a fixed fit distance drew the sphere at a FIXED pixel size — on a large
  // viewport the globe sat small in a mostly empty frame. The fit distance is now
  // solved from the stage, so the sphere always fills the same fraction of its
  // shorter side. Nothing else changes: node marks, labels and agent glyphs are
  // sized in screen units and keep exactly the weight they have now — only the
  // world and the spacing between its nodes grow.
  const FIT_DIST = 1240;
  const cam = core.makeCam({ yaw: 0, pitch: 0.24, dist: FIT_DIST, tx: 0, ty: 0, tz: 0 });
  let W = 0, H = 0, dpr = 1, ctx = null;
  function bind() {
    const r = canvas.parentElement.getBoundingClientRect();
    W = Math.max(320, Math.round(r.width)); H = Math.max(240, Math.round(r.height));
    dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  bind();
  window.addEventListener('resize', () => setTimeout(bind, 120));

  // ---- lenses: emphasis weights over ONE world; camera state never touched ----
  let view = 'map';
  const K = { map: 1, nodes: 0, swarm: 0 };
  let lensMix = 0;                 // 0 = Traffic (flow), 1 = Capacity (allocation)
  const LENS_DUR = 0.82;           // seconds, same either direction
  let tabEls = [];
  function styleTabs() {
    // read the DOM, not a list captured at boot: the driver loads from <helmet>,
    // before the template's own markup exists, so a cached list can be empty and
    // the control would keep the template's default state forever
    const els = document.querySelectorAll('[data-lens]');
    if (els.length) tabEls = [...els];
    for (const el of tabEls) {
      const on = el.dataset.lens === view;
      // the segmented control owns the frame; a tab only fills when selected, and
      // that fill is the one shared quiet surface the chips and cards also use
      if (el.tagName === 'MD-OUTLINED-SEGMENTED-BUTTON') {
        el.selected = on;
      } else if (el.tagName === 'MD-SECONDARY-TAB' || el.tagName === 'MD-PRIMARY-TAB') {
        if (on) el.setAttribute('active', ''); else el.removeAttribute('active');
      } else {
        el.style.background = on ? 'var(--selected)' : 'transparent';
        el.style.color = on ? 'var(--on-selected)' : 'var(--text-2)';
      }
      const ck = el.querySelector('[data-check]');
      if (ck) { ck.style.display = on ? 'block' : 'none'; ck.style.opacity = '1'; ck.style.transition = ''; }
    }
  }
  function setView(name) {
    view = name;
    styleTabs();
    applyNodesEmphasis();
    // the quantitative panel and the summary strip interpret CAPACITY, and Swarm
    // is the only lens that draws capacity, so they belong to it and to no other
    applyLensPanels();
  }
  // WHICH RAIL THE LENS SHOWS. Split out of setView and re-run from the frame:
  // the driver loads from <helmet>, before the template's own markup exists, so
  // the boot call found no panels and both rails kept their inline display:none
  // until the user happened to switch lenses. Idempotent and cheap.
  // 0..1 -> the rail content's own transition, derived from the same progress
  function lensRailMotion() {
    const fp = document.querySelector('[data-flow-panel]');
    const flows = opLens() === 'flows';
    if (fp) fp.style.display = flows ? 'flex' : 'none';
    const fb = document.querySelector('[data-flow-band]'); if (fb) fb.style.display = flows ? 'block' : 'none';
    const mp = document.querySelector('[data-map-panel]');
    const sp = document.querySelector('[data-cap-panel]');
    if (!mp || !sp) return;
    // FLOWS is a third reading of the SAME world: the rails and the globe stay,
    // only the supporting region changes to the resolution chain.
    if (flows) { mp.style.display = 'none'; sp.style.display = 'none'; return; }
    const m = lensMix;
    const show = (el, k) => {
      el.style.display = k > 0.001 ? 'flex' : 'none';
      if (k <= 0.001) return;
      const e = 1 - Math.pow(1 - k, 3);
      el.style.opacity = String(Math.max(0, Math.min(1, e * 1.35 - 0.35)));
      el.style.transform = 'translateY(' + ((1 - e) * -7).toFixed(2) + 'px)';
      el.style.willChange = 'transform';
    };
    show(mp, 1 - m);
    show(sp, m);
  }
  let chipRO = null, chipMore = null, chipTries = 0;
  let chipSig = '', chipBusy = false;
  function fitHeaderChips(force) {
    if (chipBusy) return;          // re-entry guard: the fit writes styles as it runs
    chipBusy = true;
    try { fitHeaderChipsInner(force); } finally { chipBusy = false; }
  }
  function fitHeaderChipsInner(force) {
    const strip = document.querySelector('[data-h-chips]');
    if (!strip) return;
    const sig = strip.clientWidth + '|' + strip.scrollWidth + '|' + strip.children.length + '|' +
      document.querySelectorAll('[data-node-chip][style*="none"]').length;
    if (!force && sig === chipSig) return;
    chipSig = sig;
    const chips = [...strip.querySelectorAll('[data-node-chip]')];
    if (!chips.length) return;
    // A strip with no width cannot be fitted: measuring now would hide every
    // chip and leave a bare "+11" over an empty row. Retry a bounded number of
    // times in case layout simply has not settled, then give up and take the
    // whole strip out — a counter with nothing to count is noise, not information.
    if (strip.clientWidth < 40) {
      chipSig = '';
      if (chipTries++ < 30) { setTimeout(() => fitHeaderChips(true), 32); return; }
      strip.style.display = 'none';
      if (chipMore) chipMore.style.display = 'none';
      return;
    }
    chipTries = 0;
    if (strip.style.display === 'none') strip.style.display = '';
    if (!chipRO && window.ResizeObserver) { /* installed below on first pass */ }
    if (!chipMore || !chipMore.isConnected) {
      chipMore = document.querySelector('[data-chip-more]');
      if (!chipMore) return;   // the template owns it; nothing to create
    }
    // measure against the row the strip actually has, with every chip laid out
    const gap = parseFloat(getComputedStyle(strip).gap) || 8;
    chipMore.style.display = 'none';
    for (const c of chips) c.style.display = 'inline-flex';
    const avail = strip.clientWidth - gap;
    let used = 0, shown = 0;
    const widths = chips.map(c => c.getBoundingClientRect().width);
    for (let i = 0; i < chips.length; i++) {
      const w = widths[i] + (i ? gap : 0);
      if (used + w > avail) break;
      used += w; shown++;
    }
    // if anything is hidden, the counter needs its own room — give it back a chip
    if (shown < chips.length) {
      chipMore.style.display = 'inline-flex';
      chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
      const mw = chipMore.getBoundingClientRect().width + gap * 2;
      while (shown > 0 && used + mw > avail) { used -= widths[shown - 1] + (shown > 1 ? gap : 0); shown--; }
      chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
      chipMore.title = chips.slice(shown).map(c => c.dataset.nodeChip).join(' · ');
    }
    for (let i = 0; i < chips.length; i++) chips[i].style.display = i < shown ? 'inline-flex' : 'none';
    // verify against the laid-out row, not the predicted one
    {
      const sb = strip.getBoundingClientRect();
      for (let i = shown - 1; i >= 0; i--) {
        const b = chips[i].getBoundingClientRect();
        if (b.right <= sb.right + 0.5 && b.left >= sb.left - 0.5) break;
        chips[i].style.display = 'none';
        shown = i;
      }
      if (shown < chips.length) {
        chipMore.style.display = 'inline-flex';
        chipMore.firstElementChild.textContent = '+' + (chips.length - shown);
        chipMore.title = chips.slice(shown).map(c => c.dataset.nodeChip).join(' · ');
      } else {
        chipMore.style.display = 'none';
      }
    }
    chipSig = strip.clientWidth + '|' + strip.scrollWidth + '|' + strip.children.length + '|' +
      document.querySelectorAll('[data-node-chip][style*="none"]').length;
    if (!chipRO && window.ResizeObserver) {
      let chipPending = false;
      chipRO = new ResizeObserver(() => {
        if (chipPending) return;
        chipPending = true;
        requestAnimationFrame(() => { chipPending = false; fitHeaderChips(true); });
      });
      chipRO.observe(strip);
      // a template re-render restores the chips without changing the strip's
      // width, so the resize observer never sees it — watch the subtree too
      new MutationObserver(() => {
        if (chipPending) return;
        chipPending = true;
        requestAnimationFrame(() => { chipPending = false; fitHeaderChips(true); });
      }).observe(strip, { childList: true });   // NOT attributes: the fit writes style itself
      if (window.customElements && customElements.whenDefined)
        customElements.whenDefined('md-assist-chip').then(() => setTimeout(fitHeaderChips, 60));
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => fitHeaderChips());
    }
  }
  // THEME. Both halves of the role layer move together; nothing else is touched, so
  // the particles, telemetry, camera, selection and lens carry straight through.
  function applyTheme(name) {
    if (!setTheme(name)) return;
    document.documentElement.setAttribute('data-theme', name);
    document.documentElement.classList.toggle('light', name === 'light');
    document.documentElement.classList.toggle('dark', name !== 'light');
    lastKey = '';                 // node cards repaint from the new roles
    asgKey = '';                  // engaged capacity re-derives its colours
    try { buildRoutes(); } catch (_) { }   // route colours come from the new table
    if (chipMore) { chipMore.remove(); chipMore = null; }
    const wb = document.querySelector('[data-m-wl]'); if (wb) delete wb.dataset.k;
    // rail rows are REPAINTED, never rebuilt: a rebuild would restart telemetry
    for (const el of document.querySelectorAll('[data-wlc]')) {
      const c = WL_COLORS[el.dataset.wlc];
      if (!c) continue;
      const hex = hexOf(c);
      if (el.tagName === 'I') el.style.background = hex; else el.style.color = hex;
    }
    try { styleTabs(); applyNodesEmphasis(); } catch (_) { }
  }
  if (typeof window !== 'undefined') {
    window.__ops = window.__ops || {};
    window.__setTheme = applyTheme;
  }
  let __delegated = false;
  function bindControls() {
    if (__delegated) return;
    __delegated = true;
    document.addEventListener('click', ev => {
      const t = ev.target;
      const v = t.closest && t.closest('[data-lens]');
      if (v && v.dataset.lens) { setView(v.dataset.lens); return; }
      const z = t.closest && t.closest('[data-zoom]');
      if (z) { setZoom(zoomT * (z.dataset.zoom === 'in' ? 1.9 : 1 / 1.9), true); return; }
      if (t.closest && t.closest('[data-theme-toggle]')) {
        applyTheme(themeName() === 'dark' ? 'light' : 'dark'); return;
      }
      const wc = t.closest && t.closest('[data-wl]');
      if (wc && !(t.closest('md-icon-button') || t.closest('md-assist-chip') || t.closest('button'))) {
        activateWorkloadCard(wc); return;
      }
      const nc = t.closest && t.closest('[data-node]');
      if (nc && !(t.closest('md-icon-button') || t.closest('md-assist-chip') || t.closest('button'))) {
        activateNodeCard(nc); return;
      }
      const f = t.closest && t.closest('[data-fit]');
      if (f) { computeFitFrame(); fit = true; drag = null; vyaw = 0; vpitch = 0;
        distT = FIT_DIST; manualHold = 0; focusId = null; zoomT = 1; }
    });
  }
  function bindThemeToggle() {
    const el = document.querySelector('[data-theme-toggle]');
    if (!el || el.dataset.bound) return;
    el.dataset.bound = '1';
    // click is handled by the delegate in bindControls — binding it here too made
    // every click flip the theme twice. Only the keys the delegate cannot see.
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        applyTheme(themeName() === 'dark' ? 'light' : 'dark');
      }
    });
  }
  let lastOpLens = '';
  function applyLensPanels() {
    // FLOWS reads the resolved state, so it needs the routes on the world: entering
    // it settles the world on the map reading. Camera, zoom and orientation are
    // untouched, exactly as with the other two lenses.
    const ol = opLens();
    if (ol !== lastOpLens) {
      lastOpLens = ol;
      if (ol === 'flows' && view !== 'map') setView('map');
    }
    const sw = view === 'swarm';
    const lg = $('[data-legend]'); if (lg) lg.style.display = 'none';
    // display is owned by lensRailMotion so a panel can be mid-transition; this
    // only keeps the traffic rail's contents current before it becomes visible
    if (!sw) fillTrafficRail();
    fillFlowPanel();
    lensRailMotion();
    const st = $('[data-strip]'); if (st) st.style.display = (sw && DEV_MODE) ? 'flex' : 'none';
    const ss = $('[data-swarm-state]'); if (ss) ss.style.display = sw ? 'flex' : 'none';
    const wc = $('[data-wl-card]'); if (wc) wc.style.display = 'none';
    // the persistent region shortcut row is gone from the product UI (the wrapper
    // stays as an empty hook); focusRegion() itself is untouched
    const rg = $('[data-regions]'); if (rg) rg.style.display = 'none';
  }
  let railTab = 'nodes';
  function styleRail() {
    for (const el of document.querySelectorAll('[data-rail]')) {
      const on = el.dataset.rail === railTab;
      const lab = el.querySelector('[data-rail-label]');
      if (lab && lab.parentElement) lab.parentElement.style.color = on ? T.primaryInk : T.ink2;
      const ind = el.querySelector('[data-rail-ind]');
      if (ind) ind.style.display = on ? 'block' : 'none';
    }
  }
  function applyNodesEmphasis() {
    // THE RAIL IS THE INVENTORY, AND EVERY CARD READS THE SAME. The Nodes / Stats
    // tabs are gone: a rail that switches between a compact list and a detailed one
    // asked the user to choose a density instead of just showing the inventory, and
    // mixed card heights are harder to scan than a uniform column that scrolls.
    const on = true;
    for (const el of document.querySelectorAll('[data-stats]')) el.style.display = on ? 'flex' : 'none';
    for (const el of document.querySelectorAll('[data-compact]')) el.style.display = on ? 'none' : 'flex';
    for (const t of document.querySelectorAll('[data-tele]')) t.style.display = on ? 'block' : 'none';
    for (const c of document.querySelectorAll('[data-node]')) {
      c.style.background = '';
    }
  }

  // ---- camera: drag rotate + inertia, wheel = constrained zoom, in EVERY lens --
  let drag = null, manualHold = 0, vyaw = 0, vpitch = 0, distT = cam.dist, fit = false;
  // FIT ALL = THE APPROVED OPERATIONAL FRAME, identical in Map and Swarm.
  // Reviewed and locked from the live view: a squarely-faced transatlantic globe
  // (yaw 0.1075, pitch 0.0332) at the flat lens distance, zoom 1. Ohio sits left
  // with YOU beside it, Europe right, the routed arc across the upper third and a
  // substantial globe below. Earlier passes derived this from the node centroid;
  // the derivation kept fighting the composition (too polar, or clusters on the
  // rim), so the reviewed frame is the definition now. Constant means the button
  // is trustworthy: same frame every press, in either lens, whatever the user was
  // looking at. The node-spread figure is still measured, as a review hook only.
  const FIT_YAW = 0.1075, FIT_PITCH = 0.0332;
  let fitYaw = FIT_YAW, fitPitch = FIT_PITCH;
  function computeFitFrame() {
    fitYaw = FIT_YAW; fitPitch = FIT_PITCH;
    if (typeof window !== 'undefined') {
      const cx = -Math.sin(fitYaw) * Math.cos(fitPitch), cy = -Math.sin(fitPitch), cz = -Math.cos(fitYaw) * Math.cos(fitPitch);
      let worst = 0;
      for (const m of nodeMarks) {
        const d = Math.max(-1, Math.min(1, m.u[0] * cx + m.u[1] * cy + m.u[2] * cz));
        worst = Math.max(worst, Math.sin(Math.acos(d)));
      }
      window.__fitDbg = { yaw: fitYaw, pitch: fitPitch, dist: FIT_DIST, worstNodeRadiusFrac: +worst.toFixed(3), nodes: nodeMarks.length };
    }
  }
  // real magnification, independent of dist: 1 = fit-all, 9 = street scale
  const ZMIN = 0.95, ZMAX = 44;
  let zoom = 1, zoomT = 1, focusId = null, focusHold = 0, aimHold = 0;
  const scaleName = z => z < 1.8 ? 'GLOBAL' : z < 6 ? 'REGIONAL' : 'LOCAL';
  function setZoom(v, keepFocus) {
    zoomT = Math.max(ZMIN, Math.min(ZMAX, v));
    fit = false; manualHold = 30;
    if (!keepFocus && zoomT < 1.5) focusId = null;
  }
  function focusRegion(id, z) {
    if (!REG[id]) return;    focusId = id; fit = false; focusHold = 1;
    drag = null; vyaw = 0; vpitch = 0;
    zoomT = Math.max(ZMIN, Math.min(ZMAX, z ?? 3.4));
  }
  function attachCanvas() {
  canvas.style.touchAction = 'none';
  canvas.onpointerdown = e => {
    drag = { x: e.clientX, y: e.clientY, yaw: cam.yaw, pitch: cam.pitch, t: performance.now(), px: e.clientX, py: e.clientY };
    vyaw = 0; vpitch = 0; fit = false; focusId = null;
    try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
  };
  canvas.onpointerup = e => { drag = null; try { canvas.releasePointerCapture(e.pointerId); } catch (_) { } };
  canvas.onpointermove = e => {
    if (!drag) return;
    manualHold = 30;                    // the lean waits until you are done
    const now = performance.now(), dts = Math.max(0.008, (now - drag.t) / 1000);
    cam.yaw = drag.yaw - (e.clientX - drag.x) * 0.006;
    cam.pitch = Math.max(-0.9, Math.min(0.9, drag.pitch + (e.clientY - drag.y) * 0.005));
    vyaw = -(e.clientX - drag.px) * 0.006 / dts;
    vpitch = (e.clientY - drag.py) * 0.005 / dts;
    drag.t = now; drag.px = e.clientX; drag.py = e.clientY;
  };
  // CURSOR ZOOM = THE CLICK BEHAVIOUR. A wheel-in does exactly what clicking a
  // region does: the thing nearest the cursor is taken as the focus, the world
  // turns to face it and it settles in the CENTRE of the panel while the
  // magnification rises. Same camera in Map, Node stats and Swarm, so the
  // gesture reads identically in every lens. Zooming back out releases the
  // focus once the reading returns to GLOBAL, which restores the wide framing.
  function pickUnderCursor(mx, my) {
    const f = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
    const r = [Math.cos(cam.yaw), 0, -Math.sin(cam.yaw)];
    const u = [-Math.sin(cam.yaw) * Math.sin(cam.pitch), Math.cos(cam.pitch), -Math.cos(cam.yaw) * Math.sin(cam.pitch)];
    const dx = (mx - W * 0.5) / cam.fov, dy = (H * 0.5 - my) / cam.fov;
    const D = [f[0] + r[0] * dx + u[0] * dy, f[1] + r[1] * dx + u[1] * dy, f[2] + r[2] * dx + u[2] * dy];
    const O = [-f[0] * cam.dist, -f[1] * cam.dist, -f[2] * cam.dist];
    const a = D[0] * D[0] + D[1] * D[1] + D[2] * D[2];
    const b = 2 * (O[0] * D[0] + O[1] * D[1] + O[2] * D[2]);
    const c = O[0] * O[0] + O[1] * O[1] + O[2] * O[2] - SR * SR;
    const disc = b * b - 4 * a * c;
    // a miss (outside the limb) still gives a direction: the closest point on
    // the ray, projected onto the sphere, so zooming near the rim behaves
    const t = disc >= 0 ? (-b - Math.sqrt(disc)) / (2 * a) : -b / (2 * a);
    const P = [O[0] + D[0] * t, O[1] + D[1] * t, O[2] + D[2] * t];
    const L = Math.hypot(P[0], P[1], P[2]) || 1;
    return [P[0] / L, P[1] / L, P[2] / L];
  }
  // the closest region to a direction on the sphere — the region OWNS its nodes,
  // so focusing it is what brings that group of nodes to the centre
  function nearestRegion(p) {
    let best = null, bd = -2;
    for (const rg of REGIONS) {
      const d = rg.u[0] * p[0] + rg.u[1] * p[1] + rg.u[2] * p[2];
      if (d > bd) { bd = d; best = rg.id; }
    }
    return best;
  }
  canvas.onwheel = e => {
    e.preventDefault();
    const step = -e.deltaY * 0.0026;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top - 16;   // the world sits 16px down
    setZoom(zoomT * Math.exp(step), true);
    if (step > 0) {
      const id = nearestRegion(pickUnderCursor(mx, my));
      if (id) {
        focusId = id; focusHold = 1;
        drag = null; vyaw = 0; vpitch = 0; fit = false; aimHold = 0;
      }
    } else if (zoomT < 1.5) {
      focusId = null;                            // back at GLOBAL: the wide framing
    }
    manualHold = Math.max(manualHold, 30);
  };
  // click a region mark to descend the scales onto it
  canvas.onclick = e => {
    const r = canvas.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top - 16;
    let bi = null, bd = 34 * 34;
    for (const rg of REGIONS) {
      const u = rg.u;
      const f2 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
      if (-(u[0] * f2[0] + u[1] * f2[1] + u[2] * f2[2]) < 0.05) continue;
      const o = core.project(cam, rg.p[0], rg.p[1], rg.p[2], W, H, new Float32Array(4));
      const dd = (o[0] - mx) * (o[0] - mx) + (o[1] - my) * (o[1] - my);
      if (dd < bd) { bd = dd; bi = rg.id; }
    }
    if (bi) focusRegion(bi, focusId !== bi ? 3.4 : zoom < 2.4 ? 3.4 : zoom < 8 ? 24 : 1.1);
  };
  }
  attachCanvas();

  // ---- workload allocation + route identity --------------------------------------
  function activeWorkloads() {
    return F.fixture === 'MULTI-REGION ACTIVE' ? scopedWorkloads() : (WL_BY_FIXTURE[F.fixture] || []);
  }


  // ---- WORKLOAD -> CAPACITY ASSIGNMENT --------------------------------------------
  // P0: resolved ONCE per fixture, never inside the animation loop, and never
  // from array order, randomness or particle position. A workload's slots are
  // read from the review fixture's explicit [node, slotIndex] addresses; where a
  // diagnostic fixture states only counts, the slots are taken in the capacity
  // model's own permanent ownership order — still deterministic, still stable
  // across frames and reloads.
  //
  // Each cohort also gets a PERSISTENT SEMANTIC ANCHOR: a fixed direction on the
  // world derived once from the infrastructure its slots live on (its region,
  // offset by a deterministic angle so two cohorts in one region separate). The
  // anchor rotates with the globe, and it does NOT move when particles move — so
  // the workload label has nothing to jitter against.
  let asg = null, asgKey = '';
  function assign() {
    const N = F.sim.N;
    const key = F.fixture + '|' + Object.values(F.usedByRegion()).join(',');
    if (asg && key === asgKey) return asg;
    asgKey = key;
    const wlc = new Int16Array(N * 3).fill(-1);
    const cohorts = [];
    const regionColor = {};
    const table = F.slotTable ? F.slotTable() : null;
    const list = activeWorkloads();
    if (table && list.length) {
      // the slot's permanent address: [node, index within that node]
      const perNode = {};
      const byAddr = {};
      for (const s of table) {
        const k = (perNode[s.node] = (perNode[s.node] ?? -1) + 1);
        byAddr[s.node + '#' + k] = s;
      }
      const used = table.filter(s => s.used);
      const taken = new Set();
      let si = 0;
      const perRegion = {};
      for (const w of list) {
        const co = { id: w.id || w.name, name: w.name, color: WL_COLORS[w.c] || [159, 176, 170], slots: w.slots, parts: [], rids: {} };
        const mine = [];
        if (w.at) {
          for (const [node, idx] of w.at) {
            const s = byAddr[node + '#' + idx];
            if (s && s.used && !taken.has(s.id)) mine.push(s);
          }
        }
        while (mine.length < w.slots && si < used.length) {   // count-only fixtures
          const s = used[si++];
          if (!taken.has(s.id) && !mine.includes(s)) mine.push(s);
        }
        co.nodes = [];
        for (const s of mine) {
          taken.add(s.id);
          co.rids[s.region] = (co.rids[s.region] || 0) + 1;
          const nd = REVIEW_FIXTURE.nodeIds[s.node];
          if (nd && !co.nodes.includes(nd)) co.nodes.push(nd);
          for (const i of s.ids) {
            co.parts.push(i);
            const o = i * 3;
            wlc[o] = co.color[0]; wlc[o + 1] = co.color[1]; wlc[o + 2] = co.color[2];
          }
          const tally = regionColor[s.region] || (regionColor[s.region] = {});
          tally[w.c] = (tally[w.c] || 0) + 1;
        }
        if (!co.parts.length) continue;
        // DERIVED PHYSICAL FOOTPRINTS. One workload record, but its capacity may
        // live in several regions; each footprint states where that capacity
        // actually is. Nothing downstream may relocate it.
        co.footprints = [];
        {
          const byReg = {};
          for (const s of mine) {
            const fp = byReg[s.region] || (byReg[s.region] = { regionId: s.region, slots: 0, nodeIds: [], particleIds: [] });
            fp.slots++;
            const nd2 = REVIEW_FIXTURE.nodeIds[s.node];
            if (nd2 && !fp.nodeIds.includes(nd2)) fp.nodeIds.push(nd2);
            for (const i of s.ids) fp.particleIds.push(i);
          }
          co.footprints = Object.values(byReg);
        }
        // the cohort's DOMINANT region: metadata only — a reading of where most
        // of its capacity sits. It is never used to move particles or to gather
        // distributed capacity into one place.
        let home = null, hv = -1;
        for (const rid in co.rids) if (co.rids[rid] > hv) { hv = co.rids[rid]; home = rid; }
        co.region = home;
        const k = (perRegion[home] = (perRegion[home] || 0));
        perRegion[home] = k + 1;
        co.slotInRegion = k;
        cohorts.push(co);
      }
      // one persistent anchor per workload FOOTPRINT. The field stations each
      // footprint in the region that actually owns its capacity (see
      // setCohortStations); the label anchors on the workload's primary
      // footprint, and every footprint carries the same workload colour.
      const centres = F.setCohortStations ? F.setCohortStations(cohorts) : {};
      const spread = {};
      for (const co of cohorts) spread[co.region] = (spread[co.region] || 0) + 1;
      for (const co of cohorts) {
        if (centres[co.id]) { co.anchor = centres[co.id]; continue; }
        const rg = REG[co.region];
        if (!rg) { co.anchor = [0, 1, 0]; continue; }
        const u = rg.u;
        let e1 = [u[1], -u[0], 0];
        let L = Math.hypot(e1[0], e1[1], e1[2]);
        if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
        e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
        const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
        const n = Math.max(1, spread[co.region]);
        const th = n === 1 ? 0 : 0.13;                       // arc offset, radians
        const ph = (co.slotInRegion / n) * 6.2832 + 0.7;
        const ct = Math.cos(th), st = Math.sin(th);
        const a0 = [
          u[0] * ct + (e1[0] * Math.cos(ph) + e2[0] * Math.sin(ph)) * st,
          u[1] * ct + (e1[1] * Math.cos(ph) + e2[1] * Math.sin(ph)) * st,
          u[2] * ct + (e1[2] * Math.cos(ph) + e2[2] * Math.sin(ph)) * st
        ];
        const al = Math.hypot(a0[0], a0[1], a0[2]) || 1;
        co.anchor = [a0[0] / al, a0[1] / al, a0[2] / al];
      }
    }
    const domByRegion = {};
    for (const rid in regionColor) {
      let bk = null, bv = -1;
      for (const k in regionColor[rid]) if (regionColor[rid][k] > bv) { bv = regionColor[rid][k]; bk = k; }
      if (bk) domByRegion[rid] = WL_COLORS[bk] || [159, 176, 170];
    }
    asg = { wlc, cohorts, domByRegion };
    return asg;
  }

  // ---- fixtures (diagnostics, not product states) -------------------------------
  let paused = false, timeScale = 1;
  function setFixture(name, fromClick) {
    if (!FIXTURES[name]) return;
    F.fixture = name;
    F.setLevels(FIXTURES[name]);
    if (name === 'MULTI-REGION ACTIVE' && F.setUsedSlotAddresses) {
      // the review state names its slots; every other fixture is a count-based
      // diagnostic and keeps the model's own ordering
      const addrs = [];
      for (const w of scopedWorkloads()) for (const a of (w.at || [])) addrs.push(a);
      F.setUsedSlotAddresses(addrs);
    } else {
      F.setSlots(SLOTS_TOTAL, SLOTS_USED[name] || {});
    }
    asgKey = '';
    buildRoutes();
    const wb = $('[data-m-wl]'); if (wb) delete wb.dataset.k;
    // a regional fixture is a statement about capacity behaviour: show the lens
    // that reads it, without touching the camera (same world, same orientation)
    if (fromClick) {
      const lv = FIXTURES[name];
      let pick = null, ax = 0, ay = 0, az = 0, tot = 0;
      for (const id in lv) {
        if (lv[id] <= 0.2) continue;
        if (!pick || lv[id] > lv[pick]) pick = id;
        const u = REG[id].u, w = lv[id];
        ax += u[0] * w; ay += u[1] * w; az += u[2] * w; tot += w;
      }
      if (pick) {
        if (view !== 'swarm') setView('swarm');
        // the activity centroid, so every coordinating region stays in frame
        const l = Math.hypot(ax, ay, az) || 1;
        const cx = ax / l, cy = ay / l, cz = az / l;
        cam.yawT = Math.atan2(-cx, -cz);
        cam.pitchT = Math.asin(Math.max(-1, Math.min(1, -cy)));
        aimHold = 1.6;
        drag = null; vyaw = 0; vpitch = 0; fit = false;
      }
    }
    for (const el of document.querySelectorAll('[data-fx]')) {
      const on = el.dataset.fx === name;
      el.style.color = on ? T.primaryInk : T.text2;
      el.style.borderColor = on ? rgbaT('primary', .5) : T.border;
    }
  }
  // ---- node cards -----------------------------------------------------------------
  let lastKey = '';
  function syncUI() {
    const S = F.state();
    const used = F.usedByRegion();
    const key = Object.values(used).join('|') + '|' + F.fixture + '|' + view;
    if (key !== lastKey) {
      lastKey = key;
      for (const [rid, ids] of Object.entries(NODES_BY_REGION)) {
        const busy = (used[rid] || 0) > 0;
        for (const id of ids) {
          const card = document.querySelector(`[data-node="${id}"]`);
          const name = card && card.querySelector('[data-node-name]');
          const stat = document.querySelector(`[data-rate="${id}"]`);
          if (!card) continue;
          if (busy) card.dataset.serving = '1'; else delete card.dataset.serving;
          if (card.style.background) card.style.background = '';
          if (name) name.style.color = T.text1;
          if (stat) {
            // the rate is the first thing to go when the rail is narrow: a
            // clipped "e…" says nothing, so it is shown only when it fits whole
            const room = stat.parentElement ? stat.parentElement.clientWidth : 0;
            const fits = room >= 300;
            stat.textContent = (busy && fits) ? 'engaged' : '';
            const sep = stat.previousElementSibling;
            if (sep && sep.tagName === 'I') sep.style.display = (busy && fits) ? 'block' : 'none';
          }
        }
      }
      // P0 DATA BINDING: the card's workload identity comes from the SAME source
      // as the Active Workloads legend — the review fixture — never from static
      // markup. Name and dot show the largest active workload; with no active
      // workload the card carries no invented identity.
      {
        const co = assign().cohorts.slice().sort((p, q) => q.slots - p.slots)[0];
        const nm = $('[data-wl-name]'), dt = $('[data-wl-dot]'), card = $('[data-wl-card]');
        if (nm) nm.textContent = co ? 'workload · ' + co.name.toLowerCase() : 'no active workload';
        if (dt) dt.style.background = co ? hexOf(co.color) : T.ink2;
        // the floating caption is retired: the right rail carries this reading now
        if (card) card.style.display = 'none';
      }
      const busy = Object.keys(used).filter(id => used[id] > 0).map(id => REG[id].label.split(' · ')[0]);
      $('[data-wl-status]').textContent = busy.length
        ? 'adaptive · engaging ' + busy.join(', ')
        : 'adaptive · distributed';
      const fxc = $('[data-fx-chip]'); if (fxc) fxc.textContent = F.fixture;
      // the node badge is the file's own Material 3 component; its label is a prop
      // on the mount, so the count is written to the mount, not into its markup
      // the badge is the file's own Material 3 component, mounted from the bundle;
      // its label element is the only thing the driver touches, so the count stays
      // real fixture data instead of a number typed into the markup
      const nc = $('[data-nodes-head] .sc-host-x span');
      if (nc) {
        // the badge counts what the collection SHOWS, so it can never disagree with
        // the cards under it (supersedes the 2026-08-31 collection-total note)
        const n = String(SCOPE ? SCOPE.nodes.size : F.ownership().network.nodes);
        if (nc.textContent !== n) nc.textContent = n;
      }
    }
    const sc = $('[data-scale]');
    if (sc) {
      sc.textContent = scaleName(zoom) + (focusId ? ' · ' + (REG[focusId].label || focusId) : '');
      sc.style.color = zoom > 1.5 ? T.textHi : T.text2;
    }
    for (const el of document.querySelectorAll('[data-focus]')) {
      const on = el.dataset.focus === focusId;
      el.style.color = on ? T.primaryInk : T.text2;
      el.style.borderColor = on ? rgbaT('primary', .5) : T.border;
    }
    syncPanels(S);
    // The rails are filled from the frame, not only on a lens switch: the driver
    // boots from <helmet>, before the template's own markup exists, so the very
    // first fill finds no container. Both fills self-guard on a key, so this costs
    // one property read per frame once they are populated.
    applyLensPanels();
    applyNodesEmphasis();
    if (view !== 'swarm') { fillTrafficRail(); updateTrafficNumbers(); drawThroughputSpark(performance.now()); }

    const dbg = $('[data-dbg]');
    if (dbg && dbg.style.display !== 'none') {
      dbg.textContent = 'prototype simulation values (not product metrics) — '
        + `capacityParticipation ${S.capacityParticipation.toFixed(2)} · `
        + `crowding engaged ${S.crowding.toFixed(1)} vs field ${S.crowdingAll.toFixed(1)} · `
        + `heading change ${S.turnEngaged.toFixed(2)} vs ${S.turnResting.toFixed(2)} rad/s · `
        + S.regions.filter(r => r.activityLevel > 0.05)
          .map(r => `${r.id} activity ${r.activityLevel.toFixed(2)} coherence ${r.coherence.toFixed(2)} spread ${r.spread.toFixed(2)}`)
          .join(' · ');
    }
  }

  // ---- DRIVER-OWNED ROW SLOTS ---------------------------------------------------
  // A rail container may already carry placeholder rows from the template. Wiping
  // it with textContent='' detaches nodes the template's renderer still owns, and
  // its next reconcile then fails to remove them — which took the whole view down
  // in a render-error loop. So the driver never touches the template's children:
  // it appends ONE slot of its own and rewrites only that, hiding the placeholder
  // rows it supersedes.
  function rowSlot(box) {
    let slot = null;
    for (const el of box.children) if (el.hasAttribute && el.hasAttribute('data-driver-rows')) { slot = el; break; }
    if (!slot) {
      slot = document.createElement('div');
      slot.setAttribute('data-driver-rows', '');
      slot.style.cssText = 'display:flex;flex-direction:column;';
      box.appendChild(slot);
    }
    for (const el of box.children) if (el !== slot) el.style.display = 'none';
    const g = getComputedStyle(box).rowGap;      // inherit the rail's own spacing
    slot.style.gap = (g && g !== 'normal') ? g : '16px';
    slot.textContent = '';
    return slot;
  }

  // ---- the quantitative legend ----------------------------------------------------
  // The right-hand panel and the strip under the world are the SAME numbers at two
  // densities: the strip is the immediate summary, the panel is the detail plus the
  // workload legend. Both read F.slots and the fixture's own workload table, so no
  // two readouts in the frame can disagree. No simulation value reaches either.
  function syncPanels(S) {
    const s = scopedSlots();
    const own = F.ownership();
    const list = activeWorkloads();
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    set('[data-m-cap]', String(s.total));
    set('[data-m-nodes]', String(s.nodes));
    set('[data-m-used]', String(s.usedPct));
    set('[data-m-usedn]', String(s.used));
    set('[data-m-free]', String(s.free));
    // the indicator is the Figma artwork at its own 340x12 scale: the active wave
    // is clipped at the used fraction, and the track picks up 6px after it
    {
      // flat indicator: active bar, 6px gap, track running to the stop at x=334
      const act = $('[data-bar-active]'), track = $('[data-bar-track]');
      const span = 336 - 2;                       // 2px padding, stop excluded
      const aw = Math.max(0, Math.min(span, (s.usedPct / 100) * span));
      if (act && act.getAttribute('width') !== String(aw)) act.setAttribute('width', String(aw));
      if (track) {
        const x = Math.min(330, 2 + aw + 6), w = Math.max(0, 330 - x);
        if (track.getAttribute('x') !== String(x)) { track.setAttribute('x', String(x)); track.setAttribute('width', String(w)); }
      }
    }
    const box = $('[data-m-wl]');
    if (box && box.dataset.k !== F.fixture + '|' + scopeKey) {
      box.dataset.k = F.fixture + '|' + scopeKey;
      const slot = rowSlot(box);
      // ACTIVE means it holds capacity in this snapshot. A workload with 0 slots
      // stays in the fixture (it exists in the review state) but it is not active,
      // so it is not listed here.
      const active = list.filter(w => w.slots > 0);
      if (!active.length) {
        const d0 = document.createElement('div');
        d0.style.cssText = 'color:' + T.text3 + ';font-size:10.5px;';
        d0.textContent = 'none · all capacity free';
        slot.appendChild(d0);
      }
      for (const w of active) {
        const c = { name: w.name, wlc: w.c, color: WL_COLORS[w.c] || [159, 176, 170] };
        const FS = "'Source Sans 3',sans-serif";
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;flex-direction:row;align-items:flex-start;gap:24px;min-height:14px;';
        const nm = document.createElement('span');
        nm.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;flex:1 1 auto;min-width:0;';
        const dot = document.createElement('i');
        dot.dataset.wlc = c.wlc || '';
        dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(c.color) + ';';
        const nmT = document.createElement('span');
        nmT.setAttribute('data-wl-label','');
        // owner 2026-09-01: colour lives in the DOT only; the label stays neutral
        nmT.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:' + T.text1 + ';';
        nmT.textContent = c.name;
        nm.appendChild(dot); nm.appendChild(nmT);
        const q = document.createElement('span');
        q.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:16px;flex:0 0 auto;';
        const numCss = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);text-align:right;color:' + T.ink2 + ';font-variant-numeric:tabular-nums;';
        const qs = document.createElement('span');
        qs.style.cssText = numCss;
        qs.textContent = String(w.slots);
        const sep = document.createElement('i');
        sep.style.cssText = 'width:2px;height:2px;border-radius:50%;background:' + T.ink2 + ';flex:0 0 auto;';
        const qp = document.createElement('span');
        qp.style.cssText = numCss;
        qp.textContent = (w.pct ?? Math.round(w.slots / s.total * 100)) + '%';
        q.appendChild(qs); q.appendChild(sep); q.appendChild(qp);
        row.appendChild(nm); row.appendChild(q);
        slot.appendChild(row);
      }
    }
  }

  // ---- bottom swarm micro-metrics ---------------------------------------------
  // The strip is the ORIGINAL prototype's instrument line, not a dashboard:
  // RELEASE (a discrete behavioural state over five ticks), Cₐ(t) (the MOST
  // ACTIVE REGION's measured coherence — a regional coordination signal, not a
  // per-workload cohort measure, and named that way here so the code stops
  // claiming otherwise) and Nₐ/N (engaged-to-total capacity, as a segmented
  // micro-bar). All three are read from the model; none are quantities the HUD
  // already prints.
  const REL_NAMES = ['DISTRIBUTED', 'ENGAGING', 'COORDINATING', 'STEADY', 'RELEASE'];
  const caBuf = new Float32Array(96);
  let caLen = 0, caAcc = 1, sparkEl = null, sparkCtx = null;
  function syncStrip(dtRaw) {
    const st = $('[data-swarm-state]');
    if (!st || st.style.display === 'none') return;
    const s = F.slots;
    // Cₐ(t) = the coherence of the ENGAGED capacity: every region that actually
    // holds used slots, weighted by how much of the engaged capacity it holds.
    // (It used to report the single most active region's coherence and call it a
    // cohort measure; that claim is gone — this is the engaged aggregate.)
    const usedBy = F.usedByRegion ? F.usedByRegion() : {};
    let cw = 0, cs = 0;
    for (const r of F.regions) {
      const wgt = usedBy[r.id] || 0;
      if (wgt > 0) { cs += Math.max(0, Math.min(1, r.coherence)) * wgt; cw += wgt; }
    }
    let ca = cw ? cs / cw : 0;
    if (!cw) { // nothing engaged: fall back to the field's resting coherence
      let n = 0, acc = 0;
      for (const r of F.regions) { acc += Math.max(0, Math.min(1, r.coherence)); n++; }
      ca = n ? acc / n : 0;
    }
    let eSum = 0, eN = 0;
    for (let i = 0; i < F.sim.N; i++) if (F.alloc[i]) { eSum += F.sim.eng[i]; eN++; }
    const engMean = eN ? eSum / eN : 0;
    let rel;
    if (!s.used && engMean < 0.15) rel = 0;
    else if (!s.used) rel = 4;
    else if (engMean < 0.6) rel = 1;
    else rel = ca > 0.55 ? 3 : 2;
    const rn = $('[data-rel-name]');
    if (rn && rn.textContent !== REL_NAMES[rel]) rn.textContent = REL_NAMES[rel];
    const dots = document.querySelectorAll('[data-rel-dots] i');
    for (let i = 0; i < dots.length; i++) {
      const bg = i === rel ? T.text1 : i < rel ? T.barOn : T.barOff;
      if (dots[i].dataset.on !== bg) { dots[i].dataset.on = bg; dots[i].style.background = bg; }
    }
    const cv = $('[data-ca]');
    if (cv) { const t2 = ca.toFixed(2); if (cv.textContent !== t2) cv.textContent = t2; }
    caAcc += dtRaw;
    if (caAcc < 0.25) return;
    caAcc = 0;
    if (caLen < caBuf.length) caBuf[caLen++] = ca;
    else { caBuf.copyWithin(0, 1); caBuf[caBuf.length - 1] = ca; }
    const el = $('[data-spark]');
    if (!el) return;
    if (el !== sparkEl) { sparkEl = el; sparkCtx = el.getContext('2d'); }
    { const r0 = el.getBoundingClientRect();
      const d0 = Math.min(2, window.devicePixelRatio || 1);
      const ww = Math.round(r0.width * d0), hhh = Math.round(r0.height * d0);
      if (ww && (el.width !== ww || el.height !== hhh)) { el.width = ww; el.height = hhh; } }
    const w2 = el.width, h2 = el.height;
    sparkCtx.clearRect(0, 0, w2, h2);
    sparkCtx.strokeStyle = T.telemetry;
    sparkCtx.lineWidth = (window.devicePixelRatio || 1) * 1.5;   // 1.5 CSS px — owner 2026-09-01: every telemetry line
    sparkCtx.lineJoin = 'round'; sparkCtx.lineCap = 'round';
    sparkCtx.beginPath();
    for (let i = 0; i < caLen; i++) {
      const x2 = (i / (caBuf.length - 1)) * (w2 - 2) + 1;
      const y2 = h2 - 2 - caBuf[i] * (h2 - 4);
      i ? sparkCtx.lineTo(x2, y2) : sparkCtx.moveTo(x2, y2);
    }
    sparkCtx.stroke();
    if (caLen) {
      const x2 = ((caLen - 1) / (caBuf.length - 1)) * (w2 - 2) + 1;
      const y2 = h2 - 2 - caBuf[caLen - 1] * (h2 - 4);
      sparkCtx.fillStyle = T.telemetryHi;
      sparkCtx.fillRect(x2 - 1.2, y2 - 1.2, 2.4, 2.4);
    }
  }

  // ---- controls (re-hooked after any template remount) ------------------------------
  function hookControls() {
    // PRODUCT MODE IS THE DEFAULT. The prototype harness — diagnostic fixtures,
    // pause/speed, tuning sliders, the sim-values readout and the experimental
    // bottom instrument strip — stays in the code (it is still how the model gets
    // tested) but never appears in the product surface. Everything the harness owns
    // carries data-dev-only; the strip is handled in setView. Flip DEV_MODE to true
    // in source to get the harness back. There is deliberately no in-product toggle.
    for (const el of document.querySelectorAll('[data-dev-only]')) el.style.display = DEV_MODE ? 'flex' : 'none';
    tabEls = [...document.querySelectorAll('[data-lens]')];
    for (const el of tabEls) el.onclick = () => setView(el.dataset.lens);
    for (const el of document.querySelectorAll('[data-rail]'))
      el.onclick = () => { railTab = el.dataset.rail; styleRail(); applyNodesEmphasis(); };
    styleRail();
    const fb = $('[data-fit]');
    if (fb) fb.onclick = () => {
      computeFitFrame();
      fit = true; drag = null; vyaw = 0; vpitch = 0;
      distT = FIT_DIST; manualHold = 0; focusId = null; zoomT = 1;
    };
    for (const el of document.querySelectorAll('[data-zoom]'))
      el.onclick = () => setZoom(zoomT * (el.dataset.zoom === 'in' ? 1.9 : 1 / 1.9), true);
    for (const el of document.querySelectorAll('[data-focus]'))
      el.onclick = () => focusRegion(el.dataset.focus,
        el.dataset.focus !== focusId ? 3.4 : zoom < 2.4 ? 3.4 : zoom < 8 ? 24 : 1.1);
    for (const el of document.querySelectorAll('[data-fx]'))
      el.onclick = () => setFixture(el.dataset.fx, true);
    const pb = $('[data-pause]');
    if (pb) pb.onclick = e => { paused = !paused; e.target.textContent = paused ? 'Play' : 'Pause'; };
    const sb = $('[data-slow]');
    if (sb) sb.onclick = e => {
      timeScale = timeScale === 1 ? 0.25 : 1;
      e.target.style.color = timeScale !== 1 ? T.primaryInk : T.text2;
      e.target.style.borderColor = timeScale !== 1 ? rgbaT('primary', .5) : T.border;
    };
    const db = $('[data-debug]');
    if (db) db.onclick = e => {
      const d = $('[data-dbg]');
      const show = d.style.display === 'none';
      d.style.display = show ? 'block' : 'none';
      e.target.style.color = show ? T.primaryInk : T.text2;
      e.target.style.borderColor = show ? rgbaT('primary', .5) : T.border;
    };
    const tf = $('[data-tn-flow]');
    if (tf) tf.oninput = e => { F.tune.flow = parseFloat(e.target.value); };
    const tc = $('[data-tn-chroma]');
    if (tc) tc.oninput = e => { F.tune.chroma = parseFloat(e.target.value); };
  }
  hookControls();

  // the DC template can remount on a hot edit: reacquire the canvas and every
  // hook, restore lens/fixture styling, keep the world and camera untouched
  function rewire() {
    const c = document.querySelector('[data-stage]');
    if (!c || !c.parentElement) return false;
    canvas = c;
    attachCanvas();
    hookControls();
    bind();
    styleTabs();
    applyNodesEmphasis();
    setFixture(F.fixture);
    setView(view);
    const wb2 = $('[data-m-wl]'); if (wb2) delete wb2.dataset.k;
    const pb = $('[data-pause]'); if (pb) pb.textContent = paused ? 'Play' : 'Pause';
    const tf = $('[data-tn-flow]'); if (tf) tf.value = F.tune.flow;
    const tc = $('[data-tn-chroma]'); if (tc) tc.value = F.tune.chroma;
    lastKey = '';
    return true;
  }

  // ---- MAP RAIL: network traffic -----------------------------------------------
  // Origin, total throughput, target count and the per-workload split, all read
  // from REVIEW_FIXTURE. The tok/s figures are PROTOTYPE FIXTURE values (review
  // stand-ins), never measured product rates; the workload totals are the source
  // of truth and the headline total is their sum.
  let trafficKey = '';
  let trafficCells = [], railRows = -1;
  // The rail reads the live state; rows, labels, colours and positions never move.
  // Values are whole tok/s and the underlying signal is already smoothed, so the
  // digits count toward the new reading instead of flickering.
  function updateTrafficNumbers() {
    if (!trafficCells.length || !trafficState._ready) return;
    for (const c of trafficCells) {
      const t = Math.round(trafficState.live[c.wid] || 0).toLocaleString('en-US') + ' tok/s';
      if (c.el.textContent !== t) c.el.textContent = t;
    }
    const tot = $('[data-t-total]');
    if (tot) {
      const t = Math.round(trafficState.totalTokPerSec).toLocaleString('en-US');
      if (tot.textContent !== t) tot.textContent = t;
    }
  }
  // ---- THROUGHPUT HISTORY ------------------------------------------------------
  // The same live state the readings and the particle emission consume, sampled on
  // a slow clock and drawn as one hairline. Not a chart component: no axis, no
  // grid, no fill, no glow — the rail's own vocabulary, in its neutral grey.
  const SPARK_N = 48;             // samples held
  const SPARK_EVERY = 700;        // ms between samples -> ~34s of history
  const spark = [];
  let sparkTook = 0;
  function drawThroughputSpark(now) {
    const cv = $('[data-t-spark]');
    if (!cv || !trafficState._ready) return;
    if (now - sparkTook >= SPARK_EVERY) {
      sparkTook = now;
      spark.push(trafficState.totalTokPerSec);
      if (spark.length > SPARK_N) spark.shift();
    }
    const r = cv.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = Math.round(r.width * dpr), H = Math.round(r.height * dpr);
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const g = cv.getContext('2d');
    g.clearRect(0, 0, W, H);
    if (spark.length < 2) return;
    let lo = Infinity, hi = -Infinity, sum = 0;
    for (const v of spark) { if (v < lo) lo = v; if (v > hi) hi = v; sum += v; }
    const mean = sum / spark.length;
    const floor = Math.max(1, mean * 0.02);
    if (hi - lo < floor) { const c = (hi + lo) / 2; lo = c - floor / 2; hi = c + floor / 2; }
    const span = hi - lo;
    lo -= span * 0.06; hi += span * 0.06;
    g.beginPath();
    for (let i = 0; i < spark.length; i++) {
      const px = (i / Math.max(1, spark.length - 1)) * (W - dpr) + dpr / 2;
      const py = H - dpr / 2 - ((spark[i] - lo) / (hi - lo)) * (H - dpr);
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    }
    g.strokeStyle = T.telemetry;
    g.lineWidth = dpr * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
    g.stroke();
  }
  function fillTrafficRail() {
    const box = $('[data-t-wl]');
    if (!box) return;
    const key = F.fixture + '|' + scopeKey;
    if (trafficKey === key && (railRows === 0 || box.querySelector('[data-driver-rows] > *'))) return;
    trafficKey = key;
    trafficCells = [];
    const T = scopedThroughput();
    trafficState.init({ throughput: T });
    const rows = [];
    const nodes = new Set();
    let total = 0;
    for (const w of scopedWorkloads()) {
      const per = T[w.id] || {};
      let sum = 0;
      for (const nd in per) { sum += per[nd]; nodes.add(nd); }
      if (sum > 0) { rows.push({ wid: w.id, name: w.name, wlc: w.c, color: WL_COLORS[w.c] || [159, 176, 170], tok: sum }); total += sum; }
    }
    const set = (sel, txt) => { const el = $(sel); if (el && el.textContent !== txt) el.textContent = txt; };
    set('[data-t-src]', REVIEW_FIXTURE.source.ctrl);
    set('[data-t-total]', total.toLocaleString('en-US'));
    set('[data-t-targets]', String(nodes.size));
    const slot = rowSlot(box);
    const FS = "'Source Sans 3',sans-serif";
    for (const r of rows) {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;flex-direction:row;align-items:flex-start;gap:24px;min-height:14px;';
      const nm = document.createElement('span');
      nm.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:8px;flex:1 1 auto;min-width:0;';
      const dot = document.createElement('i');
      dot.dataset.wlc = r.wlc || '';
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:' + hexOf(r.color) + ';';
      const t = document.createElement('span');
      t.setAttribute('data-wl-label','');
      // owner 2026-09-01: colour lives in the DOT only; the label stays neutral
      t.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:' + T.text1 + ';';
      t.textContent = r.name;
      nm.appendChild(dot); nm.appendChild(t);
      const v = document.createElement('span');
      v.style.cssText = 'font-family:var(--md-sys-typescale-label-large-font);font-weight:var(--md-sys-typescale-label-large-weight);font-size:var(--md-sys-typescale-label-large-size);line-height:var(--md-sys-typescale-label-large-line-height);letter-spacing:var(--md-sys-typescale-label-large-tracking);text-align:right;white-space:nowrap;color:' + T.ink2 + ';flex:0 0 auto;font-variant-numeric:tabular-nums;';
      v.textContent = Math.round(r.tok).toLocaleString('en-US') + ' tok/s';
      trafficCells.push({ el: v, wid: r.wid });     // only the numbers change later
      row.appendChild(nm); row.appendChild(v);
      slot.appendChild(row);
    }
    railRows = rows.length;   // a legitimate zero-result rebuild stays cached
  }

  // ---- node card sparklines ---------------------------------------------------
  // PROTOTYPE TELEMETRY: each card plots a short cpu (red) / mem (teal) history
  // seeded from that node's stated utilisation. Crisp: the canvas is sized in
  // device pixels and the strokes sit on the half-pixel grid.
  const sparkSeries = new Map();
  // canvas strokeStyle cannot parse var() — resolve tokens against computed style
  const cssCol = c => {
    if (!c || c.indexOf('var(') !== 0) return c;
    const v = getComputedStyle(document.documentElement).getPropertyValue(c.slice(4, -1).trim()).trim();
    return v || null;
  };
  let sparkAt = 0;
  // WHILE THE RAIL IS MOVING, LEAVE IT ALONE. Twenty canvases redrawing mid-scroll
  // is what made the column stutter: each redraw invalidates the masked layer the
  // compositor is trying to slide. The plots hold their last frame during the
  // gesture and resume ~180ms after it stops — no visible loss, the series moves
  // slowly anyway.
  let scrollingUntil = 0;
  let scrollBound = false;
  function bindNodeScroll() {
    if (scrollBound) return;
    const el = $('[data-node-list]');
    if (!el) return;
    scrollBound = true;
    el.addEventListener('scroll', () => { scrollingUntil = performance.now() + 180; }, { passive: true });
  }
  function drawNodeSparks(now) {
    bindNodeScroll();
    if (now < scrollingUntil) return;
    if (now - sparkAt < 220) return;
    sparkAt = now;
    for (const cv of document.querySelectorAll('[data-spark-node]')) {
      const id = cv.dataset.sparkNode;
      let st = sparkSeries.get(id);
      if (!st) { st = { cpu: [], mem: [], p: Math.random() * 6.28 }; sparkSeries.set(id, st); }
      const base = { cpu: +cv.dataset.cpu || 0, mem: +cv.dataset.mem || 0 };
      st.p += 0.35;
      const jit = (a, k) => Math.min(100, Math.max(0, a + Math.sin(st.p * k) * 1.6 + (Math.random() - 0.5) * 1.2));
      st.cpu.push(jit(base.cpu, 1)); st.mem.push(jit(base.mem, 0.6));
      if (st.cpu.length > 64) { st.cpu.shift(); st.mem.shift(); }
      const r = cv.getBoundingClientRect();
      if (!r.width) continue;
      const d = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const g = cv.getContext('2d');
      g.clearRect(0, 0, w, hh);
      const top = Math.max(2, Math.max(...st.cpu, ...st.mem, 8)) * 1.25;
      const plot = (arr, col) => {
        g.beginPath();
        for (let i = 0; i < arr.length; i++) {
          const x = (i / Math.max(1, arr.length - 1)) * (w - d) + d / 2;
          const y = hh - d / 2 - (arr[i] / top) * (hh - d);
          i ? g.lineTo(x, y) : g.moveTo(x, y);
        }
        g.strokeStyle = col; g.lineWidth = d * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
        g.stroke();
      };
      // one neutral for both series: the row labels carry the category
      plot(st.mem, T.telemetry);
      plot(st.cpu, T.telemetry);
    }
    // UTILISATION BANDS, on the reading only — never the card, the node id or the
    // neighbouring rows. Neutral below 75, amber to 89, the system's error red from
    // 90 up, where a resource is effectively saturated.
    const levelColor = v => v >= 90 ? 'var(--md-sys-color-error)'
    : v >= 75 ? 'var(--md-sys-color-tertiary)'
    : T.text1;
    for (const cv of document.querySelectorAll('[data-spark-metric]')) {
      const key = cv.dataset.sparkMetric;
      let st = sparkSeries.get(key);
      if (!st) { st = { v: [], p: Math.random() * 6.28 }; sparkSeries.set(key, st); }
      const base = +cv.dataset.val || 0;
      st.p += 0.4;
      st.v.push(Math.min(100, Math.max(0, base + Math.sin(st.p) * (base * 0.06 + 1.4) + (Math.random() - 0.5) * 1.6)));
      if (st.v.length > 64) st.v.shift();
      const r = cv.getBoundingClientRect();
      if (!r.width) continue;
      const d = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const g = cv.getContext('2d');
      g.clearRect(0, 0, w, hh);
      const top = Math.max(...st.v, 8) * 1.2;
      g.beginPath();
      for (let i = 0; i < st.v.length; i++) {
        const x = (i / Math.max(1, st.v.length - 1)) * (w - d) + d / 2;
        const y = hh - d / 2 - (st.v[i] / top) * (hh - d);
        i ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      const nowV = Math.round(st.v[st.v.length - 1]);
      g.strokeStyle = nowV >= 90 ? cssCol('var(--md-sys-color-error)') : nowV >= 75 ? rgbaT('warn', 0.85) : (cssCol(cv.dataset.col) || T.telemetry);
      g.lineWidth = d * 1.5; g.lineJoin = 'round'; g.lineCap = 'round';
      g.stroke();
      // THE NUMBER IS THE SERIES. The reading was static text while the line beside
      // it moved, so a card could show 16% over a plot that was clearly elsewhere.
      // It now reports the sample just plotted, and takes its colour from the level.
      const cur = Math.round(st.v[st.v.length - 1]);
      const col = levelColor(cur);
      const vEl = document.querySelector('[data-mval="' + key + '"]');
      if (vEl) {
        const t = cur + '%';
        if (vEl.textContent !== t) vEl.textContent = t;
        if (vEl.style.color !== col) vEl.style.color = col;
      }
      const card = cv.closest('[data-node]');
      const metric = key.split(':')[1];
      if (card) {
        const sEl = card.querySelector('[data-msum="' + metric + '"]');
        if (sEl) {
          const t = metric + ' ' + cur + '%';
          if (sEl.textContent !== t) sEl.textContent = t;
          if (sEl.style.color !== col) sEl.style.color = col;
        }
      }
    }
  }

  // ---- loop --------------------------------------------------------------------------
  setView('map');
  setFixture('MULTI-REGION ACTIVE');
  buildRoutes();   // the review build opens on the canonical fixture: 10 / 59 used
  // the product opens ON the Fit All frame, so the first thing seen is the same
  // infrastructure-framed composition the button returns to
  computeFitFrame();
  cam.yaw = fitYaw; cam.pitch = fitPitch;
  let tempMask = null;
  let last = performance.now();
  // the frame loop can return before its fit call, so the first run — which is also
  // what installs the observers that keep it correct — is kicked from boot
  const __chipsBoot = () => { try { fitHeaderChips(true); } catch (_) { } };
  setTimeout(__chipsBoot, 32);
  setTimeout(__chipsBoot, 300);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(__chipsBoot);
  // resize fires in bursts; one coalesced pass per burst instead of one per event
  let __chipsT = 0;
  window.addEventListener('resize', () => {
    clearTimeout(__chipsT);
    __chipsT = setTimeout(__chipsBoot, 120);
  });

  // scheduled here, immediately after its definition, so no later failure in boot()
  // can leave the render loop unstarted. Its own first guard handles a canvas that
  // is not attached yet.
  // rAF does not fire in a hidden tab, so the loop needs a pulse that survives it.
  // frame() stamps __tick every pass; the interval pumps ONLY when that stamp has
  // gone stale, so a healthy rAF loop is never doubled and a frozen one is revived.
  // ONE loop, always. rAF does not fire in a hidden tab, so the interval can revive
  // a frozen loop — but it must cancel the outstanding frame first, or each revival
  // leaves another permanent chain running and the page grinds to a halt.
  let __tick = 0, __raf = 0, __to = 0;
  // DUAL SCHEDULER. rAF does not fire reliably in this runtime, and a loop that
  // reschedules itself with rAF alone paints one frame and dies — the watchdog below
  // then revives it about once a second, which reads as frozen. Every frame arms
  // BOTH a rAF and a timer; whichever lands first cancels the other, so a healthy
  // rAF still drives the loop at display rate and a dead one costs nothing.
  const __sched = () => {
    if (__raf) cancelAnimationFrame(__raf);
    if (__to) clearTimeout(__to);
    __raf = requestAnimationFrame(__onFrame);
    __to = setTimeout(() => __onFrame(performance.now()), 24);
  };
  function __onFrame(now) {
    if (__raf) { cancelAnimationFrame(__raf); __raf = 0; }
    if (__to) { clearTimeout(__to); __to = 0; }
    try { frame(now); } catch (_) { }
  }
  const __pump = () => { __onFrame(performance.now()); };
  __pump();
  // ~30fps fallback: fires only when rAF has not ticked for longer than a frame, so
  // it never competes with a healthy loop and never leaves a throttled one at 1fps
  setInterval(() => { if (performance.now() - __tick > 400) __pump(); }, 250);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) __pump(); });

  let lastSizeCheck = 0, lastHookCheck = 0;
  function frame(now) {
    __tick = now;
    __sched();
    if (!canvas || !canvas.isConnected) {
      let ok = false;
      try { ok = rewire(); } catch (_) { ok = false; }
      if (!ok) return;
    }
    if (now - lastHookCheck > 250) {
      lastHookCheck = now;
      const probe = document.querySelector('[data-lens="swarm"]');
      if (probe && !probe.onclick) { hookControls(); styleTabs(); }
    }
    if (now - lastSizeCheck > 250) {
      lastSizeCheck = now;
      const pr = canvas.parentElement.getBoundingClientRect();
      const wantW = Math.round(Math.max(320, Math.round(pr.width)) * dpr);
      const wantH = Math.round(Math.max(240, Math.round(pr.height)) * dpr);
      if (canvas.width !== wantW || canvas.height !== wantH) bind();
    }
    drawNodeSparks(now);
    const dtRaw = Math.min(1 / 30, Math.max(1 / 240, (now - last) / 1000));
    const dt = dtRaw * timeScale;
    last = now;
    const S = F.state();
    const lv = Object.fromEntries(S.regions.map(r => [r.id, r.activityLevel]));
    // OCCUPANCY, not activity. A fixture's activity number describes motion; the
    // used-slot count describes capacity. Everything the product shows — labels,
    // marks, counts, traffic, node chips — reads the slots, so a region can never
    // be presented as busy while none of its capacity is engaged.
    const usedBy = F.usedByRegion();
    const ownR = F.ownership().regions;
    const rinfo = {}, lvq = {};
    for (const r of REGIONS) {
      const o = ownR[r.id];
      rinfo[r.id] = {
        name: r.name || r.id.toUpperCase(),
        used: usedBy[r.id] || 0,
        total: o ? o.slots : 0,
        nodes: o ? o.nodes : (NODE_COUNTS[r.id] || 0)
      };
      lvq[r.id] = o && o.slots ? (usedBy[r.id] || 0) / o.slots : 0;
    }
    const props = PR();
    F.tune.orbit = props.orbitStrength ?? 1.3;

    // TRAFFIC <-> CAPACITY: one progress, 0 = flow, 1 = allocation. Advanced at a
    // fixed rate so the duration is the same whichever way it runs, and eased once
    // here so every consumer below shares the same curve.
    {
      const want = view === 'swarm' ? 1 : 0;
      const step = dtRaw / LENS_DUR;
      lensMix += Math.max(-step, Math.min(step, want - lensMix));
      lensMix = Math.max(0, Math.min(1, lensMix));
    }
    const LM = lensMix < 0.5 ? 4 * lensMix * lensMix * lensMix
                             : 1 - Math.pow(-2 * lensMix + 2, 3) / 2;   // cubic in-out
    K.swarm = LM; K.map = 1 - LM;
    K.nodes += ((view === 'nodes' ? 1 : 0) - K.nodes) * Math.min(1, dtRaw / 0.3);
    // PHASE WINDOWS, all cut from LM so they overlap instead of queueing:
    //   flow finishes -> routes retract -> capacity expands -> stems -> labels
    const win = (a, b) => Math.max(0, Math.min(1, (LM - a) / (b - a)));
    const eOut = x => 1 - Math.pow(1 - x, 3);
    const routeDraw = 1 - win(0.22, 0.55);      // route contracts into its node
    const trafFade  = 1 - win(0.12, 0.42);      // flow hands off as it arrives
    const emergeK   = eOut(win(0.30, 0.68));    // capacity grows out of its anchor
    const stemK     = eOut(win(0.48, 0.78));    // stem draws along the normal
    const labelK    = win(0.62, 0.90);          // label resolves last
    try { lensRailMotion(); } catch (_) { }
    try { fitHeaderChips(); } catch (_) { }
    try { bindControls(); } catch (_) { }
    const mapK = Math.min(1, K.map + K.nodes * 0.9);   // geography emphasis
    const swarmK = K.swarm;

    if (!paused) {
      try { F.update(dt); } catch (err) { if (!window.__fieldErr) { window.__fieldErr = (err && err.stack) || String(err); console.error(err); } }
      const scaleNow = scaleName(zoom);
      // a route carries traffic only while the capacity it describes is engaged;
      // its cadence follows that workload's own slot count and nothing else
      // ONE STATE, THREE CONSUMERS. The live rates advance once per frame here;
      // the rail readings, the per-node stream rates and the emission budget below
      // all read the result, so a rise in the panel IS a rise in particle density.
      trafficState.update(F.sim.t, dt);
      for (const r of activeRoutes) {
        r.want = lvq[r.targetRegion] > 0.01 ? 1 : 0;
        if (!r.want) continue;
        for (const st of r.streams) {
          st.tokPerSec = trafficState.nodeRate(st.co.id, st.node);
          st.rate = st.tokPerSec / TOKEN_PARTICLE_SCALE;
        }
        // TOKENS, not decoration: particles/s = tok/s / TOKEN_PARTICLE_SCALE, run
        // through an emission budget so fractional rates (75 tok/s -> 1.5 p/s)
        // stay mathematically correct instead of rounding away
        for (const st of r.streams) {
          if (st.rate <= 0) continue;
          st.budget += st.rate * dt;
          let guard = 0;
          while (st.budget >= 1 && guard++ < 8) {
            traffic.spawn(r, 1, 1 / TRAFFIC_VISIBLE_WINDOW, st.co.color);
            st.budget -= 1;
            st.emitted++;
          }
        }
      }
      traffic.update(dt);
    }

    // camera integrates on real time so drag/zoom stay live while paused
    if (!drag && (Math.abs(vyaw) > 1e-4 || Math.abs(vpitch) > 1e-4)) {
      cam.yaw += vyaw * dtRaw;
      cam.pitch = Math.max(-0.9, Math.min(0.9, cam.pitch + vpitch * dtRaw));
      const k = Math.exp(-4.5 * dtRaw);
      vyaw *= k; vpitch *= k;
    }
    cam.dist += (distT - cam.dist) * Math.min(1, dtRaw * 6);
    // one eased magnification: transitions between scales read as intentional
    {
      const lz = Math.log(zoom), lt = Math.log(zoomT);
      zoom = Math.exp(lz + (lt - lz) * Math.min(1, dtRaw * 3.0));
      if (Math.abs(zoomT - zoom) < zoomT * 0.002) zoom = zoomT;
    }
    if (fit) {
      const kf = Math.min(1, dtRaw * 4);
      let dy = fitYaw - cam.yaw;
      while (dy > Math.PI) dy -= 6.2831853;
      while (dy < -Math.PI) dy += 6.2831853;
      cam.yaw += dy * kf;
      cam.pitch += (fitPitch - cam.pitch) * kf;
      if (Math.abs(dy) < 0.004 && Math.abs(cam.pitch - fitPitch) < 0.005 && Math.abs(zoom - 1) < 0.02) fit = false;
    }
    if (aimHold > 0 && cam.yawT != null && !drag) {
      let dy = cam.yawT - cam.yaw;
      while (dy > Math.PI) dy -= 2 * Math.PI;
      while (dy < -Math.PI) dy += 2 * Math.PI;
      const k = Math.min(1, dtRaw * 4.5);
      cam.yaw += dy * k;
      cam.pitch += (cam.pitchT - cam.pitch) * k;
      aimHold = Math.max(0, aimHold - dtRaw);
      manualHold = Math.max(manualHold, 0.2);
    }

    // FOCUS: turn the world so the region faces the viewer, then hold it there
    // FOCUS: turn the world so the region faces the viewer, then hold it there.
    // NOT DEAD-ON: a site turned to exactly face the camera puts its radial pole
    // straight down the view axis, where the flag foreshortens to nothing. The
    // geometry stays honestly radial and the FRAMING does the work — the focus
    // target is offset to a three-quarter view, so poles and flags are seen at an
    // angle and read in perspective (owner 2026-09-11).
    if (focusId && REG[focusId] && !drag) {
      const u = REG[focusId].u;
      const wy = Math.atan2(-u[0], -u[2]), wp = Math.asin(Math.max(-1, Math.min(1, -u[1])));
      let dy = wy - cam.yaw;
      while (dy > Math.PI) dy -= 2 * Math.PI;
      while (dy < -Math.PI) dy += 2 * Math.PI;
      const kf = Math.min(1, dtRaw * (focusHold > 0.4 ? 3.4 : 2.2));
      cam.yaw += dy * kf;
      cam.pitch += (wp - cam.pitch) * kf;
      focusHold = Math.max(0, focusHold - dtRaw);
      manualHold = Math.max(manualHold, 0.2);
    }
    if (manualHold > 0) manualHold = Math.max(0, manualHold - dtRaw);
    // P0-I: the review state has NO automatic camera behaviour. No lean toward
    // activity, no auto-centring on workloads, no drift, no hidden rebalancing.
    // The camera moves only when the user drags, zooms or focuses a region.
    // (props.autoLean must be explicitly turned on to restore the old lean.)
    else if (props.autoLean === true && !fit && !focusId && zoom < 1.6) {
      let ax = 0, ay = 0, az = 0, tot = 0;
      for (const r of S.regions) {
        if (r.activityLevel < 0.1) continue;
        const u = REG[r.id].u, w = r.activityLevel;
        ax += u[0] * w; ay += u[1] * w; az += u[2] * w; tot += w;
      }
      if (tot > 0) {
        // focus on the zone of interest: turn to the activity centroid, and
        // zoom so that ALL active regions stay in frame — one region: close;
        // activity spread across the Atlantic: wide enough to hold everything
        const l = Math.hypot(ax, ay, az) || 1;
        const cx2 = ax / l, cy2 = ay / l, cz2 = az / l;
        let spread = 0;
        for (const r of S.regions) {
          if (r.activityLevel < 0.1) continue;
          const u = REG[r.id].u;
          const dotc = Math.max(-1, Math.min(1, u[0] * cx2 + u[1] * cy2 + u[2] * cz2));
          spread = Math.max(spread, Math.acos(dotc));
        }
        const want = Math.atan2(-cx2, -cz2);
        let d = want - cam.yaw;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d < -Math.PI) d += 2 * Math.PI;
        cam.yaw += d * Math.min(1, dt * 0.7);
        cam.pitch += (-0.30 - cam.pitch) * Math.min(1, dt * 0.6);
      } else {
        // no drift: rest at the framing that holds all regions
        let d0 = -cam.yaw;
        while (d0 > Math.PI) d0 -= 2 * Math.PI;
        while (d0 < -Math.PI) d0 += 2 * Math.PI;
        cam.yaw += d0 * Math.min(1, dt * 0.4);
        cam.pitch += (0.24 - cam.pitch) * Math.min(1, dt * 0.5);
      }
    }
    // globe screen radius = zoom · R0. At fit-all the world nearly fills the
    // panel (the reference's presence); zooming genuinely magnifies it.
    // the canvas scales with its panel, like the rest of the design
    // KNOWN-GOOD SWARM GEOMETRY: the world at its original projected radius and
    // the glyphs at their original viewport scale. Every attempt to enlarge the
    // globe regressed the engaged-cohort rendering; if it is retried, glyph size,
    // station pitch and the separation solver must all move together.
    const uiMul = 1;
    setUiScale(Math.min(W, H) / 700);
    // THE WORLD'S SCREEN RADIUS — the one place the globe's size is decided, every
    // frame. The height term binds on a wide stage, so it is what makes the world
    // read large; the width term only takes over on a narrow one. Raised from
    // 0.40/0.34: the sphere now fills ~0.94 of the shorter side instead of ~0.79,
    // and still never crops. Nothing else moves with it — agent glyphs are a fixed
    // 3.2px, node marks and labels are sized in screen units, and the one place
    // that reads the projected scale normalises it against fov/dist.
    const shortView = (window.innerHeight || H) <= 1000;
    let R0;
    if (shortView) {
      // free band between the columns, in canvas pixels
      const cvw = (canvas && canvas.getBoundingClientRect().width) || W;
      const px = W / cvw;                                  // canvas px per css px
      const L = document.querySelector('[data-nodes-rail]');
      const Rr = document.querySelector('[data-map-panel]') || document.querySelector('[data-cap-panel]');
      let band = 0;
      if (L && Rr) {
        const lb = L.getBoundingClientRect(), rb = Rr.getBoundingClientRect();
        band = Math.max(0, rb.left - lb.right) * px;
      }
      // the height term is a floor, not a cap: it keeps the world from collapsing
      // on a window too narrow to hold both columns, and never shrinks the band
      R0 = Math.max(Math.min(band, H * 1.30) / 2, H * 0.55);
    } else {
      R0 = Math.min(W * 0.44, (H - 16) * 0.47);            // large screen: exactly as before
    }
    cam.fov = zoom * R0 * cam.dist / SR;
    if (typeof window !== 'undefined') window.__stageDbg = { R0: +R0.toFixed(1), dia: +(2 * R0).toFixed(1), W, H, short: shortView, ratio: +((2 * R0) / H).toFixed(3) };
    // the formation's spacing follows the screen: pitch = glyph + a small gap
    {
      const pxPerWorld = R0 / SR;
      const uiK = Math.max(1, Math.min(1.55, Math.min(W, H) / 700 * uiMul));
      const glyphPx = (2.8 + 0.55) * 1.24 * 1.1 * 2 * (props.agentScale ?? 1) * uiK;
      F.setStationPitch((glyphPx + 2.4) / (1.7320508 * pxPerWorld));
    }
    // the existing semantic-zoom thresholds speak in distance: give them one
    const sdist = 262 - Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6)) * 90;
    // SWARM ZOOMS ONTO NODES TOO. At GLOBAL, Swarm stays workload-led — no node
    // marks, no infrastructure ids. But descending a scale is the same gesture in
    // both lenses, so from REGIONAL onward the compute nodes come up in Swarm
    // exactly as they do in Map (marks first, hardware detail at LOCAL), which is
    // what lets you zoom onto the node a cohort is actually sitting on.
    const swarmNodesA = swarmK * Math.max(0, Math.min(1, (zoom - 1.9) / 1.1));

    if (ctx) try {
      ctx.clearRect(0, 0, W, H);
      ctx.save();
      ctx.translate(0, 16);            // drop the world below the panel head
      // v3: geography is never absent, only quieter. Map and Node stats carry the
      // full reading (filled land, coasts, graticule); Swarm keeps a third of the
      // stipple's base layer, which is enough to know WHERE a cohort is without
      // competing with it. mapK stays 0 in Swarm, so only that base layer draws.
      // ONE WORLD, TWO LENSES. The geography is the same cartography in Swarm as in
      // Map: same point density, same dot size, same alpha. Swarm used to draw a
      // third of the stipple at a third of the weight, which left the capacity
      // cohorts floating over a hint of a globe rather than over countries.
      const geoK = Math.min(1, K.map + K.nodes + swarmK);
      // THE LIMB IS THE SAME IN EVERY LENS. The globe's outline is the world's
      // edge, not a geography detail, so it draws at full strength in Swarm too
      // (the stipple below still fades to a third there).
      {
        const rimA = Math.min(1, K.map + K.nodes + swarmK);
        if (rimA > 0.01) {
          ctx.save();
          ctx.globalAlpha = rimA;
          drawSphereBase(ctx, cam, W, H, SR, grat, mapK);
          ctx.restore();
        }
      }
      if (geoK > 0.01) {
        ctx.save();
        ctx.globalAlpha = geoK;
        try { ensureLandLod(performance.now()); } catch (_) { }
        // THE ORIGINAL CARTOGRAPHY IS THE CARTOGRAPHY. The filled-continent layer
        // tried here was reverted by direction: geography stays the restrained
        // dotted point-cloud, contextual infrastructure rather than subject. All
        // new information (stems, ids, YOU, traffic) sits ABOVE this quiet layer.
        // the density term drives both the infill thirds and the dot size, so Swarm
        // passes its own lens weight through it and gets Map's cartography verbatim
        const geoDensity = Math.min(1, Math.max(mapK, swarmK));
        drawLand(ctx, cam, W, H, land, F.sim.t, props.landAlpha ?? 1, geoDensity, zoom, landLod);
        ctx.restore();
      }

      // traffic: geographic context in Map, a whisper in Swarm
      // SWARM IS NOT MAP: token traffic is Map's system only. Swarm shows capacity
      // state, so no routes and no token particles are drawn here.
      const trafA = 0.95 * Math.min(1, trafFade + K.nodes);
      if (trafA > 0.02) {
        ctx.save(); ctx.globalAlpha = trafA;
        traffic.draw(ctx, cam, W, H, { scale: scaleName(zoom), focus: focusId, draw: routeDraw,
          flows: opLens() === 'flows',
          flowLabels: opLens() === 'flows' && scopedWorkloads().filter(w => (w.at || []).length).length === 1,
          modelOf: r => NODE_MODEL[r.target], regionOf: r => (REGION_DISPLAY[r.targetRegion] || [r.targetRegion])[0],
          workloadOf: r => (r.workloads && r.workloads[0]) ? r.workloads[0].name : '', ctrlOf: r => r.sourceControlId || '',
          fontStrong: '600 12px "Source Sans 3", sans-serif',
          ink: [232, 234, 233] });
        ctx.restore();
      }
      // capacity: only the Swarm lens shows it — Map is infrastructure
      if (swarmK > 0.03) {
        ctx.save();
        ctx.globalAlpha = swarmK;
        // node and region marks are hard obstacles: capacity flows around them
        const avoid = [];
        {
          const uiK2 = Math.max(1, Math.min(1.55, Math.min(W, H) / 700 * uiMul));
          const glyphD = ((2.8 + 1.0) * (props.agentScale ?? 1) * uiK2) * 2 + 1.6 * uiK2;
          // the ball's hollow core, in px — the obstacle must fit inside it so
          // it can never displace the body it sits in
          let coreW = Infinity;
          for (const rg of F.regions) if (rg.ballR) coreW = Math.min(coreW, rg.ballR * 0.42);
          if (!isFinite(coreW)) coreW = F.stationPitch * 0.65;
          const rMax = Math.max(4, coreW * (R0 / SR) - glyphD * 0.5);
          const rNode = Math.min(11, rMax);
          for (const m of nodeMarks) {
            core.project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
            avoid.push([o4[0], o4[1], rNode]);
          }
        }
        // ORIENTATION TICKS — the free capacity field only. Engaged capacity now
        // carries its structure explicitly: the radial spokes out of its
        // workload's anchor. A second, per-particle stroke system on top of that
        // read as arbitrary scribble, so it is gone from engaged marks.
        {
          const f3 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
          const sim3 = F.sim;
          ctx.lineWidth = 0.75;
          for (let i = 0; i < sim3.N; i++) {
            if (F.alloc[i]) continue;                  // engaged: the spokes speak
            if (i % 4) continue;                       // free field: a sparse quarter
            const x3 = sim3.px[i], y3 = sim3.py[i], z3 = sim3.pz[i];
            const pl3 = Math.hypot(x3, y3, z3) || 1;
            const fc = -(x3 * f3[0] + y3 * f3[1] + z3 * f3[2]) / pl3;
            if (fc < 0.22) continue;
            // the tick starts just OFF the glyph and runs outward along the normal.
            // A radial line foreshortens to nothing at the disc centre (it points
            // at the camera), so the projected stroke is stretched to a small
            // minimum length — the mark stays a subtle tick at every latitude.
            const k0 = 1 + 0.35 / pl3;
            const kk = 1 + (0.35 + 1.15) / pl3;
            core.project(cam, x3 * k0, y3 * k0, z3 * k0, W, H, o4c);
            core.project(cam, x3 * kk, y3 * kk, z3 * kk, W, H, o4d);
            let dx3 = o4d[0] - o4c[0], dy3 = o4d[1] - o4c[1];
            const L3 = Math.hypot(dx3, dy3);
            const Lmin = 3.2;
            if (L3 < 0.4) continue;                    // dead-on: no honest direction
            if (L3 < Lmin) { dx3 *= Lmin / L3; dy3 *= Lmin / L3; }
            ctx.strokeStyle = `rgba(159,176,170,${(0.16 * fc).toFixed(3)})`;
            ctx.beginPath(); ctx.moveTo(o4c[0], o4c[1]); ctx.lineTo(o4c[0] + dx3, o4c[1] + dy3); ctx.stroke();
          }
        }
        const realTemp = F.sim.temp;
        if (!tempMask || tempMask.length !== realTemp.length) tempMask = new Float32Array(realTemp.length);
        let tmax = 0;
        for (let i = 0; i < realTemp.length; i++) {
          const v = F.alloc[i] ? F.chroma[i] : 0;   // v3: the accent, not the thermal field
          tempMask[i] = v;
          if (v > tmax) tmax = v;
        }
        const realMax = F.sim.tempMax;
        F.sim.temp = tempMask; F.sim.tempMax = tmax;
        F.sim.wlc = assign().wlc;            // per-particle workload identity
        // RADIAL LIFT, FOR DRAWING ONLY. Engaged capacity is shown standing a
        // little way up its workload's filament, along the local normal, so the
        // cohort reads as a plume emerging from the sphere. The physics keeps
        // running on the shell: positions are restored immediately after the
        // draw, so the lift can never fight the docking or accumulate.
        const lf = F.lift;
        let sv = null;
        {
          const s5 = F.sim;
          sv = [Float32Array.from(s5.px), Float32Array.from(s5.py), Float32Array.from(s5.pz)];
          // origin of the emergence, per particle: its own anchor on the sphere
          const org = F.emergeOrigins ? F.emergeOrigins() : null;
          const em = emergeK;
          for (let i = 0; i < s5.N; i++) {
            let x = s5.px[i], y = s5.py[i], z = s5.pz[i];
            if (em < 0.999 && org) {
              const o = i * 3;
              const ax = org[o] * SR, ay = org[o + 1] * SR, az = org[o + 2] * SR;
              if (ax || ay || az) { x = ax + (x - ax) * em; y = ay + (y - ay) * em; z = az + (z - az) * em; }
            }
            const h = lf ? lf[i] * em : 0;
            if (h) { const L0 = Math.hypot(x, y, z) || 1; const kk = (L0 + h) / L0; x *= kk; y *= kk; z *= kk; }
            s5.px[i] = x; s5.py[i] = y; s5.pz[i] = z;
          }
        }
        sceneOrig.drawScene(ctx, W, H, F.sim, {
          cam,
          keepCanvas: true,
          hideInstrument: true,
          isotherms: false,          // v3: thermal contours read as failure, not coordination
          // TRAILS OFF. Capacity marks stand on the sphere with their own normal
          // stems; a tail behind each one added motion blur on top of that and made
          // the field read as smeared rather than as discrete standing capacity.
          trails: props.trails ?? false,
          trailCfg: {
            n: Math.min(F.sim.TL, props.trailLength ?? 15),
            stride: props.trailEvery ?? 4,
            w: props.trailWidth ?? 0.55,
            alpha: props.trailOpacity ?? 0.2,
            ticks: props.trailTicks ?? true,
            depth: props.trailDepth ?? true,
            taper: props.trailTaper ?? false,
            speedK: props.trailSpeedK ?? false
          },
          glyph: GLYPHS[props.glyph ?? 'Hexagon'] || GLYPHS.Hexagon,
          glyphK: props.agentScale ?? 1
        }, null, null, { on: 0, phase: 0 });
        // PER-PARTICLE SPHERE NORMALS: every engaged mark carries the same
        // geometry as its workload stem — a line straight out along its own
        // normal — but markedly fainter and shorter, so the structure reads
        // workload-stem first and particle-stem second. Drawn while the draw-only
        // radial lift is still applied, so each starts at its own glyph.
        drawParticleStems(ctx, cam, F.sim, W, H, F.alloc, swarmK, SR);
        if (sv) { F.sim.px.set(sv[0]); F.sim.py.set(sv[1]); F.sim.pz.set(sv[2]); }
        F.sim.temp = realTemp; F.sim.tempMax = realMax;
        ctx.restore();
      }
      // ONE label layer, in priority order: cohorts claim their slots and
      // reserve their footprint first, then region names, then place names.
      // where the colony's response actually sits, so the mark is in the swarm
      let ballAt = null;
      if (F.sim.perturb > 0.02) {
        let dm = null;
        for (const rg of S.regions) if (!dm || rg.activityLevel > dm.activityLevel) dm = rg;
        if (dm && dm.activityLevel > 0.1) ballAt = { id: dm.id, r: F.sim.shellR * 1.35, p: [F.sim.probe.x, F.sim.probe.y, F.sim.probe.z] };
      }
      beginLabels(ctx);
      {
        const cr = canvas.getBoundingClientRect();
        // The rails are opaque chrome, and world-scene's placer treats panels and
        // control rails as the one thing a fixed-offset label may dodge — but they
        // were never handed in, so labels (the YOU lockup most visibly) slid under
        // the node rail. Registering them lets the label flip to its free side.
        for (const sel of ['[data-scale]', '[data-focus]', '[data-cap-panel]', '[data-strip]', '[data-wl-card]', '[data-nodes-rail]', '[data-map-panel]']) {
          for (const el of document.querySelectorAll(sel)) {
            const r = el.getBoundingClientRect();
            keepOutRect(r.left - cr.left - 4, r.top - cr.top - 16 - 3, r.width + 8, r.height + 6);
          }
        }
        keepOutRect(0, -16, W, 58);          // panel head: lens tabs and Fit All
      }
      // node markers reserve their spot only AFTER the regional labels are
      // placed: a regional label must be able to sit BESIDE its own anchor, and
      // the node discs cluster exactly there. Node ids come last and yield.
      const reserveNodes = () => {
        const f4 = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), Math.cos(cam.yaw) * Math.cos(cam.pitch)];
        for (const m of nodeMarks) {
          if (-(m.u[0] * f4[0] + m.u[1] * f4[1] + m.u[2] * f4[2]) < 0.1) continue;
          core.project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
          keepOut(o4[0], o4[1], 5);
        }
      };
      // WHERE / WHAT / HOW MUCH — rinfo and lvq are built at the top of the frame
      // from the ownership model, so the labels, the marks and the panels are all
      // printing the same numbers.
      const scaleTxt = scaleName(zoom);
      // P0-F: the label layout is only re-solved when the camera meaningfully
      // moves. Quantising yaw/pitch/zoom gives a key that is constant while the
      // user is not touching anything, so stored placements simply persist.
      const camKey = (Math.round(cam.yaw * 24) + '|' + Math.round(cam.pitch * 24) + '|' + Math.round(Math.log(zoom) * 8) + '|' + view);
      const zz = Math.max(0, Math.min(1, Math.log(Math.max(1, zoom)) / Math.log(6)));
      // collision priority order: YOU first, then cohort cards, then regions,
      // then node ids (serving first), then secondary hardware detail
      // MAP: YOU and its location are ONE context block, and it is the only
      // explicit location text on the lens. SWARM: the word YOU alone, because
      // the region prints its own spatial reference there.
      const mapLensA = Math.min(1, K.map + K.nodes);
      // GLOBAL SWARM is workload-led, with NO operator/location layer: the YOU
      // lockup (and with it control-use2-1 and its Ohio context) belongs to Map
      // only, where geography, control and nodes are the reading. In Swarm it
      // would compete with the workload identities, so its alpha is the Map/Nodes
      // lens alpha alone — it fades out entirely as Swarm takes over.
      drawYou(ctx, cam, W, H, REG.ohio.u, SR, zz, mapLensA, {
        combined: mapLensA > 0.5,
        region: REG.ohio.name, nodes: rinfo.ohio.nodes, ctrl: REG.ohio.ctrl
      });
      // P0 PRIORITY LAYERS, in order: YOU / control reference, then the
      // infrastructure regions, then the workload cohorts, then node detail. A
      // lower layer can never displace a higher one, so moving capacity cannot
      // push an infrastructure label around.
      // no regional anchors on the Map: a mark that is not a compute node must
      // not look like one. Ohio's context is the YOU block; Europe is read from
      // its own nodes and their traffic.
      // NO REGIONAL ANCHOR MARKERS, in either lens: a mark that is not a compute
      // node must not look like one. Regions are named in text in Swarm; Ohio's
      // context is the YOU lockup. Only the 10 real nodes carry node marks.
      // REGION NAMES: Swarm keeps them as its spatial reference (it has no
      // basemap to orient against); on the geographic Map they are contextual
      // only — at GLOBAL the reading is YOU + nodes + workload traffic, and the
      // names arrive when you descend a scale or focus a region.
      // region names: SWARM only. The Map has no persistent FRANKFURT /
      // EU-WEST overlays — geography plus the real nodes carry the location.
      // LOCATION LABELS ARE CONTEXTUAL, NOT PERSISTENT. In GLOBAL Swarm the only
      // location text is the YOU lockup: the globe and the distribution of
      // capacity already carry the spatial reading, so FRANKFURT / EU-WEST would
      // only compete with workload state. Other regions name themselves once you
      // descend a scale or focus one — and Ohio never repeats itself, because the
      // YOU lockup is already saying it.
      const namedRegions = (scaleTxt === 'GLOBAL' && !focusId)
        ? []
        : REGIONS.filter(r => r.id !== 'ohio');
      // SEMANTIC ZOOM ON REGION NAMES: full weight only while the world is the
      // subject; at REGIONAL they drop to a third as node ids take over, and at
      // LOCAL they go entirely — the node context already says where you are.
      const regionFade = scaleTxt === 'LOCAL' ? 0 : scaleTxt === 'REGIONAL' ? 0.34 : 1;
      drawSideRegionLabels(ctx, cam, W, H, namedRegions, NBR, 0.52 * swarmK * regionFade, rinfo, camKey);
      reserveNodes();
      drawNodeMarks(ctx, cam, W, H, nodeMarks, lvq, Math.min(1, Math.max(K.map, swarmNodesA)), K.nodes, sdist, F.sim.t, scaleTxt, focusId, zz, NODE_HW, Math.min(1, K.map + K.nodes) > 0.5, nodeAccent);
      // workload labels sit BELOW node ids in priority: activity yields to
      // infrastructure identity, never the other way round
      // WORKLOAD NAMES ARE A SWARM READING ONLY. On the geographic Map the workload
      // is already stated twice — by its token colour on the route and by Traffic by
      // workload in the right rail — so repeating the names over the geography was
      // pure duplication. Hard gate on the lens, not just on its eased weight.
      const wlLabelA = K.map > 0.5 ? 0 : swarmK;
      {
        const _st = F.cohortStructures ? F.cohortStructures() : null;
        if (typeof window !== 'undefined' && _st) {
          // review hook: how many footprints each workload actually has on the world
          const fp = {}; for (const k in _st) fp[k] = (_st[k].all || [_st[k]]).length;
          window.__fpDbg = fp;
        }
        drawWorkloadCohorts(ctx, cam, W, H, F.sim, assign().cohorts, wlLabelA, SR, camKey, _st, stemK, labelK);
      }
      // AUXILIARY CITY NAMES: off. This is an abstract operational world, not a
      // cartographic gazetteer — geographic context comes from the YOU lockup and
      // the real node ids, so scattered town names are pure noise.
      // drawPlaces(ctx, cam, W, H, SR, focusId, ...) intentionally not called.
      ctx.restore();
    } catch (err) {
      if (!window.__drawErr) { window.__drawErr = (err && err.stack) || String(err); console.error(err); }
      try { ctx.restore(); } catch (_) { }
    }
    try { syncUI(); } catch (err) { if (!window.__syncErr) { window.__syncErr = (err && err.stack) || String(err); console.error(err); } }
    try { syncStrip(dtRaw); } catch (_) { }
  }

  // review/testing hook
  window.__ops = {
    // review hook: the resolved scope and the capacity reading derived from it
    get scope() {
      return { key: scopeKey, nodes: SCOPE ? [...SCOPE.nodes] : null,
               wl: SCOPE ? [...SCOPE.wl] : null, slots: scopedSlots(), lens: opLens(), view: view };
    },
    get state() {
      return {
        ...F.state(), view,
        lens: { map: +K.map.toFixed(3), nodes: +K.nodes.toFixed(3), swarm: +K.swarm.toFixed(3) },
        yaw: +cam.yaw.toFixed(4), pitch: +cam.pitch.toFixed(4), dist: +cam.dist.toFixed(1),
        zoom: +zoom.toFixed(2), scale: scaleName(zoom), focus: focusId, fov: Math.round(cam.fov),
        slots: F.slots, audit: F.audit(), ownership: F.ownership(),
        stationPitch: +F.stationPitch.toFixed(3),
        geometry: F.geometry(),
        motor: F.motor(),
        pulses: traffic.pulses.length,
        // P1 review hook: the derived route table, explicit ownership included
        tokenScale: TOKEN_PARTICLE_SCALE,
        visibleWindow: TRAFFIC_VISIBLE_WINDOW,
        routes: activeRoutes.map(r => ({
          sourceControlId: r.sourceControlId,
          targetNodeId: r.target, targetRegionId: r.targetRegion,
          workloads: r.workloads.map(w => ({ workloadId: w.id, name: w.name, color: w.color })),
          streams: r.streams.map(s => ({
            workloadId: s.co.id, tokPerSec: s.tokPerSec,
            particlesPerSec: +s.rate.toFixed(3), emitted: s.emitted
          }))
        }))
      };
    },
    // review hook: step the field without the animation frame, so a headless
    // check can settle the model deterministically before measuring it
    advance(sec) {
      const n = Math.max(1, Math.round((sec || 1) * 60));
      for (let i = 0; i < n; i++) F.update(1 / 60);
      return +F.sim.t.toFixed(2);
    },
    setView, 
    setTheme: applyTheme, theme: themeName,
    setFixture, focusRegion, setZoom,
    fitAll() { computeFitFrame(); fit = true; focusId = null; zoomT = 1; drag = null; manualHold = 0; },
    get zoom() { return zoom; },
    get scale() { return scaleName(zoom); },
    setTimeScale(v) { timeScale = v; },
    fixtures: Object.keys(FIXTURES)
  };
}

// boot only once the template has fully streamed: [data-dbg] is the last
// interactive element in the DC, so its presence means every hook exists
(function wait() {
  const c = document.querySelector('[data-stage]');
  if (c && c.parentElement && document.querySelector('[data-fit]')) {
    // ONE INSTANCE. The helmet script can be evaluated more than once across a
    // remount, and two live drivers share one DOM: both write the fixture chip,
    // both style the tabs and both draw, so the page appears to fight itself and
    // to revert state at random. The first boot wins; a second is a no-op.
    if (window.__opsBooted) return;
    window.__opsBooted = 1;
    boot(c);
  } else setTimeout(wait, 32);
})();

// NODE LIST TOP FADE (owner 2026-09-01): the top edge only fades once the list is
// actually scrolled — at rest the first card shows whole.
// Capture-phase at document level so it survives any remount of the list node.
document.addEventListener('scroll',e=>{
  const el=e.target;
  if(!(el instanceof Element)||!el.hasAttribute||!el.hasAttribute('data-node-list'))return;
  if(el.scrollTop>2) el.setAttribute('data-scrolled',''); else el.removeAttribute('data-scrolled');
},{capture:true,passive:true});


// CHIP FIT — LATE MEASURE. The strip is measured at boot, before the chips are
// upgraded custom elements, so their widths read 0 and nothing looks clipped.
// Force one more fit when the definitions and the webfont land.
(function lateChipFit(){
  const again = () => { try { fitHeaderChips(true); } catch (_) {} };
  if (window.customElements) customElements.whenDefined('md-icon').then(again).catch(() => {});
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(again).catch(() => {});
  window.addEventListener('load', again);
  setTimeout(again, 600);
})();


// NODE CARD ACTIVATION. The cards are interactive (owner, 2026-09-01), so they
// are reachable by keyboard and they act on a capability the product already
// has: focusing the node's region in the world. No new behaviour is invented —
// this is the same focusRegion the canvas uses.
(function nodeCardActivation(){
  const REGION_OF = { ohio: 'ohio', frankfurt: 'frankfurt', dublin: 'dublin' };
  const NODE_REGION = {
    'amd-0':'ohio','sev-0':'ohio','sev-1':'ohio','sev-2':'ohio',
    'gpu-1':'frankfurt','gpu-2':'frankfurt','sev-6':'frankfurt',
    'sev-3':'dublin','sev-4':'dublin','sev-5':'dublin'
  };
  window.activateNodeCard = function (card) {
    const id = card && card.dataset && card.dataset.node;
    const reg = id && REGION_OF[NODE_REGION[id]];
    if (reg && window.__ops && window.__ops.focusRegion) window.__ops.focusRegion(reg);
  };
  const arm = () => {
    const cards = document.querySelectorAll('[data-node]');
    if (!cards.length) { setTimeout(arm, 60); return; }
    for (const c of cards) {
      if (c.dataset.kbd) continue;
      c.dataset.kbd = '1';
      c.tabIndex = 0;
      c.setAttribute('role', 'button');
      c.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.activateNodeCard(c); }
      });
    }
  };
  arm();
  setInterval(arm, 1000);   // the rail re-renders; new cards get the same reach
})();


// WORKLOAD CARD ACTIVATION. Same contract as the node cards: whole card, pointer
// or Enter/Space, nested controls exempt. The outcome is the product's current
// workload — recorded on <html> so one source of truth drives whatever the
// workspace grows into. No visual treatment is attached to it yet.
(function workloadCardActivation(){
  window.activateWorkloadCard = function (card) {
    const id = card && card.dataset && card.dataset.wl;
    if (!id) return;
    document.documentElement.dataset.currentWorkload = id;
    window.dispatchEvent(new CustomEvent('civarro:workload', { detail: { id } }));
  };
  const arm = () => {
    const cards = document.querySelectorAll('[data-wl]');
    if (!cards.length) { setTimeout(arm, 60); return; }
    for (const c of cards) {
      if (c.dataset.kbd) continue;
      c.dataset.kbd = '1';
      c.tabIndex = 0;
      c.setAttribute('role', 'button');
      c.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.activateWorkloadCard(c); }
      });
    }
  };
  arm();
  setInterval(arm, 1000);
})();


// PERSISTENT SELECTION. One selected entity per collection: activating a card
// clears its siblings and marks itself. The treatment is the kit's focused
// recipe, reused by owner decision, so nothing new is drawn.
(function persistentSelection(){
  // Owner 2026-09-11: node cards no longer carry a persistent selection — the
  // state was dropped, not restyled. Activation behaviour is untouched. Workload
  // cards keep theirs: the Workloads destination renders from the current one.
  function select(card, group) {
    for (const s of document.querySelectorAll('[' + group + '][data-selected]')) {
      if (s !== card) s.removeAttribute('data-selected');
    }
    card.setAttribute('data-selected', '');
  }
  for (const s of document.querySelectorAll('[data-node][data-selected]')) s.removeAttribute('data-selected');
  const wlAct = window.activateWorkloadCard;
  if (wlAct) window.activateWorkloadCard = function (card) { select(card, 'data-wl'); return wlAct(card); };
})();


// WORKLOADS — navigator selection, tabs, search and the wide evidence drawer.
// Every value rendered comes from REVIEW_FIXTURE; nothing is synthesised.


// WORKLOADS — selection, filters, search, summary and serving-node composition.
// Every figure is REVIEW_FIXTURE or arithmetic on it; nothing is synthesised.


// WORKLOADS ACTIVE — populated. Node identity, region, per-node throughput, slots
// and share come from REVIEW_FIXTURE; invoice, evidence marks, engine counters and
// the five series come from the demo content module. One renderer, so every region
// of the screen is driven by the same selected workload.

// WORKLOADS ACTIVE — populated. Node identity, region, per-node throughput, slots
// and share come from REVIEW_FIXTURE; invoice figures, evidence marks, engine
// counters and the five series come from ops-v4/workload-demo.js. One renderer, so
// every region of the screen is driven by the same selected workload.
(function workloadsActive(){
  const NODE={'ohio-node-01':['amd-0','Ohio'],'ohio-node-02':['sev-0','Ohio'],'ohio-node-03':['sev-1','Ohio'],'ohio-node-04':['sev-2','Ohio'],'frankfurt-node-01':['gpu-1','Frankfurt'],'frankfurt-node-02':['gpu-2','Frankfurt'],'frankfurt-node-03':['sev-6','Frankfurt'],'dublin-node-01':['sev-3','EU-West'],'dublin-node-02':['sev-4','EU-West'],'dublin-node-03':['sev-5','EU-West']};
  const HW={'amd-0':'AMD Radeon Pro V520 8GB','gpu-1':'NVIDIA L4 24GB','gpu-2':'NVIDIA L4 24GB','sev-0':'CPU · AMD EPYC / SEV-SNP','sev-1':'CPU · AMD EPYC / SEV-SNP','sev-2':'CPU · AMD EPYC / SEV-SNP','sev-3':'CPU · AMD EPYC / SEV-SNP','sev-4':'CPU · AMD EPYC / SEV-SNP','sev-5':'CPU · AMD EPYC / SEV-SNP','sev-6':'CPU · AMD EPYC / SEV-SNP'};
  const COLOR={'eric-1':'eric','vision-1':'vision','conf-remote-1':'confRemote','workload-1':'workload','conf-carlos-1':'confCarlos','eric-2':'eric'};
  const T=function(r){return 'font-family:var(--md-sys-typescale-'+r+'-font);font-weight:var(--md-sys-typescale-'+r+'-weight);font-size:var(--md-sys-typescale-'+r+'-size);line-height:var(--md-sys-typescale-'+r+'-line-height);letter-spacing:var(--md-sys-typescale-'+r+'-tracking);';};
  const byId={}; for(const w of REVIEW_FIXTURE.workloads) byId[w.id]=w;
  const esc=function(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');};
  const CUR='$';

  function spark(seed,color,w,h){
    let s=seed,pts=[],n=40;
    for(let i=0;i<n;i++){ s=(s*1103515245+12345)&0x7fffffff; const v=(s%1000)/1000;
      pts.push((i/(n-1)*w).toFixed(1)+','+(h-4-v*(h-8)).toFixed(1)); }
    return '<svg viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" style="width:100%;height:'+h+'px;display:block;overflow:visible;"><polyline points="'+pts.join(' ')+'" fill="none" stroke="'+color+'" stroke-width="1.25" vector-effect="non-scaling-stroke"/></svg>';
  }
  const lab=function(t){return '<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--md-sys-color-on-surface-variant);">'+t+'</span>';};
  const over=function(t){return '<span style="'+T('label-large')+'text-transform:uppercase;color:var(--text-1);">'+t+'</span>';};
  function markHTML(t,tone){
    const col = tone==='error' ? 'var(--md-sys-color-error)' : tone==='accent' ? 'var(--md-sys-color-primary)' : 'var(--md-sys-color-on-surface-variant)';
    const bd  = tone==='error' ? 'var(--md-sys-color-error)' : 'var(--md-sys-color-outline-variant)';
    return '<span data-custom="status-indicator" style="display:inline-flex;align-items:center;height:28px;padding:0 10px;box-shadow:inset 0 0 0 1px '+bd+';border-radius:var(--md-sys-shape-corner-small);'+T('label-medium')+'color:'+col+';white-space:nowrap;">'+esc(t)+'</span>';
  }
  // RESIDENCY — the concise violation summary shown in the invoice is derived from
  // the same allowlist string the policy carries, counted against the jurisdictions
  // of the nodes actually serving. The verbose allowlist stays available as the
  // element's title, so no policy detail is lost.
  function residency(nodes,ND,rule){
    const allow=(rule.match(/\b[A-Z]{2}\b/g)||[]);
    const bad=[]; for(const p of nodes){ const j=(ND[p[0]]||{}).juris; if(j&&allow.indexOf(j)<0&&bad.indexOf(j)<0) bad.push(j); }
    let n=0; for(const p of nodes){ const j=(ND[p[0]]||{}).juris; if(j&&allow.indexOf(j)<0) n++; }
    if(!n) return '';
    return n+' of '+nodes.length+' serving nodes outside the allowed regions ('+bad.join(', ')+')';
  }
  function figHTML(l,v,s){
    return '<div style="min-width:0;display:flex;flex-direction:column;gap:4px;">'
      +'<span style="'+T('label-large')+'text-transform:uppercase;color:var(--text-2);">'+l+'</span>'
      +'<span data-fig="'+l+'" style="'+T('headline-medium')+'color:var(--text-1);font-variant-numeric:tabular-nums;">'+v+'</span>'
      +'<span data-figsub="'+l+'" style="'+T('body-medium')+'color:var(--text-2);">'+s+'</span></div>';
  }
  function render(id){
    const w=byId[id]; if(!w) return;
    const DM=window.WORKLOAD_DEMO, ND=window.NODE_DEMO;
    if(!DM||!ND) return;
    const pane=document.querySelector('[data-wl-pane="active"]'); if(!pane) return;
    const INV=DM.invoice;
    const nodes=(w.at||[]).map(function(a){return NODE[a[0]];}).filter(Boolean);
    const thr=REVIEW_FIXTURE.throughput[w.id]||{};
    let tot=0; for(const k in thr) tot+=thr[k];
    // TOTALS ARE DERIVED FROM THE ROWS ON SCREEN. This section exists to reconcile
    // two tallies, so a headline that disagrees with its own rows defeats it. The
    // spec's $0.1434 / $1.71 / 166 fall out of the sum when its six nodes are the
    // row set; they are never pinned over a different one.
    let gw=0, eng=0, reqs=0;
    for(const p of nodes){ const nd=ND[p[0]]||{};
      gw+=parseFloat(nd.amt||0); eng+=parseFloat(nd.eamt||0); reqs+=(nd.reqs||0); }
    const feePct=parseFloat(INV.fee)||50;
    const provider=gw/(1+feePct/100), fee=gw-provider;
    const f4=function(x){return x.toFixed(4);}, f2=function(x){return x.toFixed(2);};
    const wlCol='var(--wl-'+(COLOR[w.id]||'eric')+')';
    const resid=residency(nodes,ND,DM.failedRule);

    // MEASUREMENT — one shared small-multiple for all five metrics. Fixed 0..1
    // visual domain (never auto-scaled per metric), same 40px chart height, same
    // 40-sample window, same type roles. Reading order is label -> value -> avg
    // -> trend, so the figure outranks the chart. The dashed hairline is the mean
    // of the plotted window; semantic error colour appears only where the value
    // is itself an alert state (s.alert).
    const seriesHTML=DM.series.map(function(s){
      const w=120,h=40,n=40; let x=s.seed, raw=[];
      for(let i=0;i<n;i++){ x=(x*1103515245+12345)&0x7fffffff; raw.push((x%1000)/1000); }
      const Y=function(v){return (h-4-v*(h-8)).toFixed(1);};
      const pts=raw.map(function(v,i){return (i/(n-1)*w).toFixed(1)+','+Y(v);}).join(' ');
      let m=0; for(const v of raw) m+=v; const my=Y(m/n);
      const stroke=s.alert?'var(--md-sys-color-error)':wlCol;
      const vcol=s.alert?'var(--md-sys-color-error)':(s.value==='\u2014'?'var(--md-sys-color-on-surface-variant)':'var(--md-sys-color-on-surface)');
      return '<div style="min-width:0;display:flex;flex-direction:column;gap:12px;">'
      +'<div style="display:flex;flex-direction:column;gap:2px;">'
      +lab(s.label)
      +'<span style="'+T('headline-small')+'color:'+vcol+';font-variant-numeric:tabular-nums;">'+esc(s.value)+'</span>'
      +'<span style="'+T('body-small')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+esc(s.avg)+'</span></div>'
      +'<svg viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" style="width:100%;height:'+h+'px;display:block;overflow:visible;">'
      +'<line x1="0" y1="'+my+'" x2="'+w+'" y2="'+my+'" stroke="var(--md-sys-color-outline-variant)" stroke-width="1" stroke-dasharray="2 3" vector-effect="non-scaling-stroke"/>'
      +'<polyline points="'+pts+'" fill="none" stroke="'+stroke+'" stroke-width="1.25" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>'
      +'<circle cx="'+w+'" cy="'+Y(raw[n-1])+'" r="1.75" fill="'+stroke+'"/></svg></div>';}).join('');

    const nodeRows=nodes.map(function(pair){
      const n=pair[0], reg=pair[1], nd=ND[n]||{}, v=thr[n]||0, share=tot?Math.round(v/tot*100):0;
      // per-row evidence keeps only what differs between nodes; the workload-level
      // confidentiality / meter / time marks are stated once above the table
      const ev=[(HW[n]||''), reg+' \u00b7 '+(nd.juris||''), nd.inst+' \u00b7 '+CUR+nd.rate+'/hr'].join('  \u00b7  ');
      return '<div data-nrow><div data-nline>'
        +'<span data-cell="node" style="'+T('body-large')+'color:var(--md-sys-color-on-surface);">'+n+'</span>'
        +'<span data-cell="act" style="display:block;">'+spark(parseInt(nd.gpuS,10)||7,wlCol,56,18)+'</span>'
        +'<span data-cell="gpu" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.gpuS+'</span>'
        +'<span data-cell="tok" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.tok+'</span>'
        +'</div><div data-nev><span style="'+T('body-small')+'color:var(--md-sys-color-on-surface-variant);">'+esc(ev)+'</span></div></div>';}).join('');

    const sotRows=nodes.map(function(pair){
      const n=pair[0], nd=ND[n]||{};
      return '<div data-sotrow>'
        +'<span style="'+T('body-large')+'color:var(--md-sys-color-on-surface);">'+n+'</span>'
        +'<span style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+CUR+nd.amt+'</span>'
        +'<span data-sotcell="prompt" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.prompt+'</span>'
        +'<span data-sotcell="gen" style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.gen+'</span>'
        +'<span style="text-align:right;'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+nd.egpu+'</span>'
        +'<span style="text-align:right;'+T('body-large')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+nd.eamt+'</span>'
        +'<span data-sotcell="link" style="text-align:right;"><a href="#" aria-label="Open engine metrics for '+n+'" style="'+T('label-medium')+'color:var(--md-sys-color-primary);text-decoration:none;white-space:nowrap;">metrics \u2197</a></span>'
        +'</div>';}).join('');

    pane.innerHTML=
      '<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'
      +'<div style="display:flex;flex-direction:row;align-items:baseline;justify-content:space-between;gap:24px;flex-wrap:wrap;">'
      +over('Invoice')+'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);">'+esc(INV.job)+'</span></div>'
      +'<div style="display:flex;flex-direction:row;align-items:baseline;gap:16px;flex-wrap:wrap;">'
      +'<span style="'+T('display-small')+'color:var(--text-1);font-variant-numeric:tabular-nums;">'+CUR+f4(gw)+'</span>'
      +markHTML(INV.state,'accent')+'</div>'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);font-variant-numeric:tabular-nums;">'+reqs+' metered requests · provider cost '+CUR+f4(provider)+' + '+feePct+'% platform fee = '+CUR+f4(gw)+'</span>'
      +'<div style="display:flex;flex-direction:row;align-items:center;gap:8px;flex-wrap:wrap;">'
      +markHTML(DM.attestation)+'</div>'
      +'<div style="display:flex;flex-direction:column;align-items:flex-start;gap:4px;">'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-'+(resid?'error':'on-surface-variant')+');">'+(resid?'\u2717 Residency policy violation':'Residency policy not yet applicable')+'</span>'
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">'+esc(resid||'No serving nodes to place, so no region can be checked.')+'</span>'
      +'<md-text-button data-policy-toggle aria-expanded="false" aria-controls="wl-policy-detail">Policy detail</md-text-button>'
      +'<span id="wl-policy-detail" data-policy-detail hidden style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">Required: '+esc(DM.failedRule)+'</span></div>'
      +'<div style="display:flex;flex-direction:row;align-items:center;gap:8px;flex-wrap:wrap;padding-top:4px;">'
      +'<md-filled-button>Send test request</md-filled-button><md-outlined-button>Close and sign invoice</md-outlined-button><md-outlined-button>Verify ledger signatures</md-outlined-button></div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Measurement')
      +'<div style="align-self:stretch;display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:clamp(16px,2vw,32px);">'+seriesHTML+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Allocation')
      +'<div data-summary style="align-self:stretch;display:grid;grid-template-columns:repeat(auto-fit,minmax(168px,1fr));align-items:flex-start;gap:clamp(20px,3vw,48px) clamp(24px,3vw,48px);">'
      +figHTML('Allocated capacity', w.slots===0?'None':w.slots+(w.slots===1?' slot':' slots'), w.slots===0?'no capacity allocated':'of 59 across the fabric')
      +figHTML('Share of fabric', w.pct+'%', 'by allocated slots')
      +figHTML('Throughput', tot.toLocaleString('en-US')+' tok/s', 'gateway rate')
      +figHTML('Serving nodes', String(nodes.length), 'of 10 compute nodes')+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Serving nodes')
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);">'+esc([DM.tier,DM.meter,DM.timeAttestation].join('  \u00b7  '))+' \u2014 same for every node in this workload</span>'
      +'<div data-noderows style="align-self:stretch;display:flex;flex-direction:column;"><div data-nhead>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Node</span>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Activity</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">GPU seconds</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Tokens</span>'
      +'</div>'+nodeRows+'</div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;gap:16px;">'+over('Source of truth')
      +'<span style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);max-width:72ch;">Two independent tallies for the same work, node by node: what the gateway metered, and what the node\u2019s own inference engine counted. Bill = compute-seconds × provider on-demand rate + '+DM.platformFeePct+'% platform fee.</span>'
      +'<div data-sotrows style="align-self:stretch;display:flex;flex-direction:column;"><div data-sothead>'
      +'<span style="'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Node</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Gateway amount</span>'
      +'<span data-sotcell="prompt" style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Prompt</span>'
      +'<span data-sotcell="gen" style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Generated</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">GPU seconds</span>'
      +'<span style="text-align:right;'+T('label-medium')+'text-transform:uppercase;color:var(--text-2);">Engine amount</span>'
      +'<span data-sotcell="link"></span></div>'+sotRows+'</div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:column;align-items:flex-start;gap:8px;padding-top:8px;">'
      +'<span style="display:grid;grid-template-columns:minmax(0,140px) auto;align-items:baseline;gap:16px;">'+lab('Gateway amount \u00b7 metered')+'<span style="text-align:right;'+T('title-medium')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+f4(gw)+'</span></span>'
      +'<span style="display:grid;grid-template-columns:minmax(0,140px) auto;align-items:baseline;gap:16px;">'+lab('Engine amount \u00b7 independent')+'<span style="text-align:right;'+T('title-medium')+'color:var(--md-sys-color-on-surface);font-variant-numeric:tabular-nums;">'+CUR+f4(eng)+'</span></span>'
      +'<md-outlined-button style="margin-top:8px;">Bill from engine \u00b7 '+CUR+f2(eng)+'</md-outlined-button></div></div>'
      +'<div style="align-self:stretch;display:flex;flex-direction:row;align-items:center;gap:8px;">'
      +'<md-outlined-button data-open-log>View request log</md-outlined-button>'
      +'<md-outlined-button data-copy-key data-key="'+esc(DM.apiKey||'')+'" aria-label="Copy API key for this workload">Copy API key</md-outlined-button>'
      +'<span data-key-note aria-live="polite" style="'+T('body-medium')+'color:var(--md-sys-color-on-surface-variant);"></span></div>';
  }
  function detail(id){
    const w=byId[id]; if(!w) return;
    const t=document.querySelector('[data-wl-title]'); if(t) t.textContent=w.name;
    const nodesFor=(w.at||[]).map(function(a){return NODE[a[0]];}).filter(Boolean);
    const regs=[...new Set(nodesFor.map(function(n){return n[1];}))];
    // HEADER — name plus the headline verdict, nothing else. Node count and region
    // are canonical in Allocation and Serving nodes; the API key moved to the
    // invoice line as an operational identifier.
    const DM=window.WORKLOAD_DEMO||{};
    const mt=document.querySelector('[data-wl-meta]');
    if(mt) mt.remove();
    const hm=document.querySelector('[data-wl-headmarks]');
    const bad=/non-?compliant|fail/i.test(DM.verdict||'');
    if(hm) hm.innerHTML=markHTML(DM.verdict,bad?'error':null);
    render(id);
  }
  let rebuilding=false, lastPane=null;
  function paint(){
    const pane=document.querySelector('[data-wl-pane="active"]');
    if(!pane||!window.WORKLOAD_DEMO||rebuilding) return;
    if(pane===lastPane && !pane.querySelector('[data-seed]')) return;
    lastPane=pane; rebuilding=true;
    try{ detail(document.documentElement.dataset.currentWorkload||'eric-1'); }
    finally{ rebuilding=false; }
  }
  const settle=function(){ setTimeout(paint,0); setTimeout(paint,80); setTimeout(paint,300); };
  // observe a stable ancestor: the runtime replaces the pane node itself, and an
  // observer bound to the pane dies with it
  const watch=new MutationObserver(function(){ if(!rebuilding) paint(); });
  const arm=function(){
    const host=document.querySelector('[data-destination="Workloads"]');
    if(!host||!window.WORKLOAD_DEMO){ setTimeout(arm,50); return; }
    watch.observe(host,{childList:true,subtree:true});
    paint(); settle();
  };
  arm();
  window.addEventListener('load',settle);
  function applyFilters(){
    const el=document.querySelector('[data-wl-search]');
    const s=((el&&el.value)||'').trim().toLowerCase();
    const on={}; for(const c of document.querySelectorAll('[data-wlfilter]')) on[c.dataset.wlfilter]=!!c.selected;
    for(const it of document.querySelectorAll('[data-wl]')){
      const w=byId[it.dataset.wl];
      let ok=!s||(w&&((w.name||'').toLowerCase().indexOf(s)>=0||(w.id||'').toLowerCase().indexOf(s)>=0));
      if(ok&&on.cap) ok=it.dataset.cap==='1';
      if(ok&&on.multi) ok=it.dataset.multi==='1';
      it.style.display=ok?'flex':'none';
    }
  }
  document.addEventListener('click',function(ev){
    const t=ev.target;
    if(t.closest&&t.closest('[data-open-log]')){
      document.querySelector('[data-eviscrim]').style.display='block';
      const dr=document.querySelector('[data-evidrawer]'); dr.style.display='flex';
      const c=dr.querySelector('[data-close-log]'); if(c)c.focus(); return;
    }
    if((t.closest&&t.closest('[data-close-log]'))||t.matches('[data-eviscrim]')){
      document.querySelector('[data-eviscrim]').style.display='none';
      document.querySelector('[data-evidrawer]').style.display='none'; return;
    }
    const pt=t.closest&&t.closest('[data-policy-toggle]');
    if(pt){
      const det=document.querySelector('[data-policy-detail]');
      if(det){ const open=det.hasAttribute('hidden'); if(open) det.removeAttribute('hidden'); else det.setAttribute('hidden',''); pt.setAttribute('aria-expanded',String(open)); }
      return;
    }
    const ck=t.closest&&t.closest('[data-copy-key]');
    if(ck){
      const note=document.querySelector('[data-key-note]');
      const done=function(ok){ if(note) note.textContent=ok?'API key copied':'Copy unavailable — key: '+ck.dataset.key; };
      if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(ck.dataset.key).then(function(){done(true);},function(){done(false);});
      else done(false);
      return;
    }
    if(t.closest&&t.closest('[data-wlfilter]')){ setTimeout(applyFilters,0); return; }
    const tab=t.closest&&t.closest('[data-ctab]');
    if(tab){
      const tabs=[...document.querySelectorAll('[data-ctab]')];
      tabs.forEach(function(x){x.setAttribute('aria-selected',String(x===tab)); if('active' in x) x.active=(x===tab);});
      const names=['active','invoices','attestation'], which=names[tabs.indexOf(tab)];
      for(const n of names){ const p=document.querySelector('[data-wl-pane="'+n+'"]'); if(p) p.style.display=n===which?'flex':'none'; }
    }
  },true);
  document.addEventListener('keydown',function(ev){
    if(ev.key==='Escape'){
      const dr=document.querySelector('[data-evidrawer]');
      if(dr&&dr.style.display!=='none'){ document.querySelector('[data-eviscrim]').style.display='none'; dr.style.display='none'; }
    }
  });
  // delegated: the runtime may replace the field node on a template re-render, so
  // the listener lives on the document and matches the hook, not the node
  document.addEventListener('input',function(ev){ if(ev.target&&ev.target.closest&&ev.target.closest('[data-wl-search]')) applyFilters(); },true);
  const armSearch=function(){};
  armSearch();
  // ONE binding site for pointer and keyboard, re-run because the runtime replaces
  // the cards on re-render. Nested controls stay exempt.
  const armCards=function(){
    const cards=document.querySelectorAll('[data-wl]');
    for(const c of cards){
      if(c.dataset.wlArmed) continue;
      c.dataset.wlArmed='1';
      c.tabIndex=0; c.setAttribute('role','option');
      c.addEventListener('click',function(e){
        if(e.target.closest('md-icon-button')||e.target.closest('md-filter-chip')||e.target.closest('button')) return;
        window.activateWorkloadCard(c);
      });
      c.addEventListener('keydown',function(e){
        if(e.key==='Enter'||e.key===' '){ e.preventDefault(); window.activateWorkloadCard(c); }
      });
    }
    setTimeout(armCards,600);
  };
  armCards();
  window.activateWorkloadCard=function(card){
    const id=card&&card.dataset&&card.dataset.wl; if(!id) return;
    for(const s2 of document.querySelectorAll('[data-wl][data-selected]')) if(s2!==card) s2.removeAttribute('data-selected');
    card.setAttribute('data-selected','');
    document.documentElement.dataset.currentWorkload=id;
    lastPane=document.querySelector('[data-wl-pane="active"]');
    rebuilding=true;
    try{ detail(id); } finally{ rebuilding=false; }
  };
})();


// headerHeightToken — the rail's height is bounded by the viewport minus the real
// header; --header-h was never defined, so it silently used a wrong fallback.
(function headerHeightToken(){
  const set=function(){
    const h=document.querySelector('header');
    if(h) document.documentElement.style.setProperty('--header-h', Math.round(h.getBoundingClientRect().height)+'px');
    // the navigator rail is bounded by ITS SCROLL PORT, not by the viewport: the
    // host's content box is what the rail may occupy without the footer clipping it
    const port=document.querySelector('[data-wl-scroll]');
    if(port){
      const cs=getComputedStyle(port);
      const inner=port.clientHeight-parseFloat(cs.paddingTop||0)-parseFloat(cs.paddingBottom||0);
      const sb=Math.max(0, Math.round(port.offsetWidth-port.clientWidth));
      document.documentElement.style.setProperty('--wl-sb', sb+'px');
    }
  };
  set(); window.addEventListener('resize',set); window.addEventListener('load',set);
  setTimeout(set,300); setTimeout(set,1200);
})();


// HEADER GEOMETRY, MEASURED. The New workload overlay hangs off row 1's bottom
// edge and the app ground hangs off the header's, so both offsets are published
// from the RENDERED boxes instead of constants: row 1 wraps at narrow widths, and
// any constant is wrong the moment it does (verifier, 2026-09-11 — a 96px
// constant cut the panel through the middle of a 144px row).
(function headerGeometry(){
  const arm = () => {
    const h = document.querySelector('header');
    const r1 = h && h.children[0];
    if (!r1) { setTimeout(arm, 60); return; }
    const publish = () => {
      const a = Math.round(r1.getBoundingClientRect().height);
      const b = Math.round(h.getBoundingClientRect().height);
      const st = document.documentElement.style;
      if (a) st.setProperty('--header-row1-height', a + 'px');
      if (b) st.setProperty('--header-height', b + 'px');
    };
    publish();
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(publish);
      ro.observe(h); ro.observe(r1);
    }
    window.addEventListener('resize', publish);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(publish).catch(() => {});
  };
  arm();
})();

return {  };
})();
