// FIELD LANGUAGE — the hive as an ENVIRONMENTAL / DOMAIN layer.
//
// Three components only: a cavity, one aperture, a few comb planes. Deliberately
// kept apart from the other systems:
//   hive geometry   = physical context      (this file)
//   FCC / rhombic   = organisational structure  (swarm-core FCC_DIRS / RD_FACES)
//   thermal field   = emergent outcome      (treatments layerIsotherms)
//   agents / flow   = colony behaviour      (swarm-core)
// The hive is never coloured by temperature and never drawn from FCC geometry.

import { project } from './vendor/swarm-core.js';

const S = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const o4 = new Float32Array(4), o4b = new Float32Array(4);

// Visual-only. Presence never touches the swarm mathematics — it is independent
// of STRUCTURE PRESENCE by design, so hive and lattice can be judged separately.
export const HIVE_PRESENCE = {
  'None': { chamber: 0, entrance: 0, comb: 0, section: 0 },
  'Entrance only': { chamber: 0, entrance: 1, comb: 0, section: 0 },
  'Entrance + chamber': { chamber: 1, entrance: 1, comb: 0, section: 0 },
  'Chamber + sparse comb': { chamber: 1, entrance: 0.4, comb: 1, section: 0 },
  'Full contextual': { chamber: 1, entrance: 1, comb: 1, section: 1 }
};

export function makeHive(o = {}) {
  // The cavity is deliberately small relative to the frame: it is the boundary
  // the colony lives inside, so it has to occupy a central portion of the
  // composition rather than run past the viewport on every side.
  const hx = o.hx ?? 92, hy = o.hy ?? 50, hz = o.hz ?? 82;
  // aperture low and off-axis on the -z wall: never centred, never symmetric
  const ent = { x: o.ex ?? 68, y: o.ey ?? -29, z: -hz, r: o.er ?? 14 };
  const combs = o.combs ?? [-30, 18, 64];      // parallel comb plates, fixed z

  const h = {
    hx, hy, hz, ent, combs,
    // camera hypothesis: inside, oblique, entrance toward a frame edge, world
    // continuing past the viewport
    view: { target: [-2, -22, 6], yaw: Math.PI + 0.44, pitch: 0.16, dist: 252, fov: 900 },
    anchors: {
      far: [ent.x, ent.y, -hz - 118],
      outside: [ent.x, ent.y, -hz - 46],
      mouth: [ent.x * 0.94, ent.y * 0.9, -hz + 10],
      inner: [ent.x * 0.6, ent.y * 0.62, -hz + 58],
      deep: [ent.x * 0.34, ent.y * 0.4, -hz + 82]
    },
    inside(x, y, z) { return Math.abs(x) < hx && Math.abs(y) < hy && Math.abs(z) < hz; },
    // ENVIRONMENTAL GATING. Outside the cavity the probe is not a threat the
    // colony can answer; the entrance neighbourhood registers as local detection
    // only; inside, the full defensive sequence is available.
    gate(x, y, z) {
      if (h.inside(x, y, z)) return 1;
      const dxy = Math.hypot(x - ent.x, y - ent.y);
      const out = -hz - z;
      if (out < 0 || out > 100 || dxy > ent.r * 2.9) return 0;
      return 0.62 * (1 - S(ent.r * 0.85, ent.r * 2.9, dxy)) * (1 - S(6, 94, out));
    },
    // the unattended intruder: approach, cross, wander, retreat
    autoPath(a) {
      const u = ((a * 0.16) % 1 + 1) % 1, A = h.anchors;
      const L = (p, q, w) => [p[0] + (q[0] - p[0]) * w, p[1] + (q[1] - p[1]) * w, p[2] + (q[2] - p[2]) * w];
      if (u < 0.20) return L(A.far, A.outside, u / 0.20);
      if (u < 0.32) return L(A.outside, A.mouth, (u - 0.20) / 0.12);
      if (u < 0.48) return L(A.mouth, A.inner, (u - 0.32) / 0.16);
      if (u < 0.70) return L(A.inner, A.deep, (u - 0.48) / 0.22);
      if (u < 0.82) return L(A.deep, A.mouth, (u - 0.70) / 0.12);
      return L(A.mouth, A.far, (u - 0.82) / 0.18);
    }
  };
  return h;
}

// ---- drawing helpers -------------------------------------------------------
const pt = (view, x, y, z, out) => project(view.cam, x, y, z, view.W, view.H, out);

function polyline(ctx, view, pts, close) {
  ctx.beginPath();
  for (let i = 0; i < pts.length; i++) {
    pt(view, pts[i][0], pts[i][1], pts[i][2], o4);
    i ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
  }
  if (close) ctx.closePath();
  ctx.stroke();
}
function segmented(ctx, view, A, B, n, duty, tickEvery) {
  for (let i = 0; i < n; i++) {
    const u0 = i / n, u1 = u0 + duty / n;
    pt(view, A[0] + (B[0] - A[0]) * u0, A[1] + (B[1] - A[1]) * u0, A[2] + (B[2] - A[2]) * u0, o4);
    const x0 = o4[0], y0 = o4[1];
    pt(view, A[0] + (B[0] - A[0]) * u1, A[1] + (B[1] - A[1]) * u1, A[2] + (B[2] - A[2]) * u1, o4b);
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(o4b[0], o4b[1]); ctx.stroke();
    if (tickEvery && i % tickEvery === 0) {
      const dx = o4b[0] - x0, dy = o4b[1] - y0, L = Math.hypot(dx, dy) || 1, t = 3.2;
      ctx.beginPath();
      ctx.moveTo(x0 - (-dy / L) * t, y0 - (dx / L) * t);
      ctx.lineTo(x0 + (-dy / L) * t, y0 + (dx / L) * t);
      ctx.stroke();
    }
  }
}
function reg(ctx, view, p, c) {
  pt(view, p[0], p[1], p[2], o4);
  ctx.beginPath();
  ctx.moveTo(o4[0] - c, o4[1]); ctx.lineTo(o4[0] + c, o4[1]);
  ctx.moveTo(o4[0], o4[1] - c); ctx.lineTo(o4[0], o4[1] + c);
  ctx.stroke();
}
function scr(view, pts) {
  const out = [];
  for (const p of pts) { pt(view, p[0], p[1], p[2], o4); out.push([o4[0], o4[1]]); }
  return out;
}
function fillPoly(ctx, sp, style) {
  ctx.beginPath();
  for (let i = 0; i < sp.length; i++) i ? ctx.lineTo(sp[i][0], sp[i][1]) : ctx.moveTo(sp[i][0], sp[i][1]);
  ctx.closePath(); ctx.fillStyle = style; ctx.fill();
}

// shared topology: the entrance wall, the recession edges, the floor
function topo(h) {
  const { hx, hy, hz } = h, back = -hz + 2 * hz * 0.6;
  return {
    F: [[-hx, -hy, -hz], [hx, -hy, -hz], [hx, hy, -hz], [-hx, hy, -hz]],
    R: [[-hx, -hy, back], [hx, -hy, back], [hx, hy, back], [-hx, hy, back]],
    floorZ: [-hz + 2 * hz * 0.30, -hz + 2 * hz * 0.62]
  };
}
function combQuad(h, z) {
  const x0 = -h.hx * 0.76, x1 = h.hx * 0.76, y0 = -h.hy * 0.88, y1 = h.hy * 0.56;
  return [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]];
}
// real comb geometry, used sparingly because it IS the physical architecture
function cells(h, z, cb) {
  const r = 8.6, dx = r * Math.sqrt(3), dy = r * 1.5;
  for (let row = 0; row < 3; row++) for (let col = 0; col < 5; col++)
    cb(-h.hx * 0.58 + col * dx + (row % 2 ? dx * 0.5 : 0), -h.hy * 0.74 + row * dy, r, row, col);
}
function hexPts(cx, cy, z, r) {
  const p = [];
  for (let k = 0; k < 6; k++) {
    const a = Math.PI / 6 + k * Math.PI / 3;
    p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r, z]);
  }
  return p;
}
const ringPts = (ent, n, k) => {
  const p = [];
  for (let i = 0; i < n; i++) {
    const a = 2 * Math.PI * i / n;
    p.push([ent.x + Math.cos(a) * ent.r * k, ent.y + Math.sin(a) * ent.r * k, ent.z]);
  }
  return p;
};

// ---- 1A engraved survey ----------------------------------------------------
function chamberI(ctx, view, h, P, pres) {
  const { F, R, floorZ } = topo(h);
  ctx.lineWidth = 0.6; ctx.strokeStyle = P.a('ink', 0.26);
  polyline(ctx, view, F, true);
  ctx.lineWidth = 0.5; ctx.strokeStyle = P.a('ink', 0.15);
  for (let i = 0; i < 4; i++) polyline(ctx, view, [F[i], R[i]], false);
  ctx.strokeStyle = P.a('graphite', 0.28);
  for (let k = 1; k <= 3; k++) {                       // section lines across the wall
    const y = -h.hy + 2 * h.hy * k / 4;
    polyline(ctx, view, [[-h.hx, y, -h.hz], [h.hx, y, -h.hz]], false);
  }
  for (let k = 1; k <= 3; k++) {
    const x = -h.hx + 2 * h.hx * k / 4;
    polyline(ctx, view, [[x, -h.hy, -h.hz], [x, h.hy, -h.hz]], false);
  }
  ctx.strokeStyle = P.a('graphite', 0.22);
  for (const z of floorZ) polyline(ctx, view, [[-h.hx, -h.hy, z], [h.hx, -h.hy, z]], false);
  if (pres.section) {                                  // survey stations along the sill
    ctx.strokeStyle = P.a('ink', 0.3); ctx.lineWidth = 0.5;
    for (let k = 0; k <= 16; k++) {
      const x = -h.hx + 2 * h.hx * k / 16, t = k % 4 ? 3 : 6;
      pt(view, x, -h.hy, -h.hz, o4);
      ctx.beginPath(); ctx.moveTo(o4[0], o4[1]); ctx.lineTo(o4[0], o4[1] - t); ctx.stroke();
    }
    polyline(ctx, view, [[-h.hx, h.hy * 0.1, -h.hz], [-h.hx, h.hy * 0.1, R[0][2]]], false);
  }
}
function entI(ctx, view, h, P, k) {
  const e = h.ent;
  fillPoly(ctx, scr(view, ringPts(e, 40, 1)), P.a('ink', 0.055 * k));
  ctx.lineWidth = 0.75; ctx.strokeStyle = P.a('ink', 0.5 * k);
  polyline(ctx, view, ringPts(e, 48, 1), true);
  ctx.lineWidth = 0.5; ctx.strokeStyle = P.a('ink', 0.2 * k);
  polyline(ctx, view, ringPts(e, 48, 1.34), true);
  ctx.strokeStyle = P.a('ink', 0.34 * k);               // measured entrance marks
  for (let i = 0; i < 12; i++) {
    const a = i * Math.PI / 6;
    polyline(ctx, view, [
      [e.x + Math.cos(a) * e.r * 1.06, e.y + Math.sin(a) * e.r * 1.06, e.z],
      [e.x + Math.cos(a) * e.r * 1.28, e.y + Math.sin(a) * e.r * 1.28, e.z]], false);
  }
  ctx.strokeStyle = P.a('graphite', 0.42 * k); ctx.lineWidth = 0.5;
  polyline(ctx, view, [[e.x - e.r * 1.8, e.y, e.z], [e.x + e.r * 1.8, e.y, e.z]], false);
  for (const s of [-1, 1]) polyline(ctx, view, [
    [e.x + s * e.r * 1.8, e.y - 4.5, e.z], [e.x + s * e.r * 1.8, e.y + 4.5, e.z]], false);
}
function combI(ctx, view, h, P) {
  ctx.lineWidth = 0.5;
  for (const z of h.combs) {
    ctx.strokeStyle = P.a('ink', 0.13);
    polyline(ctx, view, combQuad(h, z), true);
    ctx.strokeStyle = P.a('graphite', 0.3);
    cells(h, z, (cx, cy, r) => polyline(ctx, view, hexPts(cx, cy, z, r), true));
  }
}

// ---- 1B interval notation --------------------------------------------------
function chamberII(ctx, view, h, P, pres) {
  const { F, R, floorZ } = topo(h);
  ctx.lineWidth = 0.9; ctx.strokeStyle = P.a('ink', 0.3);
  for (let i = 0; i < 4; i++) segmented(ctx, view, F[i], F[(i + 1) % 4], 12, 0.42, 4);
  ctx.strokeStyle = P.a('ink', 0.2);
  for (let i = 0; i < 4; i++) segmented(ctx, view, F[i], R[i], 7, 0.36, 0);
  ctx.strokeStyle = P.a('graphite', 0.34);
  for (let k = 1; k <= 3; k++) {
    const y = -h.hy + 2 * h.hy * k / 4;
    segmented(ctx, view, [-h.hx, y, -h.hz], [h.hx, y, -h.hz], 16, 0.3, 0);
  }
  for (const z of floorZ) segmented(ctx, view, [-h.hx, -h.hy, z], [h.hx, -h.hy, z], 14, 0.28, 0);
  ctx.lineWidth = 0.8; ctx.strokeStyle = P.a('gold', 0.34);   // registration signs
  for (const p of F) reg(ctx, view, p, 3.4);
  for (const p of R) reg(ctx, view, p, 2.4);
  if (pres.section) {
    ctx.strokeStyle = P.a('ink', 0.3); ctx.lineWidth = 0.7;
    for (let k = 0; k <= 8; k++) {
      const x = -h.hx + 2 * h.hx * k / 8;
      pt(view, x, -h.hy, -h.hz, o4);
      ctx.beginPath(); ctx.moveTo(o4[0], o4[1]); ctx.lineTo(o4[0], o4[1] - (k % 2 ? 3 : 6)); ctx.stroke();
    }
  }
}
function entII(ctx, view, h, P, k) {
  const e = h.ent, n = 48;
  fillPoly(ctx, scr(view, ringPts(e, 40, 1)), P.a('ink', 0.05 * k));
  ctx.lineWidth = 1.0; ctx.strokeStyle = P.a('ink', 0.55 * k);
  const R1 = ringPts(e, n, 1);
  for (let s = 0; s < 16; s++) {                        // segmented boundary notation
    const a = s * 3, b = a + 2;
    ctx.beginPath();
    for (let i = a; i <= b; i++) {
      const p = R1[i % n]; pt(view, p[0], p[1], p[2], o4);
      i === a ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
    }
    ctx.stroke();
  }
  ctx.lineWidth = 0.8; ctx.strokeStyle = P.a('ink', 0.34 * k);
  for (let i = 0; i < 8; i++) {                          // interval marks
    const a = i * Math.PI / 4;
    polyline(ctx, view, [
      [e.x + Math.cos(a) * e.r * 1.12, e.y + Math.sin(a) * e.r * 1.12, e.z],
      [e.x + Math.cos(a) * e.r * 1.34, e.y + Math.sin(a) * e.r * 1.34, e.z]], false);
  }
  ctx.strokeStyle = P.a('gold', 0.42 * k); ctx.lineWidth = 0.8;
  for (const s of [[-1, -1], [1, -1], [1, 1], [-1, 1]])
    reg(ctx, view, [e.x + s[0] * e.r * 1.42, e.y + s[1] * e.r * 1.42, e.z], 3);
}
function combII(ctx, view, h, P) {
  ctx.lineWidth = 0.8;
  for (const z of h.combs) {
    ctx.strokeStyle = P.a('ink', 0.16);
    const q = combQuad(h, z);
    segmented(ctx, view, q[3], q[2], 14, 0.3, 0);
    ctx.strokeStyle = P.a('graphite', 0.4);
    cells(h, z, (cx, cy, r, row, col) => {              // sampled comb geometry
      if ((row + col) % 2) return;
      const p = hexPts(cx, cy, z, r);
      for (let s = 0; s < 6; s += 2) polyline(ctx, view, [p[s], p[s + 1]], false);
    });
  }
}

// ---- 1C coherence field ----------------------------------------------------
function chamberIII(ctx, view, h, P, pres) {
  const { F, R } = topo(h);
  // the quads run well past the cavity so their own edges never read as a
  // contour: what is drawn is a transition, not a boundary
  const wx = h.hx * 2.2, wyLo = -h.hy * 1.9, wyHi = h.hy * 1.05;
  const sp = scr(view, [[-wx, wyLo, -h.hz], [wx, wyLo, -h.hz], [wx, wyHi, -h.hz], [-wx, wyHi, -h.hz]]);
  let y0 = 1e9, y1 = -1e9;
  for (const p of sp) { y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); }
  const g = ctx.createLinearGradient(0, y1, 0, y0);     // density transition, no contour
  g.addColorStop(0, P.a('graphite', 0.15));
  g.addColorStop(0.5, P.a('graphite', 0.05));
  g.addColorStop(1, P.a('graphite', 0));
  fillPoly(ctx, sp, g);
  const fl = scr(view, [[-wx, -h.hy, -h.hz], [wx, -h.hy, -h.hz], [wx, -h.hy, R[1][2]], [-wx, -h.hy, R[0][2]]]);
  const g2 = ctx.createLinearGradient(0, y1 + 30, 0, y1 - 90);
  g2.addColorStop(0, P.a('graphite', 0.11));
  g2.addColorStop(1, P.a('graphite', 0));
  fillPoly(ctx, fl, g2);
  if (pres.section) {                                   // the faintest possible edge
    ctx.strokeStyle = P.a('graphite', 0.2); ctx.lineWidth = 0.5;
    polyline(ctx, view, [F[0], F[1]], false);
    polyline(ctx, view, [F[0], F[3]], false);
  }
}
function entIII(ctx, view, h, P, k) {
  const e = h.ent;
  pt(view, e.x, e.y, e.z, o4);
  const rp = Math.max(6, e.r * o4[3]);
  const g = ctx.createRadialGradient(o4[0], o4[1], 0, o4[0], o4[1], rp * 2.3);
  g.addColorStop(0, P.a('ink', 0.16 * k));
  g.addColorStop(0.42, P.a('ink', 0.07 * k));
  g.addColorStop(1, P.a('ink', 0));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(o4[0], o4[1], rp * 2.3, 0, 6.2832); ctx.fill();
  ctx.strokeStyle = P.a('ink', 0.3 * k); ctx.lineWidth = 0.6;
  const R1 = ringPts(e, 48, 1);
  ctx.beginPath();
  for (let i = 26; i <= 44; i++) {
    const p = R1[i % 48]; pt(view, p[0], p[1], p[2], o4b);
    i === 26 ? ctx.moveTo(o4b[0], o4b[1]) : ctx.lineTo(o4b[0], o4b[1]);
  }
  ctx.stroke();
}
function combIII(ctx, view, h, P) {
  for (const z of h.combs) {
    fillPoly(ctx, scr(view, combQuad(h, z)), P.a('graphite', 0.035));
    cells(h, z, (cx, cy, r, row, col) => {
      if ((row + col) % 3) return;
      fillPoly(ctx, scr(view, hexPts(cx, cy, z, r)), P.a('graphite', 0.055));
    });
  }
}

const BY_T = {
  I: { chamber: chamberI, ent: entI, comb: combI },
  II: { chamber: chamberII, ent: entII, comb: combII },
  III: { chamber: chamberIII, ent: entIII, comb: combIII }
};

// Same hive topology in all three columns, expressed through each treatment's
// own formal grammar. Drawn before the colony: it is context, not subject.
export function drawHive(ctx, sim, view, P, pres) {
  const h = view.hive;
  if (!h || !pres) return;
  const g = BY_T[view.t] || BY_T.I;
  ctx.save();
  ctx.lineCap = 'butt'; ctx.setLineDash([]);
  if (pres.chamber) g.chamber(ctx, view, h, P, pres);
  if (pres.comb) g.comb(ctx, view, h, P);
  if (pres.entrance) g.ent(ctx, view, h, P, pres.entrance);
  ctx.restore();
}
