// WORLD SCENE — one persistent spherical operational world, three lenses.
//
// The world is drawn ONCE per frame from one camera; the lens weights
// (mapK / nodesK / swarmK, eased in the driver) only redistribute emphasis:
//   MAP        geography + nodes + traffic dominate, capacity recedes to ambience
//   NODE STATS same world, node marks and telemetry gain emphasis
//   SWARM      geography recedes to the v2 whisper, capacity behaviour dominates
//
// Geography comes from the source's real geo data (geo-land.js): a dense
// fibonacci stipple of actual land, never hand-drawn coastline strokes. Every
// third stipple point is the v2 "faint anchoring" layer and is always present;
// the other two thirds fade in with the Map lens, so Map reads as a fuller
// geographic world and Swarm as the approved faint one — the SAME points, so
// the transition is a change of reading, not of world.
//
// Capacity rendering (trails, hexagons, capped chroma, engaged fill) is the
// session board language over the untouched v2 behaviour. No new metrics.

import { project, isolines } from './vendor/swarm-core.js';
import { T, rgbaT, themeName } from './theme.js';
import { toSphere, POLYS } from './geo-land.js';

const o4 = new Float32Array(4), o4b = new Float32Array(4), o4c = new Float32Array(4);

export const HEAT_ON = 0.16;
// v4 colour grammar: teal is STRUCTURAL (selected node, control, YOU); engaged
// capacity takes ONE controlled WARM accent — a narrow gold band that never
// travels toward orange-red, so coordination can never read as thermal danger.
const STOPS = [[0.16, 148, 126, 86], [0.40, 178, 148, 90], [0.70, 205, 167, 95], [1, 222, 180, 100]];
export function heatRGB(T) {
  if (!(T >= HEAT_ON)) return null;
  for (let i = 1; i < STOPS.length; i++) {
    const a = STOPS[i - 1], b = STOPS[i];
    if (T <= b[0] || i === STOPS.length - 1) {
      const u = Math.max(0, Math.min(1, (T - a[0]) / (b[0] - a[0])));
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  return null;
}
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const INK = a => rgbaT('ink', a);
const LIT = a => rgbaT('lit', a);
const TEAL = a => rgbaT('primary', a);   // legacy name; reads the primary role
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
// Geometry and TYPE do not want the same factor: marks need a nudge to stay
// visible on a large panel, but the type is already sized like the DOM chrome
// around it and blows up fast. Two gentle factors, both tightly capped.
let UIK = 1, FK = 1, SK = 1;
export function setUiScale(k) {
  UIK = Math.max(1, Math.min(1.55, k));
  FK = Math.max(1, Math.min(1.22, 1 + (k - 1) * 0.28));
  SK = Math.max(1, Math.min(1.2, 1 + (UIK - 1) * 0.35));   // geography stipple
}
const fpx = px => (px * FK).toFixed(1) + 'px ui-monospace, Menlo, monospace';
const fpxw = (px, w) => w + ' ' + (px * FK).toFixed(1) + 'px ui-monospace, Menlo, monospace';
const ACC = a => rgbaT('primary', a);    // selection accent = primary role
const WRM = a => rgbaT('teal', a);   // the engagement accent, as type

function camFwd(cam) {
  const cy = Math.cos(cam.yaw), sy = Math.sin(cam.yaw);
  const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
  return [sy * cp, sp, cy * cp];
}
const dn = (cam, d, R) => Math.max(0, Math.min(1, (cam.dist + R * 0.9 - d) / (R * 1.8)));

function hexPath(ctx, x, y, r, a0) {
  ctx.beginPath();
  for (let k = 0; k < 6; k++) {
    const a = a0 + k * Math.PI / 3;
    const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
    k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
  }
  ctx.closePath();
}

// ---- the sphere itself: volume, limb, computational graticule ----------------
// Built from the SAME eased projection as land and regions, so all layers of
// the world agree. The graticule belongs to the Map reading and fades with it.
export function buildGraticule(SR) {
  const lines = [];
  for (const lat of [-60, -30, 0, 30, 60]) {
    const pts = [];
    for (let lon = -180; lon <= 180; lon += 4) pts.push(toSphere(lat, lon, SR * 1.001));
    lines.push(pts);
  }
  for (let lon = -180; lon < 180; lon += 30) {
    const pts = [];
    for (let lat = -80; lat <= 80; lat += 4) pts.push(toSphere(lat, lon, SR * 1.001));
    lines.push(pts);
  }
  return lines;
}

// ---- landmass as CONTINUOUS SURFACE ------------------------------------------
// The stipple alone leaves the world reading as scattered marks; filled
// silhouettes with a hairline coast give the sphere a real geographic surface
// that stays legible at every zoom scale, and it is the layer that makes local
// focus useful. Subtle by construction: a hair above the ocean, never a fill
// that competes with capacity.
let RINGS = null;
function rings(SR) {
  if (RINGS && RINGS.SR === SR) return RINGS.r;
  const out = [];
  for (const ring of POLYS) {
    if (ring.length < 4) continue;
    const pts = [];
    for (const [lon, lat] of ring) {
      const p = toSphere(lat, lon, SR);
      const l = Math.hypot(p[0], p[1], p[2]) || 1;
      pts.push([p[0], p[1], p[2], p[0] / l, p[1] / l, p[2] / l]);
    }
    out.push(pts);
  }
  RINGS = { SR, r: out };
  return out;
}
export function drawLandFill(ctx, cam, W, H, SR, mapK, zoom) {
  const f = camFwd(cam);
  const rs = rings(SR);
  // v3: MAP is an operational reference layer, so the land actually reads —
  // a filled silhouette a clear step above the ocean plus a legible hairline
  // coast. Swarm never gets here (it is weighted out by mapK in the driver), so
  // raising the contrast cannot make the capacity view noisier.
  const zk = Math.min(1, Math.max(0, (zoom - 1.6) / 1.4));
  const fillA = (0.60 + 0.34 * mapK) + 0.28 * zk;
  ctx.fillStyle = rgbaT('backing', Math.min(0.97, fillA));
  ctx.strokeStyle = rgbaT('outline', 0.18 + 0.28 * mapK + 0.24 * zk);
  ctx.lineWidth = Math.min(1.5, 0.75 + 0.16 * zoom);
  for (const pts of rs) {
    // a ring entirely on the far side is skipped; one that straddles the limb
    // has its far vertices slid onto the terminator, so the outline stays closed
    let front = 0;
    for (const q of pts) if (-(q[3] * f[0] + q[4] * f[1] + q[5] * f[2]) > 0) front++;
    if (!front) continue;
    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) {
      const q = pts[i];
      const d = q[3] * f[0] + q[4] * f[1] + q[5] * f[2];
      let x = q[0], y = q[1], z = q[2];
      if (d > 0) {                          // behind the limb: project onto it
        let ux = q[3] - f[0] * d, uy = q[4] - f[1] * d, uz = q[5] - f[2] * d;
        const l = Math.hypot(ux, uy, uz) || 1;
        x = ux / l * SR; y = uy / l * SR; z = uz / l * SR;
      }
      project(cam, x, y, z, W, H, o4);
      i ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
    }
    ctx.closePath();
    ctx.fill();
    if (mapK > 0.02 || zoom > 1.4) ctx.stroke();
  }
}

// ---- one label layer, one collision registry ---------------------------------
// Labels are ANNOTATIONS: they live outside the capacity they describe, joined
// back to it by a short leader. Every label in the frame competes in one
// registry, so nothing can overlap anything else, and the passes run in
// priority order — cohorts first, then region names, then places, then node
// ids — so when the frame gets busy the least important labels simply do not
// get a slot. Keep-out discs cover the active cohorts, so no label can ever
// land on top of moving hexagons.
let LBL = [], KEEP = [], BANDS = [];
export function keepOutRect(x, y, w, h) { BANDS.push([x, y, w, h]); }
export function beginLabels(ctx) {
  LBL.length = 0; KEEP.length = 0; BANDS.length = 0;
  // one baseline for every pass, so the box that was collision-tested is the
  // box that gets painted: each label draws at y + h/2
  if (ctx) ctx.textBaseline = 'middle';
}
export function keepOut(x, y, r) { KEEP.push([x, y, r]); }
// UI chrome is not a label: panels and control rails are the one thing a fixed-
// offset label is allowed to dodge, by flipping to its other side.
function clearOfBands(x, y, w, h) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  return x >= 6 && x + w <= W_LAST - 8;
}
let W_LAST = 1600;
export function setLabelWidth(w) { W_LAST = w; }
// With fixed-offset labels, occasional overlap is accepted — but the text-clearing
// backing must NOT be: destination-out would erase whatever type is already
// underneath. So a label that lands on an existing label draws WITHOUT its
// backing; the two simply cross, and neither is destroyed.
function hitsLabel(x, y, w, h) {
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    if (x < r[0] + r[2] && x + w > r[0] && y < r[1] + r[3] && y + h > r[1]) return true;
  }
  return false;
}
function free(x, y, w, h) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    // minimum external clearance between any two placed information objects
    if (x < r[0] + r[2] + 6 && x + w + 6 > r[0] && y < r[1] + r[3] + 5 && y + h + 5 > r[1]) return false;
  }
  for (let i = 0; i < KEEP.length; i++) {
    const k = KEEP[i];
    // exact circle-vs-rectangle test with external clearance, so a marker can
    // never sit inside any part of a label box — including the far end of a
    // wide card, which the old centre-distance approximation let through
    const px2 = Math.max(x, Math.min(k[0], x + w));
    const py2 = Math.max(y, Math.min(k[1], y + h));
    if (Math.hypot(k[0] - px2, k[1] - py2) < k[2] + 4) return false;
  }
  return true;
}
// Same test WITHOUT the marker keep-out discs: for a node id, sitting close to a
// neighbouring node dot is proximity, not a collision — and being pushed off its
// own node's centre line for that is worse than the near miss. Only real
// information objects (other labels, page controls) can displace it.
function freeOfLabels(x, y, w, h, sx, sy) {
  for (let i = 0; i < BANDS.length; i++) {
    const b = BANDS[i];
    if (x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]) return false;
  }
  for (let i = 0; i < LBL.length; i++) {
    const r = LBL[i];
    // generous HORIZONTAL clearance so two ids on nearly the same line can never
    // read as one run of text; no vertical padding, so ids one line apart may
    // both stay on their own node's centre line
    if (x < r[0] + r[2] + 8 && x + w + 8 > r[0] && y < r[1] + r[3] && y + h > r[1]) return false;
  }
  // other nodes' markers are respected (a label must not sit on another node's
  // dot); the label's OWN marker is not, since the gap already clears it
  for (let i = 0; i < KEEP.length; i++) {
    const k = KEEP[i];
    if (sx !== undefined && Math.hypot(k[0] - sx, k[1] - sy) < 3) continue;
    const px2 = Math.max(x, Math.min(k[0], x + w));
    const py2 = Math.max(y, Math.min(k[1], y + h));
    if (Math.hypot(k[0] - px2, k[1] - py2) < k[2] + 1) return false;
  }
  return true;
}
// candidate slots ring the anchor at growing radii; the first free one wins,
// and null means "no room — do not draw this label at all"
const SLOTS = [-0.30, 0.30, -0.95, 0.95, -1.75, 1.75, 2.55, -2.55, Math.PI];
export function placeLabel(ax, ay, w, h, rad, W, H, must, near) {
  // near = a label that must read as ONE UNIT with its mark (node ids): the
  // candidate rings hug the anchor instead of ringing it at annotation distance
  const RINGS2 = near
    ? [rad + 7 * FK, rad + 15 * FK, rad + 28 * FK, rad + 46 * FK]
    : [rad + 16 * FK, rad + 40 * FK, rad + 68 * FK, rad + 104 * FK];
  for (const R of RINGS2) {
    for (const a of SLOTS) {
      const px = ax + Math.cos(a) * R, py = ay + Math.sin(a) * R * 0.62;
      const left = px < ax;
      const x = left ? px - w : px, y = py - h / 2;
      if (x < 6 || x + w > W - 8 || y < 20 || y + h > H - 8) continue;
      if (!free(x, y, w, h)) continue;
      LBL.push([x, y, w, h]);
      return [x, y, left, px, py];
    }
  }
  // v3: an IMPORTANT label is never solved by hiding it. When every candidate
  // slot is taken, park it just outside the anchor on whichever side has room
  // and clamp it into the panel. Only region-level labels ask for this.
  if (!must) return null;
  // park on the roomier side first, then the other, walking vertically in
  // whole-box steps; only if the whole panel is exhausted does it overlap
  const sides = ax > W * 0.55 ? [true, false] : [false, true];
  const y0 = ay - h / 2;
  for (const left of sides) {
    const x0 = Math.max(6, Math.min(W - 8 - w,
      left ? ax - rad - 14 * FK - w : ax + rad + 14 * FK));
    for (const dir of [1, -1]) {
      for (let s = 0; s < 12; s++) {
        const y = y0 + dir * s * (h + 8);
        if (y < 20 || y + h > H - 8) break;
        if (!free(x0, y, w, h)) continue;
        LBL.push([x0, y, w, h]);
        return [x0, y, left, left ? x0 + w : x0, y + h / 2];
      }
    }
  }
  const leftF = sides[0];
  const xF = Math.max(6, Math.min(W - 8 - w, leftF ? ax - rad - 14 * FK - w : ax + rad + 14 * FK));
  const yF = Math.max(20, Math.min(H - 8 - h, y0));
  LBL.push([xF, yF, w, h]);
  return [xF, yF, leftF, leftF ? xF + w : xF, yF + h / 2];
}
// NOT a card: the backing ERASES the canvas noise behind the text
// (destination-out), so the actual stage — the panel's own ground — shows
// through, exactly. Nothing frames it: no border, no radius, no shadow, no
// tint. Its only job is to clear visual noise behind the type; against the
// stage it is invisible as a rectangle.
function clearBox(ctx, x, y, w, h, a) {
  ctx.save();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.globalAlpha = Math.min(1, a * 1.7);
  ctx.fillStyle = '#000';
  ctx.fillRect(x, y, w, h);
  ctx.restore();
}
// the anchor a regional leader line starts FROM: a small technical tick target —
// a hair ring with a centre dot — sitting on the real thing being described
function anchorMark(ctx, x, y, alpha) {
  ctx.strokeStyle = INK(0.55 * alpha);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath(); ctx.arc(x, y, 4.5 * UIK, 0.6, 0.6 + 4.4); ctx.stroke();
  ctx.fillStyle = INK(0.7 * alpha);
  ctx.beginPath(); ctx.arc(x, y, 1.1 * UIK, 0, 6.2832); ctx.fill();
}
function leader(ctx, ax, ay, lx, ly, alpha) {
  ctx.strokeStyle = INK(0.26 * alpha);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath();
  ctx.moveTo(ax, ay); ctx.lineTo(lx, ly);
  ctx.stroke();
}

// ---- place names: real settlements near each region -------------------------
// They appear only at LOCAL scale, and they are what makes a close-up an
// operational view instead of a magnified dot. Real coordinates, no invention.
const PLACES = {
  ohio: [['Columbus', 39.96, -83.00], ['Dublin', 40.10, -83.11], ['Delaware', 40.30, -83.07],
         ['Newark', 40.06, -82.40], ['Lancaster', 39.71, -82.60], ['Springfield', 39.92, -83.81],
         ['Marysville', 40.24, -83.37], ['Circleville', 39.60, -82.95], ['Grove City', 39.88, -83.09]],
  frankfurt: [['Frankfurt', 50.11, 8.68], ['Offenbach', 50.10, 8.77], ['Hanau', 50.13, 8.92],
              ['Darmstadt', 49.87, 8.65], ['Mainz', 49.99, 8.25], ['Wiesbaden', 50.08, 8.24]],
  dublin: [['Dublin', 53.35, -6.26], ['Swords', 53.46, -6.22], ['Bray', 53.20, -6.11],
           ['Malahide', 53.45, -6.15], ['Tallaght', 53.29, -6.37]],
  london: [['London', 51.51, -0.13], ['Croydon', 51.37, -0.10], ['Watford', 51.66, -0.40],
           ['Bromley', 51.41, 0.01], ['Ilford', 51.56, 0.07]]
};
export function drawPlaces(ctx, cam, W, H, SR, focusId, localA) {
  if (localA < 0.03 || !focusId || !PLACES[focusId]) return;
  const f = camFwd(cam);
  ctx.font = fpx(10);
  ctx.textAlign = 'left';
  for (const [name, lat, lon] of PLACES[focusId]) {
    const p = toSphere(lat, lon, SR);
    const l = Math.hypot(p[0], p[1], p[2]) || 1;
    if (-(p[0] / l * f[0] + p[1] / l * f[1] + p[2] / l * f[2]) < 0.05) continue;
    project(cam, p[0], p[1], p[2], W, H, o4);
    const wT = ctx.measureText(name).width;
    const slot = placeLabel(o4[0], o4[1], wT, 11 * FK, 4 * FK, W, H);
    if (!slot) continue;
    ctx.fillStyle = INK(0.30 * localA);
    ctx.beginPath(); ctx.arc(o4[0], o4[1], 1.6, 0, 6.2832); ctx.fill();
    ctx.fillStyle = INK(0.52 * localA);
    ctx.fillText(name, slot[0], slot[1] + 5.5 * FK);
  }
}

// ---- cohort reservation --------------------------------------------------------
// Regional cards no longer live inside the globe (they moved to the side rails),
// but each active cohort still RESERVES its footprint in the collision registry,
// so node ids and other labels can never sit on moving engaged capacity. A small
// anchor tick marks the cohort's live centroid — the "you are looking at it"
// point the side label describes.
export function drawCohortLabels(ctx, cam, W, H, regions, info, swarmK, SR, detail, ballAt) {
  if (swarmK < 0.15) return;
  const f = camFwd(cam);
  for (const r of regions) {
    if (r.activityLevel < 0.12) continue;
    const nfo0 = info && info[r.id];
    if (nfo0 && nfo0.used <= 0) continue;
    const P = r.centroid || ((ballAt && ballAt.id === r.id) ? ballAt.p : r.p);
    const pl = Math.hypot(P[0], P[1], P[2]) || 1;
    const facing = -(P[0] * f[0] + P[1] * f[1] + P[2] * f[2]) / pl;
    if (facing < 0.12) continue;
    project(cam, P[0], P[1], P[2], W, H, o4);
    const span = (ballAt && ballAt.r) || r.ballR || 6;
    const rad = span * o4[3] + 8;
    keepOut(o4[0], o4[1], rad);
    const a = Math.min(1, (facing - 0.12) / 0.3) * swarmK;
    anchorMark(ctx, o4[0], o4[1], a * 0.8);
  }
}

export function drawSphereBase(ctx, cam, W, H, SR, grat, mapK) {
  const q = SR / cam.dist;
  if (q >= 0.98) return;
  const Rs = SR * cam.fov / (cam.dist * Math.sqrt(1 - q * q));
  const cx = W * 0.5, cy = H * 0.5;   // no gradient fill: the stipple carries the volume
  ctx.strokeStyle = INK(0.15);
  ctx.lineWidth = 0.8 * UIK;
  ctx.beginPath(); ctx.arc(cx, cy, Rs, 0, 6.2832); ctx.stroke();
}

// ---- geography: one stipple, two readings ------------------------------------
// i%3===0 points are the permanent v2 faint layer; the rest arrive with mapK.
// Every point is a SMALL HEXAGON — the world's grid speaks the same cell
// language as the capacity glyphs. Stamped from a supersampled sprite so a
// hundred-thousand-point frame stays cheap.
let HEXS = null, HEXR = 0;
let HEXT = null;
function hexSprite(r) {
  if (HEXS && HEXR === r && HEXT === themeName()) return HEXS;
  const s = Math.max(12, Math.ceil((r + 1) * 8));
  const c = document.createElement('canvas'); c.width = c.height = s;
  const x = c.getContext('2d');
  x.fillStyle = rgbaT('ink', 1);
  x.beginPath();
  const R = s / 2 - 1;
  for (let k = 0; k < 6; k++) {
    const a = -Math.PI / 2 + k * Math.PI / 3;
    const X = s / 2 + Math.cos(a) * R, Y = s / 2 + Math.sin(a) * R;
    k ? x.lineTo(X, Y) : x.moveTo(X, Y);
  }
  x.closePath(); x.fill();
  HEXT = themeName(); HEXS = c; HEXR = r;
  return c;
}
// GEOGRAPHIC LOD — MORE POINTS, not bigger or brighter ones. The base stipple is
// a fixed point set on the sphere, so zooming magnifies the gaps between its
// points and the continents thin out. The fix is to SAMPLE MORE GEOGRAPHY where
// the camera is looking (the driver builds a denser cap-restricted stipple per
// zoom and hands it in as `lod`) and draw it with exactly the same dot rule as
// the base layer. Nothing else changes: same size, same alpha, same texture.
export function drawLand(ctx, cam, W, H, land, t, k, mapK, zoom = 1, lod = null) {
  const f = camFwd(cam);
  // dot size barely grows with zoom (the LOD adds POINTS, not bulk): at GLOBAL
  // it is exactly the original 1.6, and it never passes 1.15× that, so the
  // texture keeps gaps between dots instead of flooding into a solid mass
  const rBase = (1.25 + 0.35 * mapK) * Math.min(1.15, 1 + 0.12 * (zoom - 1)) * SK;
  const spr = hexSprite(rBase);
  const ga = ctx.globalAlpha;
  let drawn = 0;
  const paint = (arr, thirds, aMul, onlyThirds) => {
    for (let i = 0; i < arr.length; i++) {
      const q = arr[i];
      const base = !thirds || i % 3 === 0;
      if (!base && (mapK < 0.02 || onlyThirds)) continue;
      const facing = -(q.u[0] * f[0] + q.u[1] * f[1] + q.u[2] * f[2]);
      if (q.node || facing < 0.02) continue;   // node points draw highlighted, not twice
      // NO LIMB SHADING. This used to ramp alpha over the outer 0.34 of the
      // hemisphere and square it, so geography darkened toward the silhouette and
      // the globe read as if it were lit from the centre — a shaded rim that is not
      // part of the visual language. Density alone carries the curvature now: the
      // alpha is flat, and only the last sliver before the terminator fades, just
      // enough that points do not pop in and out as the world turns.
      const vis = Math.min(1, (facing - 0.02) / 0.05);
      const shim = 0.9 + 0.1 * Math.sin(t * 0.55 + q.j * 6.28);
      const a = (base ? (0.30 + 0.22 * mapK) : 0.34 * mapK) * aMul;
      ctx.globalAlpha = Math.min(1, vis * a * shim * k) * ga;
      project(cam, q.p[0], q.p[1], q.p[2], W, H, o4);
      if (o4[0] < -12 || o4[0] > W + 12 || o4[1] < -12 || o4[1] > H + 12) continue;
      const d = (base ? rBase : rBase * 0.82) * 2;
      ctx.drawImage(spr, o4[0] - d / 2, o4[1] - d / 2, d, d);
      drawn++;
    }
  };
  // with a LOD patch in hand the base layer only needs to carry the geography
  // OUTSIDE it, so it drops to its every-third sampling and gets out of the way
  const hasLod = !!(lod && lod.length);
  paint(land, true, hasLod ? 0.55 : 1, hasLod);
  if (hasLod) paint(lod, false, 0.7);
  ctx.globalAlpha = ga;
  // review hook: the LOD numbers behind this frame's geography
  if (typeof window !== 'undefined') window.__geoDbg = { drawn, lod: lod ? lod.length : 0, rBase, mapK, k };
}

// ---- capacity trails: short local wakes (v2 rule, board rendering) -----------
export function drawTrails(ctx, cam, sim, W, H, eng, chroma) {
  const TL = sim.TL, head = sim.head;
  for (let i = 0; i < sim.N; i++) {
    const e = eng[i];
    if (chroma[i] > 0.5) continue;               // assembled: no wake
    if (e < 0.22 && i % 3) continue;
    const n = Math.round(7 + e * 3);
    const hc = heatRGB(chroma[i]);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = dn(cam, o4[2], sim.R);
    if (dl < 0.05) continue;
    const sw = Math.max(0.15, Math.min(1, sim.spd[i] / (sim.SPD * 2.2)));
    let hx = 0, hy = 0;
    for (let a = n - 1; a >= 0; a--) {
      const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
      project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
      if (a < n - 1) {
        const u = 1 - a / n, t2 = u * u;
        ctx.lineWidth = 0.6 * (0.35 + 1.15 * t2) * (0.55 + dl * 0.85);
        const aa = Math.min(1, 0.20 * (0.55 + e * 1.05) * 2.4 * t2 * sw * (0.35 + dl * 0.65));
        ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.0)) : INK(aa);
        ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
      }
      hx = o4[0]; hy = o4[1];
    }
  }
}

// ---- capacity agents: hexagons, available vs engaged --------------------------
// PARTICLE RENDERING — lifted from capacity-scene.js so the marks in this UI are
// the marks of the original scene: one size and one opacity for every agent (no
// depth cueing), the glyph oriented along its own heading, stroke plus fill, and
// the five-stop response ramp that runs through amber into red. Trails are the
// original's tapered histories with their cross ticks.
const TAN_HALF = Math.tan(70.529 * Math.PI / 360);
const SC_STOPS = [[0.2, 148, 126, 86], [0.45, 178, 148, 90], [0.68, 200, 164, 94], [0.85, 212, 172, 96], [1, 222, 180, 100]];
export function sceneHeat(T) {
  if (!(T >= 0.2)) return null;
  for (let i = 1; i < SC_STOPS.length; i++) {
    const a = SC_STOPS[i - 1], b = SC_STOPS[i];
    if (T <= b[0]) {
      const u = (T - a[0]) / (b[0] - a[0]);
      return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
    }
  }
  const l = SC_STOPS[SC_STOPS.length - 1];
  return [l[1], l[2], l[3]];
}
export const GLYPHS = {
  Triangle: { kind: 'tri', scale: 1 },
  Dash: { kind: 'dash', scale: 1 },
  Circle: { kind: 'dot', scale: 1.15 },
  Diamond: { kind: 'dia', scale: 0.9 },
  Hexagon: { kind: 'hex', scale: 1 },
  'Circle filled': { kind: 'dot', scale: 1.15, fill: true },
  'Diamond filled': { kind: 'dia', scale: 0.9, fill: true }
};
function prim(ctx, kind, x, y, hx, hy, sz, fill) {
  const px_ = -hy, py_ = hx;
  if (kind === 'dash') {
    const L = sz * 1.35;
    ctx.beginPath();
    ctx.moveTo(x - hx * L, y - hy * L); ctx.lineTo(x + hx * L, y + hy * L);
    ctx.stroke(); return;
  }
  ctx.beginPath();
  if (kind === 'dot') {
    ctx.arc(x, y, sz * 0.5, 0, 6.2832);
  } else if (kind === 'dia') {
    const a = sz * 1.15, b = a / Math.SQRT2;
    ctx.moveTo(x + hx * a, y + hy * a);
    ctx.lineTo(x + px_ * b, y + py_ * b);
    ctx.lineTo(x - hx * a, y - hy * a);
    ctx.lineTo(x - px_ * b, y - py_ * b);
    ctx.closePath();
  } else if (kind === 'hex') {
    const r = sz * 0.82, a0 = Math.atan2(hy, hx);
    for (let k = 0; k < 6; k++) {
      const a = a0 + k * Math.PI / 3;
      const X = x + Math.cos(a) * r, Y = y + Math.sin(a) * r;
      k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
    }
    ctx.closePath();
  } else {
    const Hh = sz * 1.25, b = TAN_HALF * Hh;
    ctx.moveTo(x + hx * Hh * 0.66, y + hy * Hh * 0.66);
    ctx.lineTo(x - hx * Hh * 0.34 + px_ * b, y - hy * Hh * 0.34 + py_ * b);
    ctx.lineTo(x - hx * Hh * 0.34 - px_ * b, y - hy * Hh * 0.34 - py_ * b);
    ctx.closePath();
  }
  if (fill) ctx.fill(); else ctx.stroke();
}

let TB = null, TGW = 0, TGH = 0;
const SEGS = [];
export function drawIsotherms(ctx, cam, sim, W, H) {
  if (sim.tempMax < 0.06) return;
  const cell = 7 * UIK;
  const gw = Math.max(8, Math.round(W / cell)), gh = Math.max(6, Math.round(H / cell));
  if (TGW !== gw || TGH !== gh) { TGW = gw; TGH = gh; TB = new Float32Array(gw * gh); }
  TB.fill(0);
  for (let i = 0; i < sim.N; i++) {
    if (sim.temp[i] < 0.02) continue;
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const x0 = Math.round(o4[0] / W * gw), y0 = Math.round(o4[1] / H * gh);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = x0 + dx, y = y0 + dy;
      if (x < 0 || y < 0 || x >= gw || y >= gh) continue;
      const v = sim.temp[i] * Math.exp(-(dx * dx + dy * dy) / 1.5);
      if (v > TB[y * gw + x]) TB[y * gw + x] = v;
    }
  }
  const kx = W / gw, ky = H / gh, n = 5;
  const stroke = () => {
    ctx.beginPath();
    for (let s = 0; s < SEGS.length; s += 2) {
      ctx.moveTo(SEGS[s][0] * kx, SEGS[s][1] * ky);
      ctx.lineTo(SEGS[s + 1][0] * kx, SEGS[s + 1][1] * ky);
    }
    ctx.stroke();
  };
  for (let l = 0; l < n; l++) {
    const lv = 0.2 + (sim.tempMax - 0.2) * ((l + 0.6) / n);
    if (lv <= 0.2) continue;
    const c = sceneHeat(lv); if (!c) continue;
    isolines(TB, gw, gh, lv, SEGS);
    if (!SEGS.length) continue;
    const crit = lv > 0.82;
    ctx.strokeStyle = rgba(c, crit ? 0.95 : 0.5 + (l / n) * 0.32);
    ctx.lineWidth = (crit ? 1.1 : 0.55) * UIK;
    stroke();
    if (crit) {
      ctx.setLineDash([2 * UIK, 3 * UIK]); ctx.lineWidth = 0.5 * UIK;
      stroke();
      ctx.setLineDash([]);
    }
  }
}

// the original's tapered histories, with the cross ticks
export function drawHistories(ctx, cam, sim, W, H, cfg) {
  const c = cfg || {};
  const TL = sim.TL, head = sim.head;
  const n = Math.max(3, Math.min(TL, Math.round(c.n ?? 15)));
  const stride = Math.max(1, Math.round(c.stride ?? 4));
  const w = (c.w ?? 0.55) * UIK;
  const alpha = c.alpha ?? 0.2;
  const tick = 7;
  for (let i = 0; i < sim.N; i += stride) {
    const hc = sceneHeat(sim.temp[i]);
    project(cam, sim.px[i], sim.py[i], sim.pz[i], W, H, o4);
    const dl = Math.max(0, Math.min(1, (cam.dist + sim.R * 0.9 - o4[2]) / (sim.R * 1.8)));
    if (dl < 0.04) continue;
    const av = alpha * (0.3 + dl * 0.7);
    if (c.taper) {
      const sw = Math.max(0.12, Math.min(1, sim.spd[i] / (sim.SPD * 2.4)));
      let hx = 0, hy = 0;
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        if (a < n - 1) {
          const u = 1 - a / n, t2 = u * u;
          ctx.lineWidth = w * (0.35 + 1.05 * t2) * (0.55 + dl * 0.85);
          const aa = Math.min(1, av * 2.6 * t2 * sw);
          ctx.strokeStyle = hc ? rgba(hc, Math.min(1, aa * 1.5)) : INK(aa);
          ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(o4[0], o4[1]); ctx.stroke();
        }
        hx = o4[0]; hy = o4[1];
      }
    } else {
      ctx.beginPath();
      for (let a = n - 1; a >= 0; a--) {
        const o = (i * TL + ((head - a + TL * 2) % TL)) * 3;
        project(cam, sim.trail[o], sim.trail[o + 1], sim.trail[o + 2], W, H, o4);
        a === n - 1 ? ctx.moveTo(o4[0], o4[1]) : ctx.lineTo(o4[0], o4[1]);
      }
      ctx.lineWidth = w * (0.55 + dl * 0.85);
      ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 1.6)) : INK(av);
      ctx.stroke();
    }
    if (c.ticks === false) continue;
    ctx.lineWidth = 0.6 * UIK;
    ctx.strokeStyle = hc ? rgba(hc, Math.min(1, av * 2.2)) : INK(alpha * (0.3 + dl * 0.7));
    for (let a = n - 2; a >= 1; a -= tick) {
      const oA = (i * TL + ((head - a - 1 + TL * 2) % TL)) * 3;
      const oB = (i * TL + ((head - a + 1 + TL * 2) % TL)) * 3;
      project(cam, sim.trail[oA], sim.trail[oA + 1], sim.trail[oA + 2], W, H, o4);
      project(cam, sim.trail[oB], sim.trail[oB + 1], sim.trail[oB + 2], W, H, o4b);
      const mx = (o4[0] + o4b[0]) / 2, my = (o4[1] + o4b[1]) / 2;
      const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
      const tk = 1.9 * UIK * (1 - a / n * 0.55);
      ctx.beginPath();
      ctx.moveTo(mx + dy / L * tk, my - dx / L * tk);
      ctx.lineTo(mx - dy / L * tk, my + dx / L * tk);
      ctx.stroke();
    }
  }
}

let ORD = null, SD = null, SX = null, SY = null, ROT = null, SHX = null, SHY = null;
// the separation hash is reused across frames: at 4K the grid is ~74k cells,
// and reallocating it every frame would cost more than the relaxation itself
let HEAD = null, NEXT = null, HCOLS = 0, HROWS = 0;
export function drawAgents(ctx, cam, sim, W, H, eng, chroma, scale = 1, ambient = 1, avoid, glyph = 'Hexagon', lift = null, ink = null) {
  const N = sim.N;
  if (!SD || SD.length !== N) {
    SD = new Float32Array(N); SX = new Float32Array(N); SY = new Float32Array(N);
    ROT = new Float32Array(N); ORD = Array.from({ length: N }, (_, i) => i);
  }
  if (!SHX || SHX.length !== N) { SHX = new Float32Array(N); SHY = new Float32Array(N); }
  const sx = SX, sy = SY, rot = ROT;
  for (let i = 0; i < N; i++) {
    // RADIAL LIFT, applied at DRAW time only: an engaged particle is shown
    // standing a little way up its workload's filament, along the local normal,
    // while the physics keeps running on the shell — so the plume reads as
    // emerging from the sphere without the lift ever fighting the docking.
    let px = sim.px[i], py = sim.py[i], pz = sim.pz[i];
    if (lift && lift[i]) {
      const L0 = Math.hypot(px, py, pz) || 1;
      const kk = (L0 + lift[i]) / L0;
      px *= kk; py *= kk; pz *= kk;
    }
    project(cam, px, py, pz, W, H, o4);
    project(cam, px + sim.vx[i] * 0.3, py + sim.vy[i] * 0.3, pz + sim.vz[i] * 0.3, W, H, o4b);
    sx[i] = o4[0]; sy[i] = o4[1]; SD[i] = o4[2];
    const dx = o4b[0] - o4[0], dy = o4b[1] - o4[1], L = Math.hypot(dx, dy) || 1;
    SHX[i] = dx / L; SHY[i] = dy / L;
    rot[i] = Math.atan2(dy, dx);
  }
  ORD.sort((a, b) => SD[b] - SD[a]);

  // ---- NO OVERLAP OF ANY MARK ----------------------------------------------
  // Enforced in SCREEN space, where the constraint actually lives: the glyph is
  // a fixed pixel size while the world scales with the viewport and the zoom.
  // A spatial hash finds every pair closer than one glyph and relaxes them
  // apart; node marks are hard obstacles applied last, so nothing can be pushed
  // back onto one. The guard matters: if the visible hemisphere cannot hold N
  // glyphs at this spacing the solver would saturate and flatten the whole
  // field into a uniform lattice, so on a panel that small only the node discs
  // are applied and the field keeps its natural distribution.
  {
    const D = ((2.8 + 1.0) * scale * UIK) * 2 + 1.6 * UIK;
    const Rw = sim.R * cam.fov / cam.dist;              // world radius, on screen
    const roomy = Math.PI * Rw * Rw > N * 0.866 * D * D * 1.85;
    if (roomy) {
      const cell = D, cols = Math.max(1, Math.ceil(W / cell) + 2), rows = Math.max(1, Math.ceil(H / cell) + 2);
      if (!HEAD || HCOLS !== cols || HROWS !== rows) { HEAD = new Int32Array(cols * rows); HCOLS = cols; HROWS = rows; }
      if (!NEXT || NEXT.length !== N) NEXT = new Int32Array(N);
      const head = HEAD, next = NEXT;
      const cellOf = i => {
        const cx = Math.min(cols - 1, Math.max(0, Math.floor(sx[i] / cell) + 1));
        const cy = Math.min(rows - 1, Math.max(0, Math.floor(sy[i] / cell) + 1));
        return cy * cols + cx;
      };
      for (let pass = 0; pass < 4; pass++) {
        head.fill(-1);
        for (let i = 0; i < N; i++) { const k = cellOf(i); next[i] = head[k]; head[k] = i; }
        for (let i = 0; i < N; i++) {
          const cx = Math.min(cols - 1, Math.max(0, Math.floor(sx[i] / cell) + 1));
          const cy = Math.min(rows - 1, Math.max(0, Math.floor(sy[i] / cell) + 1));
          for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
            const nx2 = cx + ox, ny2 = cy + oy;
            if (nx2 < 0 || nx2 >= cols || ny2 < 0 || ny2 >= rows) continue;
            for (let j = head[ny2 * cols + nx2]; j !== -1; j = next[j]) {
              if (j <= i) continue;
              let dx = sx[j] - sx[i], dy = sy[j] - sy[i];
              const d2 = dx * dx + dy * dy;
              if (d2 >= D * D) continue;
              let d = Math.sqrt(d2);
              if (d < 1e-4) { dx = 1; dy = 0; d = 1; }
              const push = (D - d) * 0.5;
              dx /= d; dy /= d;
              sx[i] -= dx * push; sy[i] -= dy * push;
              sx[j] += dx * push; sy[j] += dy * push;
            }
          }
        }
      }
    }
    if (avoid) for (let i = 0; i < N; i++) {
      for (let k = 0; k < avoid.length; k++) {
        const A = avoid[k];
        let dx = sx[i] - A[0], dy = sy[i] - A[1];
        let d = Math.hypot(dx, dy);
        const R = A[2] + D * 0.5;
        if (d >= R) continue;
        if (d < 1e-6) { dx = 1; dy = 0; d = 1; }
        sx[i] = A[0] + dx / d * R; sy[i] = A[1] + dy / d * R;
      }
    }
  }

  const fw = camFwd(cam);
  const gl = GLYPHS[glyph] || GLYPHS.Hexagon;
  for (let q = 0; q < N; q++) {
    const i = ORD[q];
    const dl = dn(cam, SD[i], sim.R);
    if (dl <= 0.01) continue;
    const pl = Math.hypot(sim.px[i], sim.py[i], sim.pz[i]) || 1;
    if (-(sim.px[i] * fw[0] + sim.py[i] * fw[1] + sim.pz[i] * fw[2]) / pl < 0.02) continue;
    // the original's treatment: no depth cueing — every mark reads at one size
    // and one opacity, and only the response colour separates them
    const al = sim.meas[i];
    const hc = sceneHeat(chroma[i]);
    const engd = !!hc;
    const s = (engd ? (3.2 + (al > 0.08 ? 0.9 : 0)) : 3.2 * 0.62) * scale * UIK;
    const a = engd ? (0.78 + (al > 0.08 ? Math.min(0.22, al * 0.9) : 0)) : 0.26;
    // INK OVERRIDE: free capacity normally takes the theme's ink, which assumes a
    // surface ground. A caller drawing the swarm on a coloured ground (the sign-in
    // world, on primary) hands in its own foreground instead. Engaged particles
    // are unaffected — their colour is the response reading, not a foreground.
    const IK = ink ? (aa => rgba(ink, aa)) : INK;
    ctx.strokeStyle = engd ? rgba(hc, Math.min(1, a * 1.55)) : IK(a * ambient);
    ctx.lineWidth = (engd && al > 0.08 ? 1.05 : 0.7) * UIK;
    ctx.fillStyle = engd ? rgba(hc, Math.min(1, a * 1.35)) : IK(a * 0.9 * ambient);
    prim(ctx, gl.kind, sx[i], sy[i], SHX[i], SHY[i], s * (gl.scale || 1), !!gl.fill);
  }
}

// ---- engagement field: the zone reads as a unit -------------------------------
// Two spherical isolines around an active region delimit where capacity is
// coordinating — the board's isoline language (isoline = scalar), drawn, not
// simulated: the v2 behaviour underneath is untouched and nothing converges.
function drawEngagementField(ctx, cam, W, H, regions, levels, swarmK, SR, t) {
  if (swarmK < 0.05) return;
  const f = camFwd(cam);
  let idx = 0;
  for (const r of regions) {
    const lv = levels[r.id] || 0;
    idx++;
    if (lv < 0.06) continue;
    const u = r.u;
    let e1 = [u[1], -u[0], 0];
    let L = Math.hypot(e1[0], e1[1], e1[2]);
    if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
    e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
    const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
    const breathe = 1 + 0.02 * Math.sin(t * 0.7 + idx * 2.1);
    const thO = (0.24 + 0.18 * lv) * breathe;
    const hc = heatRGB(0.45 + 0.3 * lv) || [210, 126, 38];
    // [angular radius, alpha, dash, width] — a soft glow pass under each line
    const rings = [
      [thO, 0.12 + 0.10 * lv, [], 6],
      [thO, 0.30 + 0.45 * lv, [], 1.3],
      [thO * 0.55, 0.16 + 0.22 * lv, [3, 5], 1]
    ];
    for (const [th, ra, dash, lw] of rings) {
      const ct = Math.cos(th), st = Math.sin(th);
      ctx.setLineDash(dash);
      ctx.lineWidth = lw;
      ctx.strokeStyle = rgba(hc, Math.min(1, ra * swarmK));
      ctx.beginPath();
      let pen = false;
      for (let s2 = 0; s2 <= 72; s2++) {
        const ph = s2 / 72 * 6.2832;
        const px = (u[0] * ct + (e1[0] * Math.cos(ph) + e2[0] * Math.sin(ph)) * st) * SR * 1.003;
        const py = (u[1] * ct + (e1[1] * Math.cos(ph) + e2[1] * Math.sin(ph)) * st) * SR * 1.003;
        const pz = (u[2] * ct + (e1[2] * Math.cos(ph) + e2[2] * Math.sin(ph)) * st) * SR * 1.003;
        const pl = Math.hypot(px, py, pz) || 1;
        if (-(px * f[0] + py * f[1] + pz * f[2]) / pl < 0.03) { pen = false; continue; }
        project(cam, px, py, pz, W, H, o4);
        pen ? ctx.lineTo(o4[0], o4[1]) : ctx.moveTo(o4[0], o4[1]);
        pen = true;
      }
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }
}

// ---- region marks: one glyph across all lenses --------------------------------
// The crosshair tick is the region in EVERY lens (same world, same mark); the
// Map lens adds a quiet label, the zoom adds node counts (semantic zoom), and
// the thin arc prints the region's existing activityLevel. No boxes.
export function drawRegionMarks(ctx, cam, W, H, regions, levels, mapK, swarmK, dist, ballAt, scale) {
  const f = camFwd(cam);
  const zoomA = clamp01((252 - dist) / 30);          // REGIONAL reading arrives as you approach
  for (const r of regions) {
    const lv = levels[r.id] || 0;
    const P = (ballAt && ballAt.id === r.id) ? ballAt.p : r.p;
    const l = Math.hypot(P[0], P[1], P[2]) || 1;
    const facing = -(P[0] * f[0] + P[1] * f[1] + P[2] * f[2]) / l;
    if (facing < 0.12) continue;
    const vis = Math.min(1, (facing - 0.12) / 0.3);
    project(cam, P[0], P[1], P[2], W, H, o4);
    const x = o4[0], y = o4[1];
    const a = vis * (0.30 + 0.50 * lv) * Math.max(0.85 * mapK + 0.35, swarmK);
    // REGIONAL / CONTROL ANCHOR — the region's operational reference point, NOT
    // one of the compute nodes and never counted as one: a target ring with a
    // centre and four short outward ticks, in the control teal. One clear step
    // above a compute-node marker, identical in Map and Swarm. No glow.
    const rr2 = 6.5 * UIK;
    ctx.strokeStyle = TEAL(Math.min(1, a * 0.95));
    ctx.lineWidth = 1 * UIK;
    ctx.beginPath(); ctx.arc(x, y, rr2, 0, 6.2832); ctx.stroke();
    ctx.fillStyle = TEAL(Math.min(1, a));
    ctx.beginPath(); ctx.arc(x, y, 1.6 * UIK, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = TEAL(Math.min(1, a * 0.6));
    ctx.beginPath();
    ctx.moveTo(x - rr2 - 3.5 * UIK, y); ctx.lineTo(x - rr2 - 1 * UIK, y);
    ctx.moveTo(x + rr2 + 1 * UIK, y); ctx.lineTo(x + rr2 + 3.5 * UIK, y);
    ctx.moveTo(x, y - rr2 - 3.5 * UIK); ctx.lineTo(x, y - rr2 - 1 * UIK);
    ctx.moveTo(x, y + rr2 + 1 * UIK); ctx.lineTo(x, y + rr2 + 3.5 * UIK);
    ctx.stroke();
    keepOut(x, y, rr2 + 4 * UIK);
    // the SIDE RAIL names regions now; on the globe only the control-plane id
    // remains, close to its anchor, at REGIONAL scale and beyond
    if (r.ctrl && mapK > 0.04 && scale !== 'GLOBAL') {
      const alpha = vis * (0.6 + 0.3 * lv) * mapK;
      ctx.font = fpx(9);
      ctx.textAlign = 'left';
      const wT = ctx.measureText(r.ctrl).width;
      const slot = placeLabel(x, y, wT, 11 * FK, rr2 + 5 * UIK, W, H, false, true);
      if (slot) {
        ctx.fillStyle = TEAL(Math.min(1, alpha * 0.75));
        ctx.fillText(r.ctrl, slot[0], slot[1] + 5.5 * FK);
      }
    }
  }
}

// ---- node marks: actual infrastructure on the world ---------------------------
// Nodes are real compute; each region's nodes sit in a small deterministic ring
// on its tangent plane. Teal is infrastructure's colour (never capacity's).
// Node ids appear only at LOCAL zoom or under the Node-stats lens — semantic
// zoom, not clutter.
export function buildNodeMarks(regions, nodesByRegion, SR, land) {
  const marks = [];
  for (const r of regions) {
    const ids = nodesByRegion[r.id] || [];
    if (!ids.length) continue;
    const u = r.u;
    let e1 = [u[1] * 1 - u[2] * 0, u[2] * 0 - u[0] * 1, u[0] * 0 - u[1] * 0]; // u × ŷ
    let L = Math.hypot(e1[0], e1[1], e1[2]);
    if (L < 1e-3) { e1 = [1, 0, 0]; L = 1; }
    e1 = [e1[0] / L, e1[1] / L, e1[2] / L];
    const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
    ids.forEach((id, k) => {
      const ang = 0.9 + k * 6.2832 / ids.length;
      const rr = 4.4;
      const p = [
        u[0] * SR + (e1[0] * Math.cos(ang) + e2[0] * Math.sin(ang)) * rr,
        u[1] * SR + (e1[1] * Math.cos(ang) + e2[1] * Math.sin(ang)) * rr,
        u[2] * SR + (e1[2] * Math.cos(ang) + e2[2] * Math.sin(ang)) * rr
      ];
      const pl = Math.hypot(p[0], p[1], p[2]) || 1;
      let un = [p[0] / pl, p[1] / pl, p[2] / pl];
      let pp = [un[0] * SR * 1.004, un[1] * SR * 1.004, un[2] * SR * 1.004];
      if (land && land.length) {
        // the node is one of the map's own points, highlighted — never an extra dot
        let best = -1, bd = -2;
        for (let q = 0; q < land.length; q++) {
          if (land[q].node) continue;
          const d = land[q].u[0] * un[0] + land[q].u[1] * un[1] + land[q].u[2] * un[2];
          if (d > bd) { bd = d; best = q; }
        }
        if (best >= 0) {
          land[best].node = true;
          un = land[best].u;
          pp = [un[0] * SR * 1.004, un[1] * SR * 1.004, un[2] * SR * 1.004];
        }
      }
      marks.push({ id, rid: r.id, p: pp, u: un, rc: r.u });
    });
  }
  return marks;
}

const NODE_SIDE = new Map();
export function drawNodeMarks(ctx, cam, W, H, marks, levels, mapK, nodesK, dist, t, scale, focusId, zz, hw, idsAtGlobal, accent, flagId) {
  const f = camFwd(cam);
  const localA = clamp01((215 - dist) / 18);        // LOCAL reading: hardware detail
  const lensA = Math.max(mapK * 0.95, nodesK);
  if (lensA < 0.02) return;
  // the globe's projected centre: which side of it a node sits on decides which
  // side its label takes, so the whole set reads outward from one origin
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  // NODE MARKERS: a node is a small PRECISE mark — a fine ring with a solid core,
  // unmistakably not a capacity hexagon — and its id now attaches through the SAME
  // spatial grammar Swarm uses for workloads: one true sphere-normal stem out of
  // the surface, with the id horizontal at its outer end. Shared geometry, not
  // shared styling: the stem here is a restrained infrastructure line, never a
  // workload radial. Colour semantics unchanged — idle infrastructure is quiet
  // neutral; only a SERVING node takes the flow's colour.
  const list = [...marks].sort((a2, b2) =>
    ((levels[b2.rid] || 0) - (levels[a2.rid] || 0)) || (a2.id < b2.id ? -1 : 1));
  for (const m of list) {
    const facing = -(m.u[0] * f[0] + m.u[1] * f[1] + m.u[2] * f[2]);
    if (facing < 0.1) continue;
    const vis = Math.min(1, (facing - 0.1) / 0.3);
    const busy = (levels[m.rid] || 0) > 0.001;
    project(cam, m.p[0], m.p[1], m.p[2], W, H, o4);
    const bx = o4[0], by = o4[1];
    const a = vis * lensA;
    // NODE MARKER — concentric and precise, NO GLOW: one hairline ring and a
    // solid core, nothing radiating. A SERVING node takes the colour of the flow
    // that reaches it — the same workload colour its token traffic carries — so
    // node and route read as one identity; idle infrastructure stays neutral.
    // SELECTED NODE: the mark itself grows, so the node reads as the subject at
    // any scale; the tangent ring around it carries the rest (owner 2026-09-11).
    const flagged = !!flagId && m.id === flagId;
    const sz = (2.4 + nodesK * 0.5) * UIK * (flagged ? 1.95 : 1);
    const acc = busy && accent ? accent[m.id] : null;
    const FLOW = al => acc
      ? `rgba(${acc[0] | 0},${acc[1] | 0},${acc[2] | 0},${Math.min(1, al).toFixed(3)})`
      : TEAL(Math.min(1, al));
    ctx.strokeStyle = busy ? FLOW(a * 0.72) : INK(Math.min(1, a * 0.62));
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.arc(bx, by, sz * 1.25, 0, 6.2832); ctx.stroke();
    ctx.fillStyle = busy ? FLOW(a * 0.95) : LIT(Math.min(1, a * 0.62));
    ctx.beginPath(); ctx.arc(bx, by, sz * 0.46, 0, 6.2832); ctx.fill();

    // SEMANTIC ZOOM. On the geographic Map the node id is part of the global
    // reading, so ids are allowed at GLOBAL and the collision registry simply
    // drops the ones with no room; hardware metadata still waits for LOCAL. In
    // Swarm the global reading is capacity, so ids wait for REGIONAL.
    if (scale === 'GLOBAL' && !idsAtGlobal && nodesK < 0.3) continue;
    if (scale === 'LOCAL' && focusId && m.rid !== focusId) continue;
    const front = Math.max(0, Math.min(1, (facing - 0.36) / 0.22));
    const idA = Math.max(nodesK, mapK * 0.9, localA) * vis * front;
    if (idA > 0.10) {
      // HARDWARE IS CONTEXTUAL, NOT AMBIENT. The left rail is the home for node
      // detail, so the world shows hardware only when the view is actually about
      // one place: LOCAL scale with a region focused (or that node selected).
      // Otherwise every visible node carried two lines of metadata and the map
      // read as a diagnostic overlay instead of an operational view.
      const hwAllowed = localA > 0.25 && (focusId ? m.rid === focusId : false);
      let hwTxt = (hwAllowed && hw && hw[m.id]) ? hw[m.id] : null;
      ctx.textAlign = 'left';
      ctx.font = busy ? fpxw(10.5, 600) : fpx(10.5);
      const idW = ctx.measureText(m.id).width;
      let wT = idW;
      if (hwTxt) { ctx.font = fpx(8.5); wT = Math.max(wT, ctx.measureText(hwTxt).width); }
      let hT = (hwTxt ? 22 : 11) * FK;
      const GAP = sz * 0.8 + 7 * UIK;
      // NODE ID PLACEMENT — ONE FIXED RULE, no search, no sliding, no stepping:
      // the label hangs at the OUTER END of the node's stem, on the side away from
      // the globe centre, horizontal in screen space. Two labels may occasionally
      // overlap; that is accepted, because a label that wanders away from its node
      // to avoid a neighbour is worse than a momentary collision. The only
      // corrections are the viewport edges.
      const idOff = 5.5 * FK;
      // ONE SPHERE-NORMAL STEM, from the marker outward along this node's own
      // normal — normalize(P − C), which for a surface point is simply P/|P| — at a
      // FIXED WORLD length, shorter than the workload stem (SR*0.07 against
      // SR*0.11). No screen-length compensation: it foreshortens with the globe,
      // which is what makes it read as genuinely perpendicular to the surface.
      const nr = Math.hypot(m.p[0], m.p[1], m.p[2]) || 1;
      const nu = [m.p[0] / nr, m.p[1] / nr, m.p[2] / nr];
      const stemL = nr * 0.07;
      project(cam, m.p[0] + nu[0] * stemL, m.p[1] + nu[1] * stemL, m.p[2] + nu[2] * stemL, W, H, o4c);
      const ex = o4c[0], ey = o4c[1];
      {
        // starts clear of the marker ring, fades outward, thinner and quieter than
        // both the workload stem and the token traffic
        const dxs = ex - bx, dys = ey - by, dls = Math.hypot(dxs, dys);
        if (dls > sz * 1.9) {
          const k0 = (sz * 1.6) / dls;
          const sx0 = bx + dxs * k0, sy0 = by + dys * k0;
          const sa = Math.min(1, idA) * 0.55;
          const gr = ctx.createLinearGradient(sx0, sy0, ex, ey);
          if (busy) { gr.addColorStop(0, FLOW(sa * 0.8)); gr.addColorStop(1, FLOW(sa * 0.42)); }
          else { gr.addColorStop(0, INK(sa * 0.62)); gr.addColorStop(1, INK(sa * 0.3)); }
          ctx.strokeStyle = gr;
          ctx.lineWidth = 0.7 * UIK;
          ctx.beginPath(); ctx.moveTo(sx0, sy0); ctx.lineTo(ex, ey); ctx.stroke();
          // END DOT: the stem terminates in a small point and the id sits right
          // beside it, so point + text read as one lockup belonging to this node.
          // Smaller and quieter than the workload stem's dot.
          ctx.fillStyle = busy ? FLOW(Math.min(1, idA) * 0.8) : LIT(Math.min(1, idA) * 0.62);
          ctx.beginPath(); ctx.arc(ex, ey, 1.5 * UIK, 0, 6.2832); ctx.fill();
        }
      }
      const prevSide = NODE_SIDE.get(m.id);
      let side = (ex - gcx) > 4 * UIK ? 1 : (ex - gcx) < -4 * UIK ? -1 : (prevSide || 1);
      NODE_SIDE.set(m.id, side);
      let lx = side > 0 ? ex + GAP : ex - GAP - wT;
      if (lx < 6) lx = ex + GAP;
      else if (lx + wT > W - 8) lx = ex - GAP - wT;
      // KEEP-OUT BANDS OUTRANK A NODE ID, but a node id is never dropped — it was
      // flickering in and out as the globe turned. So: try the node's own side,
      // flip once, then step the box just above or below its own stem end. Only
      // if every one of those is still inside a reserved area does it fall back
      // to its own side, which is the readable failure.
      const bandFree = (x, y) => clearOfBands(x - 3, y, wT + 6, hT);
      let ly = ey - idOff;
      if (!bandFree(lx, ly)) {
        const alt = lx > ex ? ex - GAP - wT : ex + GAP;
        const step = hT + 6 * FK;
        if (alt >= 6 && alt + wT <= W - 8 && bandFree(alt, ly)) lx = alt;
        else if (bandFree(lx, ly - step)) ly -= step;
        else if (bandFree(lx, ly + step)) ly += step;
      }
      const slot = [lx, Math.max(20, Math.min(H - 8 - hT, ly))];
      if (slot) {
        const [lx, ly] = slot;
        if (typeof window !== 'undefined' && window.__lblDbgOn) {
          (window.__lblDbg = window.__lblDbg || {})[m.id] =
            { bx: +bx.toFixed(1), by: +by.toFixed(1), lx: +lx.toFixed(1), ly: +ly.toFixed(1), side, hw: !!hwTxt, hT: +hT.toFixed(1), idBase: +(ly + (hwTxt ? 9.6 : hT / 2 + 3.7) * FK).toFixed(1) };
        }
        const clean = !hitsLabel(lx - 3, ly, wT + 6, hT);
        LBL.push([lx, ly, wT, hT]);
        if (clean) clearBox(ctx, lx - 3, ly, wT + 6, hT, Math.min(1, idA));
        ctx.textBaseline = 'middle';
        ctx.font = busy ? fpxw(10.5, 600) : fpx(10.5);
        ctx.fillStyle = LIT(Math.min(1, idA * 0.88));
        ctx.fillText(m.id, lx, ly + idOff);
        if (hwTxt) {
          ctx.font = fpx(8.5);
          ctx.fillStyle = INK(Math.min(1, idA * 0.7) * Math.min(1, localA));
          ctx.fillText(hwTxt, lx, ly + idOff + 11 * FK);
        }
        ctx.textBaseline = 'alphabetic';
      }
    }
  }
}

// ---- WORKLOAD COHORT LABELS ------------------------------------------------------
// P2: the SAME simple rule the node ids use. The label sits at ONE fixed offset
// from the cohort's PERSISTENT SEMANTIC ANCHOR (a direction derived once from the
// infrastructure its slots live on — see the driver's assign()), on the outward
// side of the globe centre, primary line on the anchor's horizontal axis. No
// candidate search, no hysteresis bookkeeping, no dropping: nothing here consults
// where the particles happen to be this frame, so the label cannot chase them,
// and occasional overlap is accepted in exchange for absolute stability.
export function drawWorkloadCohorts(ctx, cam, W, H, sim, cohorts, swarmK, SR, camKey, structs, stemK = 1, labelK = 1) {
  if (!cohorts || !cohorts.length || swarmK < 0.15) return;
  // The stem is DRAWN, not faded: its length runs 0 -> full, so it extends along
  // the surface normal as the lens resolves. The label follows a beat later,
  // sliding the last few px outward from the stem's end into place.
  const sk = Math.max(0, Math.min(1, stemK));
  const lk = Math.max(0, Math.min(1, labelK));
  if (sk < 0.02) return;
  const f = camFwd(cam);
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  ctx.textAlign = 'left';
  for (const co of cohorts) {
    const st = structs && structs[co.id];
    const u = (st && st.u) || co.anchor;
    if (!u) continue;
    const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
    if (facing < 0.1) continue;
    const a = Math.min(1, (facing - 0.1) / 0.25) * swarmK;
    const la = a * lk;
    const P = (st && st.p) || [u[0] * SR, u[1] * SR, u[2] * SR];
    project(cam, P[0], P[1], P[2], W, H, o4);
    const ax = o4[0], ay = o4[1];
    // ONE SPHERE-NORMAL STEM per workload: from the anchor on the surface
    // straight OUT along that point's own normal (centre → surface → out), a
    // CONSTANT WORLD LENGTH. It used to be held at a constant screen length by
    // dividing by px-per-world-unit, which made the stem grow enormously toward
    // the camera near the disc centre and swing as the globe turned — it read as
    // an animated radial ray. A fixed world length foreshortens honestly instead:
    // a short perpendicular nub near the centre, a tall one at the limb, always
    // plainly perpendicular to the surface. It exists only to carry the label.
    const stemL = SR * 0.11 * sk;
    project(cam, P[0] + u[0] * stemL, P[1] + u[1] * stemL, P[2] + u[2] * stemL, W, H, o4);
    const ex = o4[0], ey = o4[1];
    // the cohort's footprint comes from its ALLOCATION, never from particle
    // positions, so the label's clearance does not breathe either
    const rad = Math.min(74, 16 + co.slots * 7) * (o4[3] / (cam.fov / cam.dist));
    keepOut(ax, ay, Math.max(14, rad));
    let name = co.name;
    if (name.length > 22) name = name.slice(0, 21).trimEnd() + '…';
    // IDENTIFICATION ONLY: the globe label answers "which cloud is this?" and
    // nothing else. Slot counts and percentages live in the Active Workloads
    // panel. The label hangs at the OUTER END of the stem, horizontal in screen
    // space — the text never rotates with the stem and never follows curvature.
    ctx.font = fpxw(10.5, 600);
    const bw = ctx.measureText(name).width + 10 * FK;
    const bh = 14 * FK;
    // the label sits RIGHT NEXT TO the stem's end dot — that adjacency is what
    // ties the name to its stem, so the gap stays small even when the stem
    // foreshortens near the disc centre (occasional overlap is accepted)
    const GAP = (8 + 10 * (1 - lk)) * UIK;
    let lx = (ex - gcx) >= 0 ? ex + GAP : ex - GAP - bw;
    W_LAST = W;
    if (!clearOfBands(lx, ey - 7 * FK, bw, bh)) {
      const alt = lx > ex ? ex - GAP - bw : ex + GAP;
      if (clearOfBands(alt, ey - 7 * FK, bw, bh)) lx = alt;
    }
    if (lx < 6) lx = ex + GAP;
    else if (lx + bw > W - 8) lx = ex - GAP - bw;
    const ly = Math.max(20, Math.min(H - 8 - bh, ey - 7 * FK));
    const clean = !hitsLabel(lx, ly, bw, bh);
    LBL.push([lx, ly, bw, bh]);
    if (clean && lk > 0.02) clearBox(ctx, lx, ly, bw, bh, la);
    // THE STEM: one line, anchor → outer end, in the workload's colour, fading
    // outward so the anchor end reads as the attachment point.
    const gr = ctx.createLinearGradient(ax, ay, ex, ey);
    gr.addColorStop(0, rgba(co.color, Math.min(1, 0.45 * a)));
    gr.addColorStop(1, rgba(co.color, Math.min(1, 0.38 * a)));
    ctx.strokeStyle = gr;
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ex, ey); ctx.stroke();
    // THE STEM'S END DOT: the stem terminates in a small filled point in the
    // workload's colour, and the name sits immediately beside it — point and
    // text read as one lockup, which is what binds the label to its stem and so
    // to the anchor and cloud below it.
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.95 * a));
    ctx.beginPath(); ctx.arc(ex, ey, 2 * UIK, 0, 6.2832); ctx.fill();
    // WORKLOAD ANCHOR — small, restrained, workload-coloured: a thin ring with a
    // core and a very slow, very small breath. Not a Map compute node.
    const t2 = (sim && sim.t) || 0;
    const pul = 0.5 + 0.5 * Math.sin(t2 * 0.8 + (co.slots + name.length) * 0.7);
    const rr = 4.4 * UIK;
    ctx.strokeStyle = rgba(co.color, Math.min(1, 0.55 * a));
    ctx.lineWidth = 0.9 * UIK;
    ctx.beginPath(); ctx.arc(ax, ay, rr * (1 + 0.06 * pul), 0, 6.2832); ctx.stroke();
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.85 * a));
    ctx.beginPath(); ctx.arc(ax, ay, 1.7 * UIK, 0, 6.2832); ctx.fill();
    ctx.textBaseline = 'middle';
    ctx.font = fpxw(10.5, 600);
    ctx.fillStyle = rgba(co.color, Math.min(1, 0.9 * la));
    ctx.fillText(name, lx + 5 * FK, ly + bh / 2);
    ctx.textBaseline = 'alphabetic';
  }
}

// ---- PER-PARTICLE SPHERE NORMALS -------------------------------------------------
// The same geometry as the workload stem, one order of magnitude quieter: every
// ENGAGED particle gets a very short line along its own sphere normal
// (normalize(p − C)), in its workload's colour at low alpha. It is not a
// scaffold and carries no label — it just states that active capacity stands
// off the surface, and it makes a cohort read as one body of upright marks
// rather than loose dots. Fixed WORLD length, so it foreshortens honestly with
// rotation and never swings.
const _ps = new Float32Array(4), _pe = new Float32Array(4), _pc = new Float32Array(4);
export function drawParticleStems(ctx, cam, sim, W, H, alloc, swarmK, SR) {
  if (!alloc || swarmK < 0.12) return;
  const f = camFwd(cam);
  const wlc = sim.wlc;
  // WHY THIS LOOKED LIKE NOTHING. A sphere-normal line foreshortens to a POINT
  // where the surface faces the camera and stands at full length at the limb — so
  // culling by `facing` threw away the only marks that could ever read as upright,
  // and everything that survived was drawn end-on. Two corrections: keep the limb
  // (cull only what is genuinely behind the horizon), and give every stem a minimum
  // SCREEN length so a foreshortened one still registers as a short tick instead
  // of vanishing. Alpha is not multiplied by swarmK here — the caller already sets
  // it as globalAlpha, and doing it twice squared the fade.
  const LE = SR * 0.042, LF = SR * 0.03;
  const MINPX = 2.2 * UIK;
  for (let i = 0; i < sim.N; i++) {
    const eng = !!alloc[i];
    const x = sim.px[i], y = sim.py[i], z = sim.pz[i];
    const l = Math.hypot(x, y, z) || 1;
    const nx = x / l, ny = y / l, nz = z / l;
    const facing = -(nx * f[0] + ny * f[1] + nz * f[2]);
    if (facing < 0.02) continue;
    const L = eng ? LE : LF;
    project(cam, x, y, z, W, H, _ps);
    project(cam, x + nx * L, y + ny * L, z + nz * L, W, H, _pe);
    let dx = _pe[0] - _ps[0], dy = _pe[1] - _ps[1];
    const len = Math.hypot(dx, dy);
    if (!isFinite(len)) continue;
    if (len < MINPX) {
      if (len < 0.25) {
        // dead-on: no honest screen direction, so take the projected radius from
        // the disc centre — that is where "outward" points there
        project(cam, 0, 0, 0, W, H, _pc);
        dx = _ps[0] - _pc[0]; dy = _ps[1] - _pc[1];
        const rl = Math.hypot(dx, dy) || 1;
        dx = dx / rl * MINPX; dy = dy / rl * MINPX;
      } else { dx *= MINPX / len; dy *= MINPX / len; }
    }
    const o = i * 3;
    const c = (eng && wlc && wlc[o] >= 0) ? [wlc[o], wlc[o + 1], wlc[o + 2]] : [159, 176, 170];
    // brightest at the limb, where the stem is longest and reads most clearly
    const av = (eng ? 0.5 : 0.26) * (0.55 + 0.45 * (1 - Math.min(1, facing)));
    ctx.lineWidth = (eng ? 1 : 0.8) * UIK;
    const gr = ctx.createLinearGradient(_ps[0], _ps[1], _ps[0] + dx, _ps[1] + dy);
    gr.addColorStop(0, rgba(c, av));
    gr.addColorStop(0.6, rgba(c, av * 0.6));
    gr.addColorStop(1, rgba(c, av * 0.14));
    ctx.strokeStyle = gr;
    ctx.beginPath(); ctx.moveTo(_ps[0], _ps[1]); ctx.lineTo(_ps[0] + dx, _ps[1] + dy); ctx.stroke();
  }
}

// ---- YOU: a small 3D golf-flag on the world -------------------------------------
// A spatial OBJECT, not floating text: a thin radial pole out of the surface and
// a small pennant built in WORLD space, so both foreshorten and travel as the
// globe turns. The pole is the SAME FIXED WORLD LENGTH as a compute node's stem
// (SR*0.07), so YOU stands at the same height as the infrastructure around it and
// foreshortens by the same rule; the pennant and base are proportional to it. The
// pole follows the local surface normal; the pennant reaches along u×f, so its
// plane partially faces the camera and stays readable from any rotation.
// Structural teal, no glow, no pin, no waving.
const _yp = new Float32Array(4), _yq = new Float32Array(4), _yr = new Float32Array(4), _ys = new Float32Array(4);
export function drawYou(ctx, cam, W, H, u, SR, zz, alpha, ctxInfo) {
  if (alpha < 0.03) return;
  const f = camFwd(cam);
  const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
  if (facing < 0.08) return;
  const vis = Math.min(1, (facing - 0.08) / 0.3) * alpha;
  // TRUE PERSPECTIVE, NO CHEATING: the pole is radial to the sphere, like every
  // node stem, so it foreshortens honestly — head-on it collapses to a point and
  // the flag is read from the base disc (a full circle in that view) and the
  // enlarged node mark instead. An earlier version leaned the pole toward the
  // camera to keep it visible; it looked forced and is gone (owner 2026-09-11).
  // pennant tangent: u × f, unit — in the screen plane, so the flag reads
  let wx = u[1] * f[2] - u[2] * f[1], wy = u[2] * f[0] - u[0] * f[2], wz = u[0] * f[1] - u[1] * f[0];
  const wl = Math.hypot(wx, wy, wz) || 1;
  wx /= wl; wy /= wl; wz /= wl;
  project(cam, u[0] * SR, u[1] * SR, u[2] * SR, W, H, _yp);                       // base
  project(cam, u[0] * SR + wx, u[1] * SR + wy, u[2] * SR + wz, W, H, _yq);        // tangent probe
  const pxw = Math.max(0.5, Math.hypot(_yq[0] - _yp[0], _yq[1] - _yp[1]));
  const L = SR * 0.07;                            // pole: same height as a node stem
  const FL = L * 0.42;                            // pennant reach, proportional
  const footH = SR + L * 0.72, tipH = SR + L * 0.90;
  project(cam, u[0] * (SR + L), u[1] * (SR + L), u[2] * (SR + L), W, H, _yq);     // pole top
  project(cam, u[0] * footH, u[1] * footH, u[2] * footH, W, H, _yr);              // flag foot
  project(cam, u[0] * tipH + wx * FL, u[1] * tipH + wy * FL, u[2] * tipH + wz * FL, W, H, _ys); // flag tip
  // CIRCULAR BASE: a real disc lying in the local tangent plane, so it
  // foreshortens into an ellipse with the surface and the flag reads as planted
  // rather than pasted on. Its basis is orthogonalised against u, so the leaning
  // pole never tips the disc out of the tangent plane.
  const wdu = wx * u[0] + wy * u[1] + wz * u[2];
  let twx = wx - u[0] * wdu, twy = wy - u[1] * wdu, twz = wz - u[2] * wdu;
  const twl = Math.hypot(twx, twy, twz) || 1; twx /= twl; twy /= twl; twz /= twl;
  let vx = u[1] * twz - u[2] * twy, vy = u[2] * twx - u[0] * twz, vz = u[0] * twy - u[1] * twx;
  const vln = Math.hypot(vx, vy, vz) || 1; vx /= vln; vy /= vln; vz /= vln;
  const BR = L * 0.31;
  ctx.beginPath();
  for (let i = 0; i <= 22; i++) {
    const th = (i / 22) * 6.2832, cs = Math.cos(th) * BR, sn = Math.sin(th) * BR;
    project(cam, u[0] * SR + twx * cs + vx * sn, u[1] * SR + twy * cs + vy * sn, u[2] * SR + twz * cs + vz * sn, W, H, _yr);
    if (i === 0) ctx.moveTo(_yr[0], _yr[1]); else ctx.lineTo(_yr[0], _yr[1]);
  }
  ctx.closePath();
  ctx.fillStyle = rgbaT('stage', (0.72 * vis).toFixed(3));
  ctx.fill();
  ctx.strokeStyle = TEAL(Math.min(1, 0.55 * vis));
  ctx.lineWidth = 0.9 * UIK;
  ctx.stroke();
  project(cam, u[0] * footH, u[1] * footH, u[2] * footH, W, H, _yr);              // flag foot (restore)
  // base tick on the surface
  ctx.fillStyle = TEAL(Math.min(1, 0.5 * vis));
  ctx.beginPath(); ctx.arc(_yp[0], _yp[1], 1.1 * UIK, 0, 6.2832); ctx.fill();
  // pole
  ctx.strokeStyle = TEAL(Math.min(1, 0.9 * vis));
  ctx.lineWidth = 1 * UIK;
  ctx.beginPath(); ctx.moveTo(_yp[0], _yp[1]); ctx.lineTo(_yq[0], _yq[1]); ctx.stroke();
  // pennant: a filled world-space triangle — restrained, no halo
  ctx.beginPath();
  ctx.moveTo(_yq[0], _yq[1]); ctx.lineTo(_ys[0], _ys[1]); ctx.lineTo(_yr[0], _yr[1]);
  ctx.closePath();
  ctx.fillStyle = TEAL(Math.min(1, 0.82 * vis));
  ctx.fill();
  // the physical object is reserved FIRST: nothing may sit on the flag
  {
    const x0 = Math.min(_yp[0], _yq[0], _ys[0]) - 6;
    const x1 = Math.max(_yp[0], _yq[0], _ys[0]) + 6;
    const y0 = Math.min(_yp[1], _yq[1], _ys[1]) - 6;
    const y1 = Math.max(_yp[1], _yq[1], _ys[1]) + 6;
    keepOutRect(x0, y0, x1 - x0, y1 - y0);
  }
  // YOU LABEL — ONE LOCKED HORIZONTAL LOCKUP: "YOU · OHIO · US-EAST-2", set on a
  // single line so nothing about it can fragment or stack. The node count is not
  // part of the lockup (the capacity panel owns quantities); the control plane is
  // optional tertiary metadata on a quiet second line once there is room. In
  // SWARM, where the region prints its own spatial reference, the flag prints the
  // word YOU alone.
  const C = ctxInfo || {};
  const combined = !!C.combined && !!C.region;
  ctx.textAlign = 'left';
  ctx.font = fpxw(11, 600);
  const wYou = ctx.measureText('YOU').width;
  let wRgn = 0, wSub = 0, wCtrl = 0;
  const ctrl = (combined && C.ctrl && (zz || 0) > 0.25) ? C.ctrl : null;
  if (combined) {
    ctx.font = fpx(11);
    wRgn = ctx.measureText(' · ' + C.region).width;
    if (ctrl) { ctx.font = fpx(8.5); wCtrl = ctx.measureText(ctrl).width; }
  }
  const PX = 5 * FK, PY = 4 * FK;
  const bw = Math.max(wYou + wRgn, wSub, wCtrl) + PX * 2;
  const bh = combined
    ? PY * 2 + (12 + (ctrl ? 3 + 8 : 0)) * FK
    : 15 * FK;
  // ATTACHED TO THE FLAG, NOT FLOATING BESIDE IT: the lockup hangs off the POLE
  // TOP — the same grammar as the node stems and the workload stems, where the
  // outer end of the 3D line carries a point and the horizontal text sits
  // immediately beside it. So the lockup rises and foreshortens with the flag.
  const mx = _yq[0], my = _yq[1];
  // SAME SIDE RULE AS THE NODES: flag on the left half of the globe, lockup goes
  // LEFT of it; right half, right of it. Fixed clearance, and the YOU line
  // aligned to the flag's mid height so the two read as one unit.
  project(cam, 0, 0, 0, W, H, o4b);
  const gcxY = o4b[0];
  const GAPY = 8 * UIK;
  const sideY = (mx - gcxY) >= 0 ? 1 : -1;
  const idOffY = combined ? PY + 6 * FK : bh * 0.5;
  const tryBox = dy => {
    const x = sideY > 0 ? mx + GAPY : mx - GAPY - bw;
    const y = my - idOffY + dy;
    if (x < 6 || x + bw > W - 8 || y < 20 || y + bh > H - 8) return null;
    return free(x, y, bw, bh) ? [x, y] : null;
  };
  let slot = tryBox(0) || tryBox(bh + 5 * FK) || tryBox(-(bh + 5 * FK));
  if (!slot) {
    // YOU is the highest-priority label on the stage: it is never dropped —
    // it parks on its own side and is clamped into the panel.
    const x = Math.max(6, Math.min(W - 8 - bw, sideY > 0 ? mx + GAPY : mx - GAPY - bw));
    slot = [x, Math.max(20, Math.min(H - 8 - bh, my - idOffY))];
  }
  LBL.push([slot[0], slot[1], bw, bh]);
  // YOU OUTRANKS EVERY OTHER LABEL: its lockup is reserved as a keep-out band, not
  // just a label box, so node ids, region names and workload names can never be
  // drawn over the flag or its text.
  keepOutRect(slot[0] - 2 * UIK, slot[1] - 2 * UIK, bw + 4 * UIK, bh + 4 * UIK);
  if (slot) {
    const [lx, ly] = slot;
    clearBox(ctx, lx, ly, bw, bh, vis);
    const y1 = combined ? ly + PY + 6 * FK : ly + bh * 0.5;
    ctx.font = fpxw(11, 600);
    ctx.fillStyle = TEAL(Math.min(1, 0.96 * vis));   // inverted (owner 2026-09-01): YOU carries the accent
    ctx.fillText('YOU', lx + PX, y1);
    if (combined) {
      ctx.font = fpx(11);
      ctx.fillStyle = LIT(Math.min(1, 0.9 * vis));    // …and the location is neutral
      ctx.fillText(' · ' + C.region, lx + PX + wYou, y1);
      if (ctrl) {
        ctx.font = fpx(8.5);
        ctx.fillStyle = INK(0.4 * vis);
        ctx.fillText(ctrl, lx + PX, ly + PY + (12 + 3 + 6) * FK);
      }
    }
  }
}

// ---- FLAGGED NODE: YOU's flag, planted on one compute node ----------------------
// Owner 2026-09-11. The SAME object as drawYou (radial pole at node-stem height,
// world-space pennant, tangent-plane base disc) in the structural primary role, so
// the two read as one grammar; what differs is the lockup, which carries what the
// node card cannot: the workloads this node serves and their tok/s.
// SELECTED NODE — THE SAME RING RESOURCE AS YOU (owner 2026-09-11, replacing the
// pole-and-pennant flag): a real circle lying in the node's local tangent plane,
// at the same world radius as YOU's base disc, so it foreshortens into an ellipse
// with the surface and reads as drawn ON the world. No pole, so nothing has to be
// propped up when the node faces the camera dead-on — that is the view where a
// ring is at its LARGEST, a full circle. Its basis comes from u alone, never from
// the camera, so the ellipse cannot wobble as the world turns.
const _np = new Float32Array(4), _nq = new Float32Array(4), _nr = new Float32Array(4);
export function drawNodeRing(ctx, cam, W, H, u, SR, alpha, info) {
  if (alpha < 0.03 || !info) return;
  const f = camFwd(cam);
  const facing = -(u[0] * f[0] + u[1] * f[1] + u[2] * f[2]);
  if (facing < 0.08) return;
  const vis = Math.min(1, (facing - 0.08) / 0.3) * alpha;
  let e1 = [u[1], -u[0], 0];                       // u × ẑ — degenerate only at the poles
  let el = Math.hypot(e1[0], e1[1], e1[2]);
  if (el < 1e-3) { e1 = [1, 0, 0]; el = 1; }
  e1 = [e1[0] / el, e1[1] / el, e1[2] / el];
  const e2 = [u[1] * e1[2] - u[2] * e1[1], u[2] * e1[0] - u[0] * e1[2], u[0] * e1[1] - u[1] * e1[0]];
  const R = SR * 0.022;                            // = YOU's base disc radius
  let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  let exL = null, exR = null;
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const th = (i / 40) * 6.2832, cs = Math.cos(th) * R, sn = Math.sin(th) * R;
    project(cam,
      u[0] * SR + e1[0] * cs + e2[0] * sn,
      u[1] * SR + e1[1] * cs + e2[1] * sn,
      u[2] * SR + e1[2] * cs + e2[2] * sn, W, H, _nr);
    if (i === 0) ctx.moveTo(_nr[0], _nr[1]); else ctx.lineTo(_nr[0], _nr[1]);
    if (_nr[0] < minX) { minX = _nr[0]; exL = [_nr[0], _nr[1]]; }
    if (_nr[0] > maxX) { maxX = _nr[0]; exR = [_nr[0], _nr[1]]; }
    if (_nr[1] < minY) minY = _nr[1];
    if (_nr[1] > maxY) maxY = _nr[1];
  }
  ctx.closePath();
  ctx.fillStyle = rgbaT('stage', (0.5 * vis).toFixed(3));
  ctx.fill();
  ctx.strokeStyle = TEAL(Math.min(1, 0.7 * vis));  // primary role
  ctx.lineWidth = 1.1 * UIK;
  ctx.stroke();
  project(cam, u[0] * SR, u[1] * SR, u[2] * SR, W, H, _np);
  ctx.fillStyle = TEAL(Math.min(1, 0.5 * vis));
  ctx.beginPath(); ctx.arc(_np[0], _np[1], 1.1 * UIK, 0, 6.2832); ctx.fill();
  keepOutRect(minX - 4, minY - 4, (maxX - minX) + 8, (maxY - minY) + 8);
  // LOCKUP — node id and region on the YOU lines, then one row per workload this
  // node serves: name in the workload's own colour, tok/s right-aligned. Every
  // figure is handed in by the caller from the live traffic state; nothing about
  // quantity is computed here.
  const rows = info.rows || [];
  ctx.textAlign = 'left';
  ctx.font = fpxw(11, 600);
  const wId = ctx.measureText(info.id || '').width;
  ctx.font = fpx(11);
  const wRgn = info.region ? ctx.measureText(' · ' + info.region).width : 0;
  let wRow = 0;
  for (const r of rows) {
    ctx.font = fpx(9.5);
    const a2 = ctx.measureText(r.name).width;
    ctx.font = fpxw(9.5, 600);
    wRow = Math.max(wRow, a2 + 10 * FK + ctx.measureText(r.tok).width);
  }
  const PX = 5 * FK, PY = 4 * FK;
  const bw = Math.max(wId + wRgn, wRow) + PX * 2;
  const bh = PY * 2 + (12 + rows.length * 11) * FK;
  // HUNG OFF THE RING, not off the node: the lockup sits just outside the ring's
  // screen-space edge, on the side away from the globe centre — the same outward
  // rule the node ids follow.
  project(cam, 0, 0, 0, W, H, _nq);
  const side = (_np[0] - _nq[0]) >= 0 ? 1 : -1;
  const anchor = side > 0 ? (exR || [maxX, _np[1]]) : (exL || [minX, _np[1]]);
  const ax = anchor[0], ay = anchor[1];
  const GAP = 8 * UIK;
  const tryBox = ddy => {
    const x = side > 0 ? ax + GAP : ax - GAP - bw;
    const y = ay - bh * 0.5 + ddy;
    if (x < 6 || x + bw > W - 8 || y < 20 || y + bh > H - 8) return null;
    return free(x, y, bw, bh) ? [x, y] : null;
  };
  let slot = tryBox(0) || tryBox(bh + 5 * FK) || tryBox(-(bh + 5 * FK));
  if (!slot) {
    // a selected node the operator asked for is never dropped: it parks on its
    // own side, clamped into the stage
    const x = Math.max(6, Math.min(W - 8 - bw, side > 0 ? ax + GAP : ax - GAP - bw));
    slot = [x, Math.max(20, Math.min(H - 8 - bh, ay - bh * 0.5))];
  }
  LBL.push([slot[0], slot[1], bw, bh]);
  keepOutRect(slot[0] - 2 * UIK, slot[1] - 2 * UIK, bw + 4 * UIK, bh + 4 * UIK);
  const [lx, ly] = slot;
  clearBox(ctx, lx, ly, bw, bh, vis);
  const y1 = ly + PY + 6 * FK;
  ctx.font = fpxw(11, 600);
  ctx.fillStyle = TEAL(Math.min(1, 0.96 * vis));
  ctx.fillText(info.id || '', lx + PX, y1);
  if (info.region) {
    ctx.font = fpx(11);
    ctx.fillStyle = LIT(Math.min(1, 0.9 * vis));
    ctx.fillText(' · ' + info.region, lx + PX + wId, y1);
  }
  let ry = y1 + 12 * FK;
  for (const r of rows) {
    const c = r.rgb;
    ctx.font = fpx(9.5);
    ctx.fillStyle = c
      ? `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${Math.min(1, 0.95 * vis).toFixed(3)})`
      : LIT(Math.min(1, 0.8 * vis));
    ctx.fillText(r.name, lx + PX, ry);
    ctx.font = fpxw(9.5, 600);
    ctx.textAlign = 'right';
    ctx.fillStyle = LIT(Math.min(1, 0.85 * vis));
    ctx.fillText(r.tok, lx + bw - PX, ry);
    ctx.textAlign = 'left';
    ry += 11 * FK;
  }
}

// ---- REGIONAL REFERENCES (SWARM) -------------------------------------------------
// P2: text only, and placed by the SAME simple rule as every other label. The
// region name sits at ONE fixed offset from its own anchor, on the outward side
// of the globe centre, primary line on the anchor's horizontal axis. No candidate
// search, no hysteresis, no leader line, no marker: Swarm's regional reference is
// a quiet spatial context label, and only real compute nodes carry node marks.
export function drawSideRegionLabels(ctx, cam, W, H, regions, nodesByRegion, lensA, info, camKey) {
  // Region names are spatial CONTEXT, not entities. The caller fades them as the
  // scales descend — full at GLOBAL, much quieter at REGIONAL, gone at LOCAL —
  // because once node ids are readable the region name is the least useful text on
  // the stage and must not sit at the same weight as node identity.
  if (lensA < 0.04) return;
  const f = camFwd(cam);
  project(cam, 0, 0, 0, W, H, o4b);
  const gcx = o4b[0];
  ctx.textAlign = 'left';
  // stable order: the same regions resolve in the same sequence every frame
  const list = [...regions].sort((p, q) => (p.id < q.id ? -1 : 1));
  for (const r of list) {
    const ids = nodesByRegion[r.id] || [];
    if (!ids.length) continue;
    const facing = -(r.u[0] * f[0] + r.u[1] * f[1] + r.u[2] * f[2]);
    if (facing < 0.08) continue;
    const a = Math.min(1, (facing - 0.08) / 0.22) * lensA;
    project(cam, r.p[0], r.p[1], r.p[2], W, H, o4);
    const ax = o4[0], ay = o4[1];
    const nfo = info && info[r.id];
    const name = (nfo && nfo.name) || r.id.toUpperCase();
    const sub = ids.length + ' nodes';
    ctx.font = fpxw(13, 600);
    const w1 = ctx.measureText(name).width;
    ctx.font = fpx(9.5);
    const w2 = ctx.measureText(sub).width;
    const bw = Math.max(w1, w2) + 8 * FK;
    const bh = 26 * FK;
    const GAP = 16 * UIK;
    let lx = (ax - gcx) >= 0 ? ax + GAP : ax - GAP - bw;
    W_LAST = W;
    if (!clearOfBands(lx, ay - 8 * FK, bw, bh)) {
      const alt = lx === ax + GAP ? ax - GAP - bw : ax + GAP;
      if (clearOfBands(alt, ay - 8 * FK, bw, bh)) lx = alt;
    }
    if (lx < 6) lx = ax + GAP;
    else if (lx + bw > W - 8) lx = ax - GAP - bw;
    const ly = ay - 8 * FK;
    if (ly < 20 || ly + bh > H - 8) continue;
    const clean = !hitsLabel(lx, ly, bw, bh);
    LBL.push([lx, ly, bw, bh]);
    if (clean) clearBox(ctx, lx, ly, bw, bh, a);
    ctx.textBaseline = 'middle';
    ctx.font = fpxw(13, 600);
    ctx.fillStyle = LIT(Math.min(1, 0.9 * a));
    ctx.fillText(name, lx + 4 * FK, ay);
    ctx.font = fpx(9.5);
    ctx.fillStyle = INK(0.5 * a);
    ctx.fillText(sub, lx + 4 * FK, ay + 14 * FK);
    ctx.textBaseline = 'alphabetic';
  }
}

