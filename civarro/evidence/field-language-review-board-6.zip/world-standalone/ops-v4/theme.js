// THEME — the canvas half of the role layer, generated from material-theme.json
// (Material Theme Builder export, seed #007D76). Same role names as the
// CSS custom properties in the page, so a colour has ONE definition per mode.
export const THEMES = {
  dark: {
    selected:   [50,75,73],
    stage:      [14,21,20],
    backing:    [22,29,28],
    outline:    [137,147,145],
    lit:        [221,228,226],
    ink:        [190,201,198],
    dim:        [63,73,71],
    tick:       [137,147,145],
    teal:       [129,213,205],
    critical:   [255,180,171],
    primary:    [129,213,205],
    health:     [176,204,200],
    warn:       [175,201,231],
    primaryInk: '#81D5CD',
    text1:      '#DDE4E2',
    text2:      '#BEC9C6',
    text3:      '#899391',
    textHi:     '#DDE4E2',
    border:     '#3F4947',
    ink2:       '#BEC9C6',
    ink3:       '#DDE4E2',
    telemetry:  '#5C8A85',   // primary 62% over surface — teal telemetry (owner)   // pure-gray data-viz neutral, low contrast (owner)
    telemetryHi:'#DDE4E2',
    barOn:      '#81D5CD',
    barOff:     '#3F4947',
    // the export defines no categorical data colours (extendedColors is empty), so
    // workload identity remains the one table authored outside Material.
    // OWNER 2026-09-01 v2: MAX-VARIATION categorical palette — blue 245, magenta 335,
    // lime 130, orange 50, yellow 95: hues far from teal structure, green-152 live,
    // amber-85 warn and red-25 error, and markedly different from each other
    workloads: {
      eric: [77,172,246], vision: [221,113,200], confRemote: [147,204,75],
      confCarlos: [245,139,75], workload: [229,201,94]
    }
  },
  light: {
    selected:   [204,232,228],
    stage:      [244,251,249],
    backing:    [232,240,238],
    outline:    [111,121,119],
    lit:        [22,29,28],
    ink:        [63,73,71],
    dim:        [141,158,154],   // geography on a LIGHT ground must darken, not lighten
    tick:       [96,107,105],
    teal:       [0,106,100],
    critical:   [186,26,26],
    primary:    [0,106,100],
    health:     [74,99,96],
    warn:       [72,97,122],
    primaryInk: '#006A64',
    text1:      '#161D1C',
    text2:      '#3F4947',
    text3:      '#6F7977',
    textHi:     '#161D1C',
    border:     '#BEC9C6',
    ink2:       '#3F4947',
    ink3:       '#161D1C',
    telemetry:  '#6FA49E',   // primary 55% over surface — teal telemetry (owner)   // pure-gray data-viz neutral, low contrast (owner)
    telemetryHi:'#161D1C',
    barOn:      '#006A64',
    barOff:     '#BEC9C6',
    // the export defines no categorical data colours (extendedColors is empty), so
    // workload identity remains the one table authored outside Material.
    // OWNER 2026-09-01 v2: MAX-VARIATION categorical palette — blue 245, magenta 335,
    // lime 130, orange 50, yellow 95: hues far from teal structure, green-152 live,
    // amber-85 warn and red-25 error, and markedly different from each other
    workloads: {
      eric: [0,104,178], vision: [150,37,133], confRemote: [81,130,0],
      confCarlos: [176,77,0], workload: [153,126,0]
    }
  }
};
let current = 'dark';    // standalone: the dark stage
export const T = { ...THEMES.dark };
export function setTheme(name) {
  if (!THEMES[name] || name === current) return false;
  current = name;
  Object.assign(T, THEMES[name]);
  return true;
}
export function themeName() { return current; }
// helpers every renderer uses instead of writing a literal
export const rgbaT = (role, a) => {
  const c = T[role];
  return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
};
