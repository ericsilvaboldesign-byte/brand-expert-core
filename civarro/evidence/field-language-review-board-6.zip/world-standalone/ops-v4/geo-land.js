// GEO — shared geography for two DIFFERENT views.
//
// Coarse hand-authored coastline polygons (lon/lat), used twice:
//   * the flat Operations Map strokes the rings directly (map-view.js)
//   * the Swarm world samples them into a faint point stipple, present only as
//     spatial anchoring behind the capacity field (never as cartography)
//
// v2 note: the stipple is deliberately sparse and low-contrast. Geography is
// subordinate in Swarm; the capacity field is the subject.
//
// IMPORTANT: land points go through the SAME eased projection as the region
// anchors (easeLon/easeLat below), so geography and markers can never
// disagree. The easing widens the mid-Atlantic view slightly and relaxes the
// poles; it is monotonic and continuous at the antimeridian.

const RAD = Math.PI / 180;
export const LON0 = -41;           // mid-Atlantic view centre
const LATK = 0.72;

export function easeLonDelta(dl) {
  // dl in degrees, relative to LON0, in (-180, 180]
  return dl + 0.2 * dl * (1 - Math.abs(dl) / 180);   // x1.2 near centre, x1 at back
}
export function toSphere(latDeg, lonDeg, R) {
  let dl = lonDeg - LON0;
  while (dl > 180) dl -= 360;
  while (dl <= -180) dl += 360;
  const L = easeLonDelta(dl) * RAD;
  const ph = latDeg * LATK * RAD;
  return [Math.cos(ph) * Math.sin(L) * R, Math.sin(ph) * R, -Math.cos(ph) * Math.cos(L) * R];
}

// (lon, lat) vertex rings — REAL geography (Natural Earth 110m via
// geo-real.js); the hand-authored approximation is retired.
export { POLYS } from './geo-real.js';
import { POLYS, BBOX } from './geo-real.js';

function inPoly(lon, lat, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
    if ((yi > lat) !== (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
export function isLand(lon, lat) {
  for (let k = 0; k < POLYS.length; k++) {
    const b = BBOX[k];
    if (lon < b[0] || lon > b[2] || lat < b[1] || lat > b[3]) continue;
    if (inPoly(lon, lat, POLYS[k])) return true;
  }
  return false;
}

// INVERSE of the eased mapping: an eased-sphere unit vector back to true
// lat/lon. Needed by the zoom LOD, which has to know WHICH piece of real
// geography the camera is looking at before it can sample more points there.
// easeLonDelta is monotonic, so the longitude term inverts by bisection.
export function fromSphereUnit(u) {
  const ph = Math.asin(Math.max(-1, Math.min(1, u[1])));
  const lat = ph / (LATK * RAD);
  const easedDl = Math.atan2(u[0], -u[2]) / RAD;         // degrees, eased
  let lo = -180, hi = 180;
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (easeLonDelta(mid) < easedDl) lo = mid; else hi = mid;
  }
  let lon = LON0 + (lo + hi) / 2;
  while (lon > 180) lon -= 360;
  while (lon <= -180) lon += 360;
  return [lat, lon];
}

// ZOOM LOD: the same stipple rule, sampled only inside a spherical cap around
// the point the camera is looking at, so a close view can carry MANY MORE POINTS
// without paying for them over the whole globe. Sampling is uniform-in-area
// inside the cap and low-discrepancy in azimuth — same texture, more of it.
export function buildLandStippleCap(R, n, seed, latC, lonC, capDeg) {
  const pts = [];
  const GOLD = 2.399963229728653;
  let s = (seed >>> 0) || 1;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  // cap centre and an orthonormal frame around it, in TRUE geographic space
  const la = latC * RAD, lo = lonC * RAD;
  const c = [Math.cos(la) * Math.cos(lo), Math.sin(la), Math.cos(la) * Math.sin(lo)];
  let e1 = [-Math.sin(lo), 0, Math.cos(lo)];
  const e2 = [
    c[1] * e1[2] - c[2] * e1[1],
    c[2] * e1[0] - c[0] * e1[2],
    c[0] * e1[1] - c[1] * e1[0]
  ];
  const cosCap = Math.cos(capDeg * RAD);
  for (let k = 0; k < n; k++) {
    const ct = 1 - (1 - cosCap) * (k + 0.5) / n;         // uniform in cap area
    const st = Math.sqrt(Math.max(0, 1 - ct * ct));
    const ph2 = GOLD * k;
    const cf = Math.cos(ph2) * st, sf = Math.sin(ph2) * st;
    const dx = c[0] * ct + e1[0] * cf + e2[0] * sf;
    const dy = c[1] * ct + e1[1] * cf + e2[1] * sf;
    const dz = c[2] * ct + e1[2] * cf + e2[2] * sf;
    const lat = Math.asin(Math.max(-1, Math.min(1, dy))) / RAD;
    let lon = Math.atan2(dz, dx) / RAD;
    if (lon > 180) lon -= 360;
    if (!isLand(lon, lat)) continue;
    const p = toSphere(lat, lon, R);
    pts.push({ p, u: [p[0] / R, p[1] / R, p[2] / R], j: rnd() });
  }
  return pts;
}

// stipple: fibonacci sphere in TRUE lat/lon space, kept where land, projected
// through the eased mapping — density is uniform on the real globe
export function buildLandStipple(R, n = 9200, seed = 77) {
  const pts = [];
  const GOLD = 2.399963229728653;
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  for (let k = 0; k < n; k++) {
    const z = 1 - 2 * (k + 0.5) / n;
    const lat = Math.asin(z) / RAD;
    let lon = ((GOLD * k) / RAD) % 360;
    if (lon > 180) lon -= 360;
    if (!isLand(lon, lat)) continue;
    const p = toSphere(lat, lon, R);
    pts.push({ p, u: [p[0] / R, p[1] / R, p[2] / R], j: rnd() });   // j: per-point shimmer phase
  }
  return pts;
}
